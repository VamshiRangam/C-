//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%650AE95B0129.cm preserve=no
//## end module%650AE95B0129.cm

//## begin module%650AE95B0129.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%650AE95B0129.cp

//## Module: CXOSJX06%650AE95B0129; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX06.hpp

#ifndef CXOSJX06_h
#define CXOSJX06_h 1

//## begin module%650AE95B0129.additionalIncludes preserve=no
//## end module%650AE95B0129.additionalIncludes

//## begin module%650AE95B0129.includes preserve=yes
//## end module%650AE95B0129.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class SingleCaseCommand;
} // namespace soapcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class TextSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLDocument;
class ImportData;

} // namespace command

//## begin module%650AE95B0129.declarations preserve=no
//## end module%650AE95B0129.declarations

//## begin module%650AE95B0129.additionalDeclarations preserve=yes
//## end module%650AE95B0129.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CaseManifest%650AE9310043.preface preserve=yes
//## end restcommand::CaseManifest%650AE9310043.preface

//## Class: CaseManifest%650AE9310043
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%650AF7780119;reusable::Buffer { -> F}
//## Uses: <unnamed>%650C874703CF;IF::Message { -> F}
//## Uses: <unnamed>%650C874B01B0;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%650C874F0069;segment::TextSegment { -> F}
//## Uses: <unnamed>%659E7E6A0199;IF::Trace { -> F}
//## Uses: <unnamed>%659E7EA40249;reusable::Statement { -> F}
//## Uses: <unnamed>%659E7EC101A6;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%659E7F100331;command::ImportData { -> F}
//## Uses: <unnamed>%659E7F590220;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%659E811F032E;timer::Clock { -> F}

class DllExport CaseManifest : public reusable::Observer  //## Inherits: <unnamed>%650B03430099
{
  //## begin restcommand::CaseManifest%650AE9310043.initialDeclarations preserve=yes
  //## end restcommand::CaseManifest%650AE9310043.initialDeclarations

  public:
    //## Constructors (generated)
      CaseManifest();

    //## Constructors (specified)
      //## Operation: CaseManifest%6564B495008E
      CaseManifest (const char* pszMVSTemplate, const char* pszTemplate);

    //## Destructor (generated)
      virtual ~CaseManifest();


    //## Other Operations (specified)
      //## Operation: add%650C96B101C6
      void add (const string& strTag, const string& strValue);

      //## Operation: addAttribute%650C8C0B0268
      void addAttribute (vector<string>& hToken);

      //## Operation: addName%650AF3FD00FC
      void addName (const string& strValue);

      //## Operation: addTag%650AF41C03C8
      void addTag (const string& strValue);

      //## Operation: execute%650B049F01B7
      bool execute ();

      //## Operation: update%650B034A0139
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: save%659E800D03BB
      bool save ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Text%650B037C024E
      const string& getText () const
      {
        //## begin restcommand::CaseManifest::getText%650B037C024E.get preserve=no
        return m_strText;
        //## end restcommand::CaseManifest::getText%650B037C024E.get
      }


      //## Attribute: DI_FILE_ID%659E802C02B5
      const int& getDI_FILE_ID () const
      {
        //## begin restcommand::CaseManifest::getDI_FILE_ID%659E802C02B5.get preserve=no
        return m_iDI_FILE_ID;
        //## end restcommand::CaseManifest::getDI_FILE_ID%659E802C02B5.get
      }


    // Additional Public Declarations
      //## begin restcommand::CaseManifest%650AE9310043.public preserve=yes
      //## end restcommand::CaseManifest%650AE9310043.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CaseManifest%650AE9310043.protected preserve=yes
      //## end restcommand::CaseManifest%650AE9310043.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CaseManifest%650AE9310043.private preserve=yes
      //## end restcommand::CaseManifest%650AE9310043.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Tag%650AFD040346
      //## begin restcommand::CaseManifest::Tag%650AFD040346.attr preserve=no  private: string {V} 
      string m_strTag;
      //## end restcommand::CaseManifest::Tag%650AFD040346.attr

      //## begin restcommand::CaseManifest::Text%650B037C024E.attr preserve=no  public: string {V} 
      string m_strText;
      //## end restcommand::CaseManifest::Text%650B037C024E.attr

      //## begin restcommand::CaseManifest::DI_FILE_ID%659E802C02B5.attr preserve=no  public: int {V} 0
      int m_iDI_FILE_ID;
      //## end restcommand::CaseManifest::DI_FILE_ID%659E802C02B5.attr

      //## Attribute: TRANSACTION_NO%659E80B20277
      //## begin restcommand::CaseManifest::TRANSACTION_NO%659E80B20277.attr preserve=no  public: int {V} 0
      int m_iTRANSACTION_NO;
      //## end restcommand::CaseManifest::TRANSACTION_NO%659E80B20277.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650AF7A00332
      //## Role: CaseManifest::<m_hGenericSegment>%650AF7A102B2
      //## begin restcommand::CaseManifest::<m_hGenericSegment>%650AF7A102B2.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::CaseManifest::<m_hGenericSegment>%650AF7A102B2.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650AF8E300C7
      //## Role: CaseManifest::<m_pXMLDocument>%650AF8E4004A
      //## begin restcommand::CaseManifest::<m_pXMLDocument>%650AF8E4004A.role preserve=no  public: command::XMLDocument { -> RFHgN}
      command::XMLDocument *m_pXMLDocument;
      //## end restcommand::CaseManifest::<m_pXMLDocument>%650AF8E4004A.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650AF9000033
      //## Role: CaseManifest::<m_hXMLText>%650AF90003BC
      //## begin restcommand::CaseManifest::<m_hXMLText>%650AF90003BC.role preserve=no  public: command::XMLText { -> VHgN}
      command::XMLText m_hXMLText;
      //## end restcommand::CaseManifest::<m_hXMLText>%650AF90003BC.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650AF93302B5
      //## Role: CaseManifest::<m_hRow>%650AF93402D3
      //## begin restcommand::CaseManifest::<m_hRow>%650AF93402D3.role preserve=no  public: reusable::Row { -> VHgN}
      reusable::Row m_hRow;
      //## end restcommand::CaseManifest::<m_hRow>%650AF93402D3.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650C862101B2
      //## Role: CaseManifest::<m_pSingleCaseCommand>%650C862201C6
      //## begin restcommand::CaseManifest::<m_pSingleCaseCommand>%650C862201C6.role preserve=no  public: soapcommand::SingleCaseCommand { -> RFHgN}
      soapcommand::SingleCaseCommand *m_pSingleCaseCommand;
      //## end restcommand::CaseManifest::<m_pSingleCaseCommand>%650C862201C6.role

    // Additional Implementation Declarations
      //## begin restcommand::CaseManifest%650AE9310043.implementation preserve=yes
      //## end restcommand::CaseManifest%650AE9310043.implementation

};

//## begin restcommand::CaseManifest%650AE9310043.postscript preserve=yes
//## end restcommand::CaseManifest%650AE9310043.postscript

} // namespace restcommand

//## begin module%650AE95B0129.epilog preserve=yes
//## end module%650AE95B0129.epilog


#endif
