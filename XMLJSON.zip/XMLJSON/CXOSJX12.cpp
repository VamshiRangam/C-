//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%652703F30282.cm preserve=no
//## end module%652703F30282.cm

//## begin module%652703F30282.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%652703F30282.cp

//## Module: CXOSJX12%652703F30282; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX12.cpp

//## begin module%652703F30282.additionalIncludes preserve=no
//## end module%652703F30282.additionalIncludes

//## begin module%652703F30282.includes preserve=yes
#include "CXODBS06.hpp"
#include "CXODRU12.hpp"
#include "CXODDB02.hpp"
#include "CXODDB52.hpp"
#include "CXODBC26.hpp"
#include "CXODPS01.hpp"
#include "CXODIF16.hpp"
//## end module%652703F30282.includes

#ifndef CXOSSX19_h
#include "CXODSX19.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSJX12_h
#include "CXODJX12.hpp"
#endif


//## begin module%652703F30282.declarations preserve=no
//## end module%652703F30282.declarations

//## begin module%652703F30282.additionalDeclarations preserve=yes
//## end module%652703F30282.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::AuthenticateCommand 

AuthenticateCommand::AuthenticateCommand()
  //## begin AuthenticateCommand::AuthenticateCommand%6526F148004C_const.hasinit preserve=no
  //## end AuthenticateCommand::AuthenticateCommand%6526F148004C_const.hasinit
  //## begin AuthenticateCommand::AuthenticateCommand%6526F148004C_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/authenticate/v1.0.0","S0003D","@##JAUSER ")
  //## end AuthenticateCommand::AuthenticateCommand%6526F148004C_const.initialization
{
  //## begin restcommand::AuthenticateCommand::AuthenticateCommand%6526F148004C_const.body preserve=yes
   memcpy(m_sID,"JX12",4);
  //## end restcommand::AuthenticateCommand::AuthenticateCommand%6526F148004C_const.body
}

AuthenticateCommand::AuthenticateCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.hasinit preserve=no
  //## end restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.hasinit
  //## begin restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/authenticate/v1.0.0","S0003D","@##JAUSER ")
  //## end restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.initialization
{
  //## begin restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.body preserve=yes
   memcpy(m_sID,"JX12",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('C',&m_hGenericSegment);
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::AuthenticateCommand::AuthenticateCommand%6526F1EC006C.body
}


AuthenticateCommand::~AuthenticateCommand()
{
  //## begin restcommand::AuthenticateCommand::~AuthenticateCommand%6526F148004C_dest.body preserve=yes
  //## end restcommand::AuthenticateCommand::~AuthenticateCommand%6526F148004C_dest.body
}



//## Other Operations (implementation)
bool AuthenticateCommand::execute ()
{
  //## begin restcommand::AuthenticateCommand::execute%6526F1D100E7.body preserve=yes
   UseCase hUseCase("CLIENT","## JX12 AUTHENTICATE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJAUSER",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX12",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   if (getUSER_ID().empty())
   {
      setUSER_ID(m_pXMLItem->get("userId"));
      segment::CommonHeaderSegment::instance()->setUserID(getUSER_ID());
      segment::SOAPSegment::instance()->setUSER_ID(getUSER_ID());
      string strSSO(m_pXMLItem->get("sso"));
      if (!strSSO.empty())
      {
         string strContextData;
         auto_ptr<CommonContext> pCommonContext(new CommonContext(Application::instance()->image(),"CRQ"));
         if (pCommonContext->get("HASHKEY",strContextData))
         {
            Security::instance()->setKey(strContextData);
            Security::instance()->decrypt(strSSO);
            if (strSSO != getUSER_ID())
               iRC = 4;
         }
         else
            iRC = 4;
      }
      else
         iRC = 4;
   }
   if (SOAPSegment::instance()->getUSER_PASSWORD().empty())
      iRC = 4;
   char* pMessage[] = {
      "Success",
      "1",
      "2",
      "Invalid request",
      "Authentication unsuccessful"
   };
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (iRC == 0)
   {
      m_hQuery.reset();
      m_hQuery.detach(this);
      m_hQuery.setDistinct(true);
      m_hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
      m_hQuery.bind("AS_USER_PROFILE","CUST_ID",Column::STRING,&m_strCUST_ID);
      m_hQuery.setBasicPredicate("AS_USER_PROFILE","USER_ID","=",getUSER_ID().c_str());
      m_hQuery.setOrderByClause("CUST_ID");
      pSelectStatement->execute(m_hQuery);
      if (pSelectStatement->getRows() == 0)
         iRC = 4;
   }
   if (iRC <= 4)
   {
      SOAPSegment::instance()->setTxt(pMessage[iRC]);
      SOAPSegment::instance()->setRtnCde('0' + iRC);
   }
   if (iRC == 0)
   {
      m_pXMLDocument->add("Connection");
      m_hQuery.attach(this);
      pSelectStatement->execute(m_hQuery);
      setRows(pSelectStatement->getRows());
      setTotalRows(pSelectStatement->getRows());
   }
   CommonHeaderSegment::instance()->setResultCode(iRC);
   if (iRC > 0)
      UseCase::addItem();
   return reply();
  //## end restcommand::AuthenticateCommand::execute%6526F1D100E7.body
}

// Additional Declarations
  //## begin restcommand::AuthenticateCommand%6526F148004C.declarations preserve=yes
void AuthenticateCommand::update (Subject* pSubject)
{
   if (pSubject == &m_hQuery)
   {
      string strPTCPADD;
      string strPTCPPORT;
      Extract::instance()->getSpec(m_strCUST_ID.c_str(),strPTCPADD);
      size_t npos = strPTCPADD.find(',');
      if (npos == string::npos)
         npos = strPTCPADD.find(' ');
      if (npos != string::npos)
      {
         strPTCPPORT = strPTCPADD.substr(npos + 1);
         strPTCPADD.erase(npos);
      }
      m_hGenericSegment.set("CUST_ID",m_strCUST_ID);
      m_hGenericSegment.set("PTCPADD",strPTCPADD);
      m_hGenericSegment.set("PTCPPORT",strPTCPPORT);
      m_pXMLDocument->add("row");
   }
   RESTCommand::update(pSubject);
}
  //## end restcommand::AuthenticateCommand%6526F148004C.declarations

} // namespace restcommand

//## begin module%652703F30282.epilog preserve=yes
//## end module%652703F30282.epilog
