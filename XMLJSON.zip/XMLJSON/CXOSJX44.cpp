//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67BEEF610034.cm preserve=no
//## end module%67BEEF610034.cm

//## begin module%67BEEF610034.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67BEEF610034.cp

//## Module: CXOSJX39%67BEEF610034; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX39.cpp

//## begin module%67BEEF610034.additionalIncludes preserve=no
//## end module%67BEEF610034.additionalIncludes

//## begin module%67BEEF610034.includes preserve=yes
//## end module%67BEEF610034.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSJX44_h
#include "CXODJX44.hpp"
#endif


//## begin module%67BEEF610034.declarations preserve=no
//## end module%67BEEF610034.declarations

//## begin module%67BEEF610034.additionalDeclarations preserve=yes
//## end module%67BEEF610034.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ContactsCommand 

 RelatedCasesCommand::RelatedCasesCommand()
  //## begin ContactsCommand::ContactsCommand%67BEF0690257_const.hasinit preserve=no
  //## end ContactsCommand::ContactsCommand%67BEF0690257_const.hasinit
  //## begin ContactsCommand::ContactsCommand%67BEF0690257_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/relatedcases/v1.0.0", "S0003D", "@##JRLCSE ")
  //## end ContactsCommand::ContactsCommand%67BEF0690257_const.initialization
{
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF0690257_const.body preserve=yes
   memcpy(m_sID, "JX44", 4);
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF0690257_const.body
}

 RelatedCasesCommand::RelatedCasesCommand (Handler* pSuccessor)
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.hasinit preserve=no
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.hasinit
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/relatedcases/v1.0.0", "S0003D", "@##JRLCSE ")
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.initialization
{
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.body preserve=yes
   memcpy(m_sID, "JX44", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.body
}


 RelatedCasesCommand::~RelatedCasesCommand()
{
  //## begin restcommand::ContactsCommand::~ContactsCommand%67BEF0690257_dest.body preserve=yes
  //## end restcommand::ContactsCommand::~ContactsCommand%67BEF0690257_dest.body
}



//## Other Operations (implementation)
bool RelatedCasesCommand::execute ()
{
  //## begin restcommand::ContactsCommand::execute%67BEF260020A.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX44 READ RELATED CASES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRLCSE", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX44", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   
  //## end restcommand::ContactsCommand::execute%67BEF260020A.body
}

void RelatedCasesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ContactsCommand::update%67BEF287027D.body preserve=yes
  //## end restcommand::ContactsCommand::update%67BEF287027D.body
}

// Additional Declarations
  //## begin restcommand::ContactsCommand%67BEF0690257.declarations preserve=yes
  //## end restcommand::ContactsCommand%67BEF0690257.declarations

} // namespace restcommand

//## begin module%67BEEF610034.epilog preserve=yes
//## end module%67BEEF610034.epilog
