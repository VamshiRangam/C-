//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66F2BB810053.cm preserve=no
//## end module%66F2BB810053.cm

//## begin module%66F2BB810053.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66F2BB810053.cp

//## Module: CXOSJX26%66F2BB810053; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX26.hpp

#ifndef CXOSJX26_h
#define CXOSJX26_h 1

//## begin module%66F2BB810053.additionalIncludes preserve=no
//## end module%66F2BB810053.additionalIncludes

//## begin module%66F2BB810053.includes preserve=yes
//## end module%66F2BB810053.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseSegment;
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
} // namespace segment

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class ActionDetail;

} // namespace rules

//## begin module%66F2BB810053.declarations preserve=no
//## end module%66F2BB810053.declarations

//## begin module%66F2BB810053.additionalDeclarations preserve=yes
//## end module%66F2BB810053.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ActionsCommand%66F2BCA40279.preface preserve=yes
//## end restcommand::ActionsCommand%66F2BCA40279.preface

//## Class: ActionsCommand%66F2BCA40279
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66F2BF270299;monitor::UseCase { -> F}
//## Uses: <unnamed>%66F2BF2B0211;reusable::Query { -> F}
//## Uses: <unnamed>%66F2BF2F0207;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%66F2BF3300B6;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66F2BF3F008D;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%66F2BF430295;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%66F2BF4D00B2;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%66F2BF51006D;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%66F2BF56036E;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%66F2C27203C4;rules::ActionDetail { -> F}

class DllExport ActionsCommand : public command::RESTCommand  //## Inherits: <unnamed>%66F2BF2200B5
{
  //## begin restcommand::ActionsCommand%66F2BCA40279.initialDeclarations preserve=yes
  //## end restcommand::ActionsCommand%66F2BCA40279.initialDeclarations

  public:
    //## Constructors (generated)
      ActionsCommand();

    //## Constructors (specified)
      //## Operation: ActionsCommand%66F2C0A90269
      ActionsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ActionsCommand();


    //## Other Operations (specified)
      //## Operation: execute%66F2C102000C
      virtual bool execute ();

      //## Operation: update%66F2C12E021C
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ActionsCommand%66F2BCA40279.public preserve=yes
      //## end restcommand::ActionsCommand%66F2BCA40279.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ActionsCommand%66F2BCA40279.protected preserve=yes
      //## end restcommand::ActionsCommand%66F2BCA40279.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ActionsCommand%66F2BCA40279.private preserve=yes
      //## end restcommand::ActionsCommand%66F2BCA40279.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%66F2C1C3015B
      //## begin restcommand::ActionsCommand::Buffer%66F2C1C3015B.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end restcommand::ActionsCommand::Buffer%66F2C1C3015B.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66F2C2FC01F2
      //## Role: ActionsCommand::<m_hGenericSegment>%66F2C2FE012C
      //## begin restcommand::ActionsCommand::<m_hGenericSegment>%66F2C2FE012C.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ActionsCommand::<m_hGenericSegment>%66F2C2FE012C.role

    // Additional Implementation Declarations
      //## begin restcommand::ActionsCommand%66F2BCA40279.implementation preserve=yes
      //## end restcommand::ActionsCommand%66F2BCA40279.implementation

};

//## begin restcommand::ActionsCommand%66F2BCA40279.postscript preserve=yes
//## end restcommand::ActionsCommand%66F2BCA40279.postscript

} // namespace restcommand

//## begin module%66F2BB810053.epilog preserve=yes
//## end module%66F2BB810053.epilog


#endif
