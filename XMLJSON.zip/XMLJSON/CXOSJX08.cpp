//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%651ABA310351.cm preserve=no
//## end module%651ABA310351.cm

//## begin module%651ABA310351.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%651ABA310351.cp

//## Module: CXOSJX08%651ABA310351; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX08.cpp

//## begin module%651ABA310351.additionalIncludes preserve=no
//## end module%651ABA310351.additionalIncludes

//## begin module%651ABA310351.includes preserve=yes
//## end module%651ABA310351.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSEX33_h
#include "CXODEX33.hpp"
#endif
#ifndef CXOSJX08_h
#include "CXODJX08.hpp"
#endif


//## begin module%651ABA310351.declarations preserve=no
//## end module%651ABA310351.declarations

//## begin module%651ABA310351.additionalDeclarations preserve=yes
//## end module%651ABA310351.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReasonCodesCommand 

ReasonCodesCommand::ReasonCodesCommand()
  //## begin ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.hasinit preserve=no
      : m_pszBuffer(0)
  //## end ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.hasinit
  //## begin ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/reasoncodes/v1.0.0","S0003D","@##JLAVRC ")
  //## end ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.initialization
{
  //## begin restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.body preserve=yes
   memcpy(m_sID, "JX08", 4);
  //## end restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB8E100D2_const.body
}

ReasonCodesCommand::ReasonCodesCommand (Handler* pSuccessor)
  //## begin restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.hasinit preserve=no
      : m_pszBuffer(0)
  //## end restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.hasinit
  //## begin restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/reasoncodes/v1.0.0","S0003D","@##JLAVRC ")
  //## end restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.initialization
{
  //## begin restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.body preserve=yes
   memcpy(m_sID, "JX08", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_pszBuffer = new char[sizeof(segReasonCode) + 1];
  //## end restcommand::ReasonCodesCommand::ReasonCodesCommand%651AB9A00209.body
}


ReasonCodesCommand::~ReasonCodesCommand()
{
  //## begin restcommand::ReasonCodesCommand::~ReasonCodesCommand%651AB8E100D2_dest.body preserve=yes
   delete[] m_pszBuffer;
  //## end restcommand::ReasonCodesCommand::~ReasonCodesCommand%651AB8E100D2_dest.body
}



//## Other Operations (implementation)
bool ReasonCodesCommand::execute ()
{
  //## begin restcommand::ReasonCodesCommand::execute%651AB9C00165.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX08 LIST AVAILABLE RC");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLAVTR", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX08", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   CaseSegment::instance()->setPresence(true);
   CaseTransitionSegment::instance()->setPresence(true);
   CasePhaseSegment::instance()->setPresence(true);
   Query hQuery;
   hQuery.join("EMS_CASE", "INNER", "EMS_TRANSITION", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "PHASE_TSTAMP", "TSTAMP_CREATED");
   CaseSegment::instance()->bind(hQuery);
   CasePhaseSegment::instance()->bind(hQuery);
   CaseTransitionSegment::instance()->bind(hQuery);
   hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_pXMLItem->get("requestType"));
      CaseTransitionSegment::instance()->setSTATUS_NEXT(m_pXMLItem->get("status"));
      CasePhaseSegment::instance()->setUSER_ROLE(m_pXMLItem->get("role"));
      bool b = ems::EMSRulesEngine::instance()->exportAvailableReasonCodes(this, m_pszBuffer);
      SOAPSegment::instance()->setRtnCde(b ? '0' : '2');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReasonCodesCommand::execute%651AB9C00165.body
}

void ReasonCodesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReasonCodesCommand::update%651AB9C402D4.body preserve=yes
   if (pSubject == 0)
   {
      ++m_iRows;
      ++m_iTotalRows;
      segReasonCode* p = (segReasonCode*)m_pszBuffer;
      string strValue(p->sRESN_CODE_ID, sizeof(p->sRESN_CODE_ID));
      m_hGenericSegment.set("Code", strValue);
      m_hGenericSegment.set("Description", p->sDESCRIPTION_TEXT);
      strValue.assign(p->sActionsAvailable, sizeof(p->sActionsAvailable));
      m_hGenericSegment.set("Actions", strValue);
      strValue.assign(p->sMMTAvailable, sizeof(p->sMMTAvailable));
      m_hGenericSegment.set("MMT", strValue);
      m_pXMLDocument->add("row");
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ReasonCodesCommand::update%651AB9C402D4.body
}

// Additional Declarations
  //## begin restcommand::ReasonCodesCommand%651AB8E100D2.declarations preserve=yes
  //## end restcommand::ReasonCodesCommand%651AB8E100D2.declarations

} // namespace restcommand

//## begin module%651ABA310351.epilog preserve=yes
//## end module%651ABA310351.epilog
