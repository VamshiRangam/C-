//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%677CB59B0194.cm preserve=no
//## end module%677CB59B0194.cm

//## begin module%677CB59B0194.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%677CB59B0194.cp

//## Module: CXOSJX32%677CB59B0194; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX32.cpp

//## begin module%677CB59B0194.additionalIncludes preserve=no
//## end module%677CB59B0194.additionalIncludes

//## begin module%677CB59B0194.includes preserve=yes
//## end module%677CB59B0194.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX32_h
#include "CXODJX32.hpp"
#endif


//## begin module%677CB59B0194.declarations preserve=no
//## end module%677CB59B0194.declarations

//## begin module%677CB59B0194.additionalDeclarations preserve=yes
//## end module%677CB59B0194.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::WorkqueueCommand 

WorkqueueCommand::WorkqueueCommand()
  //## begin WorkqueueCommand::WorkqueueCommand%677CB676021B_const.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end WorkqueueCommand::WorkqueueCommand%677CB676021B_const.hasinit
  //## begin WorkqueueCommand::WorkqueueCommand%677CB676021B_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/workqueue/v1.0.0", "S0003D", "@##JRWRKQ ")
  //## end WorkqueueCommand::WorkqueueCommand%677CB676021B_const.initialization
{
  //## begin restcommand::WorkqueueCommand::WorkqueueCommand%677CB676021B_const.body preserve=yes
   memcpy(m_sID, "JX32", 4);
  //## end restcommand::WorkqueueCommand::WorkqueueCommand%677CB676021B_const.body
}

WorkqueueCommand::WorkqueueCommand (Handler* pSuccessor)
  //## begin restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.hasinit
  //## begin restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/workqueue/v1.0.0", "S0003D", "@##JRWRKQ ")
  //## end restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.initialization
{
  //## begin restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.body preserve=yes
   memcpy(m_sID, "JX32", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('C', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::WorkqueueCommand::WorkqueueCommand%677CB7CC0117.body
}


WorkqueueCommand::~WorkqueueCommand()
{
  //## begin restcommand::WorkqueueCommand::~WorkqueueCommand%677CB676021B_dest.body preserve=yes
   delete m_pPersistentSegment;
  //## end restcommand::WorkqueueCommand::~WorkqueueCommand%677CB676021B_dest.body
}



//## Other Operations (implementation)
bool WorkqueueCommand::execute ()
{
  //## begin restcommand::WorkqueueCommand::execute%677CB80203C1.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX32 LIST WORKQUEUE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRWRKQ", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX32", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_bUpdateDetails = true;
   int iRC = parse();
   if (iRC != 0)
      return reply();
   m_pXMLDocument->add("root");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strTableName;
   string strOrderByClause;
   for (int i = 0; i < 3; i++)
   {
      m_hQuery.reset();
      if (i == 0)
      {
         strTableName = "CQC_CONSTRAINT";
         m_strTagName = "WorkQueue";
      }
      else if (i == 1)
      {
         strTableName = "CQC_COLUMN_QUAL";
         m_strTagName = "Predicate";
         strOrderByClause = "CQC_COLUMN_QUAL.COLUMN_NAME, CQC_COLUMN_QUAL.COLUMN_VALUE";
      }
      else if (i == 2)
      {
         strTableName = "CQC_USER";
         m_strTagName = "User";
         strOrderByClause = "CQC_USER.USER_ID";
      }
      if (!m_pPersistentSegment)
         m_pPersistentSegment = new PersistentSegment("XXXX", strTableName.c_str(), "QUALIFY");
      else if (m_pPersistentSegment->getTableName() != strTableName)
      {
         delete m_pPersistentSegment;
         m_pPersistentSegment = new PersistentSegment("XXXX", strTableName.c_str(), "QUALIFY");
      }
      m_hXMLText.add('Z', m_pPersistentSegment);
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      string strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      m_pPersistentSegment->bindPerCatalog(m_hQuery);
      m_hQuery.setBasicPredicate(strTableName.c_str(), "CONSTRAINT_ID", "=", atoi(m_pXMLItem->get("constraint").c_str()));
      if(i!=0)
         m_hQuery.setOrderByClause(strOrderByClause);
      bool b = pSelectStatement->execute(m_hQuery);
      if (b == false || pSelectStatement->getRows() == 0 || m_hQuery.getAbort() == true)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde(b ? '2' : '5');;
         return reply();
      }
      m_pXMLDocument->write("tab");
   }
   return reply();
  //## end restcommand::WorkqueueCommand::execute%677CB80203C1.body
}

void WorkqueueCommand::update (Subject* pSubject)
{
  //## begin restcommand::WorkqueueCommand::update%677CB82701E4.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_pXMLDocument->add("row");
      if (m_pXMLDocument->add(m_strTagName.c_str()) == false)
      {
         m_pXMLDocument->revert();
         m_hQuery.setAbort(true);
         return;
      }
      m_pXMLDocument->write("row");
      UseCase::addItem();
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::WorkqueueCommand::update%677CB82701E4.body
}

// Additional Declarations
  //## begin restcommand::WorkqueueCommand%677CB676021B.declarations preserve=yes
  //## end restcommand::WorkqueueCommand%677CB676021B.declarations

} // namespace restcommand

//## begin module%677CB59B0194.epilog preserve=yes
//## end module%677CB59B0194.epilog
