//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6525EE020132.cm preserve=no
//## end module%6525EE020132.cm

//## begin module%6525EE020132.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6525EE020132.cp

//## Module: CXOSJX11%6525EE020132; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX11.hpp

#ifndef CXOSJX11_h
#define CXOSJX11_h 1

//## begin module%6525EE020132.additionalIncludes preserve=no
//## end module%6525EE020132.additionalIncludes

//## begin module%6525EE020132.includes preserve=yes
//## end module%6525EE020132.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class Case;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6525EE020132.declarations preserve=no
//## end module%6525EE020132.declarations

//## begin module%6525EE020132.additionalDeclarations preserve=yes
//## end module%6525EE020132.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CasesCommand%6525C12F0364.preface preserve=yes
//## end restcommand::CasesCommand%6525C12F0364.preface

//## Class: CasesCommand%6525C12F0364
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%652692F400C4;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%652692F603AB;monitor::UseCase { -> F}
//## Uses: <unnamed>%652692FA020C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%652692FE022D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65269BF302D0;emssegment::Case { -> F}
//## Uses: <unnamed>%65269DC902B1;reusable::Buffer { -> F}

class DllExport CasesCommand : public command::RESTCommand  //## Inherits: <unnamed>%6525C13E0343
{
  //## begin restcommand::CasesCommand%6525C12F0364.initialDeclarations preserve=yes
  //## end restcommand::CasesCommand%6525C12F0364.initialDeclarations

  public:
    //## Constructors (generated)
      CasesCommand();

    //## Constructors (specified)
      //## Operation: CasesCommand%6525C28B021E
      CasesCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CasesCommand();


    //## Other Operations (specified)
      //## Operation: endElement%6525C26D03C0
      virtual bool endElement (const string& strTag);

      //## Operation: execute%6525C1EC009E
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%6525C1EE02D8
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::CasesCommand%6525C12F0364.public preserve=yes
      //## end restcommand::CasesCommand%6525C12F0364.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CasesCommand%6525C12F0364.protected preserve=yes
      //## end restcommand::CasesCommand%6525C12F0364.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CasesCommand%6525C12F0364.private preserve=yes
      //## end restcommand::CasesCommand%6525C12F0364.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%657996360072
      //## begin restcommand::CasesCommand::Count%657996360072.attr preserve=no  private: int {U} 
      int m_iCount;
      //## end restcommand::CasesCommand::Count%657996360072.attr

      //## Attribute: Index%6526A69A024C
      //## begin restcommand::CasesCommand::Index%6526A69A024C.attr preserve=no  private: vector<pair<int,int> > {V} 
      vector<pair<int,int> > m_hIndex;
      //## end restcommand::CasesCommand::Index%6526A69A024C.attr

      //## Attribute: Tag%65269DDE000F
      //## begin restcommand::CasesCommand::Tag%65269DDE000F.attr preserve=no  private: vector<pair<string,string> > {V} 
      vector<pair<string,string> > m_hTag;
      //## end restcommand::CasesCommand::Tag%65269DDE000F.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65269397020D
      //## Role: CasesCommand::<m_hGenericSegment>%652693980033
      //## begin restcommand::CasesCommand::<m_hGenericSegment>%652693980033.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::CasesCommand::<m_hGenericSegment>%652693980033.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6526939D02C5
      //## Role: CasesCommand::<m_hQuery>%6526939E009C
      //## begin restcommand::CasesCommand::<m_hQuery>%6526939E009C.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::CasesCommand::<m_hQuery>%6526939E009C.role

    // Additional Implementation Declarations
      //## begin restcommand::CasesCommand%6525C12F0364.implementation preserve=yes
      //## end restcommand::CasesCommand%6525C12F0364.implementation

};

//## begin restcommand::CasesCommand%6525C12F0364.postscript preserve=yes
//## end restcommand::CasesCommand%6525C12F0364.postscript

} // namespace restcommand

//## begin module%6525EE020132.epilog preserve=yes
//## end module%6525EE020132.epilog


#endif
