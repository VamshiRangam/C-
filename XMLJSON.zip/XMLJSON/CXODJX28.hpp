//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6717364D00A3.cm preserve=no
//## end module%6717364D00A3.cm

//## begin module%6717364D00A3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6717364D00A3.cp

//## Module: CXOSJX28%6717364D00A3; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX28.hpp

#ifndef CXOSJX28_h
#define CXOSJX28_h 1

//## begin module%6717364D00A3.additionalIncludes preserve=no
//## end module%6717364D00A3.additionalIncludes

//## begin module%6717364D00A3.includes preserve=yes
//## end module%6717364D00A3.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%6717364D00A3.declarations preserve=no
//## end module%6717364D00A3.declarations

//## begin module%6717364D00A3.additionalDeclarations preserve=yes
//## end module%6717364D00A3.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::LockCommand%6717379902FE.preface preserve=yes
//## end restcommand::LockCommand%6717379902FE.preface

//## Class: LockCommand%6717379902FE
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Secure REST Lock
//	<h6>Secure : REST : Lock
//	<p>
//	Locks or unlocks a case.
//	<p>
//	<ul>
//	<li><a href="../../REST/resolve/lock.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6717387503AB;monitor::UseCase { -> F}
//## Uses: <unnamed>%6717387B004F;reusable::Query { -> F}
//## Uses: <unnamed>%6717387F000D;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%671738810242;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%67173884031C;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6718AAC802D4;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%6718DB3F025B;reusable::Statement { -> F}
//## Uses: <unnamed>%6718DB8C02BB;timer::Clock { -> F}
//## Uses: <unnamed>%6718E10D03E1;IF::Timestamp { -> F}

class DllExport LockCommand : public command::RESTCommand  //## Inherits: <unnamed>%67173870000A
{
  //## begin restcommand::LockCommand%6717379902FE.initialDeclarations preserve=yes
  //## end restcommand::LockCommand%6717379902FE.initialDeclarations

  public:
    //## Constructors (generated)
      LockCommand();

    //## Constructors (specified)
      //## Operation: LockCommand%6717400C03B6
      LockCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~LockCommand();


    //## Other Operations (specified)
      //## Operation: execute%6717404A025B
      virtual bool execute ();

      //## Operation: process%6717411602CB
      bool process (const int& iCASE_ID);

      //## Operation: unlock%6717415701D3
      bool unlock ();

      //## Operation: calculateUpdatedLockTime%6718DD2E02EA
      reusable::string calculateUpdatedLockTime ();

      //## Operation: update%6717408202CE
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::LockCommand%6717379902FE.public preserve=yes
      //## end restcommand::LockCommand%6717379902FE.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::LockCommand%6717379902FE.protected preserve=yes
      //## end restcommand::LockCommand%6717379902FE.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::LockCommand%6717379902FE.private preserve=yes
      //## end restcommand::LockCommand%6717379902FE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Valid%672083AB0379
      //## begin restcommand::LockCommand::Valid%672083AB0379.attr preserve=no  private: bool {U} 
      bool m_bValid;
      //## end restcommand::LockCommand::Valid%672083AB0379.attr

    // Additional Implementation Declarations
      //## begin restcommand::LockCommand%6717379902FE.implementation preserve=yes
      //## end restcommand::LockCommand%6717379902FE.implementation

};

//## begin restcommand::LockCommand%6717379902FE.postscript preserve=yes
//## end restcommand::LockCommand%6717379902FE.postscript

} // namespace restcommand

//## begin module%6717364D00A3.epilog preserve=yes
//## end module%6717364D00A3.epilog


#endif
