//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6729EF4B030E.cm preserve=no
//## end module%6729EF4B030E.cm

//## begin module%6729EF4B030E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6729EF4B030E.cp

//## Module: CXOSJX29%6729EF4B030E; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX29.cpp

//## begin module%6729EF4B030E.additionalIncludes preserve=no
//## end module%6729EF4B030E.additionalIncludes

//## begin module%6729EF4B030E.includes preserve=yes
//## end module%6729EF4B030E.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSEX16_h
#include "CXODEX16.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX29_h
#include "CXODJX29.hpp"
#endif


//## begin module%6729EF4B030E.declarations preserve=no
//## end module%6729EF4B030E.declarations

//## begin module%6729EF4B030E.additionalDeclarations preserve=yes
//## end module%6729EF4B030E.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::DescriptionsCommand 

DescriptionsCommand::DescriptionsCommand()
  //## begin DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.hasinit preserve=no
  //## end DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.hasinit
  //## begin DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/descriptions/v1.0.0","S0003D","@##JLRULE ")
  //## end DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.initialization
{
  //## begin restcommand::DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.body preserve=yes
   memcpy(m_sID, "JX29", 4);
  //## end restcommand::DescriptionsCommand::DescriptionsCommand%6729EFEB0157_const.body
}

DescriptionsCommand::DescriptionsCommand (Handler* pSuccessor)
  //## begin restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.hasinit preserve=no
  //## end restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.hasinit
  //## begin restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/descriptions/v1.0.0","S0003D","@##JLRULE ")
  //## end restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.initialization
{
  //## begin restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.body preserve=yes
   memcpy(m_sID, "JX29", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('C', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::DescriptionsCommand::DescriptionsCommand%6729F24401ED.body
}


DescriptionsCommand::~DescriptionsCommand()
{
  //## begin restcommand::DescriptionsCommand::~DescriptionsCommand%6729EFEB0157_dest.body preserve=yes
  //## end restcommand::DescriptionsCommand::~DescriptionsCommand%6729EFEB0157_dest.body
}



//## Other Operations (implementation)
bool DescriptionsCommand::execute ()
{
  //## begin restcommand::DescriptionsCommand::execute%6729F2DB00D9.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX29 LIST RULE INFO");
   {
      if (!m_pXMLDocument)
#ifdef MVS
         m_pXMLDocument = new XMLDocument("JCL", "RJLRULE", &m_hRow, &m_hXMLText);
#else
         m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX29", &m_hRow, &m_hXMLText);
#endif
      m_pXMLDocument->reset();
      m_pXMLItem->reset();
      m_pXMLDocument->setMaximumSize(1000000);
      m_pXMLDocument->setSuppressEmptyTags(false);
      m_hQuery.reset();
      m_bUpdateDetails = true;
      int i = parse();
      if (i != 0)
         return reply();
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_strTagName = "Phase";
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      string strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      m_hGenericSegment.bind("EMSR_PHASE", "PHASE_ID", m_hQuery);
      m_hGenericSegment.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", m_hQuery);
      m_hQuery.join("EMSR_PHASE", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
      m_hQuery.join("EMSR_PHASE", "INNER", "EMSR_DESC_TEXT", "PHASE_STAT", "DESCRIPTION_STAT");
      m_hQuery.setBasicPredicate("EMSR_PHASE", "PHASE_ID", "NOT IN", "('INIT','MANO','ZALL')");
      m_hQuery.setBasicPredicate("EMSR_PHASE", "PHASE_STAT", "=", "P");
      m_hQuery.setBasicPredicate("EMSR_DESC_TEXT", "LANGUAGE", "=", "ENGLISH");
      m_hQuery.setQualifier("QUALIFY", "EMSR_PHASE");
      m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
      if (pSelectStatement->execute(m_hQuery) == false || m_hQuery.getAbort() == true)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('5');
         return reply();
      }
      m_pXMLDocument->write("tab");
      m_hQuery.reset();
      m_hGenericSegment.reset();
      m_strTagName = "Status";
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      m_hGenericSegment.bind("EMSR_STATUS", "STATUS_ID", m_hQuery);
      m_hGenericSegment.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", m_hQuery);
      m_hQuery.join("EMSR_STATUS", "INNER", "EMSR_DESC_TEXT", "BUS_DESCRIPTION", "DESCRIPTION_ID");
      m_hQuery.join("EMSR_STATUS", "INNER", "EMSR_DESC_TEXT", "STATUS_STAT", "DESCRIPTION_STAT");
      m_hQuery.setBasicPredicate("EMSR_STATUS", "STATUS_ID", "<>", "TEMP");
      m_hQuery.setBasicPredicate("EMSR_STATUS", "STATUS_STAT", "=", "P");
      m_hQuery.setBasicPredicate("EMSR_DESC_TEXT", "LANGUAGE", "=", "ENGLISH");
      m_hQuery.setQualifier("QUALIFY", "EMSR_STATUS");
      m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
      if (pSelectStatement->execute(m_hQuery) == false || m_hQuery.getAbort() == true)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('5');
         return reply();
      }
      m_pXMLDocument->write("tab");
      m_hQuery.reset();
      m_hGenericSegment.reset();
      m_strTagName = "Action";
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      m_hGenericSegment.bind("EMSR_ACTION", "ACTION_ID", m_hQuery);
      m_hGenericSegment.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", m_hQuery);
      m_hGenericSegment.bind("EMSR_ACTION", "OTHER_ACTION_DATA", m_hQuery);
      m_hQuery.join("EMSR_ACTION", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
      m_hQuery.join("EMSR_ACTION", "INNER", "EMSR_DESC_TEXT", "ACTION_STAT", "DESCRIPTION_STAT");
      m_hQuery.setBasicPredicate("EMSR_DESC_TEXT", "LANGUAGE", "=", "ENGLISH");
      m_hQuery.setBasicPredicate("EMSR_ACTION", "ACTION_STAT", "=", "P");
      m_hQuery.setQualifier("QUALIFY", "EMSR_ACTION");
      m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
      if (pSelectStatement->execute(m_hQuery) == false || m_hQuery.getAbort() == true)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('5');
         return reply();
      }
      m_pXMLDocument->write("tab");
      m_hQuery.reset();
      m_hGenericSegment.reset();
      m_strTagName = "NetRule";
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      short siIndex = 0;
      string strCustID;
      Extract::instance()->getSpec("CUSTOMER", strCustID);
      EMSNetRuleUseTable::instance()->setNetRuleUseVector(strCustID);
      while (EMSNetRuleUseTable::instance()->get(m_hEMSNetRuleUse, siIndex++))
      {
         m_hGenericSegment.reset();
         update(&m_hQuery);
         if (m_hQuery.getAbort() == true)
         {
            m_pXMLDocument->revert();
            SOAPSegment::instance()->setRtnCde('5');
            return reply();
         }
      }
      m_pXMLDocument->write("tab");
      m_hQuery.reset();
      m_hGenericSegment.reset();
      m_strTagName = "StateName";
      m_hGenericSegment.set("Tab", m_strTagName);
      m_pXMLDocument->add("tab");
      strColumnName = "^" + m_strTagName;
      m_pXMLDocument->add(strColumnName.c_str());
      m_hGenericSegment.bind("EMSR_STATE", "PHASE_ID", m_hQuery);
      m_hGenericSegment.bind("EMSR_STATE", "STATUS_ID", m_hQuery);
      m_hGenericSegment.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", m_hQuery);
      m_hQuery.join("EMSR_STATE", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
      m_hQuery.join("EMSR_STATE", "INNER", "EMSR_DESC_TEXT", "RULE_SET_STAT", "DESCRIPTION_STAT");
      m_hQuery.setBasicPredicate("EMSR_STATE", "STATUS_ID", "<>", "TEMP");
      m_hQuery.setBasicPredicate("EMSR_STATE", "RULE_SET_STAT", "=", "P");
      m_hQuery.setBasicPredicate("EMSR_DESC_TEXT", "LANGUAGE", "=", "ENGLISH");
      m_hQuery.setQualifier("QUALIFY", "EMSR_STATE");
      m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
      if (pSelectStatement->execute(m_hQuery) == false || m_hQuery.getAbort() == true)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('5');
         return reply();
      }
      m_pXMLDocument->write("tab");
      m_hQuery.reset();
      m_hGenericSegment.reset();
   }
   return reply();
  //## end restcommand::DescriptionsCommand::execute%6729F2DB00D9.body
}

void DescriptionsCommand::update (Subject* pSubject)
{
  //## begin restcommand::DescriptionsCommand::update%6729F30802FD.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_pXMLDocument->add("row");
      if (m_strTagName == "NetRule")
      {
         m_hGenericSegment.set("KEY",m_hEMSNetRuleUse.getClientKey());
         m_hGenericSegment.set("SETTINGS", m_hEMSNetRuleUse.getClientData());
      }
      if (m_pXMLDocument->add(m_strTagName.c_str()) == false)
      {
         m_pXMLDocument->revert();
         m_hQuery.setAbort(true);
         return;
      }
      m_pXMLDocument->write("row");
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::DescriptionsCommand::update%6729F30802FD.body
}

// Additional Declarations
  //## begin restcommand::DescriptionsCommand%6729EFEB0157.declarations preserve=yes
  //## end restcommand::DescriptionsCommand%6729EFEB0157.declarations

} // namespace restcommand

//## begin module%6729EF4B030E.epilog preserve=yes
//## end module%6729EF4B030E.epilog
