//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66790E9E0277.cm preserve=no
//## end module%66790E9E0277.cm

//## begin module%66790E9E0277.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66790E9E0277.cp

//## Module: CXOSJX21%66790E9E0277; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX21.hpp

#ifndef CXOSJX21_h
#define CXOSJX21_h 1

//## begin module%66790E9E0277.additionalIncludes preserve=no
//## end module%66790E9E0277.additionalIncludes

//## begin module%66790E9E0277.includes preserve=yes
//## end module%66790E9E0277.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%66790E9E0277.declarations preserve=no
//## end module%66790E9E0277.declarations

//## begin module%66790E9E0277.additionalDeclarations preserve=yes
//## end module%66790E9E0277.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::SaveSettingsCommand%667910C400BD.preface preserve=yes
//## end restcommand::SaveSettingsCommand%667910C400BD.preface

//## Class: SaveSettingsCommand%667910C400BD
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6679115B025B;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6679117A012B;monitor::UseCase { -> F}
//## Uses: <unnamed>%667911C00023;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%667911E2027A;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66794F0001AE;reusable::Table { -> F}
//## Uses: <unnamed>%667952FD025F;reusable::Statement { -> F}
//## Uses: <unnamed>%667BB5E6007A;database::Database { -> F}
//## Uses: <unnamed>%667BB69D022F;reusable::Query { -> F}

class DllExport SaveSettingsCommand : public command::RESTCommand  //## Inherits: <unnamed>%667911A00238
{
  //## begin restcommand::SaveSettingsCommand%667910C400BD.initialDeclarations preserve=yes
  //## end restcommand::SaveSettingsCommand%667910C400BD.initialDeclarations

  public:
    //## Constructors (generated)
      SaveSettingsCommand();

    //## Constructors (specified)
      //## Operation: SaveSettingsCommand%667913A4025A
      SaveSettingsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~SaveSettingsCommand();


    //## Other Operations (specified)
      //## Operation: endElement%667BB05200FB
      virtual bool endElement (const string& strTag);

      //## Operation: execute%667913FD0002
      virtual bool execute ();

      //## Operation: save%667BB0F9001D
      bool save ();

      //## Operation: update%667BBA2401AC
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::SaveSettingsCommand%667910C400BD.public preserve=yes
      //## end restcommand::SaveSettingsCommand%667910C400BD.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::SaveSettingsCommand%667910C400BD.protected preserve=yes
      //## end restcommand::SaveSettingsCommand%667910C400BD.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::SaveSettingsCommand%667910C400BD.private preserve=yes
      //## end restcommand::SaveSettingsCommand%667910C400BD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Return%667BB372007C
      //## begin restcommand::SaveSettingsCommand::Return%667BB372007C.attr preserve=no  private: int {U} 0
      int m_iReturn;
      //## end restcommand::SaveSettingsCommand::Return%667BB372007C.attr

      //## Attribute: Values%667BB454013E
      //## begin restcommand::SaveSettingsCommand::Values%667BB454013E.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hValues;
      //## end restcommand::SaveSettingsCommand::Values%667BB454013E.attr

      //## Attribute: Columns%667BD1B90135
      //## begin restcommand::SaveSettingsCommand::Columns%667BD1B90135.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumns;
      //## end restcommand::SaveSettingsCommand::Columns%667BD1B90135.attr

    // Additional Implementation Declarations
      //## begin restcommand::SaveSettingsCommand%667910C400BD.implementation preserve=yes
      //## end restcommand::SaveSettingsCommand%667910C400BD.implementation

};

//## begin restcommand::SaveSettingsCommand%667910C400BD.postscript preserve=yes
//## end restcommand::SaveSettingsCommand%667910C400BD.postscript

} // namespace restcommand

//## begin module%66790E9E0277.epilog preserve=yes
//## end module%66790E9E0277.epilog


#endif
