//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67123BC8016A.cm preserve=no
//## end module%67123BC8016A.cm

//## begin module%67123BC8016A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67123BC8016A.cp

//## Module: CXOSJX27%67123BC8016A; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX27.hpp

#ifndef CXOSJX27_h
#define CXOSJX27_h 1

//## begin module%67123BC8016A.additionalIncludes preserve=no
//## end module%67123BC8016A.additionalIncludes

//## begin module%67123BC8016A.includes preserve=yes
//## end module%67123BC8016A.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class CardholderInformationSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67123BC8016A.declarations preserve=no
//## end module%67123BC8016A.declarations

//## begin module%67123BC8016A.additionalDeclarations preserve=yes
//## end module%67123BC8016A.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CardholderCommand%67123C76036A.preface preserve=yes
//## end restcommand::CardholderCommand%67123C76036A.preface

//## Class: CardholderCommand%67123C76036A
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67123D410349;monitor::UseCase { -> F}
//## Uses: <unnamed>%67123D450209;reusable::Query { -> F}
//## Uses: <unnamed>%67123D480085;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67123D4A023B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%67123D4D038C;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67123D510164;repositorysegment::CardholderInformationSegment { -> F}

class DllExport CardholderCommand : public command::RESTCommand  //## Inherits: <unnamed>%67123CB002D6
{
  //## begin restcommand::CardholderCommand%67123C76036A.initialDeclarations preserve=yes
  //## end restcommand::CardholderCommand%67123C76036A.initialDeclarations

  public:
    //## Constructors (generated)
      CardholderCommand();

    //## Constructors (specified)
      //## Operation: CardholderCommand%67123E6B015F
      CardholderCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CardholderCommand();


    //## Other Operations (specified)
      //## Operation: execute%67123E9B02B4
      virtual bool execute ();

      //## Operation: update%67123EBC0251
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::CardholderCommand%67123C76036A.public preserve=yes
      //## end restcommand::CardholderCommand%67123C76036A.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CardholderCommand%67123C76036A.protected preserve=yes
      //## end restcommand::CardholderCommand%67123C76036A.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CardholderCommand%67123C76036A.private preserve=yes
      //## end restcommand::CardholderCommand%67123C76036A.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67123D770010
      //## Role: CardholderCommand::<m_hGenericSegment>%67123D770360
      //## begin restcommand::CardholderCommand::<m_hGenericSegment>%67123D770360.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::CardholderCommand::<m_hGenericSegment>%67123D770360.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6712404C01F6
      //## Role: CardholderCommand::<m_hQuery>%6712404D00A2
      //## begin restcommand::CardholderCommand::<m_hQuery>%6712404D00A2.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::CardholderCommand::<m_hQuery>%6712404D00A2.role

    // Additional Implementation Declarations
      //## begin restcommand::CardholderCommand%67123C76036A.implementation preserve=yes
      //## end restcommand::CardholderCommand%67123C76036A.implementation

};

//## begin restcommand::CardholderCommand%67123C76036A.postscript preserve=yes
//## end restcommand::CardholderCommand%67123C76036A.postscript

} // namespace restcommand

//## begin module%67123BC8016A.epilog preserve=yes
//## end module%67123BC8016A.epilog


#endif
