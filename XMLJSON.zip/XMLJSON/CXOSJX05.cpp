//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6509EAA101CB.cm preserve=no
//## end module%6509EAA101CB.cm

//## begin module%6509EAA101CB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6509EAA101CB.cp

//## Module: CXOSJX05%6509EAA101CB; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX05.cpp

//## begin module%6509EAA101CB.additionalIncludes preserve=no
//## end module%6509EAA101CB.additionalIncludes

//## begin module%6509EAA101CB.includes preserve=yes
//## end module%6509EAA101CB.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSJX06_h
#include "CXODJX06.hpp"
#endif
#ifndef CXOSJX05_h
#include "CXODJX05.hpp"
#endif


//## begin module%6509EAA101CB.declarations preserve=no
//## end module%6509EAA101CB.declarations

//## begin module%6509EAA101CB.additionalDeclarations preserve=yes
//## end module%6509EAA101CB.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::CaseCommand 

CaseCommand::CaseCommand()
  //## begin CaseCommand::CaseCommand%6509EA120212_const.hasinit preserve=no
      : m_pCaseManifest(0)
  //## end CaseCommand::CaseCommand%6509EA120212_const.hasinit
  //## begin CaseCommand::CaseCommand%6509EA120212_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/case/v1.0.0","S0003D","@##JUCASE ")
  //## end CaseCommand::CaseCommand%6509EA120212_const.initialization
{
  //## begin restcommand::CaseCommand::CaseCommand%6509EA120212_const.body preserve=yes
   memcpy(m_sID,"JX02",4);
  //## end restcommand::CaseCommand::CaseCommand%6509EA120212_const.body
}

CaseCommand::CaseCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::CaseCommand::CaseCommand%6509EC6703D8.hasinit preserve=no
      : m_pCaseManifest(0)
  //## end restcommand::CaseCommand::CaseCommand%6509EC6703D8.hasinit
  //## begin restcommand::CaseCommand::CaseCommand%6509EC6703D8.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/case/v1.0.0","S0003D","@##JUCASE ")
  //## end restcommand::CaseCommand::CaseCommand%6509EC6703D8.initialization
{
  //## begin restcommand::CaseCommand::CaseCommand%6509EC6703D8.body preserve=yes
   memcpy(m_sID,"JX05",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::CaseCommand::CaseCommand%6509EC6703D8.body
}


CaseCommand::~CaseCommand()
{
  //## begin restcommand::CaseCommand::~CaseCommand%6509EA120212_dest.body preserve=yes
  //## end restcommand::CaseCommand::~CaseCommand%6509EA120212_dest.body
}



//## Other Operations (implementation)
bool CaseCommand::endElement (const string& strTag)
{
  //## begin restcommand::CaseCommand::endElement%6509EC8902C7.body preserve=yes
   if (strTag == "userId"
      || strTag == "password")
      m_pCaseManifest->add(strTag,m_pXMLItem->get(strTag.c_str()));
   if (strTag == "name")
      m_pCaseManifest->addName(m_pXMLItem->get("name"));
   if (strTag == "tag")
      m_pCaseManifest->addTag(m_pXMLItem->get("tag"));
   m_pXMLItem->resetToken();
   return true;
  //## end restcommand::CaseCommand::endElement%6509EC8902C7.body
}

bool CaseCommand::execute ()
{
  //## begin restcommand::CaseCommand::execute%6509EA7E01F8.body preserve=yes
   UseCase hUseCase("CLIENT","## JX05 UPDATE CASE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJUCASE",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX05",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pCaseManifest = new restcommand::CaseManifest("QXICASE","CXOXJX05");
   int iRC = parse();
   m_pCaseManifest->execute();
   m_pXMLDocument->add("root");
   if (iRC != 0)
      SOAPSegment::instance()->setTxt("Invalid request (parse failure)");
   else if(atoi(SOAPSegment::instance()->getRtnCde().c_str()) > 0)
      SOAPSegment::instance()->setTxt("Query failure");
   m_pXMLDocument->add("details");
   reply();
   delete m_pCaseManifest;
   m_pCaseManifest = 0;
   return true;
  //## end restcommand::CaseCommand::execute%6509EA7E01F8.body
}

// Additional Declarations
  //## begin restcommand::CaseCommand%6509EA120212.declarations preserve=yes
  //## end restcommand::CaseCommand%6509EA120212.declarations

} // namespace restcommand

//## begin module%6509EAA101CB.epilog preserve=yes
//## end module%6509EAA101CB.epilog
