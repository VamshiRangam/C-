Platform\Common\REST test procedure

Prerequisites
  Postman installed

Client Interface
  The Client Interface task can support HTTP POST requests from Postman (for testing purposes only)
  Include the following line (set machine to your computer name) in the Pprod/caCI01.txt extract file
    DSPEC   HTTP    machine,8080

Visual Studio
  Start an instance to debug the Health Monitor task (HM)
  Start an instance to debug the Client Interface task (caCI01)
  Start an instance to debug the task that supports the request you are testing (e.g., EMS Query (caEQ01) for case list)

Command Window
  Use the 'netstat -na' command to determine the listening IP address for the DN server tasks
  Use that address (instead of 10.123.456.789) in the Postman POST URL value (see next item)

Postman
  Using case list as an example:
  Set the POST URL to http://10.123.456.789:8080/v2/cases
  Set the Body to your JSON request, for example:

{
  "info": {
    "userId": "W951A2C",
    "password": "MLife42!",
    "uuid": "00000000-0000-0000-0000-000000000000",
    "customer": "GOLD"
  },
  "tab": {
    "name": "Case",
    "filter": [
      {
        "column": "AccountNumber",
        "operator": "LIKE",
        "value": "543210*"
      },
      {
        "column": "CaseNumber",
        "operator": "BETWEEN",
        "value": "20230420000001~20240420999999"
      },
      {
        "column": "rows",
        "operator": "=",
        "value": "5"
      }
    ],
    "column": [
      "AccountNumber",
      "ReconciliationAmount",
      "TransactionDateTime",
      "Phase.AdjustmentAmount"
    ]
  }
}

Hit Send to route the request to the Client Interface task
The JSON request is forwarded for processing (e.g., to the EMS Query task)
The EMS Query task will convert the JSON to XML to parse the request using the Xerces XML Toolkit
The XML response is converted to JSON and sent back to the Client Interface
The Client Interface task will return the response to Postman

