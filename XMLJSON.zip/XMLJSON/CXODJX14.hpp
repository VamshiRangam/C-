//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B757F80266.cm preserve=no
//## end module%65B757F80266.cm

//## begin module%65B757F80266.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B757F80266.cp

//## Module: CXOSJX14%65B757F80266; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX14.hpp

#ifndef CXOSJX14_h
#define CXOSJX14_h 1

//## begin module%65B757F80266.additionalIncludes preserve=no
//## end module%65B757F80266.additionalIncludes

//## begin module%65B757F80266.includes preserve=yes
//## end module%65B757F80266.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;
class CasePhaseSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65B757F80266.declarations preserve=no
//## end module%65B757F80266.declarations

//## begin module%65B757F80266.additionalDeclarations preserve=yes
//## end module%65B757F80266.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::MmtsCommand%65B7593E0315.preface preserve=yes
//## end restcommand::MmtsCommand%65B7593E0315.preface

//## Class: MmtsCommand%65B7593E0315
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65B75BF4023D;monitor::UseCase { -> F}
//## Uses: <unnamed>%65B75C630326;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%65B75C8A035F;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%65B75CB1032F;reusable::Query { -> F}
//## Uses: <unnamed>%65B75CF8007D;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%65B75D380329;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%65B75D7B014D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65B75F2301BE;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%65B760B503C1;segment::SOAPSegment { -> F}

class DllExport MmtsCommand : public command::RESTCommand  //## Inherits: <unnamed>%65B75BBA01A9
{
  //## begin restcommand::MmtsCommand%65B7593E0315.initialDeclarations preserve=yes
  //## end restcommand::MmtsCommand%65B7593E0315.initialDeclarations

  public:
    //## Constructors (generated)
      MmtsCommand();

    //## Constructors (specified)
      //## Operation: MmtsCommand%65B759C70330
      MmtsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~MmtsCommand();


    //## Other Operations (specified)
      //## Operation: execute%65B75AA10393
      virtual bool execute ();

      //## Operation: update%65B75AD403E2
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::MmtsCommand%65B7593E0315.public preserve=yes
      //## end restcommand::MmtsCommand%65B7593E0315.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::MmtsCommand%65B7593E0315.protected preserve=yes
      //## end restcommand::MmtsCommand%65B7593E0315.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::MmtsCommand%65B7593E0315.private preserve=yes
      //## end restcommand::MmtsCommand%65B7593E0315.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%65B75B3800BE
      //## begin restcommand::MmtsCommand::Buffer%65B75B3800BE.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end restcommand::MmtsCommand::Buffer%65B75B3800BE.attr

      //## Attribute: MMTAvailableFlag%65B7E3FF010A
      //## begin restcommand::MmtsCommand::MMTAvailableFlag%65B7E3FF010A.attr preserve=no  private: bool {V} 
      bool m_bMMTAvailableFlag;
      //## end restcommand::MmtsCommand::MMTAvailableFlag%65B7E3FF010A.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65B761A6022A
      //## Role: MmtsCommand::<m_hGenericSegment>%65B761A702F3
      //## begin restcommand::MmtsCommand::<m_hGenericSegment>%65B761A702F3.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::MmtsCommand::<m_hGenericSegment>%65B761A702F3.role

    // Additional Implementation Declarations
      //## begin restcommand::MmtsCommand%65B7593E0315.implementation preserve=yes
      //## end restcommand::MmtsCommand%65B7593E0315.implementation

};

//## begin restcommand::MmtsCommand%65B7593E0315.postscript preserve=yes
//## end restcommand::MmtsCommand%65B7593E0315.postscript

} // namespace restcommand

//## begin module%65B757F80266.epilog preserve=yes
//## end module%65B757F80266.epilog


#endif
