//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67EE4E7E038D.cm preserve=no
//## end module%67EE4E7E038D.cm

//## begin module%67EE4E7E038D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67EE4E7E038D.cp

//## Module: CXOSJX41%67EE4E7E038D; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX41.cpp

//## begin module%67EE4E7E038D.additionalIncludes preserve=no
//## end module%67EE4E7E038D.additionalIncludes

//## begin module%67EE4E7E038D.includes preserve=yes
//## end module%67EE4E7E038D.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX41_h
#include "CXODJX41.hpp"
#endif


//## begin module%67EE4E7E038D.declarations preserve=no
//## end module%67EE4E7E038D.declarations

//## begin module%67EE4E7E038D.additionalDeclarations preserve=yes
//## end module%67EE4E7E038D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::SaveCardholderCommand 

SaveCardholderCommand::SaveCardholderCommand()
  //## begin SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.hasinit preserve=no
      : m_iReturn(0)
  //## end SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.hasinit
  //## begin SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/savecardholder/v1.0.0", "S0003D", "@##JUCHDR ")
  //## end SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.initialization
{
  //## begin restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.body preserve=yes
   memcpy(m_sID, "JX41", 4);
  //## end restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE4FBF0060_const.body
}

SaveCardholderCommand::SaveCardholderCommand (Handler* pSuccessor)
  //## begin restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.hasinit preserve=no
      : m_iReturn(0)
  //## end restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.hasinit
  //## begin restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/savecardholder/v1.0.0", "S0003D", "@##JUCHDR ")
  //## end restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.initialization
{
  //## begin restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.body preserve=yes
   memcpy(m_sID, "JX41", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::SaveCardholderCommand::SaveCardholderCommand%67EE52C2005A.body
}


SaveCardholderCommand::~SaveCardholderCommand()
{
  //## begin restcommand::SaveCardholderCommand::~SaveCardholderCommand%67EE4FBF0060_dest.body preserve=yes
  //## end restcommand::SaveCardholderCommand::~SaveCardholderCommand%67EE4FBF0060_dest.body
}



//## Other Operations (implementation)
bool SaveCardholderCommand::endElement (const string& strTag)
{
  //## begin restcommand::SaveCardholderCommand::endElement%67EE530C02FC.body preserve=yes
   if (m_iReturn == 0)
   {
      if (strTag == "column")
         m_hColumns.push_back(m_pXMLItem->get("column"));
      if (strTag == "value")
         m_hValues.push_back(m_pXMLItem->get("value"));
      if (strTag == "row")
      {
         if (m_hColumns.size() != m_hValues.size())
            m_iReturn = 1;
         else if (save() == false)
            m_iReturn = 2;
         m_hValues.clear();
      }
      m_pXMLItem->resetToken();
   }
   return true;
  //## end restcommand::SaveCardholderCommand::endElement%67EE530C02FC.body
}

bool SaveCardholderCommand::execute ()
{
  //## begin restcommand::SaveCardholderCommand::execute%67EE53A20283.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX41 UPDATE CARDHOLDERINFO");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJUCHDR", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX41", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_iReturn = 0;
   int iRC;
   iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0 || m_iReturn == 1)
   {
      SOAPSegment::instance()->setTxt("");
      SOAPSegment::instance()->setRtnCde('3');
   }
   else if (m_iReturn == 2)
   {
      SOAPSegment::instance()->setTxt("");
      SOAPSegment::instance()->setRtnCde('5');
   }
   if(m_iReturn == 0)
      Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   else
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   m_hColumns.clear();
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::SaveCardholderCommand::execute%67EE53A20283.body
}

bool SaveCardholderCommand::save ()
{
  //## begin restcommand::SaveCardholderCommand::save%67EE53D201DC.body preserve=yes
   reusable::Table hTable;
   hTable.reset();
   hTable.setName("CARDHOLDER");
   hTable.setQualifier("QUALIFY");
   for (int i = 0; i < m_hColumns.size() && i < m_hValues.size(); i++)
   {
      if (m_hColumns[i] == "AccountNumber")
         hTable.set("PAN", m_hValues[i], false, true);
      else if (m_hColumns[i] == "CardIssuerInstitutionID")
         hTable.set("CARD_ISS_INST_ID", m_hValues[i]);
      else if (m_hColumns[i] == "FirstName1")
         hTable.set("FIRST_NAME_1", m_hValues[i]);
      else if (m_hColumns[i] == "LastName1")
         hTable.set("LAST_NAME_1", m_hValues[i]);
      else if (m_hColumns[i] == "Title1")
         hTable.set("TITLE_1", m_hValues[i]);
      else if (m_hColumns[i] == "SSN1")
         hTable.set("SSN_1", m_hValues[i]);
      else if (m_hColumns[i] == "FirstName2")
         hTable.set("FIRST_NAME_2", m_hValues[i]);
      else if (m_hColumns[i] == "LastName2")
         hTable.set("LAST_NAME_2", m_hValues[i]);
      else if (m_hColumns[i] == "Title2")
         hTable.set("TITLE_2", m_hValues[i]);
      else if (m_hColumns[i] == "SSN2")
         hTable.set("SSN_2", m_hValues[i]);
      else if (m_hColumns[i] == "AddressLine1")
         hTable.set("ADDRESS_LINE_1", m_hValues[i]);
      else if (m_hColumns[i] == "AddressLine2")
         hTable.set("ADDRESS_LINE_2", m_hValues[i]);
      else if (m_hColumns[i] == "AddressLine3")
         hTable.set("ADDRESS_LINE_3", m_hValues[i]);
      else if (m_hColumns[i] == "City")
         hTable.set("CITY", m_hValues[i]);
      else if (m_hColumns[i] == "Region")
         hTable.set("REGION", m_hValues[i]);
      else if (m_hColumns[i] == "CountryCode")
         hTable.set("COUNTRY_CODE", m_hValues[i]);
      else if (m_hColumns[i] == "PostalCode")
         hTable.set("POSTAL_CODE", m_hValues[i]);
      else if (m_hColumns[i] == "WorkPhone")
         hTable.set("WORK_PHONE_NO", m_hValues[i]);
      else if (m_hColumns[i] == "HomePhone")
         hTable.set("HOME_PHONE_NO", m_hValues[i]);
      else if (m_hColumns[i] == "Fax")
         hTable.set("FAX_NO", m_hValues[i]);
      else if (m_hColumns[i] == "Email")
         hTable.set("EMAIL_ADDRESS", m_hValues[i]);
      else if (m_hColumns[i] == "ContactMethod")
         hTable.set("CONTACT_METHOD", m_hValues[i]);
      else if (m_hColumns[i] == "CustomerState")
         hTable.set("CUST_STAT", m_hValues[i]);
      else if (m_hColumns[i] == "InstitutionState")
         hTable.set("INST_STAT", m_hValues[i]);
      else if (m_hColumns[i] == "CountrycodeState")
         hTable.set("COUNTRY_CODE_STAT", m_hValues[i]);
      else if(m_hColumns[i] == "TimestampLastupdate")
         hTable.set("TSTAMP_LAST_UPDATE", m_hValues[i]);
      else if (m_hColumns[i] == "TimestampLastupdate")
         hTable.set("TSTAMP_LAST_UPDATE", m_hValues[i]);
      else if (m_hColumns[i] == "UpdateduserID")
         hTable.set("UPDATED_BY_USER_ID", m_hValues[i]);
   }
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hTable.set("CUST_ID", strCustomerID);
   auto_ptr<Statement> pMergeStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
   if (!pMergeStatement->execute(hTable))
      return false;
   return true;
  //## end restcommand::SaveCardholderCommand::save%67EE53D201DC.body
}

void SaveCardholderCommand::update (Subject* pSubject)
{
  //## begin restcommand::SaveCardholderCommand::update%67EE543100F7.body preserve=yes
   RESTCommand::update(pSubject);
  //## end restcommand::SaveCardholderCommand::update%67EE543100F7.body
}

// Additional Declarations
  //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.declarations preserve=yes
  //## end restcommand::SaveCardholderCommand%67EE4FBF0060.declarations

} // namespace restcommand

//## begin module%67EE4E7E038D.epilog preserve=yes
//## end module%67EE4E7E038D.epilog
