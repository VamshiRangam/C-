//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6763BACF01F0.cm preserve=no
//## end module%6763BACF01F0.cm

//## begin module%6763BACF01F0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6763BACF01F0.cp

//## Module: CXOSJX31%6763BACF01F0; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX31.hpp

#ifndef CXOSJX31_h
#define CXOSJX31_h 1

//## begin module%6763BACF01F0.additionalIncludes preserve=no
//## end module%6763BACF01F0.additionalIncludes

//## begin module%6763BACF01F0.includes preserve=yes
//## end module%6763BACF01F0.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%6763BACF01F0.declarations preserve=no
//## end module%6763BACF01F0.declarations

//## begin module%6763BACF01F0.additionalDeclarations preserve=yes
//## end module%6763BACF01F0.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::WorkqueuesCommand%6763BB6502D1.preface preserve=yes
//## end restcommand::WorkqueuesCommand%6763BB6502D1.preface

//## Class: WorkqueuesCommand%6763BB6502D1
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST Workqueues
//	<h6>Resolve : REST : Workqueues
//	<p>
//	Returns list of work queues owned by the user.
//	<p>
//	<ul>
//	<li><a href="../../REST/resolve/workqueues.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6763BC99001F;monitor::UseCase { -> F}
//## Uses: <unnamed>%6763BC9C0321;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6763BCA00054;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6763BCA30229;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6763C94C02C0;segment::CommonHeaderSegment { -> F}

class DllExport WorkqueuesCommand : public command::RESTCommand  //## Inherits: <unnamed>%6763BC940157
{
  //## begin restcommand::WorkqueuesCommand%6763BB6502D1.initialDeclarations preserve=yes
  //## end restcommand::WorkqueuesCommand%6763BB6502D1.initialDeclarations

  public:
    //## Constructors (generated)
      WorkqueuesCommand();

    //## Constructors (specified)
      //## Operation: WorkqueuesCommand%6763BD7F030A
      WorkqueuesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~WorkqueuesCommand();


    //## Other Operations (specified)
      //## Operation: execute%6763BDC70199
      virtual bool execute ();

      //## Operation: update%6763BDF10185
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::WorkqueuesCommand%6763BB6502D1.public preserve=yes
      //## end restcommand::WorkqueuesCommand%6763BB6502D1.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::WorkqueuesCommand%6763BB6502D1.protected preserve=yes
      //## end restcommand::WorkqueuesCommand%6763BB6502D1.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::WorkqueuesCommand%6763BB6502D1.private preserve=yes
      //## end restcommand::WorkqueuesCommand%6763BB6502D1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONSTRAINT_ID%6763D9B30298
      //## begin restcommand::WorkqueuesCommand::CONSTRAINT_ID%6763D9B30298.attr preserve=no  private: int {U} 0
      int m_lCONSTRAINT_ID;
      //## end restcommand::WorkqueuesCommand::CONSTRAINT_ID%6763D9B30298.attr

      //## Attribute: TYPE%6763D9F7006E
      //## begin restcommand::WorkqueuesCommand::TYPE%6763D9F7006E.attr preserve=no  private: string {U} 
      string m_strTYPE;
      //## end restcommand::WorkqueuesCommand::TYPE%6763D9F7006E.attr

      //## Attribute: DESCRIPTION%6763DA2D02E9
      //## begin restcommand::WorkqueuesCommand::DESCRIPTION%6763DA2D02E9.attr preserve=no  private: string {U} 
      string m_strDESCRIPTION;
      //## end restcommand::WorkqueuesCommand::DESCRIPTION%6763DA2D02E9.attr

      //## Attribute: ORDER_BY%6763DA6100FA
      //## begin restcommand::WorkqueuesCommand::ORDER_BY%6763DA6100FA.attr preserve=no  private: string {U} 
      string m_strORDER_BY;
      //## end restcommand::WorkqueuesCommand::ORDER_BY%6763DA6100FA.attr

      //## Attribute: TSTAMP_UPDATED%6763DA7900E9
      //## begin restcommand::WorkqueuesCommand::TSTAMP_UPDATED%6763DA7900E9.attr preserve=no  private: string {U} 
      string m_strTSTAMP_UPDATED;
      //## end restcommand::WorkqueuesCommand::TSTAMP_UPDATED%6763DA7900E9.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6763BD1E01FA
      //## Role: WorkqueuesCommand::<m_hGenericSegment>%6763BD1F00BB
      //## begin restcommand::WorkqueuesCommand::<m_hGenericSegment>%6763BD1F00BB.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::WorkqueuesCommand::<m_hGenericSegment>%6763BD1F00BB.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6763BD3D01ED
      //## Role: WorkqueuesCommand::<m_hQuery>%6763BD3E017D
      //## begin restcommand::WorkqueuesCommand::<m_hQuery>%6763BD3E017D.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::WorkqueuesCommand::<m_hQuery>%6763BD3E017D.role

    // Additional Implementation Declarations
      //## begin restcommand::WorkqueuesCommand%6763BB6502D1.implementation preserve=yes
      //## end restcommand::WorkqueuesCommand%6763BB6502D1.implementation

};

//## begin restcommand::WorkqueuesCommand%6763BB6502D1.postscript preserve=yes
//## end restcommand::WorkqueuesCommand%6763BB6502D1.postscript

} // namespace restcommand

//## begin module%6763BACF01F0.epilog preserve=yes
//## end module%6763BACF01F0.epilog


#endif
