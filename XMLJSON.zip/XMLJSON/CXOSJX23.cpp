//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6682B601005F.cm preserve=no
//## end module%6682B601005F.cm

//## begin module%6682B601005F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6682B601005F.cp

//## Module: CXOSJX23%6682B601005F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX23.cpp

//## begin module%6682B601005F.additionalIncludes preserve=no
//## end module%6682B601005F.additionalIncludes

//## begin module%6682B601005F.includes preserve=yes
//## end module%6682B601005F.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX23_h
#include "CXODJX23.hpp"
#endif


//## begin module%6682B601005F.declarations preserve=no
//## end module%6682B601005F.declarations

//## begin module%6682B601005F.additionalDeclarations preserve=yes
//## end module%6682B601005F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::SettingsCommand 

SettingsCommand::SettingsCommand()
  //## begin SettingsCommand::SettingsCommand%6682B7B70258_const.hasinit preserve=no
      : m_siSequenceNo(0)
  //## end SettingsCommand::SettingsCommand%6682B7B70258_const.hasinit
  //## begin SettingsCommand::SettingsCommand%6682B7B70258_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/secure/settings/v1.0.0", "S0003D", "@##JLCUST ")
  //## end SettingsCommand::SettingsCommand%6682B7B70258_const.initialization
{
  //## begin restcommand::SettingsCommand::SettingsCommand%6682B7B70258_const.body preserve=yes
   memcpy(m_sID, "JX23", 4);
  //## end restcommand::SettingsCommand::SettingsCommand%6682B7B70258_const.body
}

SettingsCommand::SettingsCommand (Handler* pSuccessor)
  //## begin restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.hasinit preserve=no
      : m_siSequenceNo(0)
  //## end restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.hasinit
  //## begin restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/secure/settings/v1.0.0", "S0003D", "@##JLCUST ")
  //## end restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.initialization
{
  //## begin restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.body preserve=yes
   memcpy(m_sID, "JX23", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::SettingsCommand::SettingsCommand%6682BA2E02F9.body
}


SettingsCommand::~SettingsCommand()
{
  //## begin restcommand::SettingsCommand::~SettingsCommand%6682B7B70258_dest.body preserve=yes
  //## end restcommand::SettingsCommand::~SettingsCommand%6682B7B70258_dest.body
}



//## Other Operations (implementation)
bool SettingsCommand::execute ()
{
  //## begin restcommand::SettingsCommand::execute%6682BA67039A.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX23 GET CUSTOMIZATION");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLCUST", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX23", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   bool bSuccess = false;
   int iRC;
   iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strCUSTOMIZE_NODE = m_pXMLItem->get("Node");;
   string strFULL_CUSTOMIZE_NAM = m_pXMLItem->get("Name");
   m_hQuery.setQualifier("QUALIFY", "CLIENT_CUSTOM_DATA");
   m_hQuery.bind("CLIENT_CUSTOM_DATA", "CUSTOMIZE_NODE", Column::STRING, &m_strCustomizeNode);
   m_hQuery.bind("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", Column::STRING, &m_strFullCustomizeName);
   m_hQuery.bind("CLIENT_CUSTOM_DATA", "SEQUENCE_NO", Column::SHORT, &m_siSequenceNo);
   m_hQuery.bind("CLIENT_CUSTOM_DATA", "CUSTOMIZE_DATA", Column::STRING, &m_strCustomizeData);
   if (strFULL_CUSTOMIZE_NAM.rfind("%") != string::npos &&
      strFULL_CUSTOMIZE_NAM.length() > 13 &&
      (strFULL_CUSTOMIZE_NAM.substr(0, 10) == "VIEW_TRAN_" || strFULL_CUSTOMIZE_NAM.substr(0, 9) == "VIEW_EMS_"))
   {
      string strFULL_CUSTOMIZE_NAM1 = "%" + strFULL_CUSTOMIZE_NAM;
      string strFULL_CUSTOMIZE_NAM2 = "%" + strFULL_CUSTOMIZE_NAM;
      size_t pos = strFULL_CUSTOMIZE_NAM1.rfind("_");
      if (pos != string::npos)
         strFULL_CUSTOMIZE_NAM1.erase(pos);
      string strFULL_CUSTOMIZE_NAM3(strFULL_CUSTOMIZE_NAM1);
      strFULL_CUSTOMIZE_NAM1.append("_*%");
      strFULL_CUSTOMIZE_NAM3.append("__DEFAULT%");
      m_hQuery.getSearchCondition().append("(");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "CUSTOMIZE_NODE", "=", strCUSTOMIZE_NODE.c_str());
      m_hQuery.getSearchCondition().append(" AND (");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "LIKE", strFULL_CUSTOMIZE_NAM1.c_str());
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "LIKE", strFULL_CUSTOMIZE_NAM3.c_str(), false, false);
      m_hQuery.getSearchCondition().append(")");
      m_hQuery.getSearchCondition().append(") OR (");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "LIKE", strFULL_CUSTOMIZE_NAM2.c_str());
      m_hQuery.getSearchCondition().append(")");
   }
   else
   {
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "CUSTOMIZE_NODE", "=", strCUSTOMIZE_NODE.c_str());
      if (strFULL_CUSTOMIZE_NAM.length() != 0)
      {
         if (strFULL_CUSTOMIZE_NAM[strFULL_CUSTOMIZE_NAM.length() - 1] == '%')
            m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "LIKE", strFULL_CUSTOMIZE_NAM.c_str());
         else
            m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "=", strFULL_CUSTOMIZE_NAM.c_str());
      }
   }
   string strOrderByClause("CLIENT_CUSTOM_DATA.CUSTOMIZE_NODE,CLIENT_CUSTOM_DATA.FULL_CUSTOMIZE_NAM,CLIENT_CUSTOM_DATA.SEQUENCE_NO");
   m_hQuery.setOrderByClause(strOrderByClause);
   bSuccess = pSelectStatement->execute(m_hQuery);
   if (bSuccess == false || pSelectStatement->getRows() == 0)
   {
      UseCase::setSuccess(bSuccess);
      SOAPSegment::instance()->setRtnCde(bSuccess ? '2' : '5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::SettingsCommand::execute%6682BA67039A.body
}

void SettingsCommand::update (Subject* pSubject)
{
  //## begin restcommand::SettingsCommand::update%6682BA8603AE.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iTotalRows;
      if (m_iTotalRows > m_iSkipRows)
      {
         if ((m_iTotalRows - m_iSkipRows) <= m_iMaxRows)
         {
            m_hGenericSegment.reset();
            m_hGenericSegment.set("CUSTOMIZE_NODE", m_strCustomizeNode);
            m_hGenericSegment.set("FULL_CUSTOMIZE_NAM", m_strFullCustomizeName);
            m_hGenericSegment.set("SEQUENCE_NO", m_siSequenceNo);
            m_hGenericSegment.set("CUSTOMIZE_DATA", m_strCustomizeData);
            if (m_pXMLDocument->add("row") == false)
            {
               m_pXMLDocument->revert();
               m_hQuery.setAbort(true);
               return;
            }
            m_iRows = m_iTotalRows;
            UseCase::addItem();
         }
         else
            SOAPSegment::instance()->setRtnCde('1');
      }
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::SettingsCommand::update%6682BA8603AE.body
}

// Additional Declarations
  //## begin restcommand::SettingsCommand%6682B7B70258.declarations preserve=yes
  //## end restcommand::SettingsCommand%6682B7B70258.declarations

} // namespace restcommand

//## begin module%6682B601005F.epilog preserve=yes
//## end module%6682B601005F.epilog
