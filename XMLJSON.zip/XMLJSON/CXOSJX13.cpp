//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B011E50398.cm preserve=no
//## end module%65B011E50398.cm

//## begin module%65B011E50398.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B011E50398.cp

//## Module: CXOSJX13%65B011E50398; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX13.cpp

//## begin module%65B011E50398.additionalIncludes preserve=no
//## end module%65B011E50398.additionalIncludes

//## begin module%65B011E50398.includes preserve=yes
//## end module%65B011E50398.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX13_h
#include "CXODJX13.hpp"
#endif


//## begin module%65B011E50398.declarations preserve=no
//## end module%65B011E50398.declarations

//## begin module%65B011E50398.additionalDeclarations preserve=yes
//## end module%65B011E50398.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ConfigurationCommand 

ConfigurationCommand::ConfigurationCommand()
  //## begin ConfigurationCommand::ConfigurationCommand%65B010C90017_const.hasinit preserve=no
  //## end ConfigurationCommand::ConfigurationCommand%65B010C90017_const.hasinit
  //## begin ConfigurationCommand::ConfigurationCommand%65B010C90017_const.initialization preserve=yes
   : m_pPersistentSegment(0)
   ,RESTCommand("/rest/datanavigator/configure/configuration/v1.0.0","S0003D","@##JLCNFG ")
   , m_bAuthorize(false)
  //## end ConfigurationCommand::ConfigurationCommand%65B010C90017_const.initialization
{
  //## begin restcommand::ConfigurationCommand::ConfigurationCommand%65B010C90017_const.body preserve=yes
   memcpy(m_sID, "JX13", 4);
  //## end restcommand::ConfigurationCommand::ConfigurationCommand%65B010C90017_const.body
}

ConfigurationCommand::ConfigurationCommand (Handler* pSuccessor)
  //## begin restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.hasinit preserve=no
  //## end restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.hasinit
  //## begin restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.initialization preserve=yes
   : m_pPersistentSegment(0)
   ,RESTCommand("/rest/datanavigator/configure/configuration/v1.0.0","S0003D","@##JLCNFG ")
   , m_bAuthorize(false)
  //## end restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.initialization
{
  //## begin restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.body preserve=yes
   memcpy(m_sID, "JX13", 4);
   m_pSuccessor = pSuccessor;
   loadTemplate();
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ConfigurationCommand::ConfigurationCommand%65B01169024B.body
}


ConfigurationCommand::~ConfigurationCommand()
{
  //## begin restcommand::ConfigurationCommand::~ConfigurationCommand%65B010C90017_dest.body preserve=yes
   delete m_pPersistentSegment;
  //## end restcommand::ConfigurationCommand::~ConfigurationCommand%65B010C90017_dest.body
}



//## Other Operations (implementation)
bool ConfigurationCommand::endElement (const string& strTag)
{
  //## begin restcommand::ConfigurationCommand::endElement%67F94B58025A.body preserve=yes
   if (strTag == "filter" )
   {
      size_t pos = string::npos;
      m_strColumn.assign(m_pXMLItem->get("column"));
      if ((pos = m_strColumn.find_last_of(",")) != string::npos)
         m_strColumn.erase(0, pos + 1);
      if (m_pXMLItem->get("column") == "authorized")
         m_bAuthorize = (m_pXMLItem->get("value") == "true");
      else
      {
         m_strOperator.assign(m_pXMLItem->get("operator"));
         if ((pos = m_strOperator.find_last_of(",")) != string::npos)
            m_strOperator.erase(0, pos + 1);
         m_strValue.assign(m_pXMLItem->get("value"));
         if ( (pos = m_strValue.find_last_of(",")) != string::npos)
            m_strValue.erase(0, pos + 1);
      }
   }
   return true;
  //## end restcommand::ConfigurationCommand::endElement%67F94B58025A.body
}

bool ConfigurationCommand::execute ()
{
  //## begin restcommand::ConfigurationCommand::execute%65B0118A00DE.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX13 LIST CONFIGURATION");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLCNFG", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX13", &m_hRow, &m_hXMLText);
#endif
   m_strOperator.clear();
   m_strColumn.clear();
   m_strValue.clear();
   m_strTagName.erase();
   m_strRPT_LVL_NAME.erase();
   m_strDESCRIPTION_TEXT.erase();
   m_strENTITY_TYPE[0].erase();
   m_strENTITY_TYPE[1].erase();
   m_pXMLItem->reset();
   m_pXMLDocument->reset();
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_bUpdateDetails = true;
   m_bAuthorize = false;
   int iRC = parse();
   m_pXMLDocument->setMaximumSize(1000000);
   m_strTagName = m_pXMLItem->get("name");
   map<string, pair<string, string>, less<string> >::iterator p = m_hTags.find(m_strTagName);
   if (iRC != 0
      || m_strTagName.empty()
      || p == m_hTags.end())
   {
      SOAPSegment::instance()->setRtnCde('3');
      return reply();
   }
   m_hGenericSegment.set("Tab", m_strTagName.c_str());
   save();
   m_pXMLDocument->add("tab");
   string strColumnName = "^" + m_strTagName;
   m_pXMLDocument->add(strColumnName.c_str());
   string strTableName((*p).second.first);
   m_hQuery.reset();
   if (!m_pPersistentSegment)
      m_pPersistentSegment = new PersistentSegment("XXXX", strTableName.c_str(), "QUALIFY");
   else if (m_pPersistentSegment->getTableName() != strTableName)
   {
      delete m_pPersistentSegment;
      m_pPersistentSegment = new PersistentSegment("XXXX", strTableName.c_str(), "QUALIFY");
   }
   m_hXMLText.add('Z', m_pPersistentSegment);
   auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_pPersistentSegment->bindPerCatalog(m_hQuery);
   if (!m_strValue.empty())
   {
      if (m_strTagName == "MiscData")
         m_hQuery.setBasicPredicate(strTableName.c_str(), "CFG_DATA_TYPE", "=", m_strValue.c_str());
      else
         m_hQuery.setBasicPredicate(strTableName.c_str(), (*p).second.second.c_str(), m_strOperator.c_str(), m_strValue.c_str());
   }
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   strCUST_ID.insert(0, "('");
   strCUST_ID.append("','****')");
   if (strTableName != "AS_PROFILE_ENTRY"
      && strTableName != "AS_PERMISSION"
      && strTableName != "AS_WIDGET_RESTRICT"
      && strTableName != "EMSR_ACTION"
      && strTableName != "EMSR_PHASE"
      && strTableName != "EMSR_STATE"
      && strTableName != "EMSR_STATUS")
   {
      m_hQuery.setBasicPredicate(strTableName.c_str(), "CUST_ID", "IN", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate(strTableName.c_str(), "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate(strTableName.c_str(), "CC_STATE", "=", "A");
   }
   if (strTableName == "DEVICE")
   {
      m_hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "RPT_LVL_ID");
      m_hQuery.setQualifier("QUALIFY", "REPORTING_LVL");
      m_hQuery.bind("REPORTING_LVL", "RPT_LVL_NAME", Column::STRING, &m_strRPT_LVL_NAME);
   }
   if (strTableName == "INSTITUTION")
   {
      m_hQuery.join("INSTITUTION", "LEFT OUTER", "T_FIN_ENTITY AI", "INST_ID", "ENTITY_ID");
      m_hQuery.join(0, "LEFT OUTER", "T_FIN_ENTITY AI", "AI", "ENTITY_TYPE");
      m_hQuery.join("INSTITUTION", "LEFT OUTER", "T_FIN_ENTITY II", "INST_ID", "ENTITY_ID");
      m_hQuery.join(0, "LEFT OUTER", "T_FIN_ENTITY II", "II", "ENTITY_TYPE");
      m_hQuery.bind("T_FIN_ENTITY AI", "ENTITY_TYPE", Column::STRING, &m_strENTITY_TYPE[0]);
      m_hQuery.bind("T_FIN_ENTITY II", "ENTITY_TYPE", Column::STRING, &m_strENTITY_TYPE[1]);
   }
   if (strTableName.substr(0, 5) == "EMSR_")
   {
      m_hQuery.setQualifier("QUALIFY", strTableName.c_str());
      m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
      m_hQuery.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", Column::STRING, &m_strDESCRIPTION_TEXT);
      m_hQuery.setBasicPredicate("EMSR_DESC_TEXT", "LANGUAGE", "=", "ENGLISH");
      if (strTableName == "EMSR_PHASE")
      {
         m_hQuery.join("EMSR_PHASE", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
         m_hQuery.join("EMSR_PHASE", "INNER", "EMSR_DESC_TEXT", "PHASE_STAT", "DESCRIPTION_STAT");
         m_hQuery.setBasicPredicate("EMSR_PHASE", "PHASE_ID",
            "NOT IN", "('INIT','MANO','ZALL')");
         m_hQuery.setBasicPredicate("EMSR_PHASE", "PHASE_STAT", "=", "P");
      }
      else if (strTableName == "EMSR_STATUS")
      {
         m_hQuery.join("EMSR_STATUS", "INNER", "EMSR_DESC_TEXT", "BUS_DESCRIPTION", "DESCRIPTION_ID");
         m_hQuery.join("EMSR_STATUS", "INNER", "EMSR_DESC_TEXT", "STATUS_STAT", "DESCRIPTION_STAT");
         m_hQuery.setBasicPredicate("EMSR_STATUS", "STATUS_ID", "<>", "TEMP");
         m_hQuery.setBasicPredicate("EMSR_STATUS", "STATUS_STAT", "=", "P");
      }
      else if (strTableName == "EMSR_ACTION")
      {
         m_hQuery.join("EMSR_ACTION", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
         m_hQuery.join("EMSR_ACTION", "INNER", "EMSR_DESC_TEXT", "ACTION_STAT", "DESCRIPTION_STAT");
         m_hQuery.setBasicPredicate("EMSR_ACTION", "ACTION_STAT", "=", "P");
      }
      else if (strTableName == "EMSR_STATE")
      {
         m_hQuery.setDistinct(true);
         m_hQuery.join("EMSR_STATE", "INNER", "EMSR_RULE_SET", "RULE_SET_ID");
         m_hQuery.join("EMSR_STATE", "INNER", "EMSR_RULE_SET", "RULE_SET_STAT");
         m_hQuery.join("EMSR_STATE", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
         m_hQuery.join("EMSR_STATE", "INNER", "EMSR_DESC_TEXT", "RULE_SET_STAT", "DESCRIPTION_STAT");
         m_hQuery.setQualifier("QUALIFY", "EMSR_RULE_SET");
         m_hQuery.setBasicPredicate("EMSR_STATE", "STATUS_ID", "<>", "TEMP");
         m_hQuery.setBasicPredicate("EMSR_STATE", "RULE_SET_STAT", "=", "P");
         m_hQuery.setBasicPredicate("EMSR_RULE_SET", "CUST_ID", "IN", strCUST_ID.c_str());
      }
   }
   if (m_bAuthorize)
   {
      if (strTableName == "INSTITUTION")
      {
         m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "PROC_ID");
         m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "CUST_ID");
         m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
         m_hQuery.getSearchCondition().append(" AND (");
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "IN", ClientCommand::secure(ClientCommand::ProcessorGroup), false, false);
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_ID", "IN", ClientCommand::secure(ClientCommand::Processor));
         m_hQuery.setBasicPredicate("INSTITUTION", "INST_ID", "IN", ClientCommand::secure(ClientCommand::Institution), false, false);
         m_hQuery.setBasicPredicate(0, "'*'", "IN", ClientCommand::secure(ClientCommand::All), false, false);
         m_hQuery.getSearchCondition().append(")");

      }
      else if (strTableName == "PROCESSOR")
      {
         m_hQuery.getSearchCondition().append(" AND (");
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "IN", ClientCommand::secure(ClientCommand::ProcessorGroup), false, false);
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_ID", "IN", ClientCommand::secure(ClientCommand::Processor));
         m_hQuery.setBasicPredicate(0, "'*'", "IN", ClientCommand::secure(ClientCommand::All), false, false);
         m_hQuery.getSearchCondition().append(")");
      }
      else if (strTableName == "PROCESSOR_GRP")
      {
         m_hQuery.getSearchCondition().append(" AND (");
         m_hQuery.setBasicPredicate("PROCESSOR_GRP", "PROC_GRP_ID", "IN", ClientCommand::secure(ClientCommand::ProcessorGroup), false, false);
         m_hQuery.setBasicPredicate(0, "'*'", "IN", ClientCommand::secure(ClientCommand::All), false, false);
         m_hQuery.getSearchCondition().append(")");

      }
      else if (strTableName == "REPORTING_LVL")
      {
         m_hQuery.getSearchCondition().append(" AND (");
         m_hQuery.setBasicPredicate("REPORTING_LVL", "RPT_LVL_ID", "IN", ClientCommand::secure(ClientCommand::ReportingLevel), false, false);
         m_hQuery.setBasicPredicate(0, "'*'", "IN", ClientCommand::secure(ClientCommand::All), false, false);
         m_hQuery.getSearchCondition().append(")");
      }
      else if (strTableName == "DEVICE")
      {
         m_hQuery.join("DEVICE", "INNER", "INSTITUTION", "INST_ID");
         m_hQuery.join("DEVICE", "INNER", "INSTITUTION", "CUST_ID");
         m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "PROC_ID");
         m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "CUST_ID");
         m_hQuery.setQualifier("QUALIFY", "INSTITUTION");
         m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
         m_hQuery.getSearchCondition().append(" AND (");
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "IN", ClientCommand::secure(ClientCommand::ProcessorGroup), false, false);
         m_hQuery.setBasicPredicate("PROCESSOR", "PROC_ID", "IN", ClientCommand::secure(ClientCommand::Processor));
         m_hQuery.setBasicPredicate("INSTITUTION", "INST_ID", "IN", ClientCommand::secure(ClientCommand::Institution), false, false);
         m_hQuery.setBasicPredicate("DEVICE", "RPT_LVL_ID", "IN", ClientCommand::secure(ClientCommand::ReportingLevel), false, false);
         m_hQuery.setBasicPredicate("DEVICE", "DEVICE_ID", "IN", ClientCommand::secure(ClientCommand::Device), false, false);
         m_hQuery.setBasicPredicate(0, "'*'", "IN", ClientCommand::secure(ClientCommand::All), false, false);
         m_hQuery.getSearchCondition().append(")");
      }
   }
   m_hQuery.setOrderByClause((*p).second.second);
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false || pSelectStatement->getRows() == 0)
   {
      revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
      return reply();
   }
   m_pXMLDocument->write("tab");
   return reply();
  //## end restcommand::ConfigurationCommand::execute%65B0118A00DE.body
}

void ConfigurationCommand::update (Subject* pSubject)
{
  //## begin restcommand::ConfigurationCommand::update%65B0118D0142.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iTotalRows;
      if (m_iTotalRows <= m_iSkipRows
         || m_pXMLDocument->getFull())
         return;
      if ((m_iTotalRows - m_iSkipRows) <= m_iMaxRows)
      {
         save();
         if (m_pXMLDocument->add("row") == false)
         {
            SOAPSegment::instance()->setRtnCde('1');
            revert();
            return;
         }
         if (m_strTagName == "Device")
         {
            m_hGenericSegment.set("RPT_LVL_NAME", m_strRPT_LVL_NAME);
            m_strRPT_LVL_NAME.erase();
         }
         else if (m_strTagName == "DisputeAction" || m_strTagName == "DisputePhase" || m_strTagName == "DisputeState" || m_strTagName == "DisputeStatus")
         {
            m_hGenericSegment.set("DESCRIPTION_TEXT", m_strDESCRIPTION_TEXT);
            m_strDESCRIPTION_TEXT.erase();
         }
         else if (m_strTagName == "Institution")
         {
            if (m_strENTITY_TYPE[0].empty() == false && m_strENTITY_TYPE[1].empty())
               m_hGenericSegment.set("ROLE", "A");
            else if (m_strENTITY_TYPE[0].empty() && m_strENTITY_TYPE[1].empty() == false)
               m_hGenericSegment.set("ROLE", "I");
            else
               m_hGenericSegment.set("ROLE", "B");
         }
         if (m_pXMLDocument->add(m_strTagName.c_str()) == false)
         {
            SOAPSegment::instance()->setRtnCde('1');
            revert();
            return;
         }
         m_iRows = m_iTotalRows;
         m_pXMLDocument->write("row");
      }
      else 
         SOAPSegment::instance()->setRtnCde('1');
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ConfigurationCommand::update%65B0118D0142.body
}

bool ConfigurationCommand::loadTemplate ()
{
  //## begin restcommand::ConfigurationCommand::loadTemplate%65CA554200B9.body preserve=yes
#ifdef MVS
   FlatFile hFlatFile("SCRIPT", "CRSCRIPT");
#else
   FlatFile hFlatFile("SOURCE", "CXOLCRDL");
#endif
   string strBuffer;
   char sBuffer[256];
   size_t m = 0;
   vector<string> hTokens;
   string strValue;
   while (hFlatFile.read(sBuffer, 256, &m))
   {
      if (m > 1 && (sBuffer[0] == '#' || sBuffer[0] == '%' || sBuffer[0] == '!'))
      {
         strBuffer.assign(sBuffer + 1, m - 1);
         Buffer::parse(strBuffer, " ", hTokens);
         if (sBuffer[0] == '#' || sBuffer[0] == '!')
            strValue.assign(hTokens[0].data(), hTokens[0].length());
         else if (sBuffer[0] == '%')
            m_hTags.insert(map<string, pair<string, string>, less<string> >::value_type(hTokens[0], make_pair(strValue, hTokens[1])));
      }
      hTokens.clear();
   }
   return true;
  //## end restcommand::ConfigurationCommand::loadTemplate%65CA554200B9.body
}

// Additional Declarations
  //## begin restcommand::ConfigurationCommand%65B010C90017.declarations preserve=yes
  //## end restcommand::ConfigurationCommand%65B010C90017.declarations

} // namespace restcommand

//## begin module%65B011E50398.epilog preserve=yes
//## end module%65B011E50398.epilog
