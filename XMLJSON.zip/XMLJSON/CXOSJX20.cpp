//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66702ACC038F.cm preserve=no
//## end module%66702ACC038F.cm

//## begin module%66702ACC038F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66702ACC038F.cp

//## Module: CXOSJX20%66702ACC038F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX20.cpp

//## begin module%66702ACC038F.additionalIncludes preserve=no
//## end module%66702ACC038F.additionalIncludes

//## begin module%66702ACC038F.includes preserve=yes
//## end module%66702ACC038F.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX20_h
#include "CXODJX20.hpp"
#endif


//## begin module%66702ACC038F.declarations preserve=no
//## end module%66702ACC038F.declarations

//## begin module%66702ACC038F.additionalDeclarations preserve=yes
//## end module%66702ACC038F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ProfilesCommand 

ProfilesCommand::ProfilesCommand()
  //## begin ProfilesCommand::ProfilesCommand%66702D6103AB_const.hasinit preserve=no
  //## end ProfilesCommand::ProfilesCommand%66702D6103AB_const.hasinit
  //## begin ProfilesCommand::ProfilesCommand%66702D6103AB_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/profiles/v1.0.0", "S0003D", "@##JLUSER ")
  //## end ProfilesCommand::ProfilesCommand%66702D6103AB_const.initialization
{
  //## begin restcommand::ProfilesCommand::ProfilesCommand%66702D6103AB_const.body preserve=yes
   memcpy(m_sID, "JX20", 4);
  //## end restcommand::ProfilesCommand::ProfilesCommand%66702D6103AB_const.body
}

ProfilesCommand::ProfilesCommand (Handler* pSuccessor)
  //## begin restcommand::ProfilesCommand::ProfilesCommand%66703229022B.hasinit preserve=no
  //## end restcommand::ProfilesCommand::ProfilesCommand%66703229022B.hasinit
  //## begin restcommand::ProfilesCommand::ProfilesCommand%66703229022B.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/profiles/v1.0.0", "S0003D", "@##JLUSER ")
  //## end restcommand::ProfilesCommand::ProfilesCommand%66703229022B.initialization
{
  //## begin restcommand::ProfilesCommand::ProfilesCommand%66703229022B.body preserve=yes
   memcpy(m_sID, "JX20", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ProfilesCommand::ProfilesCommand%66703229022B.body
}


ProfilesCommand::~ProfilesCommand()
{
  //## begin restcommand::ProfilesCommand::~ProfilesCommand%66702D6103AB_dest.body preserve=yes
  //## end restcommand::ProfilesCommand::~ProfilesCommand%66702D6103AB_dest.body
}



//## Other Operations (implementation)
bool ProfilesCommand::execute ()
{
  //## begin restcommand::ProfilesCommand::execute%6670328400A5.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX20 GET USER SECURITY DATA");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLUSER", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX20", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC;
   iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY", "AS_USER_PROFILE");
   m_hQuery.setQualifier("QUALIFY", "AS_PROFILE_ENTRY");
   m_hQuery.setDistinct(true);
   m_hQuery.join("AS_USER_PROFILE", "INNER", "AS_PROFILE_ENTRY", "PROFILE_ID");
   m_hQuery.bind("AS_PROFILE_ENTRY", "PROFILE_ID", Column::STRING, &m_strPROFILE_ID);
   m_hQuery.bind("AS_PROFILE_ENTRY", "RELATIONSHIP_ID", Column::STRING, &m_strRELATIONSHIP_ID);
   m_hQuery.bind("AS_PROFILE_ENTRY", "PERMISSION_ID", Column::STRING, &m_strPERMISSION_ID);
   m_hQuery.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", strCustomerID.c_str());
   m_hQuery.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   string strOrder = "AS_PROFILE_ENTRY.PROFILE_ID ASC";
   strOrder.append(",AS_PROFILE_ENTRY.RELATIONSHIP_ID ASC");
   strOrder.append(",AS_PROFILE_ENTRY.PERMISSION_ID ASC");
   m_hQuery.setOrderByClause(strOrder.c_str());
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ProfilesCommand::execute%6670328400A5.body
}

void ProfilesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ProfilesCommand::update%667032D70271.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iTotalRows;
      if (m_iMaxRows == 0)
         setMaxRows(100);
      if (m_iTotalRows > m_iSkipRows)
      {
         if (m_iTotalRows - m_iSkipRows <= m_iMaxRows)
         {
            m_hGenericSegment.set("PROFILE_ID", m_strPROFILE_ID);
            m_hGenericSegment.set("RELATIONSHIP_ID", m_strRELATIONSHIP_ID);
            m_hGenericSegment.set("PERMISSION_ID", m_strPERMISSION_ID);
            m_pXMLDocument->add("row");
            m_iRows = m_iTotalRows;
            UseCase::addItem();
         }
         else
            SOAPSegment::instance()->setRtnCde('1');
      }
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ProfilesCommand::update%667032D70271.body
}

// Additional Declarations
  //## begin restcommand::ProfilesCommand%66702D6103AB.declarations preserve=yes
  //## end restcommand::ProfilesCommand%66702D6103AB.declarations

} // namespace restcommand

//## begin module%66702ACC038F.epilog preserve=yes
//## end module%66702ACC038F.epilog
