//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66790EA10204.cm preserve=no
//## end module%66790EA10204.cm

//## begin module%66790EA10204.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66790EA10204.cp

//## Module: CXOSJX21%66790EA10204; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX21.cpp

//## begin module%66790EA10204.additionalIncludes preserve=no
//## end module%66790EA10204.additionalIncludes

//## begin module%66790EA10204.includes preserve=yes
//## end module%66790EA10204.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSJX21_h
#include "CXODJX21.hpp"
#endif


//## begin module%66790EA10204.declarations preserve=no
//## end module%66790EA10204.declarations

//## begin module%66790EA10204.additionalDeclarations preserve=yes
//## end module%66790EA10204.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::SaveSettingsCommand 

SaveSettingsCommand::SaveSettingsCommand()
  //## begin SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.hasinit preserve=no
      : m_iReturn(0)
  //## end SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.hasinit
  //## begin SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/secure/savesettings/v1.0.0", "S0003D", "@##JUCUST ")
  //## end SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.initialization
{
  //## begin restcommand::SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.body preserve=yes
   memcpy(m_sID, "JX21", 4);
  //## end restcommand::SaveSettingsCommand::SaveSettingsCommand%667910C400BD_const.body
}

SaveSettingsCommand::SaveSettingsCommand (Handler* pSuccessor)
  //## begin restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.hasinit preserve=no
      : m_iReturn(0)
  //## end restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.hasinit
  //## begin restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/secure/savesettings/v1.0.0", "S0003D", "@##JUCUST ")
  //## end restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.initialization
{
  //## begin restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.body preserve=yes
   memcpy(m_sID, "JX21", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::SaveSettingsCommand::SaveSettingsCommand%667913A4025A.body
}


SaveSettingsCommand::~SaveSettingsCommand()
{
  //## begin restcommand::SaveSettingsCommand::~SaveSettingsCommand%667910C400BD_dest.body preserve=yes
  //## end restcommand::SaveSettingsCommand::~SaveSettingsCommand%667910C400BD_dest.body
}



//## Other Operations (implementation)
bool SaveSettingsCommand::endElement (const string& strTag)
{
  //## begin restcommand::SaveSettingsCommand::endElement%667BB05200FB.body preserve=yes
   if (m_iReturn == 0)
   {
      if(strTag == "column")
         m_hColumns.push_back(m_pXMLItem->get("column"));
      if (strTag == "value")
         m_hValues.push_back(m_pXMLItem->get("value"));
      if (strTag == "row")
      {
         if (m_hColumns.empty() || m_hColumns.size() != 5 || m_hValues.empty() || m_hValues.size() != 5)
            m_iReturn = 1;
         else if (false == save())
            m_iReturn = 2;
         m_hValues.clear();
      }
      m_pXMLItem->resetToken();
      if (m_iReturn != 0)
         Database::instance()->rollback();
   }
   return true;
  //## end restcommand::SaveSettingsCommand::endElement%667BB05200FB.body
}

bool SaveSettingsCommand::execute ()
{
  //## begin restcommand::SaveSettingsCommand::execute%667913FD0002.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX21 UPDATE CUSTOMIZATION");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJUCUST", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX21", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC;
   iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0 || m_iReturn == 1)
   {
      UseCase::setSuccess(false);
      SOAPSegment::instance()->setRtnCde('3');
      SOAPSegment::instance()->setTxt("Invalid request (parse failure)");
   }
   else if (m_iReturn == 2)
   {
      UseCase::setSuccess(false);
      SOAPSegment::instance()->setRtnCde('5');
   }
   m_iReturn = 0;
   m_hColumns.clear();
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::SaveSettingsCommand::execute%667913FD0002.body
}

bool SaveSettingsCommand::save ()
{
  //## begin restcommand::SaveSettingsCommand::save%667BB0F9001D.body preserve=yes
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   Query hQuery;
   UseCase::addItem();
   hQuery.reset();
   hQuery.setQualifier("QUALIFY", "CLIENT_CUSTOM_DATA");
   hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "CUSTOMIZE_NODE", "=", m_hValues[1].c_str());
   hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA", "FULL_CUSTOMIZE_NAM", "=", m_hValues[2].c_str());
   reusable::Table hTable;
   hTable.reset();
   hTable.setName("CLIENT_CUSTOM_DATA");
   hTable.setQualifier("QUALIFY");
   hTable.set("CUSTOMIZE_NODE", m_hValues[1].c_str(), false, true);
   hTable.set("FULL_CUSTOMIZE_NAM", m_hValues[2].c_str(), false, true);
   hTable.set("SEQUENCE_NO", atoi(m_hValues[3].c_str()), true);
   hTable.set("CUSTOMIZE_DATA", m_hValues[4].c_str());
   if (m_hValues[0][0] == 'D')
   {
      if (pDeleteStatement->execute(hQuery) == false)
         return false;
   }
   else if (m_hValues[0][0] == 'U')
   {
      if (atoi(m_hValues[3].c_str()) == 1)
         if (pDeleteStatement->execute(hQuery) == false)
            return false;
      if (pInsertStatement->execute(hTable) == false)
         return false;
   }
   else
      return false;
   return true;
  //## end restcommand::SaveSettingsCommand::save%667BB0F9001D.body
}

void SaveSettingsCommand::update (Subject* pSubject)
{
  //## begin restcommand::SaveSettingsCommand::update%667BBA2401AC.body preserve=yes
   RESTCommand::update(pSubject);
  //## end restcommand::SaveSettingsCommand::update%667BBA2401AC.body
}

// Additional Declarations
  //## begin restcommand::SaveSettingsCommand%667910C400BD.declarations preserve=yes
  //## end restcommand::SaveSettingsCommand%667910C400BD.declarations

} // namespace restcommand

//## begin module%66790EA10204.epilog preserve=yes
//## end module%66790EA10204.epilog
