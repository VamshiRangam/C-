//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A02F1F017A.cm preserve=no
//## end module%67A02F1F017A.cm

//## begin module%67A02F1F017A.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%67A02F1F017A.cp

//## Module: CXOSJX35%67A02F1F017A; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX35.cpp

//## begin module%67A02F1F017A.additionalIncludes preserve=no
//## end module%67A02F1F017A.additionalIncludes

//## begin module%67A02F1F017A.includes preserve=yes
#include "CXODNS40.hpp"
//## end module%67A02F1F017A.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSJX35_h
#include "CXODJX35.hpp"
#endif


//## begin module%67A02F1F017A.declarations preserve=no
//## end module%67A02F1F017A.declarations

//## begin module%67A02F1F017A.additionalDeclarations preserve=yes
//## end module%67A02F1F017A.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReportDaysCommand 

ReportDaysCommand::ReportDaysCommand()
  //## begin ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.hasinit preserve=no
  //## end ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.hasinit
  //## begin ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.initialization preserve=yes
  //## end ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.initialization
{
  //## begin restcommand::ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.body preserve=yes
  //## end restcommand::ReportDaysCommand::ReportDaysCommand%67A02EAF00CD_const.body
}

ReportDaysCommand::ReportDaysCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.hasinit preserve=no
  //## end restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.hasinit
  //## begin restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/report/days/v1.0.0","S0003D","@##JLDAYS ")
  //## end restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.initialization
{
  //## begin restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.body preserve=yes
   memcpy(m_sID,"JX35",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReportDaysCommand::ReportDaysCommand%67A037FA001A.body
}


ReportDaysCommand::~ReportDaysCommand()
{
  //## begin restcommand::ReportDaysCommand::~ReportDaysCommand%67A02EAF00CD_dest.body preserve=yes
  //## end restcommand::ReportDaysCommand::~ReportDaysCommand%67A02EAF00CD_dest.body
}



//## Other Operations (implementation)
bool ReportDaysCommand::execute ()
{
  //## begin restcommand::ReportDaysCommand::execute%67A038170024.body preserve=yes
   UseCase hUseCase("CLIENT","## JX35 LIST REPORT DAYS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLDAYS",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX35",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   m_hQuery.setDistinct(true);
   m_hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,0);
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   m_hQuery.accept(*pFormatSelectVisitor);
   string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") X";
   m_hQuery.reset();
   m_hQuery.attach(this);
   m_hQuery.join("T_FIN_ENTITY E","INNER","T_FIN_PERIOD P","T_FIN_ENTITY_ID");
   m_hQuery.join("T_FIN_ENTITY E","INNER","T_FIN_PERIOD P","ENTITY_TYPE","'CU'"); // AND E.ENTITY_TYPE = 'CU'
   m_hQuery.join("T_FIN_ENTITY P","RIGHT OUTER",strSubSelect.c_str(),"DATE_RECON");
   m_hQuery.bind("T_FIN_PERIOD P","DATE_RECON",Column::STRING,&m_strDATE_RECON[0]);
   m_hQuery.bind("X","DATE_RECON",Column::STRING,&m_strDATE_RECON[1]);
   m_hQuery.bind("T_FIN_PERIOD P","TSTAMP_END",Column::STRING,&m_strTSTAMP_END);
   m_hQuery.bind("T_FIN_PERIOD P","TSTAMP_LAST_UPDATE",Column::STRING,&m_strTSTAMP_LAST_UPDATE);
   m_hQuery.bind("T_FIN_PERIOD P","TSTAMP_TRANS_FROM",Column::STRING,&m_strTSTAMP_TRANS_FROM);
   m_hQuery.bind("T_FIN_PERIOD P","TSTAMP_TRANS_TO",Column::STRING,&m_strTSTAMP_TRANS_TO);
   m_hQuery.setBasicPredicate("X","DATE_RECON","<=",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1).c_str());
   m_hQuery.setOrderByClause("X.DATE_RECON DESC,P.TSTAMP_END DESC");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReportDaysCommand::execute%67A038170024.body
}

void ReportDaysCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReportDaysCommand::update%67A038190397.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.reset();
      m_hGenericSegment.set("Date",m_strDATE_RECON[1]);
      m_hGenericSegment.set("EndOfDay",m_strTSTAMP_END);
      m_hGenericSegment.set("FirstTransaction",m_strTSTAMP_TRANS_FROM);
      m_hGenericSegment.set("LastTransaction",m_strTSTAMP_TRANS_TO);
      m_hGenericSegment.set("Updated",m_strTSTAMP_LAST_UPDATE);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ReportDaysCommand::update%67A038190397.body
}

// Additional Declarations
  //## begin restcommand::ReportDaysCommand%67A02EAF00CD.declarations preserve=yes
  //## end restcommand::ReportDaysCommand%67A02EAF00CD.declarations

} // namespace restcommand

//## begin module%67A02F1F017A.epilog preserve=yes
//## end module%67A02F1F017A.epilog
