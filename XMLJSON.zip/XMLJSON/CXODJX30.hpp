//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%673D83F802E7.cm preserve=no
//## end module%673D83F802E7.cm

//## begin module%673D83F802E7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%673D83F802E7.cp

//## Module: CXOSJX30%673D83F802E7; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX30.hpp

#ifndef CXOSJX30_h
#define CXOSJX30_h 1

//## begin module%673D83F802E7.additionalIncludes preserve=no
//## end module%673D83F802E7.additionalIncludes

//## begin module%673D83F802E7.includes preserve=yes
//## end module%673D83F802E7.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
class EMSNetRuleUseTable;
class EMSNetRuleUse;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class FinancialSettlementSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%673D83F802E7.declarations preserve=no
//## end module%673D83F802E7.declarations

//## begin module%673D83F802E7.additionalDeclarations preserve=yes
//## end module%673D83F802E7.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::RulesetCommand%673D84C3035B.preface preserve=yes
//## end restcommand::RulesetCommand%673D84C3035B.preface

//## Class: RulesetCommand%673D84C3035B
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST Ruleset
//	<h6>Resolve : REST : Ruleset
//	<p>
//	Returns the EMS rule set for a transaction or a case.
//	<p>
//	<ul>
//	<li><a href="../../REST/resolve/ruleset.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%673D855203CA;monitor::UseCase { -> F}
//## Uses: <unnamed>%673D855700BB;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%673D94B4036A;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%673D94F50251;ems::EMSNetRuleUse { -> F}
//## Uses: <unnamed>%673D950C03B8;ems::EMSNetRuleUseTable { -> F}
//## Uses: <unnamed>%673D969202B4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%673D972F03D6;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%673D97B10385;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%673D980C00C3;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%673D992003A3;ems::Case { -> F}
//## Uses: <unnamed>%6744499602D0;reusable::Buffer { -> F}
//## Uses: <unnamed>%6746F5CB0009;reusable::Query { -> F}

class DllExport RulesetCommand : public command::RESTCommand  //## Inherits: <unnamed>%673D854C0132
{
  //## begin restcommand::RulesetCommand%673D84C3035B.initialDeclarations preserve=yes
  //## end restcommand::RulesetCommand%673D84C3035B.initialDeclarations

  public:
    //## Constructors (generated)
      RulesetCommand();

    //## Constructors (specified)
      //## Operation: RulesetCommand%673D86130225
      RulesetCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~RulesetCommand();


    //## Other Operations (specified)
      //## Operation: execute%673D865103C0
      virtual bool execute ();

      //## Operation: update%673D8E040257
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::RulesetCommand%673D84C3035B.public preserve=yes
      //## end restcommand::RulesetCommand%673D84C3035B.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::RulesetCommand%673D84C3035B.protected preserve=yes
      //## end restcommand::RulesetCommand%673D84C3035B.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::RulesetCommand%673D84C3035B.private preserve=yes
      //## end restcommand::RulesetCommand%673D84C3035B.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%673D9F94017A
      //## Role: RulesetCommand::<m_hGenericSegment>%673D9F9501F6
      //## begin restcommand::RulesetCommand::<m_hGenericSegment>%673D9F9501F6.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::RulesetCommand::<m_hGenericSegment>%673D9F9501F6.role

    // Additional Implementation Declarations
      //## begin restcommand::RulesetCommand%673D84C3035B.implementation preserve=yes
      //## end restcommand::RulesetCommand%673D84C3035B.implementation

};

//## begin restcommand::RulesetCommand%673D84C3035B.postscript preserve=yes
//## end restcommand::RulesetCommand%673D84C3035B.postscript

} // namespace restcommand

//## begin module%673D83F802E7.epilog preserve=yes
//## end module%673D83F802E7.epilog


#endif
