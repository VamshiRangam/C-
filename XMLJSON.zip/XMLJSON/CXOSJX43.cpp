//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%681DF72D01F5.cm preserve=no
//## end module%681DF72D01F5.cm

//## begin module%681DF72D01F5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%681DF72D01F5.cp

//## Module: CXOSJX43%681DF72D01F5; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX43.cpp

//## begin module%681DF72D01F5.additionalIncludes preserve=no
//## end module%681DF72D01F5.additionalIncludes

//## begin module%681DF72D01F5.includes preserve=yes
//## end module%681DF72D01F5.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSJX43_h
#include "CXODJX43.hpp"
#endif


//## begin module%681DF72D01F5.declarations preserve=no
//## end module%681DF72D01F5.declarations

//## begin module%681DF72D01F5.additionalDeclarations preserve=yes
//## end module%681DF72D01F5.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::CaseChangesCommand 

CaseChangesCommand::CaseChangesCommand()
  //## begin CaseChangesCommand::CaseChangesCommand%681DF8220325_const.hasinit preserve=no
  //## end CaseChangesCommand::CaseChangesCommand%681DF8220325_const.hasinit
  //## begin CaseChangesCommand::CaseChangesCommand%681DF8220325_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/casechanges/v1.0.0", "S0003D", "@##JLDCHG ")
  //## end CaseChangesCommand::CaseChangesCommand%681DF8220325_const.initialization
{
  //## begin restcommand::CaseChangesCommand::CaseChangesCommand%681DF8220325_const.body preserve=yes
   memcpy(m_sID, "JX43", 4);
  //## end restcommand::CaseChangesCommand::CaseChangesCommand%681DF8220325_const.body
}

CaseChangesCommand::CaseChangesCommand (Handler* pSuccessor)
  //## begin restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.hasinit preserve=no
  //## end restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.hasinit
  //## begin restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/casechanges/v1.0.0", "S0003D", "@##JLDCHG ")
  //## end restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.initialization
{
  //## begin restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.body preserve=yes
   memcpy(m_sID, "JX43", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::CaseChangesCommand::CaseChangesCommand%681DF9620249.body
}


CaseChangesCommand::~CaseChangesCommand()
{
  //## begin restcommand::CaseChangesCommand::~CaseChangesCommand%681DF8220325_dest.body preserve=yes
  //## end restcommand::CaseChangesCommand::~CaseChangesCommand%681DF8220325_dest.body
}



//## Other Operations (implementation)
bool CaseChangesCommand::execute ()
{
  //## begin restcommand::CaseChangesCommand::execute%681DF997005C.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX43 LIST CASE CHANGES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLDCHG", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX43", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_hQuery.reset();
   int i = parse();
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_pXMLDocument->add("root");
   m_hQuery.join("EMS_DATA_CHG", "INNER", "EMS_CASE", "CASE_ID");
   m_hCaseChangeSegment.bind(m_hQuery);
   m_hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
   m_hQuery.setBasicPredicate("EMS_DATA_CHG", "COLUMN_CHANGED", "<>", "TSTAMP_UPDATED");
   m_hQuery.setOrderByClause("EMS_DATA_CHG.TSTAMP_CREATED DESC,EMS_DATA_CHG.COLUMN_CHANGED ASC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false || pSelectStatement->getRows() == 0)
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::CaseChangesCommand::execute%681DF997005C.body
}

void CaseChangesCommand::update (Subject* pSubject)
{
  //## begin restcommand::CaseChangesCommand::update%681DF9BE0010.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.set("CaseID", m_hCaseChangeSegment.getCASE_ID());
      m_hGenericSegment.set("ModificationDateTime", m_hCaseChangeSegment.getTSTAMP_CREATED());
      m_hGenericSegment.set("SequenceNumber", m_hCaseChangeSegment.getSEQ_NO());
      m_hGenericSegment.set("UserID", m_hCaseChangeSegment.getUSER_ID());
      m_hGenericSegment.set("TableName", m_hCaseChangeSegment.getTABLE_CHANGED());
      m_hGenericSegment.set("ColumnName", m_hCaseChangeSegment.getCOLUMN_CHANGED());
      string strDOC_PATH = m_hCaseChangeSegment.getCOLUMN_OLD_VALUE();
      size_t pos = strDOC_PATH.find_last_of("\\/");
      if (pos != string::npos)
      {
         strDOC_PATH.erase(0, pos + 1);
         m_hGenericSegment.set("OldValue", strDOC_PATH);
      }
      else
         m_hGenericSegment.set("OldValue", m_hCaseChangeSegment.getCOLUMN_OLD_VALUE());
      strDOC_PATH = m_hCaseChangeSegment.getCOLUMN_NEW_VALUE();
      pos = strDOC_PATH.find_last_of("\\/");
      if (pos != string::npos)
      {
         strDOC_PATH.erase(0, pos + 1);
         m_hGenericSegment.set("NewValue", strDOC_PATH);
      }
      else
         m_hGenericSegment.set("NewValue", m_hCaseChangeSegment.getCOLUMN_NEW_VALUE());
      m_pXMLDocument->add("row");
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::CaseChangesCommand::update%681DF9BE0010.body
}

// Additional Declarations
  //## begin restcommand::CaseChangesCommand%681DF8220325.declarations preserve=yes
  //## end restcommand::CaseChangesCommand%681DF8220325.declarations

} // namespace restcommand

//## begin module%681DF72D01F5.epilog preserve=yes
//## end module%681DF72D01F5.epilog
