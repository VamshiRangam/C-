//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A1910A034F.cm preserve=no
//## end module%67A1910A034F.cm

//## begin module%67A1910A034F.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%67A1910A034F.cp

//## Module: CXOSJX37%67A1910A034F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX37.cpp

//## begin module%67A1910A034F.additionalIncludes preserve=no
//## end module%67A1910A034F.additionalIncludes

//## begin module%67A1910A034F.includes preserve=yes
//## end module%67A1910A034F.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX37_h
#include "CXODJX37.hpp"
#endif


//## begin module%67A1910A034F.declarations preserve=no
//## end module%67A1910A034F.declarations

//## begin module%67A1910A034F.additionalDeclarations preserve=yes
//## end module%67A1910A034F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReportFilesCommand 

ReportFilesCommand::ReportFilesCommand()
  //## begin ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.hasinit preserve=no
  //## end ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.hasinit
  //## begin ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.initialization preserve=yes
  //## end ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.initialization
{
  //## begin restcommand::ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.body preserve=yes
  //## end restcommand::ReportFilesCommand::ReportFilesCommand%67A18FE20142_const.body
}

ReportFilesCommand::ReportFilesCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.hasinit preserve=no
  //## end restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.hasinit
  //## begin restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/report/files/v1.0.0","S0003D","@##JLFILE ")
  //## end restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.initialization
{
  //## begin restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.body preserve=yes
   memcpy(m_sID,"JX37",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReportFilesCommand::ReportFilesCommand%67A1909B0340.body
}


ReportFilesCommand::~ReportFilesCommand()
{
  //## begin restcommand::ReportFilesCommand::~ReportFilesCommand%67A18FE20142_dest.body preserve=yes
  //## end restcommand::ReportFilesCommand::~ReportFilesCommand%67A18FE20142_dest.body
}



//## Other Operations (implementation)
bool ReportFilesCommand::execute ()
{
  //## begin restcommand::ReportFilesCommand::execute%67A190AB0048.body preserve=yes
   UseCase hUseCase("CLIENT","## JX37 LIST ENTITY FILES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLFILE",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX37",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   m_hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::STRING,&m_strDX_FILE_ID);
   m_hQuery.bind("DX_DATA_CONTROL","DX_FILE_TYPE",Column::STRING,&m_strDX_FILE_TYPE);
   m_hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",m_pXMLItem->get("date").c_str());
   m_hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID","=",m_pXMLItem->get("entity").c_str());
   m_hQuery.setOrderByClause("DX_FILE_ID");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReportFilesCommand::execute%67A190AB0048.body
}

void ReportFilesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReportFilesCommand::update%67A190AD0325.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.reset();
      m_hGenericSegment.set("FileID",m_strDX_FILE_ID);
      m_hGenericSegment.set("FileType",m_strDX_FILE_TYPE);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ReportFilesCommand::update%67A190AD0325.body
}

// Additional Declarations
  //## begin restcommand::ReportFilesCommand%67A18FE20142.declarations preserve=yes
  //## end restcommand::ReportFilesCommand%67A18FE20142.declarations

} // namespace restcommand

//## begin module%67A1910A034F.epilog preserve=yes
//## end module%67A1910A034F.epilog
