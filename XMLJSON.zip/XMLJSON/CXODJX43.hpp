//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%681DF72A02EF.cm preserve=no
//## end module%681DF72A02EF.cm

//## begin module%681DF72A02EF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%681DF72A02EF.cp

//## Module: CXOSJX43%681DF72A02EF; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX43.hpp

#ifndef CXOSJX43_h
#define CXOSJX43_h 1

//## begin module%681DF72A02EF.additionalIncludes preserve=no
//## end module%681DF72A02EF.additionalIncludes

//## begin module%681DF72A02EF.includes preserve=yes
//## end module%681DF72A02EF.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSES04_h
#include "CXODES04.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%681DF72A02EF.declarations preserve=no
//## end module%681DF72A02EF.declarations

//## begin module%681DF72A02EF.additionalDeclarations preserve=yes
//## end module%681DF72A02EF.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CaseChangesCommand%681DF8220325.preface preserve=yes
//## end restcommand::CaseChangesCommand%681DF8220325.preface

//## Class: CaseChangesCommand%681DF8220325
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Resolve REST CaseChanges
//	<h6>Resolve : REST : CaseChanges
//	<p>
//	Returns list of all column changes done to a case.
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/resolve/casechanges.yaml">YAML</a>
//	</ul>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%681DF8AA00E8;monitor::UseCase { -> F}
//## Uses: <unnamed>%681DF8B0005B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%681DF8B2020E;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%681DF8B6006D;segment::SOAPSegment { -> F}

class DllExport CaseChangesCommand : public command::RESTCommand  //## Inherits: <unnamed>%681DF8A40204
{
  //## begin restcommand::CaseChangesCommand%681DF8220325.initialDeclarations preserve=yes
  //## end restcommand::CaseChangesCommand%681DF8220325.initialDeclarations

  public:
    //## Constructors (generated)
      CaseChangesCommand();

    //## Constructors (specified)
      //## Operation: CaseChangesCommand%681DF9620249
      CaseChangesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseChangesCommand();


    //## Other Operations (specified)
      //## Operation: execute%681DF997005C
      virtual bool execute ();

      //## Operation: update%681DF9BE0010
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::CaseChangesCommand%681DF8220325.public preserve=yes
      //## end restcommand::CaseChangesCommand%681DF8220325.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CaseChangesCommand%681DF8220325.protected preserve=yes
      //## end restcommand::CaseChangesCommand%681DF8220325.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CaseChangesCommand%681DF8220325.private preserve=yes
      //## end restcommand::CaseChangesCommand%681DF8220325.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%681DFC470366
      //## Role: CaseChangesCommand::<m_hQuery>%681DFC4801C3
      //## begin restcommand::CaseChangesCommand::<m_hQuery>%681DFC4801C3.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::CaseChangesCommand::<m_hQuery>%681DFC4801C3.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%681DFC8B01A3
      //## Role: CaseChangesCommand::<m_hGenericSegment>%681DFC8C0119
      //## begin restcommand::CaseChangesCommand::<m_hGenericSegment>%681DFC8C0119.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::CaseChangesCommand::<m_hGenericSegment>%681DFC8C0119.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%681DFCB4028C
      //## Role: CaseChangesCommand::<m_hCaseChangeSegment>%681DFCB50378
      //## begin restcommand::CaseChangesCommand::<m_hCaseChangeSegment>%681DFCB50378.role preserve=no  public: emssegment::CaseChangeSegment { -> VHgN}
      emssegment::CaseChangeSegment m_hCaseChangeSegment;
      //## end restcommand::CaseChangesCommand::<m_hCaseChangeSegment>%681DFCB50378.role

    // Additional Implementation Declarations
      //## begin restcommand::CaseChangesCommand%681DF8220325.implementation preserve=yes
      //## end restcommand::CaseChangesCommand%681DF8220325.implementation

};

//## begin restcommand::CaseChangesCommand%681DF8220325.postscript preserve=yes
//## end restcommand::CaseChangesCommand%681DF8220325.postscript

} // namespace restcommand

//## begin module%681DF72A02EF.epilog preserve=yes
//## end module%681DF72A02EF.epilog


#endif
