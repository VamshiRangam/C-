//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%645AEDA10207.cm preserve=no
//## end module%645AEDA10207.cm

//## begin module%645AEDA10207.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%645AEDA10207.cp

//## Module: CXOSJX01%645AEDA10207; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX01.hpp

#ifndef CXOSJX01_h
#define CXOSJX01_h 1

//## begin module%645AEDA10207.additionalIncludes preserve=no
//## end module%645AEDA10207.additionalIncludes

//## begin module%645AEDA10207.includes preserve=yes
//## end module%645AEDA10207.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%645AEDA10207.declarations preserve=no
//## end module%645AEDA10207.declarations

//## begin module%645AEDA10207.additionalDeclarations preserve=yes
//## end module%645AEDA10207.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ServersCommand%645AECCA0008.preface preserve=yes
//## end restcommand::ServersCommand%645AECCA0008.preface

//## Class: ServersCommand%645AECCA0008
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%645E299C029A;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%645E2B1F0105;monitor::UseCase { -> F}
//## Uses: <unnamed>%645E2D0203A0;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%645E2D060050;database::DatabaseFactory { -> F}

class DllExport ServersCommand : public command::RESTCommand  //## Inherits: <unnamed>%64DFD7CB006A
{
  //## begin restcommand::ServersCommand%645AECCA0008.initialDeclarations preserve=yes
  //## end restcommand::ServersCommand%645AECCA0008.initialDeclarations

  public:
    //## Constructors (generated)
      ServersCommand();

    //## Constructors (specified)
      //## Operation: ServersCommand%645AED2D03D3
      ServersCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ServersCommand();


    //## Other Operations (specified)
      //## Operation: execute%645AED7B0016
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%645E29D90090
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ServersCommand%645AECCA0008.public preserve=yes
      //## end restcommand::ServersCommand%645AECCA0008.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ServersCommand%645AECCA0008.protected preserve=yes
      //## end restcommand::ServersCommand%645AECCA0008.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ServersCommand%645AECCA0008.private preserve=yes
      //## end restcommand::ServersCommand%645AECCA0008.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%645E2C7C0205
      //## begin restcommand::ServersCommand::CONTEXT_DATA%645E2C7C0205.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCONTEXT_DATA;
      //## end restcommand::ServersCommand::CONTEXT_DATA%645E2C7C0205.attr

      //## Attribute: CONTEXT_KEY%645E2C9900D7
      //## begin restcommand::ServersCommand::CONTEXT_KEY%645E2C9900D7.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCONTEXT_KEY;
      //## end restcommand::ServersCommand::CONTEXT_KEY%645E2C9900D7.attr

      //## Attribute: IMAGE_ID%645E2C99017C
      //## begin restcommand::ServersCommand::IMAGE_ID%645E2C99017C.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strIMAGE_ID;
      //## end restcommand::ServersCommand::IMAGE_ID%645E2C99017C.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%645E296C0077
      //## Role: ServersCommand::<m_hGenericSegment>%645E296C0371
      //## begin restcommand::ServersCommand::<m_hGenericSegment>%645E296C0371.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ServersCommand::<m_hGenericSegment>%645E296C0371.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6464C4C601DC
      //## Role: ServersCommand::<m_hQuery>%6464C4C700DE
      //## begin restcommand::ServersCommand::<m_hQuery>%6464C4C700DE.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ServersCommand::<m_hQuery>%6464C4C700DE.role

    // Additional Implementation Declarations
      //## begin restcommand::ServersCommand%645AECCA0008.implementation preserve=yes
      //## end restcommand::ServersCommand%645AECCA0008.implementation

};

//## begin restcommand::ServersCommand%645AECCA0008.postscript preserve=yes
//## end restcommand::ServersCommand%645AECCA0008.postscript

} // namespace restcommand

//## begin module%645AEDA10207.epilog preserve=yes
//## end module%645AEDA10207.epilog


#endif
