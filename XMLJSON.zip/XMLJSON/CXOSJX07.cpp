//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6511C2FC0224.cm preserve=no
//## end module%6511C2FC0224.cm

//## begin module%6511C2FC0224.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6511C2FC0224.cp

//## Module: CXOSJX07%6511C2FC0224; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX07.cpp

//## begin module%6511C2FC0224.additionalIncludes preserve=no
//## end module%6511C2FC0224.additionalIncludes

//## begin module%6511C2FC0224.includes preserve=yes
//## end module%6511C2FC0224.includes

#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSEX24_h
#include "CXODEX24.hpp"
#endif
#ifndef CXOSJX07_h
#include "CXODJX07.hpp"
#endif


//## begin module%6511C2FC0224.declarations preserve=no
//## end module%6511C2FC0224.declarations

//## begin module%6511C2FC0224.additionalDeclarations preserve=yes
//## end module%6511C2FC0224.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::TransitionsCommand 

TransitionsCommand::TransitionsCommand()
  //## begin TransitionsCommand::TransitionsCommand%6511B70E01E4_const.hasinit preserve=no
      : m_pszBuffer(0)
  //## end TransitionsCommand::TransitionsCommand%6511B70E01E4_const.hasinit
  //## begin TransitionsCommand::TransitionsCommand%6511B70E01E4_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/transitions/v1.0.0","S0003D","@##JLAVTR ")
  //## end TransitionsCommand::TransitionsCommand%6511B70E01E4_const.initialization
{
  //## begin restcommand::TransitionsCommand::TransitionsCommand%6511B70E01E4_const.body preserve=yes
   memcpy(m_sID,"JX07",4);
  //## end restcommand::TransitionsCommand::TransitionsCommand%6511B70E01E4_const.body
}

TransitionsCommand::TransitionsCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.hasinit preserve=no
      : m_pszBuffer(0)
  //## end restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.hasinit
  //## begin restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/transitions/v1.0.0","S0003D","@##JLAVTR ")
  //## end restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.initialization
{
  //## begin restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.body preserve=yes
   memcpy(m_sID,"JX07",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_pszBuffer = new char[sizeof(segAvailablePhase) + 1];
  //## end restcommand::TransitionsCommand::TransitionsCommand%6511B78D009A.body
}


TransitionsCommand::~TransitionsCommand()
{
  //## begin restcommand::TransitionsCommand::~TransitionsCommand%6511B70E01E4_dest.body preserve=yes
   delete [] m_pszBuffer;
  //## end restcommand::TransitionsCommand::~TransitionsCommand%6511B70E01E4_dest.body
}



//## Other Operations (implementation)
bool TransitionsCommand::execute ()
{
  //## begin restcommand::TransitionsCommand::execute%6511B7AB00C9.body preserve=yes
   UseCase hUseCase("CLIENT","## JX07 LIST TRANSITIONS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLAVTR",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX07",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   CaseSegment::instance()->setPresence(true);
   CaseTransitionSegment::instance()->setPresence(true);
   CasePhaseSegment::instance()->setPresence(true);
   Query hQuery;
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","CASE_ID");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","PHASE_TSTAMP","TSTAMP_CREATED");
   CaseSegment::instance()->bind(hQuery);
   CasePhaseSegment::instance()->bind(hQuery);
   CaseTransitionSegment::instance()->bind(hQuery);
   hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",m_pXMLItem->get("caseNumber").c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      CaseSegment::instance()->setUSER_ROLE(m_pXMLItem->get("role"));
      bool b = ems::EMSRulesEngine::instance()->exportAvailableTransitions(this,m_pszBuffer);
      SOAPSegment::instance()->setRtnCde(b ? '0' : '2');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::TransitionsCommand::execute%6511B7AB00C9.body
}

void TransitionsCommand::update (Subject* pSubject)
{
  //## begin restcommand::TransitionsCommand::update%6511B7AE0139.body preserve=yes
   if (pSubject == 0)
   {   
      ++m_iRows;
      ++m_iTotalRows;
      segAvailablePhase* p = (segAvailablePhase*)m_pszBuffer;
      string strValue(p->sNEXT_PHASE,sizeof(p->sNEXT_PHASE));
      m_hGenericSegment.set("RequestType",rtrim(strValue));
      strValue.assign(p->sNEXT_STATUS,sizeof(p->sNEXT_STATUS));
      m_hGenericSegment.set("Status",rtrim(strValue));
      strValue.assign(&p->cROLE_IND,sizeof(p->cROLE_IND));
      m_hGenericSegment.set("Role",rtrim(strValue));
      strValue.assign(p->sSECURITY_KEY,sizeof(p->sSECURITY_KEY));
      m_hGenericSegment.set("Security",rtrim(strValue));
      strValue.assign(p->sDescription,sizeof(p->sDescription));
      m_hGenericSegment.set("Description",rtrim(strValue));
      strValue.assign(p->sNextStateDescription,sizeof(p->sNextStateDescription));
      m_hGenericSegment.set("StatusDescription",rtrim(strValue));
      strValue.assign(p->sActionsAvailable,sizeof(p->sActionsAvailable));
      m_hGenericSegment.set("Actions",rtrim(strValue));
      m_pXMLDocument->add("row");
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::TransitionsCommand::update%6511B7AE0139.body
}

// Additional Declarations
  //## begin restcommand::TransitionsCommand%6511B70E01E4.declarations preserve=yes
  //## end restcommand::TransitionsCommand%6511B70E01E4.declarations

} // namespace restcommand

//## begin module%6511C2FC0224.epilog preserve=yes
//## end module%6511C2FC0224.epilog
