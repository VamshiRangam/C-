//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D427BE005E.cm preserve=no
//## end module%65D427BE005E.cm

//## begin module%65D427BE005E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D427BE005E.cp

//## Module: CXOSJX16%65D427BE005E; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX16.hpp

#ifndef CXOSJX16_h
#define CXOSJX16_h 1

//## begin module%65D427BE005E.additionalIncludes preserve=no
//## end module%65D427BE005E.additionalIncludes

//## begin module%65D427BE005E.includes preserve=yes
//## end module%65D427BE005E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65D427BE005E.declarations preserve=no
//## end module%65D427BE005E.declarations

//## begin module%65D427BE005E.additionalDeclarations preserve=yes
//## end module%65D427BE005E.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReconFilesCommand%65D418040175.preface preserve=yes
//## end restcommand::ReconFilesCommand%65D418040175.preface

//## Class: ReconFilesCommand%65D418040175
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Research REST Transaction Reconciliation Files
//	<h6>Research : REST : Transaction Reconciliation Files
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/reconfiles/reconfiles.yml">YAML</a>
//	<li><a
//	href="../../REST/reconfiles/request/reconfiles.json">samp
//	le request</a>
//	<li><a
//	href="../../REST/reconfiles/request/reconfiles.schema.jso
//	n">JSON request schema</a>
//	<li><a
//	href="../../REST/reconfiles/response/reconfiles.json">sam
//	ple response</a>
//	<li><a
//	href="../../REST/reconfiles/response/reconfiles.schema.js
//	on">JSON response schema</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65D419A4022B;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%65D419A603C0;monitor::UseCase { -> F}
//## Uses: <unnamed>%65D419A902ED;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%65D419AB0396;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65D419AE038E;reusable::Buffer { -> F}
//## Uses: <unnamed>%65D419B30014;IF::Extract { -> F}

class DllExport ReconFilesCommand : public command::RESTCommand  //## Inherits: <unnamed>%65D4199E01B5
{
  //## begin restcommand::ReconFilesCommand%65D418040175.initialDeclarations preserve=yes
  //## end restcommand::ReconFilesCommand%65D418040175.initialDeclarations

  public:
    //## Constructors (generated)
      ReconFilesCommand();

    //## Constructors (specified)
      //## Operation: ReconFilesCommand%65D41FAD0358
      ReconFilesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReconFilesCommand();


    //## Other Operations (specified)
      //## Operation: execute%65D41FC7026E
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%65D41FCA0266
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReconFilesCommand%65D418040175.public preserve=yes
      //## end restcommand::ReconFilesCommand%65D418040175.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReconFilesCommand%65D418040175.protected preserve=yes
      //## end restcommand::ReconFilesCommand%65D418040175.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReconFilesCommand%65D418040175.private preserve=yes
      //## end restcommand::ReconFilesCommand%65D418040175.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AU_FILE_NAME%65EED063038E
      //## begin restcommand::ReconFilesCommand::AU_FILE_NAME%65EED063038E.attr preserve=no  private: string {U} 
      string m_strAU_FILE_NAME;
      //## end restcommand::ReconFilesCommand::AU_FILE_NAME%65EED063038E.attr

      //## Attribute: DATE_RECON%65EEF1A20354
      //## begin restcommand::ReconFilesCommand::DATE_RECON%65EEF1A20354.attr preserve=no  private: string {U} 
      string m_strDATE_RECON;
      //## end restcommand::ReconFilesCommand::DATE_RECON%65EEF1A20354.attr

      //## Attribute: AU_STATE%65EEF1C2034E
      //## begin restcommand::ReconFilesCommand::AU_STATE%65EEF1C2034E.attr preserve=no  private: string {U} 
      string m_strAU_STATE;
      //## end restcommand::ReconFilesCommand::AU_STATE%65EEF1C2034E.attr

      //## Attribute: TSTAMP_TRANS_FROM%65EEF1E20031
      //## begin restcommand::ReconFilesCommand::TSTAMP_TRANS_FROM%65EEF1E20031.attr preserve=no  private: string {U} 
      string m_strTSTAMP_TRANS_FROM;
      //## end restcommand::ReconFilesCommand::TSTAMP_TRANS_FROM%65EEF1E20031.attr

      //## Attribute: TSTAMP_TRANS_TO%65EEF1FE01EB
      //## begin restcommand::ReconFilesCommand::TSTAMP_TRANS_TO%65EEF1FE01EB.attr preserve=no  private: string {U} 
      string m_strTSTAMP_TRANS_TO;
      //## end restcommand::ReconFilesCommand::TSTAMP_TRANS_TO%65EEF1FE01EB.attr

      //## Attribute: BIN%65EEF21E006E
      //## begin restcommand::ReconFilesCommand::BIN%65EEF21E006E.attr preserve=no  private: string {U} 
      string m_strBIN;
      //## end restcommand::ReconFilesCommand::BIN%65EEF21E006E.attr

      //## Attribute: BIN_COUNT%65EEF23E031F
      //## begin restcommand::ReconFilesCommand::BIN_COUNT%65EEF23E031F.attr preserve=no  private: string {U} 
      string m_strBIN_COUNT;
      //## end restcommand::ReconFilesCommand::BIN_COUNT%65EEF23E031F.attr

      //## Attribute: TASK_RECONCILED%65EEF26901FC
      //## begin restcommand::ReconFilesCommand::TASK_RECONCILED%65EEF26901FC.attr preserve=no  private: string {U} 
      string m_strTASK_RECONCILED;
      //## end restcommand::ReconFilesCommand::TASK_RECONCILED%65EEF26901FC.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D419BC03DF
      //## Role: ReconFilesCommand::<m_hGenericSegment>%65D419BD0377
      //## begin restcommand::ReconFilesCommand::<m_hGenericSegment>%65D419BD0377.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReconFilesCommand::<m_hGenericSegment>%65D419BD0377.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D419C601A5
      //## Role: ReconFilesCommand::<m_hQuery>%65D419C702B6
      //## begin restcommand::ReconFilesCommand::<m_hQuery>%65D419C702B6.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReconFilesCommand::<m_hQuery>%65D419C702B6.role

    // Additional Implementation Declarations
      //## begin restcommand::ReconFilesCommand%65D418040175.implementation preserve=yes
      //## end restcommand::ReconFilesCommand%65D418040175.implementation

};

//## begin restcommand::ReconFilesCommand%65D418040175.postscript preserve=yes
//## end restcommand::ReconFilesCommand%65D418040175.postscript

} // namespace restcommand

//## begin module%65D427BE005E.epilog preserve=yes
//## end module%65D427BE005E.epilog


#endif
