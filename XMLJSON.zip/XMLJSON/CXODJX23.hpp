//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6682B5F10346.cm preserve=no
//## end module%6682B5F10346.cm

//## begin module%6682B5F10346.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6682B5F10346.cp

//## Module: CXOSJX23%6682B5F10346; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX23.hpp

#ifndef CXOSJX23_h
#define CXOSJX23_h 1

//## begin module%6682B5F10346.additionalIncludes preserve=no
//## end module%6682B5F10346.additionalIncludes

//## begin module%6682B5F10346.includes preserve=yes
//## end module%6682B5F10346.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6682B5F10346.declarations preserve=no
//## end module%6682B5F10346.declarations

//## begin module%6682B5F10346.additionalDeclarations preserve=yes
//## end module%6682B5F10346.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::SettingsCommand%6682B7B70258.preface preserve=yes
//## end restcommand::SettingsCommand%6682B7B70258.preface

//## Class: SettingsCommand%6682B7B70258
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6682B818015D;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6682B8430268;monitor::UseCase { -> F}
//## Uses: <unnamed>%6682B88701B3;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6682B8AE0368;database::DatabaseFactory { -> F}

class DllExport SettingsCommand : public command::RESTCommand  //## Inherits: <unnamed>%6682B8680057
{
  //## begin restcommand::SettingsCommand%6682B7B70258.initialDeclarations preserve=yes
  //## end restcommand::SettingsCommand%6682B7B70258.initialDeclarations

  public:
    //## Constructors (generated)
      SettingsCommand();

    //## Constructors (specified)
      //## Operation: SettingsCommand%6682BA2E02F9
      SettingsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~SettingsCommand();


    //## Other Operations (specified)
      //## Operation: execute%6682BA67039A
      virtual bool execute ();

      //## Operation: update%6682BA8603AE
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::SettingsCommand%6682B7B70258.public preserve=yes
      //## end restcommand::SettingsCommand%6682B7B70258.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::SettingsCommand%6682B7B70258.protected preserve=yes
      //## end restcommand::SettingsCommand%6682B7B70258.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::SettingsCommand%6682B7B70258.private preserve=yes
      //## end restcommand::SettingsCommand%6682B7B70258.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CustomizeNode%6682BAE20220
      //## begin restcommand::SettingsCommand::CustomizeNode%6682BAE20220.attr preserve=no  private: string {U} 
      string m_strCustomizeNode;
      //## end restcommand::SettingsCommand::CustomizeNode%6682BAE20220.attr

      //## Attribute: FullCustomizeName%6682BB310027
      //## begin restcommand::SettingsCommand::FullCustomizeName%6682BB310027.attr preserve=no  private: string {U} 
      string m_strFullCustomizeName;
      //## end restcommand::SettingsCommand::FullCustomizeName%6682BB310027.attr

      //## Attribute: SequenceNo%6682BB5A0181
      //## begin restcommand::SettingsCommand::SequenceNo%6682BB5A0181.attr preserve=no  private: short {U} 0
      short m_siSequenceNo;
      //## end restcommand::SettingsCommand::SequenceNo%6682BB5A0181.attr

      //## Attribute: CustomizeData%6682BB900280
      //## begin restcommand::SettingsCommand::CustomizeData%6682BB900280.attr preserve=no  private: string {U} 
      string m_strCustomizeData;
      //## end restcommand::SettingsCommand::CustomizeData%6682BB900280.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6682B9D20285
      //## Role: SettingsCommand::<m_hGenericSegment>%6682B9D403E4
      //## begin restcommand::SettingsCommand::<m_hGenericSegment>%6682B9D403E4.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::SettingsCommand::<m_hGenericSegment>%6682B9D403E4.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6682BD230197
      //## Role: SettingsCommand::<m_hQuery>%6682BD240140
      //## begin restcommand::SettingsCommand::<m_hQuery>%6682BD240140.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::SettingsCommand::<m_hQuery>%6682BD240140.role

    // Additional Implementation Declarations
      //## begin restcommand::SettingsCommand%6682B7B70258.implementation preserve=yes
      //## end restcommand::SettingsCommand%6682B7B70258.implementation

};

//## begin restcommand::SettingsCommand%6682B7B70258.postscript preserve=yes
//## end restcommand::SettingsCommand%6682B7B70258.postscript

} // namespace restcommand

//## begin module%6682B5F10346.epilog preserve=yes
//## end module%6682B5F10346.epilog


#endif
