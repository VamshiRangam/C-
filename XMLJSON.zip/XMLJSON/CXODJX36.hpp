//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A0D0090032.cm preserve=no
//## end module%67A0D0090032.cm

//## begin module%67A0D0090032.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67A0D0090032.cp

//## Module: CXOSJX36%67A0D0090032; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX36.hpp

#ifndef CXOSJX36_h
#define CXOSJX36_h 1

//## begin module%67A0D0090032.additionalIncludes preserve=no
//## end module%67A0D0090032.additionalIncludes

//## begin module%67A0D0090032.includes preserve=yes
//## end module%67A0D0090032.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67A0D0090032.declarations preserve=no
//## end module%67A0D0090032.declarations

//## begin module%67A0D0090032.additionalDeclarations preserve=yes
//## end module%67A0D0090032.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReportDayCommand%67A0CF7E0262.preface preserve=yes
//## end restcommand::ReportDayCommand%67A0CF7E0262.preface

//## Class: ReportDayCommand%67A0CF7E0262
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67A0CFB70321;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67A0CFBD03D2;monitor::UseCase { -> F}
//## Uses: <unnamed>%67A0CFBF01FB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67A0CFC10212;database::DatabaseFactory { -> F}

class DllExport ReportDayCommand : public command::RESTCommand  //## Inherits: <unnamed>%67A0CFB3001B
{
  //## begin restcommand::ReportDayCommand%67A0CF7E0262.initialDeclarations preserve=yes
  //## end restcommand::ReportDayCommand%67A0CF7E0262.initialDeclarations

  public:
    //## Constructors (generated)
      ReportDayCommand();

    //## Constructors (specified)
      //## Operation: ReportDayCommand%67A0D0950021
      ReportDayCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReportDayCommand();


    //## Other Operations (specified)
      //## Operation: execute%67A0D0A30198
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%67A0D0A60262
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReportDayCommand%67A0CF7E0262.public preserve=yes
      //## end restcommand::ReportDayCommand%67A0CF7E0262.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReportDayCommand%67A0CF7E0262.protected preserve=yes
      //## end restcommand::ReportDayCommand%67A0CF7E0262.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReportDayCommand%67A0CF7E0262.private preserve=yes
      //## end restcommand::ReportDayCommand%67A0CF7E0262.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ENTITY_ID%67A0D2B4023F
      //## begin restcommand::ReportDayCommand::ENTITY_ID%67A0D2B4023F.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strENTITY_ID;
      //## end restcommand::ReportDayCommand::ENTITY_ID%67A0D2B4023F.attr

      //## Attribute: ENTITY_TYPE%67A0D2C1022E
      //## begin restcommand::ReportDayCommand::ENTITY_TYPE%67A0D2C1022E.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strENTITY_TYPE;
      //## end restcommand::ReportDayCommand::ENTITY_TYPE%67A0D2C1022E.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A0CFCF0207
      //## Role: ReportDayCommand::<m_hGenericSegment>%67A0CFD00333
      //## begin restcommand::ReportDayCommand::<m_hGenericSegment>%67A0CFD00333.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReportDayCommand::<m_hGenericSegment>%67A0CFD00333.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A0CFD30099
      //## Role: ReportDayCommand::<m_hQuery>%67A0CFD402ED
      //## begin restcommand::ReportDayCommand::<m_hQuery>%67A0CFD402ED.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReportDayCommand::<m_hQuery>%67A0CFD402ED.role

    // Additional Implementation Declarations
      //## begin restcommand::ReportDayCommand%67A0CF7E0262.implementation preserve=yes
      //## end restcommand::ReportDayCommand%67A0CF7E0262.implementation

};

//## begin restcommand::ReportDayCommand%67A0CF7E0262.postscript preserve=yes
//## end restcommand::ReportDayCommand%67A0CF7E0262.postscript

} // namespace restcommand

//## begin module%67A0D0090032.epilog preserve=yes
//## end module%67A0D0090032.epilog


#endif
