//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6525EB9C00E2.cm preserve=no
//## end module%6525EB9C00E2.cm

//## begin module%6525EB9C00E2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6525EB9C00E2.cp

//## Module: CXOSJX10%6525EB9C00E2; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX10.hpp

#ifndef CXOSJX10_h
#define CXOSJX10_h 1

//## begin module%6525EB9C00E2.additionalIncludes preserve=no
//## end module%6525EB9C00E2.additionalIncludes

//## begin module%6525EB9C00E2.includes preserve=yes
//## end module%6525EB9C00E2.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6525EB9C00E2.declarations preserve=no
//## end module%6525EB9C00E2.declarations

//## begin module%6525EB9C00E2.additionalDeclarations preserve=yes
//## end module%6525EB9C00E2.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ClaimStatusCommand%6525C0D60207.preface preserve=yes
//## end restcommand::ClaimStatusCommand%6525C0D60207.preface

//## Class: ClaimStatusCommand%6525C0D60207
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Research REST Claim Status
//	<h6>Research : REST : Claim Status
//	<p>
//	<ul>
//	<li><a href="../../REST/claimStatus/claim
//	Status.yml">YAML</a>
//	<li><a href="../../REST/claimStatus/request/claim
//	Status.json">sample request</a>
//	<li><a href="../../REST/claimStatus/request/claim
//	Status.schema.json">JSON request schema</a>
//	<li><a href="../../REST/claimStatus/response/claim
//	Status.json">sample response</a>
//	<li><a href="../../REST/claimStatus/response/claim
//	Status.schema.json">JSON response schema</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%660EA1710090;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%660EA18C0020;monitor::UseCase { -> F}
//## Uses: <unnamed>%660EA1A903AB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%660EA1C20324;database::DatabaseFactory { -> F}

class DllExport ClaimStatusCommand : public command::RESTCommand  //## Inherits: <unnamed>%6525C0EA0299
{
  //## begin restcommand::ClaimStatusCommand%6525C0D60207.initialDeclarations preserve=yes
  //## end restcommand::ClaimStatusCommand%6525C0D60207.initialDeclarations

  public:
    //## Constructors (generated)
      ClaimStatusCommand();

    //## Constructors (specified)
      //## Operation: ClaimStatusCommand%6525C2B401B9
      ClaimStatusCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ClaimStatusCommand();


    //## Other Operations (specified)
      //## Operation: execute%6525C21502A1
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%6525C2180004
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ClaimStatusCommand%6525C0D60207.public preserve=yes
      //## end restcommand::ClaimStatusCommand%6525C0D60207.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ClaimStatusCommand%6525C0D60207.protected preserve=yes
      //## end restcommand::ClaimStatusCommand%6525C0D60207.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ClaimStatusCommand%6525C0D60207.private preserve=yes
      //## end restcommand::ClaimStatusCommand%6525C0D60207.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Failed%660EA2D20255
      //## begin restcommand::ClaimStatusCommand::Failed%660EA2D20255.attr preserve=no  private: int {U} 0
      int m_iFailed;
      //## end restcommand::ClaimStatusCommand::Failed%660EA2D20255.attr

      //## Attribute: Succeeded%660EA32C017B
      //## begin restcommand::ClaimStatusCommand::Succeeded%660EA32C017B.attr preserve=no  private: int {U} 0
      int m_iSucceeded;
      //## end restcommand::ClaimStatusCommand::Succeeded%660EA32C017B.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%660EA21D031C
      //## Role: ClaimStatusCommand::<m_hQuery>%660EA21E0314
      //## begin restcommand::ClaimStatusCommand::<m_hQuery>%660EA21E0314.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ClaimStatusCommand::<m_hQuery>%660EA21E0314.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%660EA22603B5
      //## Role: ClaimStatusCommand::<m_hGenericSegment>%660EA2280092
      //## begin restcommand::ClaimStatusCommand::<m_hGenericSegment>%660EA2280092.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ClaimStatusCommand::<m_hGenericSegment>%660EA2280092.role

    // Additional Implementation Declarations
      //## begin restcommand::ClaimStatusCommand%6525C0D60207.implementation preserve=yes
      //## end restcommand::ClaimStatusCommand%6525C0D60207.implementation

};

//## begin restcommand::ClaimStatusCommand%6525C0D60207.postscript preserve=yes
//## end restcommand::ClaimStatusCommand%6525C0D60207.postscript

} // namespace restcommand

//## begin module%6525EB9C00E2.epilog preserve=yes
//## end module%6525EB9C00E2.epilog


#endif
