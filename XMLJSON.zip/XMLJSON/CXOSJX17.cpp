//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D4281602D9.cm preserve=no
//## end module%65D4281602D9.cm

//## begin module%65D4281602D9.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%65D4281602D9.cp

//## Module: CXOSJX17%65D4281602D9; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX17.cpp

//## begin module%65D4281602D9.additionalIncludes preserve=no
//## end module%65D4281602D9.additionalIncludes

//## begin module%65D4281602D9.includes preserve=yes
//## end module%65D4281602D9.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX40_h
#include "CXODJX40.hpp"
#endif
#ifndef CXOSJX17_h
#include "CXODJX17.hpp"
#endif


//## begin module%65D4281602D9.declarations preserve=no
//## end module%65D4281602D9.declarations

//## begin module%65D4281602D9.additionalDeclarations preserve=yes
//## end module%65D4281602D9.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReconFileCommand 

ReconFileCommand::ReconFileCommand()
  //## begin ReconFileCommand::ReconFileCommand%65D417D5034C_const.hasinit preserve=no
      : m_pEmail(0)
  //## end ReconFileCommand::ReconFileCommand%65D417D5034C_const.hasinit
  //## begin ReconFileCommand::ReconFileCommand%65D417D5034C_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/reconcile/reconfile/v1.0.0","S0003D","@##JRAURF ")
  //## end ReconFileCommand::ReconFileCommand%65D417D5034C_const.initialization
{
  //## begin restcommand::ReconFileCommand::ReconFileCommand%65D417D5034C_const.body preserve=yes
   memcpy(m_sID,"JX17",4);
  //## end restcommand::ReconFileCommand::ReconFileCommand%65D417D5034C_const.body
}

ReconFileCommand::ReconFileCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.hasinit preserve=no
      : m_pEmail(0)
  //## end restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.hasinit
  //## begin restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/reconcile/reconfile/v1.0.0","S0003D","@##JRAURF ")
  //## end restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.initialization
{
  //## begin restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.body preserve=yes
   memcpy(m_sID,"JX17",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReconFileCommand::ReconFileCommand%65D41FF3009B.body
}


ReconFileCommand::~ReconFileCommand()
{
  //## begin restcommand::ReconFileCommand::~ReconFileCommand%65D417D5034C_dest.body preserve=yes
  //## end restcommand::ReconFileCommand::~ReconFileCommand%65D417D5034C_dest.body
}



//## Other Operations (implementation)
bool ReconFileCommand::execute ()
{
  //## begin restcommand::ReconFileCommand::execute%65D420010176.body preserve=yes
   UseCase hUseCase("CLIENT","## JX17 LIST RECON FILE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJRAURF",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX17",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("details");
   if (i == 0)
   {
      string strGENNAM(m_pXMLItem->get("file"));
      string strDATE_RECON(m_pXMLItem->get("date"));
      m_pEmail = new restcommand::Email(m_pXMLDocument,&m_hGenericSegment,strGENNAM,"IP","PRC001",strDATE_RECON,"240000","CXOEJX17");
      m_pEmail->report('Q');
      m_pEmail->complete();
   }
   return reply();
  //## end restcommand::ReconFileCommand::execute%65D420010176.body
}

// Additional Declarations
  //## begin restcommand::ReconFileCommand%65D417D5034C.declarations preserve=yes
  //## end restcommand::ReconFileCommand%65D417D5034C.declarations

} // namespace restcommand

//## begin module%65D4281602D9.epilog preserve=yes
//## end module%65D4281602D9.epilog
