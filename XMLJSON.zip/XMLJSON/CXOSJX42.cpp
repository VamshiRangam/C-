//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67FFBD650177.cm preserve=no
//## end module%67FFBD650177.cm

//## begin module%67FFBD650177.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67FFBD650177.cp

//## Module: CXOSJX42%67FFBD650177; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX42.cpp

//## begin module%67FFBD650177.additionalIncludes preserve=no
//## end module%67FFBD650177.additionalIncludes

//## begin module%67FFBD650177.includes preserve=yes
//## end module%67FFBD650177.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSJX42_h
#include "CXODJX42.hpp"
#endif


//## begin module%67FFBD650177.declarations preserve=no
//## end module%67FFBD650177.declarations

//## begin module%67FFBD650177.additionalDeclarations preserve=yes
//## end module%67FFBD650177.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::NetworkReasonCodeCommand 

NetworkReasonCodeCommand::NetworkReasonCodeCommand()
  //## begin NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.hasinit preserve=no
      : m_iCount(0),
        m_iQueryNumber(0)
  //## end NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.hasinit
  //## begin NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/networkreasoncodes/v1.0.0", "S0003D", "@##JLNWRC ")
  //## end NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.initialization
{
  //## begin restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.body preserve=yes
   memcpy(m_sID, "JX42", 4);
  //## end restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC080036C_const.body
}

NetworkReasonCodeCommand::NetworkReasonCodeCommand (Handler* pSuccessor)
  //## begin restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.hasinit preserve=no
      : m_iCount(0),
        m_iQueryNumber(0)
  //## end restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.hasinit
  //## begin restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/networkreasoncodes/v1.0.0", "S0003D", "@##JLNWRC ")
  //## end restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.initialization
{
  //## begin restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.body preserve=yes
   memcpy(m_sID, "JX42", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::NetworkReasonCodeCommand::NetworkReasonCodeCommand%67FFC30C0039.body
}


NetworkReasonCodeCommand::~NetworkReasonCodeCommand()
{
  //## begin restcommand::NetworkReasonCodeCommand::~NetworkReasonCodeCommand%67FFC080036C_dest.body preserve=yes
  //## end restcommand::NetworkReasonCodeCommand::~NetworkReasonCodeCommand%67FFC080036C_dest.body
}



//## Other Operations (implementation)
void NetworkReasonCodeCommand::determineNetworkRules (const string& strCUST_ID, const string& strNetworkName, const string& strUserRole)
{
  //## begin restcommand::NetworkReasonCodeCommand::determineNetworkRules%6807637802AE.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (strUserRole != "A")
   {
      m_hQuery.reset();
      m_hQuery.setQualifier("QUALIFY", "EMSR_NET_RULE_USE");
      m_hQuery.bind("EMSR_NET_RULE_USE", "NETWORK_RULES", Column::STRING, &m_strNETWORK_RULES);
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "ACQ_NETWORK", "=", strNetworkName.c_str());
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "NET_RULE_USE_STAT", "=", "P");
      pSelectStatement->execute(m_hQuery);
         return;
   }
   if (pSelectStatement->getRows() == 0 && strUserRole != "I")
   {
      m_hQuery.reset();
      m_hQuery.setQualifier("QUALIFY", "EMSR_NET_RULE_USE");
      m_hQuery.bind("EMSR_NET_RULE_USE", "NETWORK_RULES", Column::STRING, &m_strNETWORK_RULES);
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "ISS_NETWORK", "=", strNetworkName.c_str());
      m_hQuery.setBasicPredicate("EMSR_NET_RULE_USE", "NET_RULE_USE_STAT", "=", "P");
      if (!pSelectStatement->execute(m_hQuery))
         return;
   }
   return;
  //## end restcommand::NetworkReasonCodeCommand::determineNetworkRules%6807637802AE.body
}

int NetworkReasonCodeCommand::determineRULE_SET_ID (const string& strCUST_ID)
{
  //## begin restcommand::NetworkReasonCodeCommand::determineRULE_SET_ID%6807645D0270.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.reset();
   m_hQuery.setQualifier("QUALIFY", "EMSR_RULE_SET");
   m_hQuery.bind("EMSR_RULE_SET", "RULE_SET_ID", Column::STRING, &m_strRULE_SET_ID);
   m_hQuery.setBasicPredicate("EMSR_RULE_SET", "NET_ID_EMS", "=", m_strNETWORK_RULES.c_str());
   m_hQuery.setBasicPredicate("EMSR_RULE_SET", "CUST_ID", "=", strCUST_ID.c_str());
   m_hQuery.setBasicPredicate("EMSR_RULE_SET", "RULE_SET_STAT", "=", "P");
   if (!pSelectStatement->execute(m_hQuery))
      return 1;
   return 0;
  //## end restcommand::NetworkReasonCodeCommand::determineRULE_SET_ID%6807645D0270.body
}

string NetworkReasonCodeCommand::determineBaseRULE_SET_ID (const string& strRULE_SET_ID)
{
  //## begin restcommand::NetworkReasonCodeCommand::determineBaseRULE_SET_ID%6807648B0036.body preserve=yes
   string strPARENT_RULE_SET_ID;
   m_hQuery.reset();
   m_hQuery.setQualifier("QUALIFY", "EMSR_RULE_SET");
   m_hQuery.bind("EMSR_RULE_SET", "PARENT_RULE_SET_ID", Column::STRING, &strPARENT_RULE_SET_ID);
   m_hQuery.setBasicPredicate("EMSR_RULE_SET", "RULE_SET_ID", "=", strRULE_SET_ID.c_str());
   m_hQuery.setBasicPredicate("EMSR_RULE_SET", "RULE_SET_STAT", "=", "P");
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(m_hQuery))
         return "";
   }
   if (strPARENT_RULE_SET_ID.find("BASE") != string::npos ||
      strPARENT_RULE_SET_ID.find("SIG") != string::npos)
      return strRULE_SET_ID;
   else
      return determineBaseRULE_SET_ID(strPARENT_RULE_SET_ID);
  //## end restcommand::NetworkReasonCodeCommand::determineBaseRULE_SET_ID%6807648B0036.body
}

bool NetworkReasonCodeCommand::execute ()
{
  //## begin restcommand::NetworkReasonCodeCommand::execute%67FFC3A20373.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX42 RETRIEVE REASON CODES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLNWRC", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX42", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_hColumns.clear();
   m_iCount = 0;
   m_iQueryNumber = 0;
   int i = parse();
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_pXMLDocument->add("root");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   m_strNETWORK_RULES.erase();
   string strNetworkName = m_pXMLItem->get("network").c_str();
   string strUserRole = m_pXMLItem->get("role").c_str();
   string strREQUEST_TYPE = m_pXMLItem->get("requestType").c_str();
   determineNetworkRules(strCUST_ID, strNetworkName, strUserRole);
   if (m_strNETWORK_RULES.empty())
   {
      determineNetworkRules("****", strNetworkName, strUserRole);
      if (m_strNETWORK_RULES.empty())
         m_strNETWORK_RULES = "GEN";
   }
   m_strRULE_SET_ID.erase();
   if (determineRULE_SET_ID(strCUST_ID) == 1)
   {
      SOAPSegment::instance()->setRtnCde('2');
      m_pXMLDocument->add("details");
      return reply();;
   }
   if (m_strRULE_SET_ID.empty())
   {
      if (determineRULE_SET_ID("****") == 1)
      {
         SOAPSegment::instance()->setRtnCde('2');
         m_pXMLDocument->add("details");
         return reply();
      }
   }
   if (m_strRULE_SET_ID.empty())
   {
      SOAPSegment::instance()->setRtnCde('2');
      m_pXMLDocument->add("details");
      return reply();
   }
   string baseRULE_SET_ID = determineBaseRULE_SET_ID(m_strRULE_SET_ID);
   m_iQueryNumber = 1;
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY", "EMSR_RESN_CODE");
   m_hQuery.setQualifier("QUALIFY", "EMSR_DESC_TEXT");
   m_hQuery.bind("EMSR_RESN_CODE", "RESN_CODE_ID", Column::STRING, &m_strRESN_CODE_ID);
   m_hQuery.bind("EMSR_DESC_TEXT", "DESCRIPTION_TEXT", Column::STRING, &m_strDESCRIPTION_TEXT);
   m_hQuery.join("EMSR_RESN_CODE", "INNER", "EMSR_DESC_TEXT", "DESCRIPTION_ID");
   m_hQuery.join("EMSR_RESN_CODE", "INNER", "EMSR_DESC_TEXT", "RULE_SET_STAT", "DESCRIPTION_STAT");
   if (!strREQUEST_TYPE.empty())
   {
      m_hQuery.setQualifier("QUALIFY", "EMSR_RESN_DETAIL");
      m_hQuery.join("EMSR_RESN_CODE", "LEFT OUTER", "EMSR_RESN_DETAIL", "RESN_CODE_ID");
      m_hQuery.join("EMSR_RESN_CODE", "LEFT OUTER", "EMSR_RESN_DETAIL", "RULE_SET_ID");
      m_hQuery.join("EMSR_RESN_CODE", "LEFT OUTER", "EMSR_RESN_DETAIL", "RULE_SET_STAT");
      m_hQuery.join(0, "LEFT OUTER", "EMSR_RESN_DETAIL", strREQUEST_TYPE.c_str(), "PHASE_ID");
      m_hQuery.join(0, "LEFT OUTER", "EMSR_RESN_DETAIL", Clock::instance()->getYYYYMMDDHHMMSS().substr(0, 8).c_str(), "EXPIRATION_DATE", ">");
   }
   m_hQuery.setBasicPredicate("EMSR_RESN_CODE", "RULE_SET_STAT", "=", "P");
   string strTemp = "('" + baseRULE_SET_ID + "','" + m_strRULE_SET_ID + "')";
   m_hQuery.setBasicPredicate("EMSR_RESN_CODE", "RULE_SET_ID", "IN", strTemp.c_str());
   m_hQuery.setOrderByClause("RESN_CODE_ID");
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false || pSelectStatement->getRows() == 0)
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
      m_pXMLDocument->add("details");
      return reply();
   }
   else
   {
      short iNull;
      vector<pair<string, string> >::iterator p;
      for (p = m_hColumns.begin(); p != m_hColumns.end(); ++p)
      {
         m_hGenericSegment.set("Code", (*p).first);
         m_hGenericSegment.set("Description", (*p).second);
         {
            m_hQuery.reset();
            m_iQueryNumber = 2;
            m_hQuery.setQualifier("QUALIFY", "EMSR_ACTION_DETAIL");
            m_hQuery.bind("EMSR_ACTION_DETAIL", "*", Column::LONG, &m_iCount, &iNull, "COUNT");
            m_hQuery.setBasicPredicate("EMSR_ACTION_DETAIL", "RESN_CODE_ID", "=", (*p).first.c_str());
            m_hQuery.setBasicPredicate("EMSR_ACTION_DETAIL", "RULE_SET_STAT", "=", "P");
            m_hQuery.setBasicPredicate("EMSR_ACTION_DETAIL", "PHASE_ID", "=", strREQUEST_TYPE.c_str());
            m_hQuery.setBasicPredicate("EMSR_ACTION_DETAIL", "RULE_SET_ID", "IN", strTemp.c_str());
            bool b = pSelectStatement->execute(m_hQuery);
            if (b == false)
            {
               m_pXMLDocument->revert();
               SOAPSegment::instance()->setRtnCde('5');
               m_pXMLDocument->add("details");
               return reply();
            }
         }
         {
            m_hQuery.reset();
            m_iQueryNumber = 3;
            m_hQuery.setQualifier("QUALIFY", "EMSR_MMT_DETAIL");
            m_hQuery.bind("EMSR_MMT_DETAIL", "*", Column::LONG, &m_iCount, &iNull, "COUNT");
            m_hQuery.setBasicPredicate("EMSR_MMT_DETAIL", "RESN_CODE_ID", "=", (*p).first.c_str());
            m_hQuery.setBasicPredicate("EMSR_MMT_DETAIL", "RULE_SET_STAT", "=", "P");
            m_hQuery.setBasicPredicate("EMSR_MMT_DETAIL", "PHASE_ID", "=", strREQUEST_TYPE.c_str());
            m_hQuery.setBasicPredicate("EMSR_MMT_DETAIL", "RULE_SET_ID", "IN", strTemp.c_str());
            bool b = pSelectStatement->execute(m_hQuery);
            if (b == false)
            {
               m_pXMLDocument->revert();
               SOAPSegment::instance()->setRtnCde('5');
               m_pXMLDocument->add("details");
               return reply();
            }
         }
      }
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::NetworkReasonCodeCommand::execute%67FFC3A20373.body
}

void NetworkReasonCodeCommand::update (Subject* pSubject)
{
  //## begin restcommand::NetworkReasonCodeCommand::update%67FFC3C303CE.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      if (m_iQueryNumber > 0 && m_iQueryNumber <=3)
      {
         if (m_iQueryNumber == 1)
            m_hColumns.push_back(make_pair(m_strRESN_CODE_ID,m_strDESCRIPTION_TEXT));
         else if (m_iQueryNumber == 2)
         {
            if (m_iCount > 0)
               m_hGenericSegment.set("Actions", "Y");
            else
               m_hGenericSegment.set("Actions", "N");
         }
         else if (m_iQueryNumber == 3)
         {
            ++m_iRows;
            ++m_iTotalRows;
            if (m_iCount > 0)
               m_hGenericSegment.set("MMT", "Y");
            else
               m_hGenericSegment.set("MMT", "N");
            m_pXMLDocument->add("row");
         }
      }
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::NetworkReasonCodeCommand::update%67FFC3C303CE.body
}

// Additional Declarations
  //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.declarations preserve=yes
  //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.declarations

} // namespace restcommand

//## begin module%67FFBD650177.epilog preserve=yes
//## end module%67FFBD650177.epilog
