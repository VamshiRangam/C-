//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66A3A4D7033E.cm preserve=no
//## end module%66A3A4D7033E.cm

//## begin module%66A3A4D7033E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66A3A4D7033E.cp

//## Module: CXOSJX24%66A3A4D7033E; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX24.hpp

#ifndef CXOSJX24_h
#define CXOSJX24_h 1

//## begin module%66A3A4D7033E.additionalIncludes preserve=no
//## end module%66A3A4D7033E.additionalIncludes

//## begin module%66A3A4D7033E.includes preserve=yes
//## end module%66A3A4D7033E.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%66A3A4D7033E.declarations preserve=no
//## end module%66A3A4D7033E.declarations

//## begin module%66A3A4D7033E.additionalDeclarations preserve=yes
//## end module%66A3A4D7033E.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ServiceUnavailableCommand%66A3A460039A.preface preserve=yes
//## end restcommand::ServiceUnavailableCommand%66A3A460039A.preface

//## Class: ServiceUnavailableCommand%66A3A460039A
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66A3A48602C9;monitor::UseCase { -> F}
//## Uses: <unnamed>%66A3A48A0106;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%66A3A48E0207;segment::CommonHeaderSegment { -> F}

class DllExport ServiceUnavailableCommand : public command::RESTCommand  //## Inherits: <unnamed>%66A3A48301AF
{
  //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.initialDeclarations preserve=yes
  //## end restcommand::ServiceUnavailableCommand%66A3A460039A.initialDeclarations

  public:
    //## Constructors (generated)
      ServiceUnavailableCommand();

    //## Constructors (specified)
      //## Operation: ServiceUnavailableCommand%66A3A59203C7
      ServiceUnavailableCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ServiceUnavailableCommand();


    //## Other Operations (specified)
      //## Operation: execute%66A3A5B70238
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.public preserve=yes
      //## end restcommand::ServiceUnavailableCommand%66A3A460039A.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.protected preserve=yes
      //## end restcommand::ServiceUnavailableCommand%66A3A460039A.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.private preserve=yes
      //## end restcommand::ServiceUnavailableCommand%66A3A460039A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.implementation preserve=yes
      //## end restcommand::ServiceUnavailableCommand%66A3A460039A.implementation

};

//## begin restcommand::ServiceUnavailableCommand%66A3A460039A.postscript preserve=yes
//## end restcommand::ServiceUnavailableCommand%66A3A460039A.postscript

} // namespace restcommand

//## begin module%66A3A4D7033E.epilog preserve=yes
//## end module%66A3A4D7033E.epilog


#endif
