//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6780D7540025.cm preserve=no
//## end module%6780D7540025.cm

//## begin module%6780D7540025.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6780D7540025.cp

//## Module: CXOSJX33%6780D7540025; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX33.hpp

#ifndef CXOSJX33_h
#define CXOSJX33_h 1

//## begin module%6780D7540025.additionalIncludes preserve=no
//## end module%6780D7540025.additionalIncludes

//## begin module%6780D7540025.includes preserve=yes
//## end module%6780D7540025.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;
} // namespace segment

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class WorkQueueUserSegment;
class WorkQueueEntitySegment;
class WorkQueueSegment;

} // namespace viewsegment

//## begin module%6780D7540025.declarations preserve=no
//## end module%6780D7540025.declarations

//## begin module%6780D7540025.additionalDeclarations preserve=yes
//## end module%6780D7540025.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.preface preserve=yes
//## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.preface

//## Class: SaveWorkqueueCommand%6780D8FD00F1
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST SaveWorkqueueCommand
//	<h6>Resolve : REST : SaveWorkqueueCommand
//	<p>
//	Saves a work queue with list of predicates and list of
//	assigned users.
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/resolve/saveworkqueue.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6780DB2C030E;monitor::UseCase { -> F}
//## Uses: <unnamed>%6780DB2F0278;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6780DB34015C;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6780DB4B0086;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6785257F00D4;reusable::Table { -> F}
//## Uses: <unnamed>%678DE3F2023F;reusable::Query { -> F}
//## Uses: <unnamed>%678DE4F80371;reusable::Statement { -> F}
//## Uses: <unnamed>%678DFA9C0235;database::Database { -> F}
//## Uses: <unnamed>%678E07B5017C;viewsegment::WorkQueueUserSegment { -> F}
//## Uses: <unnamed>%678E07D1037E;viewsegment::WorkQueueEntitySegment { -> F}
//## Uses: <unnamed>%678E24030007;viewsegment::WorkQueueSegment { -> F}
//## Uses: <unnamed>%678E33DE00D4;IF::Extract { -> F}
//## Uses: <unnamed>%678E588E0254;segment::CommonHeaderSegment { -> F}

class DllExport SaveWorkqueueCommand : public command::RESTCommand  //## Inherits: <unnamed>%6780DB280071
{
  //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.initialDeclarations preserve=yes
  //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.initialDeclarations

  public:
    //## Constructors (generated)
      SaveWorkqueueCommand();

    //## Constructors (specified)
      //## Operation: SaveWorkqueueCommand%6780F304027E
      SaveWorkqueueCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~SaveWorkqueueCommand();


    //## Other Operations (specified)
      //## Operation: endElement%678524D5033A
      virtual bool endElement (const string& strTag);

      //## Operation: execute%6780F3640303
      virtual bool execute ();

      //## Operation: save%678A008C0011
      bool save ();

      //## Operation: update%6780F38301E1
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.public preserve=yes
      //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.protected preserve=yes
      //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.private preserve=yes
      //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Name%678E61F70104
      //## begin restcommand::SaveWorkqueueCommand::Name%678E61F70104.attr preserve=no  private: string {U} 
      string m_strName;
      //## end restcommand::SaveWorkqueueCommand::Name%678E61F70104.attr

      //## Attribute: Function%678E625B0363
      //## begin restcommand::SaveWorkqueueCommand::Function%678E625B0363.attr preserve=no  private: string {U} 
      string m_strFunction;
      //## end restcommand::SaveWorkqueueCommand::Function%678E625B0363.attr

      //## Attribute: Columns%678E6469014F
      //## begin restcommand::SaveWorkqueueCommand::Columns%678E6469014F.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumns;
      //## end restcommand::SaveWorkqueueCommand::Columns%678E6469014F.attr

      //## Attribute: Values%678E6486002B
      //## begin restcommand::SaveWorkqueueCommand::Values%678E6486002B.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hValues;
      //## end restcommand::SaveWorkqueueCommand::Values%678E6486002B.attr

      //## Attribute: Return%678E64C0001F
      //## begin restcommand::SaveWorkqueueCommand::Return%678E64C0001F.attr preserve=no  private: int {U} 0
      int m_iReturn;
      //## end restcommand::SaveWorkqueueCommand::Return%678E64C0001F.attr

      //## Attribute: CONSTRAINT_ID%678E64D4024C
      //## begin restcommand::SaveWorkqueueCommand::CONSTRAINT_ID%678E64D4024C.attr preserve=no  private: int {U} 0
      int m_iCONSTRAINT_ID;
      //## end restcommand::SaveWorkqueueCommand::CONSTRAINT_ID%678E64D4024C.attr

      //## Attribute: Delete%678E64EC012D
      //## begin restcommand::SaveWorkqueueCommand::Delete%678E64EC012D.attr preserve=no  private: bool {U} false
      bool m_bDelete;
      //## end restcommand::SaveWorkqueueCommand::Delete%678E64EC012D.attr

    // Additional Implementation Declarations
      //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.implementation preserve=yes
      //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.implementation

};

//## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.postscript preserve=yes
//## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.postscript

} // namespace restcommand

//## begin module%6780D7540025.epilog preserve=yes
//## end module%6780D7540025.epilog


#endif
