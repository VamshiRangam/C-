//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6780D7560024.cm preserve=no
//## end module%6780D7560024.cm

//## begin module%6780D7560024.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6780D7560024.cp

//## Module: CXOSJX33%6780D7560024; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX33.cpp

//## begin module%6780D7560024.additionalIncludes preserve=no
//## end module%6780D7560024.additionalIncludes

//## begin module%6780D7560024.includes preserve=yes
//## end module%6780D7560024.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSVS02_h
#include "CXODVS02.hpp"
#endif
#ifndef CXOSVS03_h
#include "CXODVS03.hpp"
#endif
#ifndef CXOSVS01_h
#include "CXODVS01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX33_h
#include "CXODJX33.hpp"
#endif


//## begin module%6780D7560024.declarations preserve=no
//## end module%6780D7560024.declarations

//## begin module%6780D7560024.additionalDeclarations preserve=yes
//## end module%6780D7560024.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::SaveWorkqueueCommand 

SaveWorkqueueCommand::SaveWorkqueueCommand()
  //## begin SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.hasinit preserve=no
      : m_iReturn(0),
        m_iCONSTRAINT_ID(0),
        m_bDelete(false)
  //## end SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.hasinit
  //## begin SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/saveworkqueue/v1.0.0", "S0003D", "@##JUWRKQ ")
  //## end SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.initialization
{
  //## begin restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.body preserve=yes
   memcpy(m_sID, "JX33", 4);
  //## end restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780D8FD00F1_const.body
}

SaveWorkqueueCommand::SaveWorkqueueCommand (Handler* pSuccessor)
  //## begin restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.hasinit preserve=no
      : m_iReturn(0),
        m_iCONSTRAINT_ID(0),
        m_bDelete(false)
  //## end restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.hasinit
  //## begin restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/saveworkqueue/v1.0.0", "S0003D", "@##JUWRKQ ")
  //## end restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.initialization
{
  //## begin restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.body preserve=yes
   memcpy(m_sID, "JX33", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::SaveWorkqueueCommand::SaveWorkqueueCommand%6780F304027E.body
}


SaveWorkqueueCommand::~SaveWorkqueueCommand()
{
  //## begin restcommand::SaveWorkqueueCommand::~SaveWorkqueueCommand%6780D8FD00F1_dest.body preserve=yes
  //## end restcommand::SaveWorkqueueCommand::~SaveWorkqueueCommand%6780D8FD00F1_dest.body
}



//## Other Operations (implementation)
bool SaveWorkqueueCommand::endElement (const string& strTag)
{
  //## begin restcommand::SaveWorkqueueCommand::endElement%678524D5033A.body preserve=yes
   if (m_iReturn == 0)
   {
      if (strTag == "function" && m_strFunction.empty())
         m_strFunction = m_pXMLItem->get("function");
      if (m_strFunction == "ADD" || m_strFunction == "UPDATE")
      {
         if (strTag == "name")
         {
            if (m_pXMLItem->get("name") == "WorkQueue")
               m_strName = "WorkQueue";
            else if (m_pXMLItem->get("name") == "Predicate")
               m_strName = "Predicate";
            else if (m_pXMLItem->get("name") == "User")
               m_strName = "User";
            m_bDelete = false;
            m_hColumns.clear();
         }
         if (strTag == "column")
            m_hColumns.push_back(m_pXMLItem->get("column"));
         if (strTag == "value")
            m_hValues.push_back(m_pXMLItem->get("value"));
         if (strTag == "row")
         {
            if (m_hColumns.size() != m_hValues.size())
               m_iReturn = 1;
            else if (save() == false)
               m_iReturn = 2;
            m_hValues.clear();
         }
         m_pXMLItem->resetToken();
      }
      if (m_iReturn != 0)
         Database::instance()->rollback();
   }
   return true;
  //## end restcommand::SaveWorkqueueCommand::endElement%678524D5033A.body
}

bool SaveWorkqueueCommand::execute ()
{
  //## begin restcommand::SaveWorkqueueCommand::execute%6780F3640303.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX33 SAVE WORKQUEUE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJUWRKQ", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX33", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_strFunction.clear();
   m_iReturn = 0;
   m_hColumns.clear();
   m_hValues.clear();
   m_iCONSTRAINT_ID = 0;
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (m_strFunction == "DELETE" && iRC == 0)
   {
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      Query hQuery;
      for (int j = 0; j < 3; j++)
      {
         hQuery.reset();
         if (j == 0)
         {
            hQuery.setQualifier("QUALIFY", "CQC_COLUMN_QUAL");
            hQuery.setBasicPredicate("CQC_COLUMN_QUAL", "CONSTRAINT_ID", "=", atoi(m_pXMLItem->get("constraint").c_str()));
         }
         else if (j == 1)
         {
            hQuery.setQualifier("QUALIFY", "CQC_USER");
            hQuery.setBasicPredicate("CQC_USER", "CONSTRAINT_ID", "=", atoi(m_pXMLItem->get("constraint").c_str()));
         }
         else if (j == 2)
         {
            hQuery.setQualifier("QUALIFY", "CQC_CONSTRAINT");
            hQuery.setBasicPredicate("CQC_CONSTRAINT", "CONSTRAINT_ID", "=", atoi(m_pXMLItem->get("constraint").c_str()));
         }
         if (pDeleteStatement->execute(hQuery) == false)
         {
            m_iReturn = 2;
            Database::instance()->rollback();
            break;
         }
      }
   }
   if (iRC != 0 || m_iReturn == 1)
   {
      UseCase::setSuccess(false);
      SOAPSegment::instance()->setRtnCde('3');
      SOAPSegment::instance()->setTxt("Invalid request (parse failure)");
   }
   else if (m_iReturn == 2)
   {
      UseCase::setSuccess(false);
      SOAPSegment::instance()->setRtnCde('5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::SaveWorkqueueCommand::execute%6780F3640303.body
}

bool SaveWorkqueueCommand::save ()
{
  //## begin restcommand::SaveWorkqueueCommand::save%678A008C0011.body preserve=yes
   Query hQuery;
   Table hTable;
   hQuery.reset();
   hTable.reset();
   hTable.setQualifier("QUALIFY");
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if(m_strName == "WorkQueue")
   {
      WorkQueueSegment hWorkQueueSegment;
      string strCUST_ID;
      Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
      hWorkQueueSegment.setCUST_ID(strCUST_ID);
      hWorkQueueSegment.setUSER_ID(CommonHeaderSegment::instance()->getUserID());
      for (int i = 0; i < m_hColumns.size() && i < m_hValues.size(); i++)
      {
         if (m_hColumns[i] == "Constraint")
         {
            m_iCONSTRAINT_ID = atoi(m_hValues[i].c_str());
            hWorkQueueSegment.setCONSTRAINT_ID(m_iCONSTRAINT_ID);
         }
         else if (m_hColumns[i] == "Type")
            hWorkQueueSegment.setTYPE(m_hValues[i].c_str());
         else if (m_hColumns[i] == "Description")
            hWorkQueueSegment.setDESCRIPTION(m_hValues[i].c_str());
         else if (m_hColumns[i] == "OrderBy")
            hWorkQueueSegment.setORDER_BY(m_hValues[i].c_str());
      }
      hQuery.setQualifier("QUALIFY", "CQC_CONSTRAINT");
      if (m_strFunction == "ADD")
      {
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         int m;
         short int iNull = -1;
         hQuery.bind("CQC_CONSTRAINT", "CONSTRAINT_ID", Column::LONG, &m, &iNull, "MAX");
         if (pSelectStatement->execute(hQuery) == false)
            return false;
         if (iNull != -1)
            m_iCONSTRAINT_ID = m + 1;
         hWorkQueueSegment.setCONSTRAINT_ID(m_iCONSTRAINT_ID);
         hWorkQueueSegment.setColumns(hTable);
         if (pInsertStatement->execute(hTable) == false)
            return false;
      }
      else if (m_strFunction == "UPDATE")
      {
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         hWorkQueueSegment.setColumns(hTable);
         if (pUpdateStatement->execute(hTable) == false )
            return false;
      }
   }
   else if (m_strName == "Predicate")
   {
      WorkQueueEntitySegment hWorkQueueEntitySegment;
      hWorkQueueEntitySegment.setCONSTRAINT_ID(m_iCONSTRAINT_ID);
      for (int i = 0; i < m_hColumns.size() && i < m_hValues.size(); i++)
      {
         if (m_hColumns[i] == "Table")
            hWorkQueueEntitySegment.setTABLE_NAME(m_hValues[i].c_str());
         else if (m_hColumns[i] == "Column")
            hWorkQueueEntitySegment.setCOLUMN_NAME(m_hValues[i].c_str());
         else if (m_hColumns[i] == "Operator")
            hWorkQueueEntitySegment.setOPERATOR_TYPE(m_hValues[i].c_str());
         else if (m_hColumns[i] == "Value")
            hWorkQueueEntitySegment.setCOLUMN_VALUE(m_hValues[i].c_str());
         else if (m_hColumns[i] == "Type")
            hWorkQueueEntitySegment.setCOLUMN_DATATYPE(m_hValues[i].c_str());
      }
      hQuery.setQualifier("QUALIFY", "CQC_COLUMN_QUAL");
      hWorkQueueEntitySegment.setColumns(hTable);
      if (m_strFunction == "UPDATE" && !m_bDelete)
      {
         hQuery.setBasicPredicate("CQC_COLUMN_QUAL", "CONSTRAINT_ID", "=", m_iCONSTRAINT_ID);
         if (pDeleteStatement->execute(hQuery) == false)
            return false;
         m_bDelete = true;
      }
      if (pInsertStatement->execute(hTable) == false)
         return false;
   }
   else if (m_strName == "User")
   {
      WorkQueueUserSegment hWorkQueueUserSegment;
      hWorkQueueUserSegment.setCONSTRAINT_ID(m_iCONSTRAINT_ID);
      hWorkQueueUserSegment.setUSER_ID(m_hValues[0].c_str());
      hWorkQueueUserSegment.setColumns(hTable);
      hQuery.setQualifier("QUALIFY", "CQC_USER");
      if (m_strFunction == "UPDATE" && !m_bDelete)
      {
         hQuery.setBasicPredicate("CQC_USER", "CONSTRAINT_ID", "=", m_iCONSTRAINT_ID);
         if (pDeleteStatement->execute(hQuery) == false)
            return false;
         m_bDelete = true;
      }
      if (pInsertStatement->execute(hTable) == false)
         return false;
   }
   return true;
  //## end restcommand::SaveWorkqueueCommand::save%678A008C0011.body
}

void SaveWorkqueueCommand::update (Subject* pSubject)
{
  //## begin restcommand::SaveWorkqueueCommand::update%6780F38301E1.body preserve=yes
   RESTCommand::update(pSubject);
  //## end restcommand::SaveWorkqueueCommand::update%6780F38301E1.body
}

// Additional Declarations
  //## begin restcommand::SaveWorkqueueCommand%6780D8FD00F1.declarations preserve=yes
  //## end restcommand::SaveWorkqueueCommand%6780D8FD00F1.declarations

} // namespace restcommand

//## begin module%6780D7560024.epilog preserve=yes
//## end module%6780D7560024.epilog
