//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D42726028D.cm preserve=no
//## end module%65D42726028D.cm

//## begin module%65D42726028D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D42726028D.cp

//## Module: CXOSJX15%65D42726028D; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX15.hpp

#ifndef CXOSJX15_h
#define CXOSJX15_h 1

//## begin module%65D42726028D.additionalIncludes preserve=no
//## end module%65D42726028D.additionalIncludes

//## begin module%65D42726028D.includes preserve=yes
//## end module%65D42726028D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65D42726028D.declarations preserve=no
//## end module%65D42726028D.declarations

//## begin module%65D42726028D.additionalDeclarations preserve=yes
//## end module%65D42726028D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReconsCommand%65D417BA011F.preface preserve=yes
//## end restcommand::ReconsCommand%65D417BA011F.preface

//## Class: ReconsCommand%65D417BA011F
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Research REST Transaction Reconciliations
//	<h6>Research : REST : Transaction Reconciliations
//	<p>
//	<ul>
//	<li><a href="../../REST/recons/recons.yml">YAML</a>
//	<li><a
//	href="../../REST/recons/request/recons.json">sample
//	request</a>
//	<li><a
//	href="../../REST/recons/request/recons.schema.json">JSON
//	request schema</a>
//	<li><a
//	href="../../REST/recons/response/recons.json">sample
//	response</a>
//	<li><a
//	href="../../REST/recons/response/recons.schema.json">JSON
//	 response schema</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65D41E8D0195;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%65D41E8F0130;monitor::UseCase { -> F}
//## Uses: <unnamed>%65D41E900328;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%65D41E9202F0;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65D41E95011E;reusable::Buffer { -> F}
//## Uses: <unnamed>%65D41E9801F4;IF::Extract { -> F}
//## Uses: <unnamed>%65E87ED4035F;configuration::ConfigurationRepository { -> F}

class DllExport ReconsCommand : public command::RESTCommand  //## Inherits: <unnamed>%65D41E860136
{
  //## begin restcommand::ReconsCommand%65D417BA011F.initialDeclarations preserve=yes
  //## end restcommand::ReconsCommand%65D417BA011F.initialDeclarations

  public:
    //## Constructors (generated)
      ReconsCommand();

    //## Constructors (specified)
      //## Operation: ReconsCommand%65D41F0403C0
      ReconsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReconsCommand();


    //## Other Operations (specified)
      //## Operation: execute%65D41F1F015B
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%65D41F210394
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReconsCommand%65D417BA011F.public preserve=yes
      //## end restcommand::ReconsCommand%65D417BA011F.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReconsCommand%65D417BA011F.protected preserve=yes
      //## end restcommand::ReconsCommand%65D417BA011F.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReconsCommand%65D417BA011F.private preserve=yes
      //## end restcommand::ReconsCommand%65D417BA011F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DESCRPT%65E87B1D02BF
      //## begin restcommand::ReconsCommand::DESCRPT%65E87B1D02BF.attr preserve=no  private: string {U} 
      string m_strDESCRPT;
      //## end restcommand::ReconsCommand::DESCRPT%65E87B1D02BF.attr

      //## Attribute: TABDAT%65E87B5F027E
      //## begin restcommand::ReconsCommand::TABDAT%65E87B5F027E.attr preserve=no  private: string {U} 
      string m_strTABDAT;
      //## end restcommand::ReconsCommand::TABDAT%65E87B5F027E.attr

      //## Attribute: FileType%65E87B8C0113
      //## begin restcommand::ReconsCommand::FileType%65E87B8C0113.attr preserve=no  private: vector<pair<string, string> > {V} 
      vector<pair<string, string> > m_hFileType;
      //## end restcommand::ReconsCommand::FileType%65E87B8C0113.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D41EA6009A
      //## Role: ReconsCommand::<m_hGenericSegment>%65D41EA603AC
      //## begin restcommand::ReconsCommand::<m_hGenericSegment>%65D41EA603AC.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReconsCommand::<m_hGenericSegment>%65D41EA603AC.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D41EAD01A7
      //## Role: ReconsCommand::<m_hQuery>%65D41EAE0130
      //## begin restcommand::ReconsCommand::<m_hQuery>%65D41EAE0130.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReconsCommand::<m_hQuery>%65D41EAE0130.role

    // Additional Implementation Declarations
      //## begin restcommand::ReconsCommand%65D417BA011F.implementation preserve=yes
      //## end restcommand::ReconsCommand%65D417BA011F.implementation

};

//## begin restcommand::ReconsCommand%65D417BA011F.postscript preserve=yes
//## end restcommand::ReconsCommand%65D417BA011F.postscript

} // namespace restcommand

//## begin module%65D42726028D.epilog preserve=yes
//## end module%65D42726028D.epilog


#endif
