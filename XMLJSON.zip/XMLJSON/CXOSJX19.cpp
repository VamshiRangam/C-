//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66574F660130.cm preserve=no
//## end module%66574F660130.cm

//## begin module%66574F660130.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66574F660130.cp

//## Module: CXOSJX19%66574F660130; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX19.cpp

//## begin module%66574F660130.additionalIncludes preserve=no
//## end module%66574F660130.additionalIncludes

//## begin module%66574F660130.includes preserve=yes
//## end module%66574F660130.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX19_h
#include "CXODJX19.hpp"
#endif


//## begin module%66574F660130.declarations preserve=no
//## end module%66574F660130.declarations

//## begin module%66574F660130.additionalDeclarations preserve=yes
//## end module%66574F660130.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::EntitiesCommand 

EntitiesCommand::EntitiesCommand()
  //## begin EntitiesCommand::EntitiesCommand%66575071026E_const.hasinit preserve=no
  //## end EntitiesCommand::EntitiesCommand%66575071026E_const.hasinit
  //## begin EntitiesCommand::EntitiesCommand%66575071026E_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/entities/v1.0.0", "S0003D", "@##JLDATA ")
  //## end EntitiesCommand::EntitiesCommand%66575071026E_const.initialization
{
  //## begin restcommand::EntitiesCommand::EntitiesCommand%66575071026E_const.body preserve=yes
   memcpy(m_sID, "JX19", 4);
  //## end restcommand::EntitiesCommand::EntitiesCommand%66575071026E_const.body
}

EntitiesCommand::EntitiesCommand (Handler* pSuccessor)
  //## begin restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.hasinit preserve=no
  //## end restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.hasinit
  //## begin restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/entities/v1.0.0", "S0003D", "@##JLDATA ")
  //## end restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.initialization
{
  //## begin restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.body preserve=yes
   memcpy(m_sID, "JX19", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::EntitiesCommand::EntitiesCommand%665756BC02B2.body
}


EntitiesCommand::~EntitiesCommand()
{
  //## begin restcommand::EntitiesCommand::~EntitiesCommand%66575071026E_dest.body preserve=yes
  //## end restcommand::EntitiesCommand::~EntitiesCommand%66575071026E_dest.body
}



//## Other Operations (implementation)
bool EntitiesCommand::execute ()
{
  //## begin restcommand::EntitiesCommand::execute%66575708028C.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX19 GET DATA SECURITY DATA");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLDATA", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX19", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC;
   iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY", "AS_USER_PROFILE");
   m_hQuery.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
   m_hQuery.setQualifier("QUALIFY", "AS_ROLE_RELATION");
   m_hQuery.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
   m_hQuery.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
   m_hQuery.bind("AS_ROLE_RELATION", "RELATIONSHIP_ID", Column::STRING, &m_strRELATIONSHIP_ID);
   m_hQuery.bind("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", Column::STRING, &m_strSTS_TRAN_COL_NAME);
   m_hQuery.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, &m_strONLINE_ENTITY_ID);
   m_hQuery.bind("AS_USER_PROFILE", "PROFILE_ID", Column::STRING, &m_strPROFILE_ID);
   m_hQuery.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   string strOrder("AS_ROLE_RELATION.RELATIONSHIP_ID ASC");
   strOrder.append(",AS_ROLE_RELATION.STS_TRAN_COL_NAME ASC");
   strOrder.append(",AS_ENTITY_ROLE.ONLINE_ENTITY_ID ASC");
   strOrder.append(",AS_USER_PROFILE.PROFILE_ID ASC");
   m_hQuery.setOrderByClause(strOrder.c_str());
   m_hQuery.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", strCustomerID.c_str());
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::EntitiesCommand::execute%66575708028C.body
}

void EntitiesCommand::update (Subject* pSubject)
{
  //## begin restcommand::EntitiesCommand::update%6657572E016A.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iTotalRows;
      if (m_iMaxRows == 0)
         setMaxRows(100);
      if (m_iTotalRows > m_iSkipRows)
      {
         if (m_iTotalRows - m_iSkipRows <= m_iMaxRows)
         {
            m_hGenericSegment.set("ONLINE_ENTITY_ID", m_strONLINE_ENTITY_ID);
            m_hGenericSegment.set("STS_TRAN_COLUMN_NAME", m_strSTS_TRAN_COL_NAME);
            m_hGenericSegment.set("RELATIONSHIP_ID", m_strRELATIONSHIP_ID);
            m_hGenericSegment.set("PROFILE_ID", m_strPROFILE_ID);
            m_pXMLDocument->add("row");
            UseCase::addItem();
            m_iRows = m_iTotalRows;
         }
         else
            SOAPSegment::instance()->setRtnCde('1');
      }
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::EntitiesCommand::update%6657572E016A.body
}

// Additional Declarations
  //## begin restcommand::EntitiesCommand%66575071026E.declarations preserve=yes
  //## end restcommand::EntitiesCommand%66575071026E.declarations

} // namespace restcommand

//## begin module%66574F660130.epilog preserve=yes
//## end module%66574F660130.epilog
