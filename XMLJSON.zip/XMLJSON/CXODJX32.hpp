//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%677CB5980336.cm preserve=no
//## end module%677CB5980336.cm

//## begin module%677CB5980336.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%677CB5980336.cp

//## Module: CXOSJX32%677CB5980336; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX32.hpp

#ifndef CXOSJX32_h
#define CXOSJX32_h 1

//## begin module%677CB5980336.additionalIncludes preserve=no
//## end module%677CB5980336.additionalIncludes

//## begin module%677CB5980336.includes preserve=yes
//## end module%677CB5980336.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%677CB5980336.declarations preserve=no
//## end module%677CB5980336.declarations

//## begin module%677CB5980336.additionalDeclarations preserve=yes
//## end module%677CB5980336.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::WorkqueueCommand%677CB676021B.preface preserve=yes
//## end restcommand::WorkqueueCommand%677CB676021B.preface

//## Class: WorkqueueCommand%677CB676021B; private
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST Workqueue
//	<h6>Resolve : REST : Workqueue
//	<p>
//	Returns a work queue with list of predicates and list of
//	assigned users.
//	<p>
//	<ul>
//	<li><a href="../../REST/resolve/workqueue.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%677CB72002B5;monitor::UseCase { -> F}
//## Uses: <unnamed>%677CB725022B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%677CB72E0079;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%677E818803A5;database::DatabaseFactory { -> F}

class DllExport WorkqueueCommand : public command::RESTCommand  //## Inherits: <unnamed>%677CB7180293
{
  //## begin restcommand::WorkqueueCommand%677CB676021B.initialDeclarations preserve=yes
  //## end restcommand::WorkqueueCommand%677CB676021B.initialDeclarations

  public:
    //## Constructors (generated)
      WorkqueueCommand();

    //## Constructors (specified)
      //## Operation: WorkqueueCommand%677CB7CC0117
      WorkqueueCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~WorkqueueCommand();


    //## Other Operations (specified)
      //## Operation: execute%677CB80203C1
      virtual bool execute ();

      //## Operation: update%677CB82701E4
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::WorkqueueCommand%677CB676021B.public preserve=yes
      //## end restcommand::WorkqueueCommand%677CB676021B.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::WorkqueueCommand%677CB676021B.protected preserve=yes
      //## end restcommand::WorkqueueCommand%677CB676021B.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::WorkqueueCommand%677CB676021B.private preserve=yes
      //## end restcommand::WorkqueueCommand%677CB676021B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TagName%677CF6D60071
      //## begin restcommand::WorkqueueCommand::TagName%677CF6D60071.attr preserve=no  private: string {U} 
      string m_strTagName;
      //## end restcommand::WorkqueueCommand::TagName%677CF6D60071.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%677CB89A03D9
      //## Role: WorkqueueCommand::<m_hGenericSegment>%677CB89C0112
      //## begin restcommand::WorkqueueCommand::<m_hGenericSegment>%677CB89C0112.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::WorkqueueCommand::<m_hGenericSegment>%677CB89C0112.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%677CB89F039D
      //## Role: WorkqueueCommand::<m_hQuery>%677CB8A10233
      //## begin restcommand::WorkqueueCommand::<m_hQuery>%677CB8A10233.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::WorkqueueCommand::<m_hQuery>%677CB8A10233.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%677D2C3B0023
      //## Role: WorkqueueCommand::<m_pPersistentSegment>%677D2C3C0192
      //## begin restcommand::WorkqueueCommand::<m_pPersistentSegment>%677D2C3C0192.role preserve=no  public: segment::PersistentSegment { -> RHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end restcommand::WorkqueueCommand::<m_pPersistentSegment>%677D2C3C0192.role

    // Additional Implementation Declarations
      //## begin restcommand::WorkqueueCommand%677CB676021B.implementation preserve=yes
      //## end restcommand::WorkqueueCommand%677CB676021B.implementation

};

//## begin restcommand::WorkqueueCommand%677CB676021B.postscript preserve=yes
//## end restcommand::WorkqueueCommand%677CB676021B.postscript

} // namespace restcommand

//## begin module%677CB5980336.epilog preserve=yes
//## end module%677CB5980336.epilog


#endif
