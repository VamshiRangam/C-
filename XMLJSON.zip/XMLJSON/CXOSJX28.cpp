//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6717364F0166.cm preserve=no
//## end module%6717364F0166.cm

//## begin module%6717364F0166.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6717364F0166.cp

//## Module: CXOSJX28%6717364F0166; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX28.cpp

//## begin module%6717364F0166.additionalIncludes preserve=no
//## end module%6717364F0166.additionalIncludes

//## begin module%6717364F0166.includes preserve=yes
//## end module%6717364F0166.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSJX28_h
#include "CXODJX28.hpp"
#endif


//## begin module%6717364F0166.declarations preserve=no
//## end module%6717364F0166.declarations

//## begin module%6717364F0166.additionalDeclarations preserve=yes
//## end module%6717364F0166.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::LockCommand 

LockCommand::LockCommand()
  //## begin LockCommand::LockCommand%6717379902FE_const.hasinit preserve=no
  //## end LockCommand::LockCommand%6717379902FE_const.hasinit
  //## begin LockCommand::LockCommand%6717379902FE_const.initialization preserve=yes
   :RESTCommand("/rest/datanavigator/resolve/lock/v1.0.0","S0003D","@##JKCASE ")
  //## end LockCommand::LockCommand%6717379902FE_const.initialization
{
  //## begin restcommand::LockCommand::LockCommand%6717379902FE_const.body preserve=yes
   memcpy(m_sID, "JX28", 4);
  //## end restcommand::LockCommand::LockCommand%6717379902FE_const.body
}

LockCommand::LockCommand (Handler* pSuccessor)
  //## begin restcommand::LockCommand::LockCommand%6717400C03B6.hasinit preserve=no
  //## end restcommand::LockCommand::LockCommand%6717400C03B6.hasinit
  //## begin restcommand::LockCommand::LockCommand%6717400C03B6.initialization preserve=yes
   :RESTCommand("/rest/datanavigator/resolve/lock/v1.0.0","S0003D","@##JKCASE ")
  //## end restcommand::LockCommand::LockCommand%6717400C03B6.initialization
{
  //## begin restcommand::LockCommand::LockCommand%6717400C03B6.body preserve=yes
   memcpy(m_sID, "JX28", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::LockCommand::LockCommand%6717400C03B6.body
}


LockCommand::~LockCommand()
{
  //## begin restcommand::LockCommand::~LockCommand%6717379902FE_dest.body preserve=yes
  //## end restcommand::LockCommand::~LockCommand%6717379902FE_dest.body
}



//## Other Operations (implementation)
bool LockCommand::execute ()
{
  //## begin restcommand::LockCommand::execute%6717404A025B.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX28 LOCK EMSCASE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJKCASE", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX28", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_bValid = true;
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   int iCASE_ID;
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.bind("EMS_CASE", "CASE_ID", Column::LONG, &iCASE_ID);
   hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
   bool b = pSelectStatement->execute(hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(pSelectStatement->getRows() == 0 ? '2' : '5');
   else
   {
      if (process(iCASE_ID) == false )
         SOAPSegment::instance()->setRtnCde(m_bValid ? '5' : '3');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::LockCommand::execute%6717404A025B.body
}

bool LockCommand::process (const int& iCASE_ID)
{
  //## begin restcommand::LockCommand::process%6717411602CB.body preserve=yes
   Query hQuery;
   string strUSER_ID;
   string strTSTAMP_LOCK_UNTIL;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.bind("EMS_CASE_LOCK", "USER_ID", Column::STRING, &strUSER_ID);
   hQuery.bind("EMS_CASE_LOCK", "TSTAMP_LOCK_UNTIL", Column::STRING, &strTSTAMP_LOCK_UNTIL);
   hQuery.setBasicPredicate("EMS_CASE_LOCK", "CASE_ID", "=", iCASE_ID);
   if (!pSelectStatement->execute(hQuery))
      return false;
   if ((m_pXMLItem->get("action") == "L") && (pSelectStatement->getRows() == 0))
   {
      if (!unlock())
         return false;
      Table hTable("EMS_CASE_LOCK");
      hTable.set("CASE_ID", iCASE_ID, true);
      hTable.set("USER_ID", CommonHeaderSegment::instance()->getUserID());
      hTable.set("TSTAMP_LOCK_UNTIL", calculateUpdatedLockTime());
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (!pInsertStatement->execute(hTable))
         return false;
   }
   else if ((m_pXMLItem->get("action") == "L") && (pSelectStatement->getRows() > 0) &&
      ((CommonHeaderSegment::instance()->getUserID() == strUSER_ID) || strTSTAMP_LOCK_UNTIL < Clock::instance()->getYYYYMMDDHHMMSSHN(true)))
   {
      if (CommonHeaderSegment::instance()->getUserID() != strUSER_ID)
         if (!unlock())
            return false;
      Table hTable("EMS_CASE_LOCK");
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      hTable.set("CASE_ID", iCASE_ID, true);
      hTable.set("USER_ID", CommonHeaderSegment::instance()->getUserID());
      hTable.set("TSTAMP_LOCK_UNTIL", calculateUpdatedLockTime());
      if (!pUpdateStatement->execute(hTable))
         return false;
   }
   else if ((m_pXMLItem->get("action") == "U") && (strUSER_ID == CommonHeaderSegment::instance()->getUserID()))
   {
      if (!unlock())
         return false;
   }
   else
   {
      m_bValid = false;
      return false;
   }
   return true;
  //## end restcommand::LockCommand::process%6717411602CB.body
}

bool LockCommand::unlock ()
{
  //## begin restcommand::LockCommand::unlock%6717415701D3.body preserve=yes
   Query hQuery;
   hQuery.setBasicPredicate("EMS_CASE_LOCK", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
      return false;
   return true;
  //## end restcommand::LockCommand::unlock%6717415701D3.body
}

string LockCommand::calculateUpdatedLockTime ()
{
  //## begin restcommand::LockCommand::calculateUpdatedLockTime%6718DD2E02EA.body preserve=yes
   string strDateTime(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   string strDate(strDateTime.data(), 8);
   strDate += "000";
   string strTime(strDateTime.data() + 8, 6);
   int minuits_offset = atoi(m_pXMLItem->get("timeOut").c_str());
   Timestamp::adjustGMT(strDate, strTime, minuits_offset);
   string strTSTAMP_LOCK_UNTIL(strDate.data(), 8);
   strTSTAMP_LOCK_UNTIL += strTime;
   strTSTAMP_LOCK_UNTIL += "00";
   return strTSTAMP_LOCK_UNTIL;
  //## end restcommand::LockCommand::calculateUpdatedLockTime%6718DD2E02EA.body
}

void LockCommand::update (Subject* pSubject)
{
  //## begin restcommand::LockCommand::update%6717408202CE.body preserve=yes
   command::RESTCommand::update(pSubject);
  //## end restcommand::LockCommand::update%6717408202CE.body
}

// Additional Declarations
  //## begin restcommand::LockCommand%6717379902FE.declarations preserve=yes
  //## end restcommand::LockCommand%6717379902FE.declarations

} // namespace restcommand

//## begin module%6717364F0166.epilog preserve=yes
//## end module%6717364F0166.epilog
