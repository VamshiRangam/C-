//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66702AB8009B.cm preserve=no
//## end module%66702AB8009B.cm

//## begin module%66702AB8009B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66702AB8009B.cp

//## Module: CXOSJX20%66702AB8009B; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX20.hpp

#ifndef CXOSJX20_h
#define CXOSJX20_h 1

//## begin module%66702AB8009B.additionalIncludes preserve=no
//## end module%66702AB8009B.additionalIncludes

//## begin module%66702AB8009B.includes preserve=yes
//## end module%66702AB8009B.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%66702AB8009B.declarations preserve=no
//## end module%66702AB8009B.declarations

//## begin module%66702AB8009B.additionalDeclarations preserve=yes
//## end module%66702AB8009B.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ProfilesCommand%66702D6103AB.preface preserve=yes
//## end restcommand::ProfilesCommand%66702D6103AB.preface

//## Class: ProfilesCommand%66702D6103AB
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66702EE40169;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%66702EEA012F;monitor::UseCase { -> F}
//## Uses: <unnamed>%66702EEF016A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%66702EF30170;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66702EF80012;IF::Extract { -> F}
//## Uses: <unnamed>%66702EFE00DD;segment::CommonHeaderSegment { -> F}

class DllExport ProfilesCommand : public command::RESTCommand  //## Inherits: <unnamed>%66702EDA0399
{
  //## begin restcommand::ProfilesCommand%66702D6103AB.initialDeclarations preserve=yes
  //## end restcommand::ProfilesCommand%66702D6103AB.initialDeclarations

  public:
    //## Constructors (generated)
      ProfilesCommand();

    //## Constructors (specified)
      //## Operation: ProfilesCommand%66703229022B
      ProfilesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ProfilesCommand();


    //## Other Operations (specified)
      //## Operation: execute%6670328400A5
      virtual bool execute ();

      //## Operation: update%667032D70271
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ProfilesCommand%66702D6103AB.public preserve=yes
      //## end restcommand::ProfilesCommand%66702D6103AB.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ProfilesCommand%66702D6103AB.protected preserve=yes
      //## end restcommand::ProfilesCommand%66702D6103AB.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ProfilesCommand%66702D6103AB.private preserve=yes
      //## end restcommand::ProfilesCommand%66702D6103AB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROFILE_ID%6670334103A7
      //## begin restcommand::ProfilesCommand::PROFILE_ID%6670334103A7.attr preserve=no  private: string {U} 
      string m_strPROFILE_ID;
      //## end restcommand::ProfilesCommand::PROFILE_ID%6670334103A7.attr

      //## Attribute: RELATIONSHIP_ID%6670337C03D9
      //## begin restcommand::ProfilesCommand::RELATIONSHIP_ID%6670337C03D9.attr preserve=no  private: string {U} 
      string m_strRELATIONSHIP_ID;
      //## end restcommand::ProfilesCommand::RELATIONSHIP_ID%6670337C03D9.attr

      //## Attribute: PERMISSION_ID%667033A603B1
      //## begin restcommand::ProfilesCommand::PERMISSION_ID%667033A603B1.attr preserve=no  private: string {U} 
      string m_strPERMISSION_ID;
      //## end restcommand::ProfilesCommand::PERMISSION_ID%667033A603B1.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66702F5E023C
      //## Role: ProfilesCommand::<m_hQuery>%66702F5F01D2
      //## begin restcommand::ProfilesCommand::<m_hQuery>%66702F5F01D2.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ProfilesCommand::<m_hQuery>%66702F5F01D2.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66702F6403AB
      //## Role: ProfilesCommand::<m_hGenericSegment>%66702F650256
      //## begin restcommand::ProfilesCommand::<m_hGenericSegment>%66702F650256.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ProfilesCommand::<m_hGenericSegment>%66702F650256.role

    // Additional Implementation Declarations
      //## begin restcommand::ProfilesCommand%66702D6103AB.implementation preserve=yes
      //## end restcommand::ProfilesCommand%66702D6103AB.implementation

};

//## begin restcommand::ProfilesCommand%66702D6103AB.postscript preserve=yes
//## end restcommand::ProfilesCommand%66702D6103AB.postscript

} // namespace restcommand

//## begin module%66702AB8009B.epilog preserve=yes
//## end module%66702AB8009B.epilog


#endif
