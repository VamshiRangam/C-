//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66F2BB84006F.cm preserve=no
//## end module%66F2BB84006F.cm

//## begin module%66F2BB84006F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66F2BB84006F.cp

//## Module: CXOSJX26%66F2BB84006F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX26.cpp

//## begin module%66F2BB84006F.additionalIncludes preserve=no
//## end module%66F2BB84006F.additionalIncludes

//## begin module%66F2BB84006F.includes preserve=yes
//## end module%66F2BB84006F.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSRL05_h
#include "CXODRL05.hpp"
#endif
#ifndef CXOSJX26_h
#include "CXODJX26.hpp"
#endif


//## begin module%66F2BB84006F.declarations preserve=no
//## end module%66F2BB84006F.declarations

//## begin module%66F2BB84006F.additionalDeclarations preserve=yes
//## end module%66F2BB84006F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ActionsCommand 

ActionsCommand::ActionsCommand()
  //## begin ActionsCommand::ActionsCommand%66F2BCA40279_const.hasinit preserve=no
      : m_pszBuffer(0)
  //## end ActionsCommand::ActionsCommand%66F2BCA40279_const.hasinit
  //## begin ActionsCommand::ActionsCommand%66F2BCA40279_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/actions/v1.0.0", "S0003D", "@##JLACTD ")
  //## end ActionsCommand::ActionsCommand%66F2BCA40279_const.initialization
{
  //## begin restcommand::ActionsCommand::ActionsCommand%66F2BCA40279_const.body preserve=yes
   memcpy(m_sID, "JX26", 4);
  //## end restcommand::ActionsCommand::ActionsCommand%66F2BCA40279_const.body
}

ActionsCommand::ActionsCommand (Handler* pSuccessor)
  //## begin restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.hasinit preserve=no
      : m_pszBuffer(0)
  //## end restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.hasinit
  //## begin restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/actions/v1.0.0", "S0003D", "@##JLACTD ")
  //## end restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.initialization
{
  //## begin restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.body preserve=yes
   memcpy(m_sID, "JX26", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_pszBuffer = new char[sizeof(segActionDetail) + 1];
  //## end restcommand::ActionsCommand::ActionsCommand%66F2C0A90269.body
}


ActionsCommand::~ActionsCommand()
{
  //## begin restcommand::ActionsCommand::~ActionsCommand%66F2BCA40279_dest.body preserve=yes
   delete[] m_pszBuffer;
  //## end restcommand::ActionsCommand::~ActionsCommand%66F2BCA40279_dest.body
}



//## Other Operations (implementation)
bool ActionsCommand::execute ()
{
  //## begin restcommand::ActionsCommand::execute%66F2C102000C.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX26 LIST CLIENT ACTIONS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLACTD", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX26", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   CaseSegment::instance()->setPresence(true);
   CaseTransitionSegment::instance()->setPresence(true);
   CasePhaseSegment::instance()->setPresence(true);
   Query hQuery;
   hQuery.join("EMS_CASE", "INNER", "EMS_TRANSITION", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "PHASE_TSTAMP", "TSTAMP_CREATED");
   CaseSegment::instance()->bind(hQuery);
   CasePhaseSegment::instance()->bind(hQuery);
   CaseTransitionSegment::instance()->bind(hQuery);
   hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      char* psPreviousEnabledFields = 0;
      CaseSegment::instance()->setREQUEST_TYPE(m_pXMLItem->get("requestType"));
      CaseSegment::instance()->setSTATUS(m_pXMLItem->get("status"));
      if (!m_pXMLItem->get("previousRequestType").empty())
         CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV(m_pXMLItem->get("previousRequestType"));
      if (!m_pXMLItem->get("previousStatus").empty())
         CaseTransitionSegment::instance()->setSTATUS_PREV(m_pXMLItem->get("previousStatus"));
      CasePhaseSegment::instance()->setUSER_ROLE(m_pXMLItem->get("role"));
      bool b = ems::EMSRulesEngine::instance()->exportAvailableActions(m_pXMLItem->get("key").c_str(), this, m_pszBuffer, psPreviousEnabledFields);
      if (!b || m_iRows == 0)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('2');
      }
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ActionsCommand::execute%66F2C102000C.body
}

void ActionsCommand::update (Subject* pSubject)
{
  //## begin restcommand::ActionsCommand::update%66F2C12E021C.body preserve=yes
   if (pSubject == 0)
   {
      ++m_iRows;
      ++m_iTotalRows;
      segActionDetail* p = (segActionDetail*)m_pszBuffer;
      string strValue(p->sACTION_ID, sizeof(p->sACTION_ID));
      m_hGenericSegment.set("Action", rtrim(strValue));
      strValue.assign(p->sActionType, sizeof(p->sActionType));
      m_hGenericSegment.set("Type", rtrim(strValue));
      m_hGenericSegment.set("Instruction", p->sACTION_INSTRUCTION);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ActionsCommand::update%66F2C12E021C.body
}

// Additional Declarations
  //## begin restcommand::ActionsCommand%66F2BCA40279.declarations preserve=yes
  //## end restcommand::ActionsCommand%66F2BCA40279.declarations

} // namespace restcommand

//## begin module%66F2BB84006F.epilog preserve=yes
//## end module%66F2BB84006F.epilog
