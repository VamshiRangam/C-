//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67BEEF610034.cm preserve=no
//## end module%67BEEF610034.cm

//## begin module%67BEEF610034.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67BEEF610034.cp

//## Module: CXOSJX39%67BEEF610034; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX39.cpp

//## begin module%67BEEF610034.additionalIncludes preserve=no
//## end module%67BEEF610034.additionalIncludes

//## begin module%67BEEF610034.includes preserve=yes
//## end module%67BEEF610034.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSJX39_h
#include "CXODJX39.hpp"
#endif


//## begin module%67BEEF610034.declarations preserve=no
//## end module%67BEEF610034.declarations

//## begin module%67BEEF610034.additionalDeclarations preserve=yes
//## end module%67BEEF610034.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ContactsCommand 

ContactsCommand::ContactsCommand()
  //## begin ContactsCommand::ContactsCommand%67BEF0690257_const.hasinit preserve=no
  //## end ContactsCommand::ContactsCommand%67BEF0690257_const.hasinit
  //## begin ContactsCommand::ContactsCommand%67BEF0690257_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/configure/contacts/v1.0.0", "S0003D", "@##JRCONT ")
  //## end ContactsCommand::ContactsCommand%67BEF0690257_const.initialization
{
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF0690257_const.body preserve=yes
   memcpy(m_sID, "JX39", 4);
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF0690257_const.body
}

ContactsCommand::ContactsCommand (Handler* pSuccessor)
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.hasinit preserve=no
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.hasinit
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/configure/contacts/v1.0.0", "S0003D", "@##JRCONT ")
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.initialization
{
  //## begin restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.body preserve=yes
   memcpy(m_sID, "JX39", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ContactsCommand::ContactsCommand%67BEF23001AA.body
}


ContactsCommand::~ContactsCommand()
{
  //## begin restcommand::ContactsCommand::~ContactsCommand%67BEF0690257_dest.body preserve=yes
  //## end restcommand::ContactsCommand::~ContactsCommand%67BEF0690257_dest.body
}



//## Other Operations (implementation)
bool ContactsCommand::execute ()
{
  //## begin restcommand::ContactsCommand::execute%67BEF260020A.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX39 READ CONTACT");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRCONT", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX39", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   ContactSegment::instance(ContactSegment::SENDER)->reset();
   m_strINST_ID.clear();
   m_strPROC_GRP_ID.clear();
   m_strPROC_ID.clear();
   m_strBIN.clear();
   m_strDEVICE_ID.clear();
   m_strRPT_LVL_ID.clear();
   m_hQuery.reset();
   int i = parse();
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_pXMLDocument->add("root");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strColumn(m_pXMLItem->get("column"));
   string strOperator(m_pXMLItem->get("operator"));
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   m_hQuery.setQualifier("QUALIFY", "CONTACT_TYPE");
   if (strColumn == "Institution")
   {
      m_strINST_ID = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
      m_hQuery.setQualifier("QUALIFY", "INSTITUTION");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "PROC_ID");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "CUST_ID");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "PROC_GRP_ID");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "CUST_ID");
      m_hQuery.join("INSTITUTION", "INNER", "CONTACT_TYPE", "CONTACT_ID");
      m_hQuery.bind("INSTITUTION", "PROC_ID", Column::STRING, &m_strPROC_ID );
      m_hQuery.bind("PROCESSOR", "PROC_GRP_ID", Column::STRING, &m_strPROC_GRP_ID);
      m_hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("INSTITUTION", "INST_ID", strOperator.c_str(), m_strINST_ID.c_str());
      m_hQuery.setBasicPredicate("INSTITUTION", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("INSTITUTION", "CC_STATE", "IN", "('A','I')");
   }
   else if (strColumn == "IssuerBin")
   {
      m_strBIN = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "INSTITUTION");
      m_hQuery.setQualifier("QUALIFY", "INSTITUTION_BIN");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
      m_hQuery.join("INSTITUTION_BIN", "INNER", "CONTACT_TYPE", "CONTACT_ID");
      m_hQuery.join("INSTITUTION_BIN", "INNER", "INSTITUTION", "INST_ID", "INST_ID");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "PROC_ID");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "CUST_ID");
      m_hQuery.bind("INSTITUTION", "INST_ID", Column::STRING, &m_strINST_ID);
      m_hQuery.bind("INSTITUTION", "PROC_ID", Column::STRING, &m_strPROC_ID);
      m_hQuery.bind("PROCESSOR", "PROC_GRP_ID", Column::STRING, &m_strPROC_GRP_ID);
      m_hQuery.setBasicPredicate("INSTITUTION_BIN", "BIN", strOperator.c_str(), m_strBIN.c_str());
      m_hQuery.setBasicPredicate("INSTITUTION_BIN", "CUST_ID", " = ", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("INSTITUTION_BIN", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("INSTITUTION_BIN", "CC_STATE", "IN", "('A','I')");
   }
   else if (strColumn == "Processor")
   {
      m_strPROC_ID = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "PROC_GRP_ID");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "CUST_ID");
      m_hQuery.join("CONTACT_TYPE", "INNER", "PROCESSOR", "CONTACT_ID");
      m_hQuery.bind("PROCESSOR", "PROC_ID", Column::STRING, &m_strPROC_ID);
      m_hQuery.bind("PROCESSOR", "PROC_GRP_ID", Column::STRING, &m_strPROC_GRP_ID);
      m_hQuery.setBasicPredicate("PROCESSOR", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("PROCESSOR", "PROC_ID", strOperator.c_str(), m_strPROC_ID.c_str());
      m_hQuery.setBasicPredicate("PROCESSOR", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("PROCESSOR", "CC_STATE", "=", "A");
   }
   else if (strColumn == "Group")
   {
      m_strPROC_GRP_ID = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
      m_hQuery.join("CONTACT_TYPE", "INNER", "PROCESSOR_GRP", "CONTACT_ID");
      m_hQuery.setBasicPredicate("PROCESSOR_GRP", "CUST_ID", " = ", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("PROCESSOR_GRP", "PROC_GRP_ID", strOperator.c_str(), m_strPROC_GRP_ID.c_str());
      m_hQuery.setBasicPredicate("PROCESSOR_GRP", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("PROCESSOR_GRP", "CC_STATE", "=", "A");
   }
   else if (strColumn == "AcquirerEntity")
   {
      m_strRPT_LVL_ID = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "REPORTING_LVL");
      m_hQuery.join("CONTACT_TYPE", "INNER", "REPORTING_LVL", "CONTACT_ID");
      m_hQuery.setBasicPredicate("REPORTING_LVL", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("REPORTING_LVL", "RPT_LVL_ID", strOperator.c_str(), m_strRPT_LVL_ID.c_str());
      m_hQuery.setBasicPredicate("REPORTING_LVL", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("REPORTING_LVL", "CC_STATE", "=", "A");
   }
   else if (strColumn == "AcquirerTerminal")
   {
      m_strDEVICE_ID = m_pXMLItem->get("value");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR");
      m_hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
      m_hQuery.setQualifier("QUALIFY", "INSTITUTION");
      m_hQuery.setQualifier("QUALIFY", "DEVICE");
      m_hQuery.setQualifier("QUALIFY", "REPORTING_LVL");
      m_hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "RPT_LVL_ID");
      m_hQuery.join("DEVICE", "INNER", "INSTITUTION", "INST_ID");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "PROC_ID");
      m_hQuery.join("INSTITUTION", "INNER", "PROCESSOR", "CUST_ID");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "PROC_GRP_ID");
      m_hQuery.join("PROCESSOR", "INNER", "PROCESSOR_GRP", "CUST_ID");
      m_hQuery.join("DEVICE", "INNER", "CONTACT_TYPE", "CONTACT_ID");
      m_hQuery.bind("INSTITUTION", "INST_ID", Column::STRING, &m_strINST_ID);
      m_hQuery.bind("INSTITUTION", "PROC_ID", Column::STRING, &m_strPROC_ID);
      m_hQuery.bind("PROCESSOR", "PROC_GRP_ID", Column::STRING, &m_strPROC_GRP_ID);
      m_hQuery.bind("DEVICE", "RPT_LVL_ID", Column::STRING, &m_strRPT_LVL_ID);
      m_hQuery.setBasicPredicate("DEVICE", "CUST_ID", "=", strCUST_ID.c_str());
      m_hQuery.setBasicPredicate("DEVICE", "DEVICE_ID", strOperator.c_str(), m_strDEVICE_ID.c_str());
      m_hQuery.setBasicPredicate("DEVICE", "CC_CHANGE_GRP_ID", "IS NULL");
      m_hQuery.setBasicPredicate("DEVICE", "CC_STATE", "=", "A");
   }
   else
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde('3');
      m_pXMLDocument->add("details");
      return reply();
   }
   ContactSegment::instance(ContactSegment::SENDER)->bind(m_hQuery);
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ContactsCommand::execute%67BEF260020A.body
}

void ContactsCommand::update (Subject* pSubject)
{
  //## begin restcommand::ContactsCommand::update%67BEF287027D.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.set("UserID", ContactSegment::instance(ContactSegment::SENDER)->getUSER_ID().data());
      m_hGenericSegment.set("Name", ContactSegment::instance(ContactSegment::SENDER)->getNAME().data());
      m_hGenericSegment.set("Type", ContactSegment::instance(ContactSegment::SENDER)->getCONTACT_TYPE().data());
      m_hGenericSegment.set("Organization", ContactSegment::instance(ContactSegment::SENDER)->getORG_NAME().data());
      m_hGenericSegment.set("AddressLine1", ContactSegment::instance(ContactSegment::SENDER)->getADDRESS_LINE_1().data());
      m_hGenericSegment.set("AddressLine2", ContactSegment::instance(ContactSegment::SENDER)->getADDRESS_LINE_2().data());
      m_hGenericSegment.set("AddressLine3", ContactSegment::instance(ContactSegment::SENDER)->getADDRESS_LINE_3().data());
      m_hGenericSegment.set("AddressLine4", ContactSegment::instance(ContactSegment::SENDER)->getADDRESS_LINE_4().data());
      m_hGenericSegment.set("City", ContactSegment::instance(ContactSegment::SENDER)->getCITY().data());
      m_hGenericSegment.set("Region", ContactSegment::instance(ContactSegment::SENDER)->getREGION().data());
      m_hGenericSegment.set("PostalCode", ContactSegment::instance(ContactSegment::SENDER)->getPOSTAL_CODE().data());
      m_hGenericSegment.set("Country", ContactSegment::instance(ContactSegment::SENDER)->getCOUNTRY().data());
      m_hGenericSegment.set("ContactMethod", ContactSegment::instance(ContactSegment::SENDER)->getCONTACT_METHOD().data());
      m_hGenericSegment.set("Email", ContactSegment::instance(ContactSegment::SENDER)->getEMAIL_ADDRESS().data());
      m_hGenericSegment.set("Fax", ContactSegment::instance(ContactSegment::SENDER)->getFAX_NO().data());
      m_hGenericSegment.set("Phone", ContactSegment::instance(ContactSegment::SENDER)->getTELEPHONE_NO().data());
      m_hGenericSegment.set("Group", m_strPROC_GRP_ID);
      m_hGenericSegment.set("Processor", m_strPROC_ID);
      m_hGenericSegment.set("Institution", m_strINST_ID);
      m_hGenericSegment.set("IssuerBin", m_strBIN);
      m_hGenericSegment.set("AcquirerEntity", m_strRPT_LVL_ID);
      m_hGenericSegment.set("AcquirerTerminal", m_strDEVICE_ID);
      m_hGenericSegment.set("ContactID", ContactSegment::instance(ContactSegment::SENDER)->getCONTACT_ID());
      m_hGenericSegment.set("UpdatedBy", ContactSegment::instance(ContactSegment::SENDER)->getUPDATED_BY_USER_ID().data());
      m_hGenericSegment.set("UpdatedTime", ContactSegment::instance(ContactSegment::SENDER)->getTSTAMP_UPDATED().data());
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ContactsCommand::update%67BEF287027D.body
}

// Additional Declarations
  //## begin restcommand::ContactsCommand%67BEF0690257.declarations preserve=yes
  //## end restcommand::ContactsCommand%67BEF0690257.declarations

} // namespace restcommand

//## begin module%67BEEF610034.epilog preserve=yes
//## end module%67BEEF610034.epilog
