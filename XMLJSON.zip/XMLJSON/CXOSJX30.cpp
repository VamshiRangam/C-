//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%673D83FB0123.cm preserve=no
//## end module%673D83FB0123.cm

//## begin module%673D83FB0123.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%673D83FB0123.cp

//## Module: CXOSJX30%673D83FB0123; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX30.cpp

//## begin module%673D83FB0123.additionalIncludes preserve=no
//## end module%673D83FB0123.additionalIncludes

//## begin module%673D83FB0123.includes preserve=yes
//## end module%673D83FB0123.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSEX15_h
#include "CXODEX15.hpp"
#endif
#ifndef CXOSEX16_h
#include "CXODEX16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSJX30_h
#include "CXODJX30.hpp"
#endif


//## begin module%673D83FB0123.declarations preserve=no
//## end module%673D83FB0123.declarations

//## begin module%673D83FB0123.additionalDeclarations preserve=yes
//## end module%673D83FB0123.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::RulesetCommand 

RulesetCommand::RulesetCommand()
  //## begin RulesetCommand::RulesetCommand%673D84C3035B_const.hasinit preserve=no
  //## end RulesetCommand::RulesetCommand%673D84C3035B_const.hasinit
  //## begin RulesetCommand::RulesetCommand%673D84C3035B_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/ruleset/v1.0.0", "S0003D", "@##JRRSET ")
  //## end RulesetCommand::RulesetCommand%673D84C3035B_const.initialization
{
  //## begin restcommand::RulesetCommand::RulesetCommand%673D84C3035B_const.body preserve=yes
   memcpy(m_sID, "JX30", 4);
  //## end restcommand::RulesetCommand::RulesetCommand%673D84C3035B_const.body
}

RulesetCommand::RulesetCommand (Handler* pSuccessor)
  //## begin restcommand::RulesetCommand::RulesetCommand%673D86130225.hasinit preserve=no
  //## end restcommand::RulesetCommand::RulesetCommand%673D86130225.hasinit
  //## begin restcommand::RulesetCommand::RulesetCommand%673D86130225.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/resolve/ruleset/v1.0.0", "S0003D", "@##JRRSET ")
  //## end restcommand::RulesetCommand::RulesetCommand%673D86130225.initialization
{
  //## begin restcommand::RulesetCommand::RulesetCommand%673D86130225.body preserve=yes
   memcpy(m_sID, "JX30", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::RulesetCommand::RulesetCommand%673D86130225.body
}


RulesetCommand::~RulesetCommand()
{
  //## begin restcommand::RulesetCommand::~RulesetCommand%673D84C3035B_dest.body preserve=yes
  //## end restcommand::RulesetCommand::~RulesetCommand%673D84C3035B_dest.body
}



//## Other Operations (implementation)
bool RulesetCommand::execute ()
{
  //## begin restcommand::RulesetCommand::execute%673D865103C0.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX30 RETRIEVE RULESET");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRRSET", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX30", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   FinancialBaseSegment::instance()->reset();
   FinancialSettlementSegment::instance()->reset();
   CaseSegment::instance()->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_pXMLDocument->add("root");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   if (!m_pXMLItem->get("primaryKey").empty())
   {
      string strTSTAMP_TRANS;
      unsigned short siUNIQUENESS_KEY = 0;
      vector<string> hTokens;
      string strColumn(m_pXMLItem->get("primaryKey"));
      Buffer::parse(strColumn, ":", hTokens);
      if (hTokens.size() == 2)
      {
         strTSTAMP_TRANS = hTokens[0];
         siUNIQUENESS_KEY = atoi(hTokens[1].c_str());
      }
      string strLocator("FIN_L");
      strLocator += strTSTAMP_TRANS.substr(0, 6);
      strLocator += " L";
      hQuery.join(strLocator.c_str(), "LEFT OUTER", "FIN_RECORD R", "TSTAMP_TRANS");
      hQuery.join(strLocator.c_str(), "LEFT OUTER", "FIN_RECORD R", "UNIQUENESS_KEY");
      FinancialBaseSegment::instance()->bind(hQuery, strLocator.c_str());
      FinancialSettlementSegment::instance()->bind(hQuery);
      hQuery.setBasicPredicate(strLocator.c_str(), "TSTAMP_TRANS", "=", strTSTAMP_TRANS.c_str());
      hQuery.setBasicPredicate(strLocator.c_str(), "UNIQUENESS_KEY", "=", siUNIQUENESS_KEY);
      bool b = pSelectStatement->execute(hQuery);
      if (b == false || pSelectStatement->getRows() == 0)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
      }
      else
      {
         FinancialBaseSegment::instance()->setPresence(true);
         FinancialSettlementSegment::instance()->setPresence(true);
      }
   }
   else if (!m_pXMLItem->get("caseNumber").empty())
   {
      hQuery.join("EMS_CASE", "INNER", "EMS_TRANSITION", "CASE_ID");
      hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "CASE_ID");
      hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "PHASE_TSTAMP", "TSTAMP_CREATED");
      CaseSegment::instance()->bind(hQuery);
      hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
      bool b = pSelectStatement->execute(hQuery);
      if (b == false || pSelectStatement->getRows() == 0)
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
      }
      else
         CaseSegment::instance()->setPresence(true);
   }
   else
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde('3');
   }
   if((FinancialBaseSegment::instance()->presence() && FinancialSettlementSegment::instance()->presence()) || CaseSegment::instance()->presence())
   {
      if (CaseSegment::instance()->presence() && CaseSegment::instance()->getTSTAMP_TRANS().length() == 0)
         Case::instance()->rechain();
      EMSNetRuleUse hEMSNetRuleUse(true);
      if (!EMSNetRuleUseTable::instance()->get(hEMSNetRuleUse))
      {
         m_pXMLDocument->revert();
         SOAPSegment::instance()->setRtnCde('2');
      }
      else
      {
         m_hGenericSegment.set("FormHeading", hEMSNetRuleUse.getFORM_HEADING());
         m_hGenericSegment.set("FormName", hEMSNetRuleUse.getFORM_NAME());
         m_hGenericSegment.set("FormClose", hEMSNetRuleUse.getFORM_CLOSE_FLG());
         m_hGenericSegment.set("NetworkIdEMS", hEMSNetRuleUse.getNET_ID_EMS());
         m_hGenericSegment.set("NetworkFields", hEMSNetRuleUse.getNET_FIELDS_IND());
         m_hGenericSegment.set("NetworkRules", hEMSNetRuleUse.getNETWORK_RULES());
         m_hGenericSegment.set("Email", hEMSNetRuleUse.getEMAIL_CHECKBOX_FLG());
         m_hGenericSegment.set("DefaultComment", hEMSNetRuleUse.getDEFAULT_COMMNT_IND());
         m_hGenericSegment.set("CardholderTab", hEMSNetRuleUse.getCARDHOLDER_TAB_FLG());
         m_hGenericSegment.set("DocumentationTab", hEMSNetRuleUse.getDOC_TAB_FLG());
         m_pXMLDocument->add("row");
      }
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::RulesetCommand::execute%673D865103C0.body
}

void RulesetCommand::update (Subject* pSubject)
{
  //## begin restcommand::RulesetCommand::update%673D8E040257.body preserve=yes
   command::RESTCommand::update(pSubject);
  //## end restcommand::RulesetCommand::update%673D8E040257.body
}

// Additional Declarations
  //## begin restcommand::RulesetCommand%673D84C3035B.declarations preserve=yes
  //## end restcommand::RulesetCommand%673D84C3035B.declarations

} // namespace restcommand

//## begin module%673D83FB0123.epilog preserve=yes
//## end module%673D83FB0123.epilog
