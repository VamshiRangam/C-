//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%679BA1B901C0.cm preserve=no
//## end module%679BA1B901C0.cm

//## begin module%679BA1B901C0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%679BA1B901C0.cp

//## Module: CXOSJX34%679BA1B901C0; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX34.hpp

#ifndef CXOSJX34_h
#define CXOSJX34_h 1

//## begin module%679BA1B901C0.additionalIncludes preserve=no
//## end module%679BA1B901C0.additionalIncludes

//## begin module%679BA1B901C0.includes preserve=yes
//## end module%679BA1B901C0.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CommandMessage;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%679BA1B901C0.declarations preserve=no
//## end module%679BA1B901C0.declarations

//## begin module%679BA1B901C0.additionalDeclarations preserve=yes
//## end module%679BA1B901C0.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::OperateCommand%679BA101016E.preface preserve=yes
//## end restcommand::OperateCommand%679BA101016E.preface

//## Class: OperateCommand%679BA101016E
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%679BC24F0238;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%679BC25300E9;monitor::UseCase { -> F}
//## Uses: <unnamed>%679BC28E0304;IF::CommandMessage { -> F}

class DllExport OperateCommand : public command::RESTCommand  //## Inherits: <unnamed>%679BA15703E2
{
  //## begin restcommand::OperateCommand%679BA101016E.initialDeclarations preserve=yes
  //## end restcommand::OperateCommand%679BA101016E.initialDeclarations

  public:
    //## Constructors (generated)
      OperateCommand();

    //## Constructors (specified)
      //## Operation: OperateCommand%679BA34A03C9
      OperateCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~OperateCommand();


    //## Other Operations (specified)
      //## Operation: execute%679BA3760169
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%679BA37B016E
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::OperateCommand%679BA101016E.public preserve=yes
      //## end restcommand::OperateCommand%679BA101016E.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::OperateCommand%679BA101016E.protected preserve=yes
      //## end restcommand::OperateCommand%679BA101016E.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::OperateCommand%679BA101016E.private preserve=yes
      //## end restcommand::OperateCommand%679BA101016E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin restcommand::OperateCommand%679BA101016E.implementation preserve=yes
      //## end restcommand::OperateCommand%679BA101016E.implementation

};

//## begin restcommand::OperateCommand%679BA101016E.postscript preserve=yes
//## end restcommand::OperateCommand%679BA101016E.postscript

} // namespace restcommand

//## begin module%679BA1B901C0.epilog preserve=yes
//## end module%679BA1B901C0.epilog


#endif
