//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D4284E01D9.cm preserve=no
//## end module%65D4284E01D9.cm

//## begin module%65D4284E01D9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D4284E01D9.cp

//## Module: CXOSJX18%65D4284E01D9; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX18.hpp

#ifndef CXOSJX18_h
#define CXOSJX18_h 1

//## begin module%65D4284E01D9.additionalIncludes preserve=no
//## end module%65D4284E01D9.additionalIncludes

//## begin module%65D4284E01D9.includes preserve=yes
//## end module%65D4284E01D9.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65D4284E01D9.declarations preserve=no
//## end module%65D4284E01D9.declarations

//## begin module%65D4284E01D9.additionalDeclarations preserve=yes
//## end module%65D4284E01D9.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReconExceptionsCommand%65D4181D0085.preface preserve=yes
//## end restcommand::ReconExceptionsCommand%65D4181D0085.preface

//## Class: ReconExceptionsCommand%65D4181D0085
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Reconcile REST Recon Exceptions
//	<h6>Reconcile : REST : Recon Exceptions
//	<p>
//	Returns list of exceptions for one transaction
//	reconciliation file.
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/reconcile/reconexceptions.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65D4193B0042;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%65D4193E0111;monitor::UseCase { -> F}
//## Uses: <unnamed>%65D419400268;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%65D4194400EF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65D41947022E;reusable::Buffer { -> F}
//## Uses: <unnamed>%65D4194C0012;IF::Extract { -> F}

class DllExport ReconExceptionsCommand : public command::RESTCommand  //## Inherits: <unnamed>%65D4193400DB
{
  //## begin restcommand::ReconExceptionsCommand%65D4181D0085.initialDeclarations preserve=yes
  //## end restcommand::ReconExceptionsCommand%65D4181D0085.initialDeclarations

  public:
    //## Constructors (generated)
      ReconExceptionsCommand();

    //## Constructors (specified)
      //## Operation: ReconExceptionsCommand%65D4218C015E
      ReconExceptionsCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReconExceptionsCommand();


    //## Other Operations (specified)
      //## Operation: execute%65D421A302F7
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%65D421A50379
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReconExceptionsCommand%65D4181D0085.public preserve=yes
      //## end restcommand::ReconExceptionsCommand%65D4181D0085.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReconExceptionsCommand%65D4181D0085.protected preserve=yes
      //## end restcommand::ReconExceptionsCommand%65D4181D0085.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReconExceptionsCommand%65D4181D0085.private preserve=yes
      //## end restcommand::ReconExceptionsCommand%65D4181D0085.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D41958019F
      //## Role: ReconExceptionsCommand::<m_hGenericSegment>%65D4195901D4
      //## begin restcommand::ReconExceptionsCommand::<m_hGenericSegment>%65D4195901D4.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReconExceptionsCommand::<m_hGenericSegment>%65D4195901D4.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D4195F03D6
      //## Role: ReconExceptionsCommand::<m_hQuery>%65D4196100F0
      //## begin restcommand::ReconExceptionsCommand::<m_hQuery>%65D4196100F0.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReconExceptionsCommand::<m_hQuery>%65D4196100F0.role

    // Additional Implementation Declarations
      //## begin restcommand::ReconExceptionsCommand%65D4181D0085.implementation preserve=yes
      //## end restcommand::ReconExceptionsCommand%65D4181D0085.implementation

};

//## begin restcommand::ReconExceptionsCommand%65D4181D0085.postscript preserve=yes
//## end restcommand::ReconExceptionsCommand%65D4181D0085.postscript

} // namespace restcommand

//## begin module%65D4284E01D9.epilog preserve=yes
//## end module%65D4284E01D9.epilog


#endif
