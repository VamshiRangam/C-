//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6511C2FA0203.cm preserve=no
//## end module%6511C2FA0203.cm

//## begin module%6511C2FA0203.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6511C2FA0203.cp

//## Module: CXOSJX07%6511C2FA0203; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX07.hpp

#ifndef CXOSJX07_h
#define CXOSJX07_h 1

//## begin module%6511C2FA0203.additionalIncludes preserve=no
//## end module%6511C2FA0203.additionalIncludes

//## begin module%6511C2FA0203.includes preserve=yes
//## end module%6511C2FA0203.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseSegment;
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
class ExportTransitionsVisitor;
} // namespace ems

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6511C2FA0203.declarations preserve=no
//## end module%6511C2FA0203.declarations

//## begin module%6511C2FA0203.additionalDeclarations preserve=yes
//## end module%6511C2FA0203.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::TransitionsCommand%6511B70E01E4.preface preserve=yes
//## end restcommand::TransitionsCommand%6511B70E01E4.preface

//## Class: TransitionsCommand%6511B70E01E4
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6511C8E30262;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%6511C8FF0112;monitor::UseCase { -> F}
//## Uses: <unnamed>%6511DC230328;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%6511DC490236;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%6511F5C702D3;reusable::Query { -> F}
//## Uses: <unnamed>%6511F5CA0331;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6511F5CD004B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6511F5F00301;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%6514220E035E;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6514416F03E0;ems::ExportTransitionsVisitor { -> F}

class DllExport TransitionsCommand : public command::RESTCommand  //## Inherits: <unnamed>%6511B72D03BF
{
  //## begin restcommand::TransitionsCommand%6511B70E01E4.initialDeclarations preserve=yes
  //## end restcommand::TransitionsCommand%6511B70E01E4.initialDeclarations

  public:
    //## Constructors (generated)
      TransitionsCommand();

    //## Constructors (specified)
      //## Operation: TransitionsCommand%6511B78D009A
      TransitionsCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~TransitionsCommand();


    //## Other Operations (specified)
      //## Operation: execute%6511B7AB00C9
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%6511B7AE0139
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::TransitionsCommand%6511B70E01E4.public preserve=yes
      //## end restcommand::TransitionsCommand%6511B70E01E4.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::TransitionsCommand%6511B70E01E4.protected preserve=yes
      //## end restcommand::TransitionsCommand%6511B70E01E4.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::TransitionsCommand%6511B70E01E4.private preserve=yes
      //## end restcommand::TransitionsCommand%6511B70E01E4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%6511C91200C1
      //## begin restcommand::TransitionsCommand::Buffer%6511C91200C1.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end restcommand::TransitionsCommand::Buffer%6511C91200C1.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65141E5A024E
      //## Role: TransitionsCommand::<m_hGenericSegment>%65141E5B0157
      //## begin restcommand::TransitionsCommand::<m_hGenericSegment>%65141E5B0157.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::TransitionsCommand::<m_hGenericSegment>%65141E5B0157.role

    // Additional Implementation Declarations
      //## begin restcommand::TransitionsCommand%6511B70E01E4.implementation preserve=yes
      //## end restcommand::TransitionsCommand%6511B70E01E4.implementation

};

//## begin restcommand::TransitionsCommand%6511B70E01E4.postscript preserve=yes
//## end restcommand::TransitionsCommand%6511B70E01E4.postscript

} // namespace restcommand

//## begin module%6511C2FA0203.epilog preserve=yes
//## end module%6511C2FA0203.epilog


#endif
