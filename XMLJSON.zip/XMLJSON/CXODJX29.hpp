//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6729EF4902D4.cm preserve=no
//## end module%6729EF4902D4.cm

//## begin module%6729EF4902D4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6729EF4902D4.cp

//## Module: CXOSJX29%6729EF4902D4; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX29.hpp

#ifndef CXOSJX29_h
#define CXOSJX29_h 1

//## begin module%6729EF4902D4.additionalIncludes preserve=no
//## end module%6729EF4902D4.additionalIncludes

//## begin module%6729EF4902D4.includes preserve=yes
//## end module%6729EF4902D4.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSEX15_h
#include "CXODEX15.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSNetRuleUseTable;
} // namespace ems

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6729EF4902D4.declarations preserve=no
//## end module%6729EF4902D4.declarations

//## begin module%6729EF4902D4.additionalDeclarations preserve=yes
//## end module%6729EF4902D4.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::DescriptionsCommand%6729EFEB0157.preface preserve=yes
//## end restcommand::DescriptionsCommand%6729EFEB0157.preface

//## Class: DescriptionsCommand%6729EFEB0157
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6729F0BD011C;monitor::UseCase { -> F}
//## Uses: <unnamed>%6729F0C201A3;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6729F0C50181;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6729F0CF000E;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6731B92602FE;ems::EMSNetRuleUseTable { -> F}
//## Uses: <unnamed>%6731B98F02D8;IF::Extract { -> F}

class DllExport DescriptionsCommand : public command::RESTCommand  //## Inherits: <unnamed>%6729F0B701C2
{
  //## begin restcommand::DescriptionsCommand%6729EFEB0157.initialDeclarations preserve=yes
  //## end restcommand::DescriptionsCommand%6729EFEB0157.initialDeclarations

  public:
    //## Constructors (generated)
      DescriptionsCommand();

    //## Constructors (specified)
      //## Operation: DescriptionsCommand%6729F24401ED
      DescriptionsCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~DescriptionsCommand();


    //## Other Operations (specified)
      //## Operation: execute%6729F2DB00D9
      virtual bool execute ();

      //## Operation: update%6729F30802FD
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::DescriptionsCommand%6729EFEB0157.public preserve=yes
      //## end restcommand::DescriptionsCommand%6729EFEB0157.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::DescriptionsCommand%6729EFEB0157.protected preserve=yes
      //## end restcommand::DescriptionsCommand%6729EFEB0157.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::DescriptionsCommand%6729EFEB0157.private preserve=yes
      //## end restcommand::DescriptionsCommand%6729EFEB0157.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TagName%6733657F0372
      //## begin restcommand::DescriptionsCommand::TagName%6733657F0372.attr preserve=no  private: string {U} 
      string m_strTagName;
      //## end restcommand::DescriptionsCommand::TagName%6733657F0372.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6729F1D50381
      //## Role: DescriptionsCommand::<m_hGenericSegment>%6729F1D602D2
      //## begin restcommand::DescriptionsCommand::<m_hGenericSegment>%6729F1D602D2.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::DescriptionsCommand::<m_hGenericSegment>%6729F1D602D2.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6729F20902E2
      //## Role: DescriptionsCommand::<m_hQuery>%6729F20A026B
      //## begin restcommand::DescriptionsCommand::<m_hQuery>%6729F20A026B.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::DescriptionsCommand::<m_hQuery>%6729F20A026B.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67331C6301B8
      //## Role: DescriptionsCommand::<m_hEMSNetRuleUse>%67331C640085
      //## begin restcommand::DescriptionsCommand::<m_hEMSNetRuleUse>%67331C640085.role preserve=no  public: ems::EMSNetRuleUse { -> VHgN}
      ems::EMSNetRuleUse m_hEMSNetRuleUse;
      //## end restcommand::DescriptionsCommand::<m_hEMSNetRuleUse>%67331C640085.role

    // Additional Implementation Declarations
      //## begin restcommand::DescriptionsCommand%6729EFEB0157.implementation preserve=yes
      //## end restcommand::DescriptionsCommand%6729EFEB0157.implementation

};

//## begin restcommand::DescriptionsCommand%6729EFEB0157.postscript preserve=yes
//## end restcommand::DescriptionsCommand%6729EFEB0157.postscript

} // namespace restcommand

//## begin module%6729EF4902D4.epilog preserve=yes
//## end module%6729EF4902D4.epilog


#endif
