//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%679BA1C900F0.cm preserve=no
//## end module%679BA1C900F0.cm

//## begin module%679BA1C900F0.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%679BA1C900F0.cp

//## Module: CXOSJX34%679BA1C900F0; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX34.cpp

//## begin module%679BA1C900F0.additionalIncludes preserve=no
//## end module%679BA1C900F0.additionalIncludes

//## begin module%679BA1C900F0.includes preserve=yes
//## end module%679BA1C900F0.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSJX34_h
#include "CXODJX34.hpp"
#endif


//## begin module%679BA1C900F0.declarations preserve=no
//## end module%679BA1C900F0.declarations

//## begin module%679BA1C900F0.additionalDeclarations preserve=yes
//## end module%679BA1C900F0.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::OperateCommand 

OperateCommand::OperateCommand()
  //## begin OperateCommand::OperateCommand%679BA101016E_const.hasinit preserve=no
  //## end OperateCommand::OperateCommand%679BA101016E_const.hasinit
  //## begin OperateCommand::OperateCommand%679BA101016E_const.initialization preserve=yes
  //## end OperateCommand::OperateCommand%679BA101016E_const.initialization
{
  //## begin restcommand::OperateCommand::OperateCommand%679BA101016E_const.body preserve=yes
  //## end restcommand::OperateCommand::OperateCommand%679BA101016E_const.body
}

OperateCommand::OperateCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::OperateCommand::OperateCommand%679BA34A03C9.hasinit preserve=no
  //## end restcommand::OperateCommand::OperateCommand%679BA34A03C9.hasinit
  //## begin restcommand::OperateCommand::OperateCommand%679BA34A03C9.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/operate/command/v1.0.0","S0003D","@##JXOCMD ")
  //## end restcommand::OperateCommand::OperateCommand%679BA34A03C9.initialization
{
  //## begin restcommand::OperateCommand::OperateCommand%679BA34A03C9.body preserve=yes
   memcpy(m_sID,"JX34",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::OperateCommand::OperateCommand%679BA34A03C9.body
}


OperateCommand::~OperateCommand()
{
  //## begin restcommand::OperateCommand::~OperateCommand%679BA101016E_dest.body preserve=yes
  //## end restcommand::OperateCommand::~OperateCommand%679BA101016E_dest.body
}



//## Other Operations (implementation)
bool OperateCommand::execute ()
{
  //## begin restcommand::OperateCommand::execute%679BA3760169.body preserve=yes
   UseCase hUseCase("CLIENT","## JX34 EXECUTE COMMAND");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJXOCMD",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX34",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   string strName(m_pXMLItem->get("name"));
   string strData1(m_pXMLItem->get("data1"));
   string strData2(m_pXMLItem->get("data2"));
   CommandMessage hCommandMessage(strData1,strData2);
   if (!hCommandMessage.execute(strName.c_str()))
      SOAPSegment::instance()->setRtnCde('5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::OperateCommand::execute%679BA3760169.body
}

void OperateCommand::update (Subject* pSubject)
{
  //## begin restcommand::OperateCommand::update%679BA37B016E.body preserve=yes
   RESTCommand::update(pSubject);
  //## end restcommand::OperateCommand::update%679BA37B016E.body
}

// Additional Declarations
  //## begin restcommand::OperateCommand%679BA101016E.declarations preserve=yes
  //## end restcommand::OperateCommand%679BA101016E.declarations

} // namespace restcommand

//## begin module%679BA1C900F0.epilog preserve=yes
//## end module%679BA1C900F0.epilog
