//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF8FCA0009.cm preserve=no
//## end module%64DF8FCA0009.cm

//## begin module%64DF8FCA0009.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF8FCA0009.cp

//## Module: CXOSJX04%64DF8FCA0009; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX04.hpp

#ifndef CXOSJX04_h
#define CXOSJX04_h 1

//## begin module%64DF8FCA0009.additionalIncludes preserve=no
//## end module%64DF8FCA0009.additionalIncludes

//## begin module%64DF8FCA0009.includes preserve=yes
//## end module%64DF8FCA0009.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class Total;
class TransactionTotal;
class FinancialTotal;
class FinancialSum;
} // namespace totalscommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class CurrencyCode;
class View;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%64DF8FCA0009.declarations preserve=no
//## end module%64DF8FCA0009.declarations

//## begin module%64DF8FCA0009.additionalDeclarations preserve=yes
//## end module%64DF8FCA0009.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.preface preserve=yes
//## end restcommand::FinancialTotalsCommand%64DF8E5E036A.preface

//## Class: FinancialTotalsCommand%64DF8E5E036A
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64DFCE900304;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%64DFCE9200BC;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%64DFCE93038C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%64DFCE9502ED;database::Database { -> F}
//## Uses: <unnamed>%64DFCEB00376;totalscommand::FinancialTotal { -> F}
//## Uses: <unnamed>%64DFCEB203B4;totalscommand::TransactionTotal { -> F}
//## Uses: <unnamed>%64DFCEB402AD;totalscommand::Total { -> F}
//## Uses: <unnamed>%64DFCEB60224;totalscommand::FinancialSum { -> F}
//## Uses: <unnamed>%64DFCEB801F5;entitysegment::Customer { -> F}
//## Uses: <unnamed>%64E368AA01A9;monitor::UseCase { -> F}
//## Uses: <unnamed>%65099C38009B;reusable::Buffer { -> F}
//## Uses: <unnamed>%65099CB001EF;IF::Extract { -> F}
//## Uses: <unnamed>%65099D240209;database::CurrencyCode { -> F}

class DllExport FinancialTotalsCommand : public command::RESTCommand  //## Inherits: <unnamed>%64DFD8440307
{
  //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.initialDeclarations preserve=yes
  //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.initialDeclarations

  public:
    //## Constructors (generated)
      FinancialTotalsCommand();

    //## Constructors (specified)
      //## Operation: FinancialTotalsCommand%64DF944303CA
      FinancialTotalsCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~FinancialTotalsCommand();


    //## Other Operations (specified)
      //## Operation: endElement%64E2C1660346
      virtual bool endElement (const string& strTag);

      //## Operation: execute%64DF9463008E
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: parse%64FF0DD90173
      virtual int parse ();

      //## Operation: update%64DF946501C9
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Associations (generated)

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64DFCEDF0264
      //## Role: FinancialTotalsCommand::<m_hQuery>%64DFCEE00174
      reusable::Query& getQuery (int index)
      {
        //## begin restcommand::FinancialTotalsCommand::getQuery%64DFCEE00174.get preserve=no
        return m_hQuery[index];
        //## end restcommand::FinancialTotalsCommand::getQuery%64DFCEE00174.get
      }


    // Additional Public Declarations
      //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.public preserve=yes
      //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.public

  protected:
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64DFCEDF0264
      //## begin restcommand::FinancialTotalsCommand::<m_hQuery>%64DFCEE00174.role preserve=no  public: reusable::Query { -> 2VHgN}
      reusable::Query m_hQuery[2];
      //## end restcommand::FinancialTotalsCommand::<m_hQuery>%64DFCEE00174.role

    // Additional Protected Declarations
      //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.protected preserve=yes
      //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.private preserve=yes
      //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Column%64FF0F4B0039
      //## begin restcommand::FinancialTotalsCommand::Column%64FF0F4B0039.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumn;
      //## end restcommand::FinancialTotalsCommand::Column%64FF0F4B0039.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64DFCEEB01E6
      //## Role: FinancialTotalsCommand::<m_pView>%64DFCEEC0186
      //## begin restcommand::FinancialTotalsCommand::<m_pView>%64DFCEEC0186.role preserve=no  public: database::View { -> RFHgN}
      database::View *m_pView;
      //## end restcommand::FinancialTotalsCommand::<m_pView>%64DFCEEC0186.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64FF0A1D03B3
      //## Role: FinancialTotalsCommand::<m_hGenericSegment>%64FF0A1E0388
      //## begin restcommand::FinancialTotalsCommand::<m_hGenericSegment>%64FF0A1E0388.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::FinancialTotalsCommand::<m_hGenericSegment>%64FF0A1E0388.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6509BD87007D
      //## Role: FinancialTotalsCommand::<m_pGenericSegment>%6509BD8801C9
      //## begin restcommand::FinancialTotalsCommand::<m_pGenericSegment>%6509BD8801C9.role preserve=no  public: segment::GenericSegment { -> RFHN}
      segment::GenericSegment *m_pGenericSegment;
      //## end restcommand::FinancialTotalsCommand::<m_pGenericSegment>%6509BD8801C9.role

    // Additional Implementation Declarations
      //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.implementation preserve=yes
      //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.implementation

};

//## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.postscript preserve=yes
//## end restcommand::FinancialTotalsCommand%64DF8E5E036A.postscript

} // namespace restcommand

//## begin module%64DF8FCA0009.epilog preserve=yes
//## end module%64DF8FCA0009.epilog


#endif
