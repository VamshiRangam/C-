//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66BB26DF03AE.cm preserve=no
//## end module%66BB26DF03AE.cm

//## begin module%66BB26DF03AE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66BB26DF03AE.cp

//## Module: CXOSJX25%66BB26DF03AE; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX25.hpp

#ifndef CXOSJX25_h
#define CXOSJX25_h 1

//## begin module%66BB26DF03AE.additionalIncludes preserve=no
//## end module%66BB26DF03AE.additionalIncludes

//## begin module%66BB26DF03AE.includes preserve=yes
//## end module%66BB26DF03AE.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class View;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
class PersistentSegment;

} // namespace segment

//## begin module%66BB26DF03AE.declarations preserve=no
//## end module%66BB26DF03AE.declarations

//## begin module%66BB26DF03AE.additionalDeclarations preserve=yes
//## end module%66BB26DF03AE.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CaseDetailCommand%66BB27B40256.preface preserve=yes
//## end restcommand::CaseDetailCommand%66BB27B40256.preface

//## Class: CaseDetailCommand%66BB27B40256
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66BB296F02D4;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%66BB297400A8;monitor::UseCase { -> F}
//## Uses: <unnamed>%66BB297A03C9;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%66BB2986027C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66BB2AC20201;database::Database { -> F}
//## Uses: <unnamed>%66BC45FE029D;database::View { -> F}
//## Uses: <unnamed>%66C470CD02F9;reusable::Buffer { -> F}

class DllExport CaseDetailCommand : public command::RESTCommand  //## Inherits: <unnamed>%66BB296602B1
{
  //## begin restcommand::CaseDetailCommand%66BB27B40256.initialDeclarations preserve=yes
  //## end restcommand::CaseDetailCommand%66BB27B40256.initialDeclarations

  public:
    //## Constructors (generated)
      CaseDetailCommand();

    //## Constructors (specified)
      //## Operation: CaseDetailCommand%66BB2BF4036C
      CaseDetailCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseDetailCommand();


    //## Other Operations (specified)
      //## Operation: execute%66BB2C42009C
      virtual bool execute ();

      //## Operation: update%66BB2C630165
      virtual void update (Subject* pSubject);

      //## Operation: populateTags%66D185B40193
      void populateTags ();

      //## Operation: addtoXMLDocument%66D1A279003B
      bool addtoXMLDocument ();

      //## Operation: getRelatedCaseCHBInfo%66DB028801E6
      void getRelatedCaseCHBInfo (const string& strFEE_REL_CASE_NO);

    // Additional Public Declarations
      //## begin restcommand::CaseDetailCommand%66BB27B40256.public preserve=yes
      //## end restcommand::CaseDetailCommand%66BB27B40256.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CaseDetailCommand%66BB27B40256.protected preserve=yes
      //## end restcommand::CaseDetailCommand%66BB27B40256.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CaseDetailCommand%66BB27B40256.private preserve=yes
      //## end restcommand::CaseDetailCommand%66BB27B40256.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TagName%66D1B67F02E9
      //## begin restcommand::CaseDetailCommand::TagName%66D1B67F02E9.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hTagName;
      //## end restcommand::CaseDetailCommand::TagName%66D1B67F02E9.attr

      //## Attribute: ColumnName%66D1B7A102DB
      //## begin restcommand::CaseDetailCommand::ColumnName%66D1B7A102DB.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumnName;
      //## end restcommand::CaseDetailCommand::ColumnName%66D1B7A102DB.attr

      //## Attribute: TagColumnValues%66D1B7CF012D
      //## begin restcommand::CaseDetailCommand::TagColumnValues%66D1B7CF012D.attr preserve=no  private: vector<pair<string, string> > {U} 
      vector<pair<string, string> > m_hTagColumnValues;
      //## end restcommand::CaseDetailCommand::TagColumnValues%66D1B7CF012D.attr

      //## Attribute: Header%66DB02CF015D
      //## begin restcommand::CaseDetailCommand::Header%66DB02CF015D.attr preserve=no  private: string {U} 
      string m_strHeader;
      //## end restcommand::CaseDetailCommand::Header%66DB02CF015D.attr

      //## Attribute: NationalNetwork%66E2FD9E02E3
      //## begin restcommand::CaseDetailCommand::NationalNetwork%66E2FD9E02E3.attr preserve=no  private: bool {U} 
      bool m_bNationalNetwork;
      //## end restcommand::CaseDetailCommand::NationalNetwork%66E2FD9E02E3.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66C2ED420353
      //## Role: CaseDetailCommand::<m_hQuery>%66C2ED440035
      //## begin restcommand::CaseDetailCommand::<m_hQuery>%66C2ED440035.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::CaseDetailCommand::<m_hQuery>%66C2ED440035.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66C4550C03D5
      //## Role: CaseDetailCommand::<m_pPersistentSegment>%66C4550D02FE
      //## begin restcommand::CaseDetailCommand::<m_pPersistentSegment>%66C4550D02FE.role preserve=no  public: segment::PersistentSegment { -> RFHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end restcommand::CaseDetailCommand::<m_pPersistentSegment>%66C4550D02FE.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%66C5A6F201DD
      //## Role: CaseDetailCommand::<m_hGenericSegment>%66C5A6F301EC
      //## begin restcommand::CaseDetailCommand::<m_hGenericSegment>%66C5A6F301EC.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::CaseDetailCommand::<m_hGenericSegment>%66C5A6F301EC.role

    // Additional Implementation Declarations
      //## begin restcommand::CaseDetailCommand%66BB27B40256.implementation preserve=yes
      //## end restcommand::CaseDetailCommand%66BB27B40256.implementation

};

//## begin restcommand::CaseDetailCommand%66BB27B40256.postscript preserve=yes
//## end restcommand::CaseDetailCommand%66BB27B40256.postscript

} // namespace restcommand

//## begin module%66BB26DF03AE.epilog preserve=yes
//## end module%66BB26DF03AE.epilog


#endif
