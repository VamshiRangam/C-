//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A0D00B0062.cm preserve=no
//## end module%67A0D00B0062.cm

//## begin module%67A0D00B0062.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%67A0D00B0062.cp

//## Module: CXOSJX36%67A0D00B0062; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX36.cpp

//## begin module%67A0D00B0062.additionalIncludes preserve=no
//## end module%67A0D00B0062.additionalIncludes

//## begin module%67A0D00B0062.includes preserve=yes
//## end module%67A0D00B0062.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX36_h
#include "CXODJX36.hpp"
#endif


//## begin module%67A0D00B0062.declarations preserve=no
//## end module%67A0D00B0062.declarations

//## begin module%67A0D00B0062.additionalDeclarations preserve=yes
//## end module%67A0D00B0062.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReportDayCommand 

ReportDayCommand::ReportDayCommand()
  //## begin ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.hasinit preserve=no
  //## end ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.hasinit
  //## begin ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.initialization preserve=yes
  //## end ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.initialization
{
  //## begin restcommand::ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.body preserve=yes
  //## end restcommand::ReportDayCommand::ReportDayCommand%67A0CF7E0262_const.body
}

ReportDayCommand::ReportDayCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.hasinit preserve=no
  //## end restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.hasinit
  //## begin restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/report/day/v1.0.0","S0003D","@##JLBDAY ")
  //## end restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.initialization
{
  //## begin restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.body preserve=yes
   memcpy(m_sID,"JX36",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReportDayCommand::ReportDayCommand%67A0D0950021.body
}


ReportDayCommand::~ReportDayCommand()
{
  //## begin restcommand::ReportDayCommand::~ReportDayCommand%67A0CF7E0262_dest.body preserve=yes
  //## end restcommand::ReportDayCommand::~ReportDayCommand%67A0CF7E0262_dest.body
}



//## Other Operations (implementation)
bool ReportDayCommand::execute ()
{
  //## begin restcommand::ReportDayCommand::execute%67A0D0A30198.body preserve=yes
   UseCase hUseCase("CLIENT","## JX36 LIST REPORT DAY");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLBDAY",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX36",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   m_hQuery.setDistinct(true);
   m_hQuery.bind("DX_DATA_CONTROL","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
   m_hQuery.bind("DX_DATA_CONTROL","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   m_hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",m_pXMLItem->get("date").c_str());
   m_hQuery.setOrderByClause("ENTITY_TYPE,ENTITY_ID");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReportDayCommand::execute%67A0D0A30198.body
}

void ReportDayCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReportDayCommand::update%67A0D0A60262.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.reset();
      m_hGenericSegment.set("EntityType",m_strENTITY_TYPE);
      m_hGenericSegment.set("EntityID",m_strENTITY_ID);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ReportDayCommand::update%67A0D0A60262.body
}

// Additional Declarations
  //## begin restcommand::ReportDayCommand%67A0CF7E0262.declarations preserve=yes
  //## end restcommand::ReportDayCommand%67A0CF7E0262.declarations

} // namespace restcommand

//## begin module%67A0D00B0062.epilog preserve=yes
//## end module%67A0D00B0062.epilog
