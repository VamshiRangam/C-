//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D4284F03D8.cm preserve=no
//## end module%65D4284F03D8.cm

//## begin module%65D4284F03D8.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%65D4284F03D8.cp

//## Module: CXOSJX18%65D4284F03D8; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX18.cpp

//## begin module%65D4284F03D8.additionalIncludes preserve=no
//## end module%65D4284F03D8.additionalIncludes

//## begin module%65D4284F03D8.includes preserve=yes
//## end module%65D4284F03D8.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX18_h
#include "CXODJX18.hpp"
#endif


//## begin module%65D4284F03D8.declarations preserve=no
//## end module%65D4284F03D8.declarations

//## begin module%65D4284F03D8.additionalDeclarations preserve=yes
//## end module%65D4284F03D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReconExceptionsCommand 

ReconExceptionsCommand::ReconExceptionsCommand()
  //## begin ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.hasinit preserve=no
  //## end ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.hasinit
  //## begin ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.initialization preserve=yes
  //## end ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.initialization
{
  //## begin restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.body preserve=yes
  //## end restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4181D0085_const.body
}

ReconExceptionsCommand::ReconExceptionsCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.hasinit preserve=no
  //## end restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.hasinit
  //## begin restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/reconcile/reconexceptions/v1.0.0","S0003D","@##JLAURE ")
  //## end restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.initialization
{
  //## begin restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.body preserve=yes
   memcpy(m_sID,"JX18",4);
   m_pSuccessor = pSuccessor;
  //## end restcommand::ReconExceptionsCommand::ReconExceptionsCommand%65D4218C015E.body
}


ReconExceptionsCommand::~ReconExceptionsCommand()
{
  //## begin restcommand::ReconExceptionsCommand::~ReconExceptionsCommand%65D4181D0085_dest.body preserve=yes
  //## end restcommand::ReconExceptionsCommand::~ReconExceptionsCommand%65D4181D0085_dest.body
}



//## Other Operations (implementation)
bool ReconExceptionsCommand::execute ()
{
  //## begin restcommand::ReconExceptionsCommand::execute%65D421A302F7.body preserve=yes
   return true;
  //## end restcommand::ReconExceptionsCommand::execute%65D421A302F7.body
}

void ReconExceptionsCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReconExceptionsCommand::update%65D421A50379.body preserve=yes
   command::RESTCommand::update(pSubject);
  //## end restcommand::ReconExceptionsCommand::update%65D421A50379.body
}

// Additional Declarations
  //## begin restcommand::ReconExceptionsCommand%65D4181D0085.declarations preserve=yes
  //## end restcommand::ReconExceptionsCommand%65D4181D0085.declarations

} // namespace restcommand

//## begin module%65D4284F03D8.epilog preserve=yes
//## end module%65D4284F03D8.epilog
