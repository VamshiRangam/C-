//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B011E303E6.cm preserve=no
//## end module%65B011E303E6.cm

//## begin module%65B011E303E6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B011E303E6.cp

//## Module: CXOSJX13%65B011E303E6; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX13.hpp

#ifndef CXOSJX13_h
#define CXOSJX13_h 1

//## begin module%65B011E303E6.additionalIncludes preserve=no
//## end module%65B011E303E6.additionalIncludes

//## begin module%65B011E303E6.includes preserve=yes
//## end module%65B011E303E6.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65B011E303E6.declarations preserve=no
//## end module%65B011E303E6.declarations

//## begin module%65B011E303E6.additionalDeclarations preserve=yes
//## end module%65B011E303E6.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ConfigurationCommand%65B010C90017.preface preserve=yes
//## end restcommand::ConfigurationCommand%65B010C90017.preface

//## Class: ConfigurationCommand%65B010C90017
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Configure REST Configuration
//	<h6>Configure : REST : Configuration
//	<p>
//	Returns a set of data from a CR table.
//	The tab name in the request specifies the result set to
//	return.
//	The available tab names are documented in <a
//	href="../../SOAP/XLCNFG/Request/Search
//	Criteria.xsd">Search Criteria</a>
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/configure/configuration.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65B010F00387;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%65B010F203D4;monitor::UseCase { -> F}
//## Uses: <unnamed>%65CA57460189;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%65CA57750083;IF::FlatFile { -> F}
//## Uses: <unnamed>%65CA5C0D01D1;reusable::Buffer { -> F}
//## Uses: <unnamed>%65CA5C5B007D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65CA5CAB0088;IF::Extract { -> F}

class DllExport ConfigurationCommand : public command::RESTCommand  //## Inherits: <unnamed>%65B010ED03A4
{
  //## begin restcommand::ConfigurationCommand%65B010C90017.initialDeclarations preserve=yes
  //## end restcommand::ConfigurationCommand%65B010C90017.initialDeclarations

  public:
    //## Constructors (generated)
      ConfigurationCommand();

    //## Constructors (specified)
      //## Operation: ConfigurationCommand%65B01169024B
      ConfigurationCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ConfigurationCommand();


    //## Other Operations (specified)
      //## Operation: endElement%67F94B58025A
      virtual bool endElement (const string& strTag);

      //## Operation: execute%65B0118A00DE
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%65B0118D0142
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

      //## Operation: loadTemplate%65CA554200B9
      bool loadTemplate ();

    // Additional Public Declarations
      //## begin restcommand::ConfigurationCommand%65B010C90017.public preserve=yes
      //## end restcommand::ConfigurationCommand%65B010C90017.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Column%67F94BD40006
      //## begin restcommand::ConfigurationCommand::Column%67F94BD40006.attr preserve=no  protected: string {U} 
      string m_strColumn;
      //## end restcommand::ConfigurationCommand::Column%67F94BD40006.attr

      //## Attribute: Operator%67F94BB702A7
      //## begin restcommand::ConfigurationCommand::Operator%67F94BB702A7.attr preserve=no  protected: string {U} 
      string m_strOperator;
      //## end restcommand::ConfigurationCommand::Operator%67F94BB702A7.attr

      //## Attribute: TagName%65CA586B00C6
      //## begin restcommand::ConfigurationCommand::TagName%65CA586B00C6.attr preserve=no  protected: string {U} 
      string m_strTagName;
      //## end restcommand::ConfigurationCommand::TagName%65CA586B00C6.attr

      //## Attribute: Tags%65CA590C02F1
      //## begin restcommand::ConfigurationCommand::Tags%65CA590C02F1.attr preserve=no  private: map<string, pair<string,string>, less<string>> {U} 
      map<string, pair<string,string>, less<string>> m_hTags;
      //## end restcommand::ConfigurationCommand::Tags%65CA590C02F1.attr

      //## Attribute: Value%67F94BE60007
      //## begin restcommand::ConfigurationCommand::Value%67F94BE60007.attr preserve=no  protected: string {U} 
      string m_strValue;
      //## end restcommand::ConfigurationCommand::Value%67F94BE60007.attr

    // Additional Protected Declarations
      //## begin restcommand::ConfigurationCommand%65B010C90017.protected preserve=yes
      //## end restcommand::ConfigurationCommand%65B010C90017.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: RPT_LVL_NAME%65CA5CF201B7
      //## begin restcommand::ConfigurationCommand::RPT_LVL_NAME%65CA5CF201B7.attr preserve=no  private: string {U} 
      string m_strRPT_LVL_NAME;
      //## end restcommand::ConfigurationCommand::RPT_LVL_NAME%65CA5CF201B7.attr

    // Additional Private Declarations
      //## begin restcommand::ConfigurationCommand%65B010C90017.private preserve=yes
      //## end restcommand::ConfigurationCommand%65B010C90017.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DESCRIPTION_TEXT%65DCBC1102FD
      //## begin restcommand::ConfigurationCommand::DESCRIPTION_TEXT%65DCBC1102FD.attr preserve=no  private: string {U} 
      string m_strDESCRIPTION_TEXT;
      //## end restcommand::ConfigurationCommand::DESCRIPTION_TEXT%65DCBC1102FD.attr

      //## Attribute: ENTITY_TYPE%65E60CF201C5
      //## begin restcommand::ConfigurationCommand::ENTITY_TYPE%65E60CF201C5.attr preserve=no  private: string[2] {U} 
      string m_strENTITY_TYPE[2];
      //## end restcommand::ConfigurationCommand::ENTITY_TYPE%65E60CF201C5.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65CA564D00F5
      //## Role: ConfigurationCommand::<m_pPersistentSegment>%65CA564E01F7
      //## begin restcommand::ConfigurationCommand::<m_pPersistentSegment>%65CA564E01F7.role preserve=no  public: segment::PersistentSegment { -> RHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end restcommand::ConfigurationCommand::<m_pPersistentSegment>%65CA564E01F7.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65CA56E102BA
      //## Role: ConfigurationCommand::<m_hQuery>%65CA56E20313
      //## begin restcommand::ConfigurationCommand::<m_hQuery>%65CA56E20313.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ConfigurationCommand::<m_hQuery>%65CA56E20313.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65CA580201B3
      //## Role: ConfigurationCommand::<m_hGenericSegment>%65CA5803021B
      //## begin restcommand::ConfigurationCommand::<m_hGenericSegment>%65CA5803021B.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ConfigurationCommand::<m_hGenericSegment>%65CA5803021B.role

    // Additional Implementation Declarations
      //## begin restcommand::ConfigurationCommand%65B010C90017.implementation preserve=yes
      bool m_bAuthorize;
      //## end restcommand::ConfigurationCommand%65B010C90017.implementation

};

//## begin restcommand::ConfigurationCommand%65B010C90017.postscript preserve=yes
//## end restcommand::ConfigurationCommand%65B010C90017.postscript

} // namespace restcommand

//## begin module%65B011E303E6.epilog preserve=yes
//## end module%65B011E303E6.epilog


#endif
