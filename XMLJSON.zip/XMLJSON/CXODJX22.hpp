//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%667EAD6B0178.cm preserve=no
//## end module%667EAD6B0178.cm

//## begin module%667EAD6B0178.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%667EAD6B0178.cp

//## Module: CXOSJX22%667EAD6B0178; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX22.hpp

#ifndef CXOSJX22_h
#define CXOSJX22_h 1

//## begin module%667EAD6B0178.additionalIncludes preserve=no
//## end module%667EAD6B0178.additionalIncludes

//## begin module%667EAD6B0178.includes preserve=yes
//## end module%667EAD6B0178.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%667EAD6B0178.declarations preserve=no
//## end module%667EAD6B0178.declarations

//## begin module%667EAD6B0178.additionalDeclarations preserve=yes
//## end module%667EAD6B0178.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::SignoutCommand%667E32190207.preface preserve=yes
//## end restcommand::SignoutCommand%667E32190207.preface

//## Class: SignoutCommand%667E32190207
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%667EACA20044;monitor::UseCase { -> F}
//## Uses: <unnamed>%667EAF690368;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%667EB33E005E;segment::CommonHeaderSegment { -> F}

class DllExport SignoutCommand : public command::RESTCommand  //## Inherits: <unnamed>%667EAC9D0173
{
  //## begin restcommand::SignoutCommand%667E32190207.initialDeclarations preserve=yes
  //## end restcommand::SignoutCommand%667E32190207.initialDeclarations

  public:
    //## Constructors (generated)
      SignoutCommand();

    //## Constructors (specified)
      //## Operation: SignoutCommand%667EACE902E0
      SignoutCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~SignoutCommand();


    //## Other Operations (specified)
      //## Operation: execute%667EACC10007
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin restcommand::SignoutCommand%667E32190207.public preserve=yes
      //## end restcommand::SignoutCommand%667E32190207.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::SignoutCommand%667E32190207.protected preserve=yes
      //## end restcommand::SignoutCommand%667E32190207.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::SignoutCommand%667E32190207.private preserve=yes
      //## end restcommand::SignoutCommand%667E32190207.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin restcommand::SignoutCommand%667E32190207.implementation preserve=yes
      //## end restcommand::SignoutCommand%667E32190207.implementation

};

//## begin restcommand::SignoutCommand%667E32190207.postscript preserve=yes
//## end restcommand::SignoutCommand%667E32190207.postscript

} // namespace restcommand

//## begin module%667EAD6B0178.epilog preserve=yes
//## end module%667EAD6B0178.epilog


#endif
