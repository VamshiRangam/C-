//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A02F1D011D.cm preserve=no
//## end module%67A02F1D011D.cm

//## begin module%67A02F1D011D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67A02F1D011D.cp

//## Module: CXOSJX35%67A02F1D011D; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX35.hpp

#ifndef CXOSJX35_h
#define CXOSJX35_h 1

//## begin module%67A02F1D011D.additionalIncludes preserve=no
//## end module%67A02F1D011D.additionalIncludes

//## begin module%67A02F1D011D.includes preserve=yes
//## end module%67A02F1D011D.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67A02F1D011D.declarations preserve=no
//## end module%67A02F1D011D.declarations

//## begin module%67A02F1D011D.additionalDeclarations preserve=yes
//## end module%67A02F1D011D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReportDaysCommand%67A02EAF00CD.preface preserve=yes
//## end restcommand::ReportDaysCommand%67A02EAF00CD.preface

//## Class: ReportDaysCommand%67A02EAF00CD
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67A0383B02F4;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67A03840028D;monitor::UseCase { -> F}
//## Uses: <unnamed>%67A038430344;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67A038470217;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%67A03F8F0315;reusable::FormatSelectVisitor { -> F}

class DllExport ReportDaysCommand : public command::RESTCommand  //## Inherits: <unnamed>%67A02ED000EC
{
  //## begin restcommand::ReportDaysCommand%67A02EAF00CD.initialDeclarations preserve=yes
  //## end restcommand::ReportDaysCommand%67A02EAF00CD.initialDeclarations

  public:
    //## Constructors (generated)
      ReportDaysCommand();

    //## Constructors (specified)
      //## Operation: ReportDaysCommand%67A037FA001A
      ReportDaysCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReportDaysCommand();


    //## Other Operations (specified)
      //## Operation: execute%67A038170024
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%67A038190397
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReportDaysCommand%67A02EAF00CD.public preserve=yes
      //## end restcommand::ReportDaysCommand%67A02EAF00CD.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReportDaysCommand%67A02EAF00CD.protected preserve=yes
      //## end restcommand::ReportDaysCommand%67A02EAF00CD.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReportDaysCommand%67A02EAF00CD.private preserve=yes
      //## end restcommand::ReportDaysCommand%67A02EAF00CD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATE_RECON%67A0391101B4
      //## begin restcommand::ReportDaysCommand::DATE_RECON%67A0391101B4.attr preserve=no  private: string[2] {V} 
      string m_strDATE_RECON[2];
      //## end restcommand::ReportDaysCommand::DATE_RECON%67A0391101B4.attr

      //## Attribute: TSTAMP_END%67A0391101D6
      //## begin restcommand::ReportDaysCommand::TSTAMP_END%67A0391101D6.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_END;
      //## end restcommand::ReportDaysCommand::TSTAMP_END%67A0391101D6.attr

      //## Attribute: TSTAMP_LAST_UPDATE%67A0391101FB
      //## begin restcommand::ReportDaysCommand::TSTAMP_LAST_UPDATE%67A0391101FB.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_LAST_UPDATE;
      //## end restcommand::ReportDaysCommand::TSTAMP_LAST_UPDATE%67A0391101FB.attr

      //## Attribute: TSTAMP_TRANS_FROM%67A039110220
      //## begin restcommand::ReportDaysCommand::TSTAMP_TRANS_FROM%67A039110220.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS_FROM;
      //## end restcommand::ReportDaysCommand::TSTAMP_TRANS_FROM%67A039110220.attr

      //## Attribute: TSTAMP_TRANS_TO%67A039110245
      //## begin restcommand::ReportDaysCommand::TSTAMP_TRANS_TO%67A039110245.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS_TO;
      //## end restcommand::ReportDaysCommand::TSTAMP_TRANS_TO%67A039110245.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A0385D00D0
      //## Role: ReportDaysCommand::<m_hGenericSegment>%67A0385E0232
      //## begin restcommand::ReportDaysCommand::<m_hGenericSegment>%67A0385E0232.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReportDaysCommand::<m_hGenericSegment>%67A0385E0232.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A0386A0099
      //## Role: ReportDaysCommand::<m_hQuery>%67A0386B01CA
      //## begin restcommand::ReportDaysCommand::<m_hQuery>%67A0386B01CA.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReportDaysCommand::<m_hQuery>%67A0386B01CA.role

    // Additional Implementation Declarations
      //## begin restcommand::ReportDaysCommand%67A02EAF00CD.implementation preserve=yes
      //## end restcommand::ReportDaysCommand%67A02EAF00CD.implementation

};

//## begin restcommand::ReportDaysCommand%67A02EAF00CD.postscript preserve=yes
//## end restcommand::ReportDaysCommand%67A02EAF00CD.postscript

} // namespace restcommand

//## begin module%67A02F1D011D.epilog preserve=yes
//## end module%67A02F1D011D.epilog


#endif
