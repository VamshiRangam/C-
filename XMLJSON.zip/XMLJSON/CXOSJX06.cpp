//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%650AE95D01F7.cm preserve=no
//## end module%650AE95D01F7.cm

//## begin module%650AE95D01F7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%650AE95D01F7.cp

//## Module: CXOSJX06%650AE95D01F7; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX06.cpp

//## begin module%650AE95D01F7.additionalIncludes preserve=no
//## end module%650AE95D01F7.additionalIncludes

//## begin module%650AE95D01F7.includes preserve=yes
//## end module%650AE95D01F7.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBC39_h
#include "CXODBC39.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
#ifndef CXOSSX40_h
#include "CXODSX40.hpp"
#endif
#ifndef CXOSJX06_h
#include "CXODJX06.hpp"
#endif


//## begin module%650AE95D01F7.declarations preserve=no
//## end module%650AE95D01F7.declarations

//## begin module%650AE95D01F7.additionalDeclarations preserve=yes
//## end module%650AE95D01F7.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::CaseManifest 

CaseManifest::CaseManifest()
  //## begin CaseManifest::CaseManifest%650AE9310043_const.hasinit preserve=no
      : m_iDI_FILE_ID(0),
        m_iTRANSACTION_NO(0),
        m_pXMLDocument(0),
        m_pSingleCaseCommand(0)
  //## end CaseManifest::CaseManifest%650AE9310043_const.hasinit
  //## begin CaseManifest::CaseManifest%650AE9310043_const.initialization preserve=yes
  //## end CaseManifest::CaseManifest%650AE9310043_const.initialization
{
  //## begin restcommand::CaseManifest::CaseManifest%650AE9310043_const.body preserve=yes
   memcpy(m_sID,"JX06",4);
  //## end restcommand::CaseManifest::CaseManifest%650AE9310043_const.body
}

CaseManifest::CaseManifest (const char* pszMVSTemplate, const char* pszTemplate)
  //## begin restcommand::CaseManifest::CaseManifest%6564B495008E.hasinit preserve=no
      : m_iDI_FILE_ID(0),
        m_iTRANSACTION_NO(0),
        m_pXMLDocument(0),
        m_pSingleCaseCommand(0)
  //## end restcommand::CaseManifest::CaseManifest%6564B495008E.hasinit
  //## begin restcommand::CaseManifest::CaseManifest%6564B495008E.initialization preserve=yes
  //## end restcommand::CaseManifest::CaseManifest%6564B495008E.initialization
{
  //## begin restcommand::CaseManifest::CaseManifest%6564B495008E.body preserve=yes
   memcpy(m_sID,"JX06",4);
   m_pSingleCaseCommand = new soapcommand::SingleCaseCommand(0);
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL",pszMVSTemplate,&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE",pszTemplate,&m_hRow,&m_hXMLText);
#endif
   m_hXMLText.add('X',&m_hGenericSegment);
   m_hRow.attach(this);
  //## end restcommand::CaseManifest::CaseManifest%6564B495008E.body
}


CaseManifest::~CaseManifest()
{
  //## begin restcommand::CaseManifest::~CaseManifest%650AE9310043_dest.body preserve=yes
   delete m_pXMLDocument;
   delete m_pSingleCaseCommand;
  //## end restcommand::CaseManifest::~CaseManifest%650AE9310043_dest.body
}



//## Other Operations (implementation)
void CaseManifest::add (const string& strTag, const string& strValue)
{
  //## begin restcommand::CaseManifest::add%650C96B101C6.body preserve=yes
   m_hGenericSegment.set(strTag.c_str(),strValue);
   if (strTag == "password")
      m_pXMLDocument->add("SingleCaseRqst");
  //## end restcommand::CaseManifest::add%650C96B101C6.body
}

void CaseManifest::addAttribute (vector<string>& hToken)
{
  //## begin restcommand::CaseManifest::addAttribute%650C8C0B0268.body preserve=yes
   string strEmpty;
   if (hToken.size() == 1)
   {
      m_hGenericSegment.set("attribute",strEmpty);
      return;
   }
   size_t pos = hToken[1].find("=");
   if (pos != string::npos)
   {
      hToken[1].insert(pos + 1,"\"",1);
      hToken[1].append("\"",1);
   }
   m_hGenericSegment.set("attribute",hToken[1]);
  //## end restcommand::CaseManifest::addAttribute%650C8C0B0268.body
}

void CaseManifest::addName (const string& strValue)
{
  //## begin restcommand::CaseManifest::addName%650AF3FD00FC.body preserve=yes
   vector<string> hToken;
   Buffer::parse(strValue,"!",hToken);
   addAttribute(hToken);
   m_pXMLDocument->add(hToken[0].c_str());
   m_strTag = hToken[0];
   m_strTag.append("Tag",3);
  //## end restcommand::CaseManifest::addName%650AF3FD00FC.body
}

void CaseManifest::addTag (const string& strValue)
{
  //## begin restcommand::CaseManifest::addTag%650AF41C03C8.body preserve=yes
   vector<string> hToken;
   Buffer::parse(strValue,"!",hToken);
   vector<string> hTag;
   Buffer::parse(hToken[0],"=",hTag);
   m_hGenericSegment.set("tag",hTag[0]);
   if (hTag.size() > 1)
      std::replace(hTag[1].begin(),hTag[1].end(),'^',':');
   string strEmpty("XXX"); // !!! ??? WIP
   m_hGenericSegment.set("value",hTag.size() == 2 ? hTag[1] : strEmpty);
   addAttribute(hToken);
   m_pXMLDocument->add(m_strTag.c_str());
  //## end restcommand::CaseManifest::addTag%650AF41C03C8.body
}

bool CaseManifest::execute ()
{
  //## begin restcommand::CaseManifest::execute%650B049F01B7.body preserve=yes
   m_strText.erase();
   m_pXMLDocument->write("SingleCaseRqst");
   Message::instance(Message::INBOUND)->reset("      ", "S0003R");
   char* p = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&p);
   TextSegment hTextSegment;
   hTextSegment.setText(m_strText);
   Trace::put(m_strText.data(), m_strText.length());
   hTextSegment.deport(&p);
   char szTemp[9];
   snprintf(szTemp, sizeof(szTemp), "%08d", p - Message::instance(Message::INBOUND)->data());
   memcpy(Message::instance(Message::INBOUND)->data(), szTemp, 8);
   Message::instance(Message::INBOUND)->setDataLength(p - Message::instance(Message::INBOUND)->data());
   m_pSingleCaseCommand->transition();
   m_pSingleCaseCommand->cleanup();
   return true;
  //## end restcommand::CaseManifest::execute%650B049F01B7.body
}

void CaseManifest::update (Subject* pSubject)
{
  //## begin restcommand::CaseManifest::update%650B034A0139.body preserve=yes
   m_strText += m_hRow.getBuffer();
  //## end restcommand::CaseManifest::update%650B034A0139.body
}

bool CaseManifest::save ()
{
  //## begin restcommand::CaseManifest::save%659E800D03BB.body preserve=yes
   bool bReturn = false;;
   m_strText.erase();
   m_pXMLDocument->write("CaseManifest");
   if (m_strText.empty() || m_strText.find("<CaseManifest") == string::npos)
   {
      m_iDI_FILE_ID = -1;
      return bReturn;
   }
   reusable::Table hTable;
   if (m_iDI_FILE_ID == 0)
   {
      Query hQuery;
      short iNull = -1;
      hQuery.bind("DI_DATA_CONTROL", "DI_FILE_ID", Column::LONG, &m_iDI_FILE_ID, &iNull, "MAX");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iDI_FILE_ID = -1;
         return false;
      }
      ++m_iDI_FILE_ID;
      auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
      hTable.setName("DI_DATA_CONTROL");
      hTable.set("DI_FILE_ID", m_iDI_FILE_ID, true);
      hTable.set("DI_FILE_TYPE", "DNBXML");
      hTable.set("DI_PATH", CommonHeaderSegment::instance()->getUserID());
      hTable.set("TSTAMP_INITIATED", Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      if (!pInsertStatement->execute(hTable))
      {
         m_iDI_FILE_ID = -1;
         return false;
      }
   }
   hTable.reset();
   hTable.setName("DI_DATA");
   size_t nPos = m_strText.find("<CaseManifest");
   size_t nPos1 = m_strText.find("</CaseManifest>");
   int m = nPos1 - nPos + 15;
   ImportData::instance()->setTRANSACTION_NO(++m_iTRANSACTION_NO);
   ImportData::instance()->setDI_FILE_ID(m_iDI_FILE_ID);
   ImportData::instance()->setSEQ_NO(1);
   ImportData::instance()->setIMPORT_KEY("");
   if (!(bReturn = ImportData::instance()->insert(m_strText.data() + nPos, m, false)))
      m_iDI_FILE_ID = -1;
   return bReturn;
  //## end restcommand::CaseManifest::save%659E800D03BB.body
}

// Additional Declarations
  //## begin restcommand::CaseManifest%650AE9310043.declarations preserve=yes
  //## end restcommand::CaseManifest%650AE9310043.declarations

} // namespace restcommand

//## begin module%650AE95D01F7.epilog preserve=yes
//## end module%650AE95D01F7.epilog
