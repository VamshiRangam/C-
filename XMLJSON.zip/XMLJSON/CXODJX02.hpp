//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64A81FED0226.cm preserve=no
//## end module%64A81FED0226.cm

//## begin module%64A81FED0226.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64A81FED0226.cp

//## Module: CXOSJX02%64A81FED0226; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX02.hpp

#ifndef CXOSJX02_h
#define CXOSJX02_h 1

//## begin module%64A81FED0226.additionalIncludes preserve=no
//## end module%64A81FED0226.additionalIncludes

//## begin module%64A81FED0226.includes preserve=yes
//## end module%64A81FED0226.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%64A81FED0226.declarations preserve=no
//## end module%64A81FED0226.declarations

//## begin module%64A81FED0226.additionalDeclarations preserve=yes
//## end module%64A81FED0226.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ServicesCommand%64A81DB90195.preface preserve=yes
//## end restcommand::ServicesCommand%64A81DB90195.preface

//## Class: ServicesCommand%64A81DB90195
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64A81DDF01C0;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%64A81DE302BF;monitor::UseCase { -> F}
//## Uses: <unnamed>%64A81DE70068;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%64A81DEA0250;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%64A8220101BC;reusable::Buffer { -> F}
//## Uses: <unnamed>%652949D000C1;IF::Extract { -> F}

class DllExport ServicesCommand : public command::RESTCommand  //## Inherits: <unnamed>%64DFD7F000D2
{
  //## begin restcommand::ServicesCommand%64A81DB90195.initialDeclarations preserve=yes
  //## end restcommand::ServicesCommand%64A81DB90195.initialDeclarations

  public:
    //## Constructors (generated)
      ServicesCommand();

    //## Constructors (specified)
      //## Operation: ServicesCommand%64A81E5A032F
      ServicesCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ServicesCommand();


    //## Other Operations (specified)
      //## Operation: execute%64A81E77007C
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%64A81E790252
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ServicesCommand%64A81DB90195.public preserve=yes
      //## end restcommand::ServicesCommand%64A81DB90195.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ServicesCommand%64A81DB90195.protected preserve=yes
      //## end restcommand::ServicesCommand%64A81DB90195.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ServicesCommand%64A81DB90195.private preserve=yes
      //## end restcommand::ServicesCommand%64A81DB90195.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%64A81F940006
      //## begin restcommand::ServicesCommand::CONTEXT_DATA%64A81F940006.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCONTEXT_DATA;
      //## end restcommand::ServicesCommand::CONTEXT_DATA%64A81F940006.attr

      //## Attribute: IMAGE_ID%64A81F940031
      //## begin restcommand::ServicesCommand::IMAGE_ID%64A81F940031.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strIMAGE_ID;
      //## end restcommand::ServicesCommand::IMAGE_ID%64A81F940031.attr

      //## Attribute: TASK_ID%64A81F9E0254
      //## begin restcommand::ServicesCommand::TASK_ID%64A81F9E0254.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strTASK_ID;
      //## end restcommand::ServicesCommand::TASK_ID%64A81F9E0254.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64A81E0502D5
      //## Role: ServicesCommand::<m_hGenericSegment>%64A81E06024A
      //## begin restcommand::ServicesCommand::<m_hGenericSegment>%64A81E06024A.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ServicesCommand::<m_hGenericSegment>%64A81E06024A.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64A81E0D02B9
      //## Role: ServicesCommand::<m_hQuery>%64A81E0E018A
      //## begin restcommand::ServicesCommand::<m_hQuery>%64A81E0E018A.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ServicesCommand::<m_hQuery>%64A81E0E018A.role

    // Additional Implementation Declarations
      //## begin restcommand::ServicesCommand%64A81DB90195.implementation preserve=yes
      //## end restcommand::ServicesCommand%64A81DB90195.implementation

};

//## begin restcommand::ServicesCommand%64A81DB90195.postscript preserve=yes
//## end restcommand::ServicesCommand%64A81DB90195.postscript

} // namespace restcommand

//## begin module%64A81FED0226.epilog preserve=yes
//## end module%64A81FED0226.epilog


#endif
