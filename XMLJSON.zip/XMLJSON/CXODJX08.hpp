//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%651ABA2F033D.cm preserve=no
//## end module%651ABA2F033D.cm

//## begin module%651ABA2F033D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%651ABA2F033D.cp

//## Module: CXOSJX08%651ABA2F033D; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX08.hpp

#ifndef CXOSJX08_h
#define CXOSJX08_h 1

//## begin module%651ABA2F033D.additionalIncludes preserve=no
//## end module%651ABA2F033D.additionalIncludes

//## begin module%651ABA2F033D.includes preserve=yes
//## end module%651ABA2F033D.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
class ReasonCode;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseSegment;
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%651ABA2F033D.declarations preserve=no
//## end module%651ABA2F033D.declarations

//## begin module%651ABA2F033D.additionalDeclarations preserve=yes
//## end module%651ABA2F033D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReasonCodesCommand%651AB8E100D2.preface preserve=yes
//## end restcommand::ReasonCodesCommand%651AB8E100D2.preface

//## Class: ReasonCodesCommand%651AB8E100D2
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%651AB91E00ED;monitor::UseCase { -> F}
//## Uses: <unnamed>%651AB9200205;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%651AB92201BC;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%651AB924025D;reusable::Query { -> F}
//## Uses: <unnamed>%651AB92701FD;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%651AB93C0366;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%651AB93E0355;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%651AB9400375;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%651AB94302C6;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%651ABC5F029E;ems::ReasonCode { -> F}

class DllExport ReasonCodesCommand : public command::RESTCommand  //## Inherits: <unnamed>%651AB91603CE
{
  //## begin restcommand::ReasonCodesCommand%651AB8E100D2.initialDeclarations preserve=yes
  //## end restcommand::ReasonCodesCommand%651AB8E100D2.initialDeclarations

  public:
    //## Constructors (generated)
      ReasonCodesCommand();

    //## Constructors (specified)
      //## Operation: ReasonCodesCommand%651AB9A00209
      ReasonCodesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReasonCodesCommand();


    //## Other Operations (specified)
      //## Operation: execute%651AB9C00165
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%651AB9C402D4
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReasonCodesCommand%651AB8E100D2.public preserve=yes
      //## end restcommand::ReasonCodesCommand%651AB8E100D2.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReasonCodesCommand%651AB8E100D2.protected preserve=yes
      //## end restcommand::ReasonCodesCommand%651AB8E100D2.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReasonCodesCommand%651AB8E100D2.private preserve=yes
      //## end restcommand::ReasonCodesCommand%651AB8E100D2.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%655B5BB0029B
      //## begin restcommand::ReasonCodesCommand::Buffer%655B5BB0029B.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end restcommand::ReasonCodesCommand::Buffer%655B5BB0029B.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%651AB95D0284
      //## Role: ReasonCodesCommand::<m_hGenericSegment>%651AB95E01CD
      //## begin restcommand::ReasonCodesCommand::<m_hGenericSegment>%651AB95E01CD.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReasonCodesCommand::<m_hGenericSegment>%651AB95E01CD.role

    // Additional Implementation Declarations
      //## begin restcommand::ReasonCodesCommand%651AB8E100D2.implementation preserve=yes
      //## end restcommand::ReasonCodesCommand%651AB8E100D2.implementation
};

//## begin restcommand::ReasonCodesCommand%651AB8E100D2.postscript preserve=yes
//## end restcommand::ReasonCodesCommand%651AB8E100D2.postscript

} // namespace restcommand

//## begin module%651ABA2F033D.epilog preserve=yes
//## end module%651ABA2F033D.epilog


#endif
