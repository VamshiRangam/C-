//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67FFBD6301DD.cm preserve=no
//## end module%67FFBD6301DD.cm

//## begin module%67FFBD6301DD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67FFBD6301DD.cp

//## Module: CXOSJX42%67FFBD6301DD; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX42.hpp

#ifndef CXOSJX42_h
#define CXOSJX42_h 1

//## begin module%67FFBD6301DD.additionalIncludes preserve=no
//## end module%67FFBD6301DD.additionalIncludes

//## begin module%67FFBD6301DD.includes preserve=yes
//## end module%67FFBD6301DD.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67FFBD6301DD.declarations preserve=no
//## end module%67FFBD6301DD.declarations

//## begin module%67FFBD6301DD.additionalDeclarations preserve=yes
//## end module%67FFBD6301DD.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.preface preserve=yes
//## end restcommand::NetworkReasonCodeCommand%67FFC080036C.preface

//## Class: NetworkReasonCodeCommand%67FFC080036C
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST Network Reason Code
//	<h6>Resolve : REST : Network Reason Code
//	<p>
//	Returns list of available reason codes for a network
//	request type.
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/resolve/networkreasoncodes.yaml">YAML</a
//	>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67FFC17C0186;monitor::UseCase { -> F}
//## Uses: <unnamed>%67FFC1830170;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67FFC1860395;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%67FFC18A00B6;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%68075C880385;IF::Extract { -> F}
//## Uses: <unnamed>%68076A1A01D8;timer::Clock { -> F}

class DllExport NetworkReasonCodeCommand : public command::RESTCommand  //## Inherits: <unnamed>%67FFC1780137
{
  //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.initialDeclarations preserve=yes
  //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkReasonCodeCommand();

    //## Constructors (specified)
      //## Operation: NetworkReasonCodeCommand%67FFC30C0039
      NetworkReasonCodeCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~NetworkReasonCodeCommand();


    //## Other Operations (specified)
      //## Operation: determineNetworkRules%6807637802AE
      void determineNetworkRules (const string& strCUST_ID, const string& strNetworkName, const string& strUserRole);

      //## Operation: determineRULE_SET_ID%6807645D0270
      int determineRULE_SET_ID (const string& strCUST_ID);

      //## Operation: determineBaseRULE_SET_ID%6807648B0036
      reusable::string determineBaseRULE_SET_ID (const string& strRULE_SET_ID);

      //## Operation: execute%67FFC3A20373
      virtual bool execute ();

      //## Operation: update%67FFC3C303CE
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.public preserve=yes
      //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.protected preserve=yes
      //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.private preserve=yes
      //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NETWORK_RULES%680764C1012B
      //## begin restcommand::NetworkReasonCodeCommand::NETWORK_RULES%680764C1012B.attr preserve=no  private: string {U} 
      string m_strNETWORK_RULES;
      //## end restcommand::NetworkReasonCodeCommand::NETWORK_RULES%680764C1012B.attr

      //## Attribute: DESCRIPTION_TEXT%680767F603AE
      //## begin restcommand::NetworkReasonCodeCommand::DESCRIPTION_TEXT%680767F603AE.attr preserve=no  private: string {U} 
      string m_strDESCRIPTION_TEXT;
      //## end restcommand::NetworkReasonCodeCommand::DESCRIPTION_TEXT%680767F603AE.attr

      //## Attribute: RESN_CODE_ID%680768170124
      //## begin restcommand::NetworkReasonCodeCommand::RESN_CODE_ID%680768170124.attr preserve=no  private: string {U} 
      string m_strRESN_CODE_ID;
      //## end restcommand::NetworkReasonCodeCommand::RESN_CODE_ID%680768170124.attr

      //## Attribute: RULE_SET_ID%68076832008C
      //## begin restcommand::NetworkReasonCodeCommand::RULE_SET_ID%68076832008C.attr preserve=no  private: string {U} 
      string m_strRULE_SET_ID;
      //## end restcommand::NetworkReasonCodeCommand::RULE_SET_ID%68076832008C.attr

      //## Attribute: Columns%680F64860349
      //## begin restcommand::NetworkReasonCodeCommand::Columns%680F64860349.attr preserve=no  private: vector<pair<string,string> > {V} 
      vector<pair<string,string> > m_hColumns;
      //## end restcommand::NetworkReasonCodeCommand::Columns%680F64860349.attr

      //## Attribute: Count%680F64C30293
      //## begin restcommand::NetworkReasonCodeCommand::Count%680F64C30293.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end restcommand::NetworkReasonCodeCommand::Count%680F64C30293.attr

      //## Attribute: QueryNumber%680F64EE0368
      //## begin restcommand::NetworkReasonCodeCommand::QueryNumber%680F64EE0368.attr preserve=no  private: int {U} 0
      int m_iQueryNumber;
      //## end restcommand::NetworkReasonCodeCommand::QueryNumber%680F64EE0368.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%68074F3C0309
      //## Role: NetworkReasonCodeCommand::<m_hQuery>%68074F3D0259
      //## begin restcommand::NetworkReasonCodeCommand::<m_hQuery>%68074F3D0259.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::NetworkReasonCodeCommand::<m_hQuery>%68074F3D0259.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%68075CD303D0
      //## Role: NetworkReasonCodeCommand::<m_hGenericSegment>%68075CD5000D
      //## begin restcommand::NetworkReasonCodeCommand::<m_hGenericSegment>%68075CD5000D.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::NetworkReasonCodeCommand::<m_hGenericSegment>%68075CD5000D.role

    // Additional Implementation Declarations
      //## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.implementation preserve=yes
      //## end restcommand::NetworkReasonCodeCommand%67FFC080036C.implementation

};

//## begin restcommand::NetworkReasonCodeCommand%67FFC080036C.postscript preserve=yes
//## end restcommand::NetworkReasonCodeCommand%67FFC080036C.postscript

} // namespace restcommand

//## begin module%67FFBD6301DD.epilog preserve=yes
//## end module%67FFBD6301DD.epilog


#endif
