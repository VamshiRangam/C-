//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67E544C902E5.cm preserve=no
//## end module%67E544C902E5.cm

//## begin module%67E544C902E5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67E544C902E5.cp

//## Module: CXOSJX40%67E544C902E5; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX40.hpp

#ifndef CXOSJX40_h
#define CXOSJX40_h 1

//## begin module%67E544C902E5.additionalIncludes preserve=no
//## end module%67E544C902E5.additionalIncludes

//## begin module%67E544C902E5.includes preserve=yes
//## end module%67E544C902E5.includes

#ifndef CXOSRF24_h
#include "CXODRF24.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLDocument;
} // namespace command

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class FileControl;

} // namespace reconciliationfile

//## begin module%67E544C902E5.declarations preserve=no
//## end module%67E544C902E5.declarations

//## begin module%67E544C902E5.additionalDeclarations preserve=yes
//## end module%67E544C902E5.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::Email%67E4BB8F02A9.preface preserve=yes
//## end restcommand::Email%67E4BB8F02A9.preface

//## Class: Email%67E4BB8F02A9
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67E69BA400D5;reconciliationfile::FileControl { -> F}

class DllExport Email : public reconciliationfile::Email  //## Inherits: <unnamed>%67E4BBA90155
{
  //## begin restcommand::Email%67E4BB8F02A9.initialDeclarations preserve=yes
  //## end restcommand::Email%67E4BB8F02A9.initialDeclarations

  public:
    //## Constructors (generated)
      Email();

    //## Constructors (specified)
      //## Operation: Email%67E548F2029D
      Email (command::XMLDocument* pXMLDocument, GenericSegment* pGenericSegment, const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME, const string& strTemplate);

    //## Destructor (generated)
      virtual ~Email();


    //## Other Operations (specified)
      //## Operation: report%67E5540C0369
      virtual bool report (const char cType);

    // Additional Public Declarations
      //## begin restcommand::Email%67E4BB8F02A9.public preserve=yes
      //## end restcommand::Email%67E4BB8F02A9.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::Email%67E4BB8F02A9.protected preserve=yes
      //## end restcommand::Email%67E4BB8F02A9.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::Email%67E4BB8F02A9.private preserve=yes
      //## end restcommand::Email%67E4BB8F02A9.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67E5754800B5
      //## Role: Email::<m_pXMLDocument>%67E57549019D
      //## begin restcommand::Email::<m_pXMLDocument>%67E57549019D.role preserve=no  public: command::XMLDocument { -> RFHgN}
      command::XMLDocument *m_pXMLDocument;
      //## end restcommand::Email::<m_pXMLDocument>%67E57549019D.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67E576C602C8
      //## Role: Email::<m_pGenericSegment>%67E576C70307
      //## begin restcommand::Email::<m_pGenericSegment>%67E576C70307.role preserve=no  public: segment::GenericSegment { -> RFHgN}
      segment::GenericSegment *m_pGenericSegment;
      //## end restcommand::Email::<m_pGenericSegment>%67E576C70307.role

    // Additional Implementation Declarations
      //## begin restcommand::Email%67E4BB8F02A9.implementation preserve=yes
      //## end restcommand::Email%67E4BB8F02A9.implementation

};

//## begin restcommand::Email%67E4BB8F02A9.postscript preserve=yes
//## end restcommand::Email%67E4BB8F02A9.postscript

} // namespace restcommand

//## begin module%67E544C902E5.epilog preserve=yes
//## end module%67E544C902E5.epilog


#endif
