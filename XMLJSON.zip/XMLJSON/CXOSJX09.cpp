//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6525EAC1012F.cm preserve=no
//## end module%6525EAC1012F.cm

//## begin module%6525EAC1012F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6525EAC1012F.cp

//## Module: CXOSJX09%6525EAC1012F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX09.cpp

//## begin module%6525EAC1012F.additionalIncludes preserve=no
//## end module%6525EAC1012F.additionalIncludes

//## begin module%6525EAC1012F.includes preserve=yes
//## end module%6525EAC1012F.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBC39_h
#include "CXODBC39.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSJX06_h
#include "CXODJX06.hpp"
#endif
#ifndef CXOSJX09_h
#include "CXODJX09.hpp"
#endif


//## begin module%6525EAC1012F.declarations preserve=no
//## end module%6525EAC1012F.declarations

//## begin module%6525EAC1012F.additionalDeclarations preserve=yes
//## end module%6525EAC1012F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ClaimCommand 

ClaimCommand::ClaimCommand()
  //## begin ClaimCommand::ClaimCommand%6525C089037C_const.hasinit preserve=no
      : m_pCaseManifest(0)
  //## end ClaimCommand::ClaimCommand%6525C089037C_const.hasinit
  //## begin ClaimCommand::ClaimCommand%6525C089037C_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/claim/v1.0.0","S0003D","@##JCCLAM ")
  //## end ClaimCommand::ClaimCommand%6525C089037C_const.initialization
{
  //## begin restcommand::ClaimCommand::ClaimCommand%6525C089037C_const.body preserve=yes
   memcpy(m_sID, "JX09", 4);
  //## end restcommand::ClaimCommand::ClaimCommand%6525C089037C_const.body
}

ClaimCommand::ClaimCommand (Handler* pSuccessor)
  //## begin restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.hasinit preserve=no
      : m_pCaseManifest(0)
  //## end restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.hasinit
  //## begin restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/claim/v1.0.0","S0003D","@##JCCLAM ")
  //## end restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.initialization
{
  //## begin restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.body preserve=yes
   memcpy(m_sID, "JX09", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('I', segment::ImportReportAuditSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::ClaimCommand::ClaimCommand%6525C2FA02C1.body
}


ClaimCommand::~ClaimCommand()
{
  //## begin restcommand::ClaimCommand::~ClaimCommand%6525C089037C_dest.body preserve=yes
  //## end restcommand::ClaimCommand::~ClaimCommand%6525C089037C_dest.body
}



//## Other Operations (implementation)
bool ClaimCommand::endElement (const string& strTag)
{
  //## begin restcommand::ClaimCommand::endElement%6525C2E601C4.body preserve=yes
   bool bReturn = true;
   if (strTag == "userId"
      || strTag == "password")
      m_pCaseManifest->add(strTag, m_pXMLItem->get(strTag.c_str()));
   if (strTag == "name")
      m_pCaseManifest->addName(m_pXMLItem->get("name"));
   if (strTag == "tag")
      m_pCaseManifest->addTag(m_pXMLItem->get("tag"));
   if (strTag == "case")
      bReturn = m_pCaseManifest->save();
   m_pXMLItem->resetToken();
   if(!bReturn)
      Database::instance()->rollback();
   return bReturn;
  //## end restcommand::ClaimCommand::endElement%6525C2E601C4.body
}

bool ClaimCommand::execute ()
{
  //## begin restcommand::ClaimCommand::execute%6525C2E10061.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX09 CLAIM INITIATION");
   ImportReportAuditSegment::instance()->reset();
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RXCCLAM", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX09", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pCaseManifest = new restcommand::CaseManifest("CASEMAN", "CXOXJX09");
   parse();
   m_pXMLDocument->add("root");
   if (m_pCaseManifest->getDI_FILE_ID() <= 0)
   {
      SOAPSegment::instance()->setRtnCde('3');
      m_pXMLDocument->add("details");
      reply();
   }
   else
   {
      ImportReportAuditSegment::instance()->setDI_FILE_ID(m_pCaseManifest->getDI_FILE_ID());
      m_pXMLDocument->add("details");
      m_pXMLDocument->add("claimNumber");
      reply();
   }
   delete m_pCaseManifest;
   m_pCaseManifest = 0;
   return true;
  //## end restcommand::ClaimCommand::execute%6525C2E10061.body
}

void ClaimCommand::update (Subject* pSubject)
{
  //## begin restcommand::ClaimCommand::update%6525C2E801D8.body preserve=yes
   RESTCommand::update(pSubject);
  //## end restcommand::ClaimCommand::update%6525C2E801D8.body
}

// Additional Declarations
  //## begin restcommand::ClaimCommand%6525C089037C.declarations preserve=yes
  //## end restcommand::ClaimCommand%6525C089037C.declarations

} // namespace restcommand

//## begin module%6525EAC1012F.epilog preserve=yes
//## end module%6525EAC1012F.epilog
