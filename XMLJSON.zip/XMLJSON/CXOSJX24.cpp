//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66A3A4DA004B.cm preserve=no
//## end module%66A3A4DA004B.cm

//## begin module%66A3A4DA004B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66A3A4DA004B.cp

//## Module: CXOSJX24%66A3A4DA004B; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX24.cpp

//## begin module%66A3A4DA004B.additionalIncludes preserve=no
//## end module%66A3A4DA004B.additionalIncludes

//## begin module%66A3A4DA004B.includes preserve=yes
//## end module%66A3A4DA004B.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX24_h
#include "CXODJX24.hpp"
#endif


//## begin module%66A3A4DA004B.declarations preserve=no
//## end module%66A3A4DA004B.declarations

//## begin module%66A3A4DA004B.additionalDeclarations preserve=yes
//## end module%66A3A4DA004B.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ServiceUnavailableCommand 

ServiceUnavailableCommand::ServiceUnavailableCommand()
  //## begin ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.hasinit preserve=no
  //## end ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.hasinit
  //## begin ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/serviceunavailable/v1.0.0","S0003D","@##JSVCUN ")
  //## end ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.initialization
{
  //## begin restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.body preserve=yes
   memcpy(m_sID,"JX24",4);
  //## end restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A460039A_const.body
}

ServiceUnavailableCommand::ServiceUnavailableCommand (Handler* pSuccessor)
  //## begin restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.hasinit preserve=no
  //## end restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.hasinit
  //## begin restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/serviceunavailable/v1.0.0","S0003D","@##JSVCUN ")
  //## end restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.initialization
{
  //## begin restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.body preserve=yes
   memcpy(m_sID,"JX24",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::ServiceUnavailableCommand::ServiceUnavailableCommand%66A3A59203C7.body
}


ServiceUnavailableCommand::~ServiceUnavailableCommand()
{
  //## begin restcommand::ServiceUnavailableCommand::~ServiceUnavailableCommand%66A3A460039A_dest.body preserve=yes
  //## end restcommand::ServiceUnavailableCommand::~ServiceUnavailableCommand%66A3A460039A_dest.body
}



//## Other Operations (implementation)
bool ServiceUnavailableCommand::execute ()
{
  //## begin restcommand::ServiceUnavailableCommand::execute%66A3A5B70238.body preserve=yes
   UseCase hUseCase("CLIENT","## JX24 SERVICE UNAVAILABLE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJSVCUN",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX24",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC = parse();
   char* pMessage[] = {
      "Service unavailable",
      "1",
      "2",
      "Invalid request (parse failure)",
      "Authentication unsuccessful"
   };
   if (iRC <= 4)
      SOAPSegment::instance()->setTxt(pMessage[iRC]);
   if (iRC == 0)
   {
      SOAPSegment::instance()->setRtnCde('9');
      iRC = 9;
   }
   m_pXMLDocument->add("root");
   CommonHeaderSegment::instance()->setResultCode(iRC);
   if (iRC > 0)
      UseCase::addItem();
   return reply();
  //## end restcommand::ServiceUnavailableCommand::execute%66A3A5B70238.body
}

// Additional Declarations
  //## begin restcommand::ServiceUnavailableCommand%66A3A460039A.declarations preserve=yes
  //## end restcommand::ServiceUnavailableCommand%66A3A460039A.declarations

} // namespace restcommand

//## begin module%66A3A4DA004B.epilog preserve=yes
//## end module%66A3A4DA004B.epilog
