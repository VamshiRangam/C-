//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B757FB011D.cm preserve=no
//## end module%65B757FB011D.cm

//## begin module%65B757FB011D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B757FB011D.cp

//## Module: CXOSJX14%65B757FB011D; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX14.cpp

//## begin module%65B757FB011D.additionalIncludes preserve=no
//## end module%65B757FB011D.additionalIncludes

//## begin module%65B757FB011D.includes preserve=yes
//## end module%65B757FB011D.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSJX14_h
#include "CXODJX14.hpp"
#endif


//## begin module%65B757FB011D.declarations preserve=no
//## end module%65B757FB011D.declarations

//## begin module%65B757FB011D.additionalDeclarations preserve=yes
//## end module%65B757FB011D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::MmtsCommand 

MmtsCommand::MmtsCommand()
  //## begin MmtsCommand::MmtsCommand%65B7593E0315_const.hasinit preserve=no
      : m_pszBuffer(0)
  //## end MmtsCommand::MmtsCommand%65B7593E0315_const.hasinit
  //## begin MmtsCommand::MmtsCommand%65B7593E0315_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/mmts/v1.0.0","S0003D","@##JLMMTS ")
  //## end MmtsCommand::MmtsCommand%65B7593E0315_const.initialization
{
  //## begin restcommand::MmtsCommand::MmtsCommand%65B7593E0315_const.body preserve=yes
   memcpy(m_sID, "JX14", 4);
  //## end restcommand::MmtsCommand::MmtsCommand%65B7593E0315_const.body
}

MmtsCommand::MmtsCommand (Handler* pSuccessor)
  //## begin restcommand::MmtsCommand::MmtsCommand%65B759C70330.hasinit preserve=no
      : m_pszBuffer(0)
  //## end restcommand::MmtsCommand::MmtsCommand%65B759C70330.hasinit
  //## begin restcommand::MmtsCommand::MmtsCommand%65B759C70330.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/mmts/v1.0.0","S0003D","@##JLMMTS ")
  //## end restcommand::MmtsCommand::MmtsCommand%65B759C70330.initialization
{
  //## begin restcommand::MmtsCommand::MmtsCommand%65B759C70330.body preserve=yes
   memcpy(m_sID, "JX14", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_pszBuffer = new char[sizeof(segMMTSegment) + 1];
  //## end restcommand::MmtsCommand::MmtsCommand%65B759C70330.body
}


MmtsCommand::~MmtsCommand()
{
  //## begin restcommand::MmtsCommand::~MmtsCommand%65B7593E0315_dest.body preserve=yes
   delete[] m_pszBuffer;
  //## end restcommand::MmtsCommand::~MmtsCommand%65B7593E0315_dest.body
}



//## Other Operations (implementation)
bool MmtsCommand::execute ()
{
  //## begin restcommand::MmtsCommand::execute%65B75AA10393.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX14 LIST MMT");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLMMTS", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX14", &m_hRow, &m_hXMLText);
#endif
   m_bMMTAvailableFlag = false;
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   CaseSegment::instance()->setPresence(true);
   CaseTransitionSegment::instance()->setPresence(true);
   CasePhaseSegment::instance()->setPresence(true);
   Query hQuery;
   hQuery.join("EMS_CASE", "INNER", "EMS_TRANSITION", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "CASE_ID");
   hQuery.join("EMS_TRANSITION", "INNER", "EMS_PHASE", "PHASE_TSTAMP", "TSTAMP_CREATED");
   CaseSegment::instance()->bind(hQuery);
   CasePhaseSegment::instance()->bind(hQuery);
   CaseTransitionSegment::instance()->bind(hQuery);
   hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", m_pXMLItem->get("caseNumber").c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_pXMLItem->get("requestType"));
      CaseTransitionSegment::instance()->setSTATUS_NEXT(m_pXMLItem->get("status"));
      CasePhaseSegment::instance()->setUSER_ROLE(m_pXMLItem->get("role"));
      CasePhaseSegment::instance()->setREASON_CODE(m_pXMLItem->get("reasonCode"));
      ems::EMSRulesEngine::instance()->exportAvailableMMT(this, m_pszBuffer);
      SOAPSegment::instance()->setRtnCde(m_bMMTAvailableFlag ? '0' : '2');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::MmtsCommand::execute%65B75AA10393.body
}

void MmtsCommand::update (Subject* pSubject)
{
  //## begin restcommand::MmtsCommand::update%65B75AD403E2.body preserve=yes
   if (pSubject == 0)
   {
      ++m_iRows;
      ++m_iTotalRows;
      if (!m_bMMTAvailableFlag)
         m_bMMTAvailableFlag = true;
      segMMTSegment* p = (segMMTSegment*)m_pszBuffer;
      string strValue(p->sMMT_MSG_ID, sizeof(p->sMMT_MSG_ID));
      m_hGenericSegment.set("Message", strValue);
      strValue.assign(p->sParentMMT_MSG_ID, sizeof(p->sParentMMT_MSG_ID));
      m_hGenericSegment.set("Parent", strValue);
      strValue.assign(p->sPARENT_CHILD_IND, sizeof(p->sPARENT_CHILD_IND));
      m_hGenericSegment.set("ParentChild", strValue);
      strValue.assign(p->sBUSINESS_NAME, sizeof(p->sBUSINESS_NAME));
      m_hGenericSegment.set("BusinessName", strValue);
      m_hGenericSegment.set("Format", p->sFORMAT);
      m_pXMLDocument->add("row");
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::MmtsCommand::update%65B75AD403E2.body
}

// Additional Declarations
  //## begin restcommand::MmtsCommand%65B7593E0315.declarations preserve=yes
  //## end restcommand::MmtsCommand%65B7593E0315.declarations

} // namespace restcommand

//## begin module%65B757FB011D.epilog preserve=yes
//## end module%65B757FB011D.epilog
