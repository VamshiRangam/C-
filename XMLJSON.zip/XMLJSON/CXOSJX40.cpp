//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67E544CC00D0.cm preserve=no
//## end module%67E544CC00D0.cm

//## begin module%67E544CC00D0.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%67E544CC00D0.cp

//## Module: CXOSJX40%67E544CC00D0; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX40.cpp

//## begin module%67E544CC00D0.additionalIncludes preserve=no
//## end module%67E544CC00D0.additionalIncludes

//## begin module%67E544CC00D0.includes preserve=yes
//## end module%67E544CC00D0.includes

#ifndef CXOSRF26_h
#include "CXODRF26.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSJX40_h
#include "CXODJX40.hpp"
#endif


//## begin module%67E544CC00D0.declarations preserve=no
//## end module%67E544CC00D0.declarations

//## begin module%67E544CC00D0.additionalDeclarations preserve=yes
//## end module%67E544CC00D0.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::Email 

Email::Email()
  //## begin Email::Email%67E4BB8F02A9_const.hasinit preserve=no
      : m_pXMLDocument(0),
        m_pGenericSegment(0)
  //## end Email::Email%67E4BB8F02A9_const.hasinit
  //## begin Email::Email%67E4BB8F02A9_const.initialization preserve=yes
  //## end Email::Email%67E4BB8F02A9_const.initialization
{
  //## begin restcommand::Email::Email%67E4BB8F02A9_const.body preserve=yes
  //## end restcommand::Email::Email%67E4BB8F02A9_const.body
}

Email::Email (command::XMLDocument* pXMLDocument, GenericSegment* pGenericSegment, const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME, const string& strTemplate)
  //## begin restcommand::Email::Email%67E548F2029D.hasinit preserve=no
      : m_pXMLDocument(0),
        m_pGenericSegment(0)
  //## end restcommand::Email::Email%67E548F2029D.hasinit
  //## begin restcommand::Email::Email%67E548F2029D.initialization preserve=yes
   ,reconciliationfile::Email (strDX_FILE_TYPE,strENTITY_TYPE,strENTITY_ID,strDATE_RECON,strSCHED_TIME,strTemplate)
  //## end restcommand::Email::Email%67E548F2029D.initialization
{
  //## begin restcommand::Email::Email%67E548F2029D.body preserve=yes
   memcpy(m_sID,"JX40",4);
   m_pXMLDocument = pXMLDocument;
   m_pGenericSegment = pGenericSegment;
   reconciliationfile::FileControl::instance()->select(strDX_FILE_TYPE,strDATE_RECON);
  //## end restcommand::Email::Email%67E548F2029D.body
}


Email::~Email()
{
  //## begin restcommand::Email::~Email%67E4BB8F02A9_dest.body preserve=yes
  //## end restcommand::Email::~Email%67E4BB8F02A9_dest.body
}



//## Other Operations (implementation)
bool Email::report (const char cType)
{
  //## begin restcommand::Email::report%67E5540C0369.body preserve=yes
   vector<string>::iterator p;
   for (p = m_hTemplate.begin();p != m_hTemplate.end();++p)
   {
      if ((*p)[0] == cType)
      {
         string strText((*p).data() + 1,(*p).length() - 1);
         m_hXMLText.substitute(strText,false);
         int j = strText.length() > 15 && strText.substr(strText.length() - 4,4) == "@#^!" ? 15 : 0;
         m_pGenericSegment->set("Text",strText);
         m_pXMLDocument->add("text");
      }
   }
   return true;
  //## end restcommand::Email::report%67E5540C0369.body
}

// Additional Declarations
  //## begin restcommand::Email%67E4BB8F02A9.declarations preserve=yes
  //## end restcommand::Email%67E4BB8F02A9.declarations

} // namespace restcommand

//## begin module%67E544CC00D0.epilog preserve=yes
//## end module%67E544CC00D0.epilog
