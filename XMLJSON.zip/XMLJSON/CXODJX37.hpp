//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A1910801B4.cm preserve=no
//## end module%67A1910801B4.cm

//## begin module%67A1910801B4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67A1910801B4.cp

//## Module: CXOSJX37%67A1910801B4; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX37.hpp

#ifndef CXOSJX37_h
#define CXOSJX37_h 1

//## begin module%67A1910801B4.additionalIncludes preserve=no
//## end module%67A1910801B4.additionalIncludes

//## begin module%67A1910801B4.includes preserve=yes
//## end module%67A1910801B4.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67A1910801B4.declarations preserve=no
//## end module%67A1910801B4.declarations

//## begin module%67A1910801B4.additionalDeclarations preserve=yes
//## end module%67A1910801B4.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReportFilesCommand%67A18FE20142.preface preserve=yes
//## end restcommand::ReportFilesCommand%67A18FE20142.preface

//## Class: ReportFilesCommand%67A18FE20142
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67A1902E01E5;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67A190310234;monitor::UseCase { -> F}
//## Uses: <unnamed>%67A19034028B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67A1903703B2;database::DatabaseFactory { -> F}

class DllExport ReportFilesCommand : public command::RESTCommand  //## Inherits: <unnamed>%67A1902B02C7
{
  //## begin restcommand::ReportFilesCommand%67A18FE20142.initialDeclarations preserve=yes
  //## end restcommand::ReportFilesCommand%67A18FE20142.initialDeclarations

  public:
    //## Constructors (generated)
      ReportFilesCommand();

    //## Constructors (specified)
      //## Operation: ReportFilesCommand%67A1909B0340
      ReportFilesCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReportFilesCommand();


    //## Other Operations (specified)
      //## Operation: execute%67A190AB0048
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%67A190AD0325
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReportFilesCommand%67A18FE20142.public preserve=yes
      //## end restcommand::ReportFilesCommand%67A18FE20142.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReportFilesCommand%67A18FE20142.protected preserve=yes
      //## end restcommand::ReportFilesCommand%67A18FE20142.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReportFilesCommand%67A18FE20142.private preserve=yes
      //## end restcommand::ReportFilesCommand%67A18FE20142.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DX_FILE_ID%67A194490372
      //## begin restcommand::ReportFilesCommand::DX_FILE_ID%67A194490372.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDX_FILE_ID;
      //## end restcommand::ReportFilesCommand::DX_FILE_ID%67A194490372.attr

      //## Attribute: DX_FILE_TYPE%67A1944B027C
      //## begin restcommand::ReportFilesCommand::DX_FILE_TYPE%67A1944B027C.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDX_FILE_TYPE;
      //## end restcommand::ReportFilesCommand::DX_FILE_TYPE%67A1944B027C.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A1904000E6
      //## Role: ReportFilesCommand::<m_hGenericSegment>%67A190410219
      //## begin restcommand::ReportFilesCommand::<m_hGenericSegment>%67A190410219.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReportFilesCommand::<m_hGenericSegment>%67A190410219.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A1904A022E
      //## Role: ReportFilesCommand::<m_hQuery>%67A1904B033B
      //## begin restcommand::ReportFilesCommand::<m_hQuery>%67A1904B033B.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReportFilesCommand::<m_hQuery>%67A1904B033B.role

    // Additional Implementation Declarations
      //## begin restcommand::ReportFilesCommand%67A18FE20142.implementation preserve=yes
      //## end restcommand::ReportFilesCommand%67A18FE20142.implementation

};

//## begin restcommand::ReportFilesCommand%67A18FE20142.postscript preserve=yes
//## end restcommand::ReportFilesCommand%67A18FE20142.postscript

} // namespace restcommand

//## begin module%67A1910801B4.epilog preserve=yes
//## end module%67A1910801B4.epilog


#endif
