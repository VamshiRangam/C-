//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6763BAD1006F.cm preserve=no
//## end module%6763BAD1006F.cm

//## begin module%6763BAD1006F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6763BAD1006F.cp

//## Module: CXOSJX31%6763BAD1006F; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX31.cpp

//## begin module%6763BAD1006F.additionalIncludes preserve=no
//## end module%6763BAD1006F.additionalIncludes

//## begin module%6763BAD1006F.includes preserve=yes
//## end module%6763BAD1006F.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX31_h
#include "CXODJX31.hpp"
#endif


//## begin module%6763BAD1006F.declarations preserve=no
//## end module%6763BAD1006F.declarations

//## begin module%6763BAD1006F.additionalDeclarations preserve=yes
//## end module%6763BAD1006F.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::WorkqueuesCommand 

WorkqueuesCommand::WorkqueuesCommand()
  //## begin WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.hasinit preserve=no
      : m_lCONSTRAINT_ID(0)
  //## end WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.hasinit
  //## begin WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/workqueues/v1.0.0", "S0003D", "@##JLWRKQ ")
  //## end WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.initialization
{
  //## begin restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.body preserve=yes
   memcpy(m_sID, "JX31", 4);
  //## end restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BB6502D1_const.body
}

WorkqueuesCommand::WorkqueuesCommand (Handler* pSuccessor)
  //## begin restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.hasinit preserve=no
      : m_lCONSTRAINT_ID(0)
  //## end restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.hasinit
  //## begin restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/workqueues/v1.0.0", "S0003D", "@##JLWRKQ ")
  //## end restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.initialization
{
  //## begin restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.body preserve=yes
   memcpy(m_sID, "JX31", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::WorkqueuesCommand::WorkqueuesCommand%6763BD7F030A.body
}


WorkqueuesCommand::~WorkqueuesCommand()
{
  //## begin restcommand::WorkqueuesCommand::~WorkqueuesCommand%6763BB6502D1_dest.body preserve=yes
  //## end restcommand::WorkqueuesCommand::~WorkqueuesCommand%6763BB6502D1_dest.body
}



//## Other Operations (implementation)
bool WorkqueuesCommand::execute ()
{
  //## begin restcommand::WorkqueuesCommand::execute%6763BDC70199.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX31 LIST CONSTRAINT");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLWRKQ", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX31", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_hQuery.reset();
   int iRC = parse();
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_pXMLDocument->add("root");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY", "CQC_CONSTRAINT");
   m_hQuery.setQualifier("QUALIFY", "CQC_USER");
   m_hQuery.join("CQC_CONSTRAINT", "INNER", "CQC_USER", "CONSTRAINT_ID");
   m_hQuery.bind("CQC_CONSTRAINT", "CONSTRAINT_ID", Column::LONG, &m_lCONSTRAINT_ID);
   m_hQuery.bind("CQC_CONSTRAINT", "TYPE", Column::STRING, &m_strTYPE);
   m_hQuery.bind("CQC_CONSTRAINT", "DESCRIPTION", Column::STRING, &m_strDESCRIPTION);
   m_hQuery.bind("CQC_CONSTRAINT", "ORDER_BY", Column::STRING, &m_strORDER_BY);
   m_hQuery.bind("CQC_CONSTRAINT", "TSTAMP_UPDATED", Column::STRING, &m_strTSTAMP_UPDATED);
   m_hQuery.setBasicPredicate("CQC_USER", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   m_hQuery.setOrderByClause("CQC_CONSTRAINT.DESCRIPTION");
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::WorkqueuesCommand::execute%6763BDC70199.body
}

void WorkqueuesCommand::update (Subject* pSubject)
{
  //## begin restcommand::WorkqueuesCommand::update%6763BDF10185.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.set("Constraint", m_lCONSTRAINT_ID);
      m_hGenericSegment.set("Type", m_strTYPE);
      m_hGenericSegment.set("Description", m_strDESCRIPTION);
      m_hGenericSegment.set("OrderBy", m_strORDER_BY);
      m_hGenericSegment.set("Updated", m_strTSTAMP_UPDATED);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::WorkqueuesCommand::update%6763BDF10185.body
}

// Additional Declarations
  //## begin restcommand::WorkqueuesCommand%6763BB6502D1.declarations preserve=yes
  //## end restcommand::WorkqueuesCommand%6763BB6502D1.declarations

} // namespace restcommand

//## begin module%6763BAD1006F.epilog preserve=yes
//## end module%6763BAD1006F.epilog
