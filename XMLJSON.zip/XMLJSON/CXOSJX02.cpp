//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64A81FEF0245.cm preserve=no
//## end module%64A81FEF0245.cm

//## begin module%64A81FEF0245.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64A81FEF0245.cp

//## Module: CXOSJX02%64A81FEF0245; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX02.cpp

//## begin module%64A81FEF0245.additionalIncludes preserve=no
//## end module%64A81FEF0245.additionalIncludes

//## begin module%64A81FEF0245.includes preserve=yes
//## end module%64A81FEF0245.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX02_h
#include "CXODJX02.hpp"
#endif


//## begin module%64A81FEF0245.declarations preserve=no
//## end module%64A81FEF0245.declarations

//## begin module%64A81FEF0245.additionalDeclarations preserve=yes
//## end module%64A81FEF0245.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ServicesCommand 

ServicesCommand::ServicesCommand()
  //## begin ServicesCommand::ServicesCommand%64A81DB90195_const.hasinit preserve=no
  //## end ServicesCommand::ServicesCommand%64A81DB90195_const.hasinit
  //## begin ServicesCommand::ServicesCommand%64A81DB90195_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/operate/services/v1.0.0","S0003D","@##JLSVCS ")
  //## end ServicesCommand::ServicesCommand%64A81DB90195_const.initialization
{
  //## begin restcommand::ServicesCommand::ServicesCommand%64A81DB90195_const.body preserve=yes
   memcpy(m_sID,"JX02",4);
  //## end restcommand::ServicesCommand::ServicesCommand%64A81DB90195_const.body
}

ServicesCommand::ServicesCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.hasinit preserve=no
  //## end restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.hasinit
  //## begin restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/operate/services/v1.0.0","S0003D","@##JLSVCS ")
  //## end restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.initialization
{
  //## begin restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.body preserve=yes
   memcpy(m_sID,"JX02",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ServicesCommand::ServicesCommand%64A81E5A032F.body
}


ServicesCommand::~ServicesCommand()
{
  //## begin restcommand::ServicesCommand::~ServicesCommand%64A81DB90195_dest.body preserve=yes
  //## end restcommand::ServicesCommand::~ServicesCommand%64A81DB90195_dest.body
}



//## Other Operations (implementation)
bool ServicesCommand::execute ()
{
  //## begin restcommand::ServicesCommand::execute%64A81E77007C.body preserve=yes
   UseCase hUseCase("CLIENT","## JX02 LIST SERVICES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLSVCS",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX02",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
   m_hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   m_hQuery.bind("TASK_CONTEXT_COMN","IMAGE_ID",Column::STRING,&m_strIMAGE_ID);
   m_hQuery.bind("TASK_CONTEXT_COMN","TASK_ID",Column::STRING,&m_strTASK_ID);
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","STATE");
   m_hQuery.setOrderByClause("IMAGE_ID,TASK_ID ASC");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   SOAPSegment::instance()->setRtnCde(b ? '0' :'5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ServicesCommand::execute%64A81E77007C.body
}

void ServicesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ServicesCommand::update%64A81E790252.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      string strAddressSpace;
      IF::Extract::instance()->getAddressSpace(m_strTASK_ID,strAddressSpace);
      string strHost;
      IF::Extract::instance()->getHost(strAddressSpace,strHost);
      vector<string> hTokens;
      Buffer::parse(m_strCONTEXT_DATA,",",hTokens);
      if (hTokens.size() > 0)
      {
         ++m_iRows;
         ++m_iTotalRows;
         m_hGenericSegment.set("Name",m_strTASK_ID);
         m_hGenericSegment.set("Server",strHost);
         m_hGenericSegment.set("State",hTokens[0]);
         m_hGenericSegment.set("Tracing",hTokens.size() > 1 ? hTokens[1] : "Off");
         m_hGenericSegment.set("Image",m_strIMAGE_ID);
         m_pXMLDocument->add("row");
      }
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ServicesCommand::update%64A81E790252.body
}

// Additional Declarations
  //## begin restcommand::ServicesCommand%64A81DB90195.declarations preserve=yes
  //## end restcommand::ServicesCommand%64A81DB90195.declarations

} // namespace restcommand

//## begin module%64A81FEF0245.epilog preserve=yes
//## end module%64A81FEF0245.epilog
