//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6525EB9E0280.cm preserve=no
//## end module%6525EB9E0280.cm

//## begin module%6525EB9E0280.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6525EB9E0280.cp

//## Module: CXOSJX10%6525EB9E0280; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX10.cpp

//## begin module%6525EB9E0280.additionalIncludes preserve=no
//## end module%6525EB9E0280.additionalIncludes

//## begin module%6525EB9E0280.includes preserve=yes
//## end module%6525EB9E0280.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX10_h
#include "CXODJX10.hpp"
#endif


//## begin module%6525EB9E0280.declarations preserve=no
//## end module%6525EB9E0280.declarations

//## begin module%6525EB9E0280.additionalDeclarations preserve=yes
//## end module%6525EB9E0280.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ClaimStatusCommand 

ClaimStatusCommand::ClaimStatusCommand()
  //## begin ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.hasinit preserve=no
      : m_iFailed(0),
        m_iSucceeded(0)
  //## end ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.hasinit
  //## begin ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/claimstatus/v1.0.0","S0003D","@##JRCLAM ")
  //## end ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.initialization
{
  //## begin restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.body preserve=yes
   memcpy(m_sID, "JX10", 4);
  //## end restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C0D60207_const.body
}

ClaimStatusCommand::ClaimStatusCommand (Handler* pSuccessor)
  //## begin restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.hasinit preserve=no
      : m_iFailed(0),
        m_iSucceeded(0)
  //## end restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.hasinit
  //## begin restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/resolve/claimstatus/v1.0.0","S0003D","@##JRCLAM ")
  //## end restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.initialization
{
  //## begin restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.body preserve=yes
   memcpy(m_sID, "JX10", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ClaimStatusCommand::ClaimStatusCommand%6525C2B401B9.body
}


ClaimStatusCommand::~ClaimStatusCommand()
{
  //## begin restcommand::ClaimStatusCommand::~ClaimStatusCommand%6525C0D60207_dest.body preserve=yes
  //## end restcommand::ClaimStatusCommand::~ClaimStatusCommand%6525C0D60207_dest.body
}



//## Other Operations (implementation)
bool ClaimStatusCommand::execute ()
{
  //## begin restcommand::ClaimStatusCommand::execute%6525C21502A1.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX10 READ CLAIM STATUS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRCLAM", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX10", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_iSucceeded = 0;
   m_iFailed = 0;
   m_hGenericSegment.set("CLAIM_NO", atoi(m_pXMLItem->get("claimNumber").c_str()));
   m_hQuery.join("DI_DATA_CONTROL", "INNER", "DI_DATA", "DI_FILE_ID");
   m_hGenericSegment.bind("DI_DATA", "DI_STATE", m_hQuery);
   m_hGenericSegment.bind("DI_DATA", "IMPORT_KEY", m_hQuery);
   m_hGenericSegment.bind("DI_DATA", "REJECT_CODES", m_hQuery);
   m_hGenericSegment.bind("DI_DATA", "DATA_BUFFER", m_hQuery);
   m_hQuery.setBasicPredicate("DI_DATA_CONTROL", "DI_FILE_ID", "=", atoi(m_pXMLItem->get("claimNumber").c_str()));
   m_hQuery.setOrderByClause("SEQ_NO");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      m_hGenericSegment.set("Requested", UseCase::getItems());
      m_hGenericSegment.set("Attempted", m_iSucceeded + m_iFailed);
      m_hGenericSegment.set("Succeeded", m_iSucceeded);
      m_hGenericSegment.set("Failed", m_iFailed);
      m_pXMLDocument->add("claim");
   }
   m_pXMLDocument->add("details");
   reply();
   m_hGenericSegment.reset();
   m_hQuery.reset();
   m_pXMLDocument->reset();
   return true;
  //## end restcommand::ClaimStatusCommand::execute%6525C21502A1.body
}

void ClaimStatusCommand::update (Subject* pSubject)
{
  //## begin restcommand::ClaimStatusCommand::update%6525C2180004.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      string strValue;
      m_hGenericSegment._field("DATA_BUFFER", strValue);
      size_t pos1 = strValue.find("<PrimaryKey >");
      size_t pos2 = strValue.find("</PrimaryKey>");
      if (pos1 != string::npos
         && pos2 != string::npos)
         m_hGenericSegment.set("PrimaryKey", strValue.substr(pos1 + 12, pos2 - (pos1 + 12)));
      if (m_hGenericSegment.get("DI_STATE") == "IC")
      {
         m_hGenericSegment.set("Code", "0");
         m_hGenericSegment.set("CaseNumber", m_hGenericSegment.get("IMPORT_KEY"));
         m_hGenericSegment.set("Message", m_hGenericSegment.get("REJECT_CODES"));
         ++m_iSucceeded;
      }
      else if (m_hGenericSegment.get("DI_STATE") == "IF")
      {
            m_hGenericSegment.set("Code", "1");
            m_hGenericSegment.set("Message", m_hGenericSegment.get("REJECT_CODES"));
            ++m_iFailed;
      }
      else
         m_hGenericSegment.set("Message", "Case processing pending.");
      m_pXMLDocument->add("caseReport");
      m_hGenericSegment.set("CaseNumber", "");
      m_hGenericSegment.set("Code", "");
      m_pXMLDocument->add("assessment");
      UseCase::addItem();
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ClaimStatusCommand::update%6525C2180004.body
}

// Additional Declarations
  //## begin restcommand::ClaimStatusCommand%6525C0D60207.declarations preserve=yes
  //## end restcommand::ClaimStatusCommand%6525C0D60207.declarations

} // namespace restcommand

//## begin module%6525EB9E0280.epilog preserve=yes
//## end module%6525EB9E0280.epilog
