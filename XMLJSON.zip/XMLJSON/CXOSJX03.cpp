//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF8F740006.cm preserve=no
//## end module%64DF8F740006.cm

//## begin module%64DF8F740006.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF8F740006.cp

//## Module: CXOSJX03%64DF8F740006; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX03.cpp

//## begin module%64DF8F740006.additionalIncludes preserve=no
//## end module%64DF8F740006.additionalIncludes

//## begin module%64DF8F740006.includes preserve=yes
#ifndef CXOSRU54_h
#include "CXODRU54.hpp"
#endif
//## end module%64DF8F740006.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSVC30_h
#include "CXODVC30.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSVC29_h
#include "CXODVC29.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSVC32_h
#include "CXODVC32.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBC41_h
#include "CXODBC41.hpp"
#endif
#ifndef CXOSRU54_h
#include "CXODRU54.hpp"
#endif
#ifndef CXOSDB24_h
#include "CXODDB24.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSJX03_h
#include "CXODJX03.hpp"
#endif


//## begin module%64DF8F740006.declarations preserve=no
//## end module%64DF8F740006.declarations

//## begin module%64DF8F740006.additionalDeclarations preserve=yes
//## end module%64DF8F740006.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::TransactionListCommand 

TransactionListCommand::TransactionListCommand()
  //## begin TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.hasinit preserve=no
      : m_bChild(false)
  //## end TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.hasinit
  //## begin TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/research/transactions/v1.0.0","S0003D","@##JLTRAN ")
  //## end TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.initialization
{
  //## begin restcommand::TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.body preserve=yes
   memcpy(m_sID,"JX03",4);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   m_hQuery[2].attach(this);
   m_hQuery[3].attach(this);
  //## end restcommand::TransactionListCommand::TransactionListCommand%64DF8C7B0338_const.body
}

TransactionListCommand::TransactionListCommand (Handler* pSuccessor)
  //## begin restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.hasinit preserve=no
      : m_bChild(false)
  //## end restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.hasinit
  //## begin restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/research/transactions/v1.0.0","S0003D","@##JLTRAN ")
  //## end restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.initialization
{
  //## begin restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.body preserve=yes
   memcpy(m_sID,"JX03",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   m_hQuery[2].attach(this);
   m_hQuery[3].attach(this);
  //## end restcommand::TransactionListCommand::TransactionListCommand%64DF93A30059.body
}


TransactionListCommand::~TransactionListCommand()
{
  //## begin restcommand::TransactionListCommand::~TransactionListCommand%64DF8C7B0338_dest.body preserve=yes
  //## end restcommand::TransactionListCommand::~TransactionListCommand%64DF8C7B0338_dest.body
}



//## Other Operations (implementation)
bool TransactionListCommand::addtoXMLDocument ()
{
  //## begin restcommand::TransactionListCommand::addtoXMLDocument%655357FB0397.body preserve=yes
   bool bSucess = true;
   if (m_bChild)
      bSucess = m_pXMLDocument->add("childrow");
   else
      bSucess = m_pXMLDocument->add("row");
   for (int i = 0;i < m_hValues.size() && bSucess;i++)
   {
      m_hGenericSegment.set("Value", m_hValues[i]);
      bSucess = m_pXMLDocument->add("value");

   }
   if (!bSucess)
   {
      m_pXMLDocument->revert();
      m_hQuery[1].setAbort(true);
   }
   else
      m_pXMLDocument->write(m_bChild ? "childrow" : "row");
   return bSucess;
  //## end restcommand::TransactionListCommand::addtoXMLDocument%655357FB0397.body
}

bool TransactionListCommand::endElement (const string& strTag)
{
  //## begin restcommand::TransactionListCommand::endElement%64E2C187025F.body preserve=yes
   string strOperator(m_pXMLItem->get("operator"));
   string strValue(m_pXMLItem->get("value"));
   if (strTag == "filter")
   {
      if (m_pXMLItem->get("column") == "rows")
         setMaxRows(atoi(strValue.c_str()));
      else
      {
         if (m_pXMLItem->get("column") == "PrimaryKey")
            m_bChild = true;
         viewcommand::FinancialTransaction::instance()->setBasicPredicate(m_hQuery[0], "Transaction", m_pXMLItem->get("column").c_str(), strOperator, strValue.c_str());
      }
      m_pXMLItem->resetToken();
   }
   return true;
  //## end restcommand::TransactionListCommand::endElement%64E2C187025F.body
}

bool TransactionListCommand::execute ()
{
  //## begin restcommand::TransactionListCommand::execute%64DF940B00A1.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX03 LIST TRANSACTIONS");
   m_hMessage = *Message::instance(Message::INBOUND);
   ((Segment*)viewcommand::FinancialTransaction::instance()->getTransactionSegment())->reset();
   viewcommand::FinancialTransaction::instance()->join(m_hQuery[0]);
   if (!m_pXMLDocument)
   {
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLTRAN",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX03",&m_hRow,&m_hXMLText);
#endif
   }
   m_pXMLDocument->reset();
   viewcommand::Investigation::instance()->reset();
   viewcommand::FinancialTransaction::instance()->setBindAll(false);
   m_pXMLDocument->setMaximumSize(1000000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_hRequestedColumns.clear();
   m_strTab.erase();
   m_iSkipRows = 0;
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      SOAPSegment::instance()->setTxt("Invalid request (parse failure)");
      reply();
      return true;
   }
   vector<string> hTokens;
   set<string> hTempRequestedColumns;
   string strColumn(m_pXMLItem->get("column"));
   Buffer::parse(strColumn, ",", hTokens);
   if (hTokens.size() != 0)
   {
      m_bChild = false;
      set<string>::iterator itr;
      m_hGenericSegment.set("Tab", "Transaction");
      m_pXMLDocument->add("tab");
      for (int i = 0;i < hTokens.size();++i)
      {
         string strTagName = hTokens[i];
         size_t pos = strTagName.find("format~");
         if (pos != string::npos)
            strTagName.erase(pos, 7);
         viewcommand::FinancialTransaction::instance()->bind(m_hQuery[0], "Transaction", strTagName);
         if (SOAPSegment::instance()->getMsg((SOAPSegment::instance()->getMsgCount() * 3) - 1) == "Undefined column: "+ strTagName)
            continue;
         m_hRequestedColumns.insert(hTokens[i]);
         hTempRequestedColumns.insert(strTagName);
      }
      for (itr = hTempRequestedColumns.begin();itr != hTempRequestedColumns.end(); itr++)
      {
         string strColumnName = *itr;
         size_t pos = strColumnName.find("format~");
         if (pos != string::npos)
            strColumnName.erase(pos, 7);
         m_hGenericSegment.set("Name", strColumnName);
         m_pXMLDocument->add("column");
      }
   }
   else
   {
      if (!m_bChild)
      {
         SOAPSegment::instance()->setRtnCde('3');
         m_pXMLDocument->add("details");
         reply();
         return true;
      }
      m_bChild = false;
      viewcommand::FinancialTransaction::instance()->setBindAll(true);
      if (viewcommand::FinancialTransaction::instance()->getDetail() == false)
         viewcommand::FinancialTransaction::instance()->bind(m_hQuery[0], "Transaction", "IssuerAccountTypes");
   }
   viewcommand::FinancialTransaction::instance()->bind(m_hQuery[0], "Transaction", "PrimaryKey");
   viewcommand::Investigation::instance()->execute(m_hQuery[0]);
   viewcommand::FinancialTransaction::instance()->bind(m_hQuery[0]);
   secure(m_hQuery[0], "FIN_L");
   if (SOAPSegment::instance()->getRtnCde() == "4")
   {
      m_pXMLDocument->add("details");
      reply();
      return true;
   }
   string strRecord;
   Extract::instance()->getRecord("DUSER", strRecord);
   if (strRecord.find("EXCLSETTLED") != string::npos)
      m_hQuery[0].setBasicPredicate("FIN_L", "FIN_TYPE", "<>", "080");
   Application::instance()->setCallback(this);
   Application::instance()->setQueueWaitOption(false);
   return true;
  //## end restcommand::TransactionListCommand::execute%64DF940B00A1.body
}

void TransactionListCommand::onResume ()
{
  //## begin restcommand::TransactionListCommand::onResume%655357D50337.body preserve=yes
   UseCase hUseCase("CLIENT", "## CL99 LIST TRANSACTIONS");
   m_hQuery[1] = m_hQuery[0];
   bool b = viewcommand::FinancialTransaction::instance()->changeTable(m_hQuery[1]);
   Query hQuery;
   if (Extract::instance()->getCustomCode() == "EFTPOS"
      && m_hQuery[1].getSearchCondition().find(".PAN") != string::npos)
   {
      string strTABLE_NAME("FIN_Lyyyymm");
      strTABLE_NAME.replace(5, 6, command::TimeRange::instance()->getStartDateTime().data(), 6);
      string strDATA_TYPE;
      if (reusable::DataModel::instance()->isPresent(strTABLE_NAME, "PAN_TOKEN_PREFIX", strDATA_TYPE))
      {
         hQuery = m_hQuery[1];
         hQuery.addTable("FIN_L").setIndex("");
         size_t npos = hQuery.getSearchCondition().find("FIN_L.PAN ");
         if (npos != string::npos)
         {
            if (command::TimeRange::instance()->getStartDateTime().substr(0, 6) > reusable::DataModel::instance()->getFirstMonth("FIN_L", "PAN_TOKEN"))
            {
               hQuery.getSearchCondition().replace(npos, 10, "FIN_L.PAN_TOKEN ");
               hQuery.addTable("FIN_L").getIndex("PAN_TOKEN");
            }
            else
            {
               hQuery.getSearchCondition().replace(npos, 10, "FIN_RECORD.PAN_TOKEN ");
               hQuery.addTable("FIN_RECORD").getIndex("PAN_TOKEN");
            }
         }
         npos = hQuery.getSearchCondition().find("PAN_PREFIX");
         if (npos != string::npos)
         {
            hQuery.getSearchCondition().replace(npos, 10, "PAN_TOKEN_PREFIX");
            hQuery.addTable("FIN_L").getIndex("PAN_TOKEN_PREFIX");
         }
         npos = hQuery.getSearchCondition().find("PAN_SUFFIX");
         if (npos != string::npos)
            hQuery.getSearchCondition().replace(npos, 10, "PAN_TOKEN_SUFFIX");
         m_hQuery[1].setOrderByClause("");
         m_hQuery[1].setQuery(&hQuery);
      }
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[1]))
      SOAPSegment::instance()->setRtnCde('5');
   else
      if (b == false
         && m_hQuery[1].getAbort() == false)
      {
         Database::instance()->commit();
         return;
      }
      else
         SOAPSegment::instance()->setRtnCde(m_iRows == 0 ? '2' : m_hQuery[1].getAbort() ? '1' : '0');
   if (viewcommand::FinancialTransaction::instance()->getDetail() == true)
   {
      string strTSTAMP_TRANS;
      string strUNIQUENESS_KEY;
      viewcommand::FinancialTransaction::instance()->getTransactionSegment()->_field("TSTAMP_TRANS", strTSTAMP_TRANS);
      viewcommand::FinancialTransaction::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS);
      viewcommand::FinancialTransaction::instance()->getTransactionSegment()->_field("UNIQUENESS_KEY", strUNIQUENESS_KEY);
      viewcommand::FinancialTransaction::instance()->setUNIQUENESS_KEY(atoi(strUNIQUENESS_KEY.c_str()));
      processOnetoMany();
   }
   m_pXMLDocument->write("tab");
   m_pXMLDocument->add("details");
   reply();
   m_hRow.getBuffer().erase();
   Application::instance()->setCallback(0);
   Application::instance()->setQueueWaitOption(true);
  //## end restcommand::TransactionListCommand::onResume%655357D50337.body
}

int TransactionListCommand::parse ()
{
  //## begin restcommand::TransactionListCommand::parse%6553574701CB.body preserve=yes
   int iRC = RESTCommand::parse();
   if (iRC != 0)
      return iRC;
   if (command::TimeRange::instance()->getStartDateTime().empty()
      && command::TimeRange::instance()->getEndDateTime().empty())
   {
      command::TimeRange::instance()->setStartDateTime(timer::Clock::instance()->getYYYYMMDDHHMMSSHN());
      command::TimeRange::instance()->setEndDateTime("0000000000000000");
   }
   return 0;
  //## end restcommand::TransactionListCommand::parse%6553574701CB.body
}

bool TransactionListCommand::populateTags (string strTagName)
{
  //## begin restcommand::TransactionListCommand::populateTags%65535A7B0103.body preserve=yes
   string strColumnName;
   string strTemp;
   map<string, set<string, less<string> >, less<string> >::const_iterator  pColumns = viewcommand::FinancialTransaction::instance()->getChild().find(strTagName);
   for (set<string, less<string> >::const_iterator pColumn = (*pColumns).second.begin();pColumn != (*pColumns).second.end();++pColumn)
   {
      strColumnName = *pColumn;
      if (m_hRequestedColumns.size() != 0 && m_hRequestedColumns.find(*pColumn) == m_hRequestedColumns.end())
      {
         if (m_hRequestedColumns.find("format~" + *pColumn) != m_hRequestedColumns.end())
            strColumnName = "format~" + *pColumn;
         else
            continue;
      }
      strTemp = strTagName + ":" + strColumnName;
      setColumnByTag(strTemp);
   }
   if (viewcommand::FinancialTransaction::instance()->getDetail() == true)
   {
      if (m_strTab != strTagName && m_strTab.empty() == false && m_bChild == false)
         m_pXMLDocument->write("tab");
      if (m_strTab.empty() || m_strTab != strTagName)
      {
         if (m_bChild == true)
         {
            m_hGenericSegment.set("Tab", strTagName);
            m_pXMLDocument->add("child");
         }
         else
         {
            m_hGenericSegment.set("Tab", strTagName);
            m_pXMLDocument->add("tab");
         }
         m_strTab = strTagName;
         for (int i = 0;i < m_hColumns.size();i++)
         {
            m_hGenericSegment.set("Name", m_hColumns[i]);
            m_pXMLDocument->add("column");
         }
      }
   }
   bool b = addtoXMLDocument();
   m_hColumns.erase(m_hColumns.begin(), m_hColumns.end());
   m_hValues.erase(m_hValues.begin(), m_hValues.end());
   return b;
  //## end restcommand::TransactionListCommand::populateTags%65535A7B0103.body
}

void TransactionListCommand::processOnetoMany ()
{
  //## begin restcommand::TransactionListCommand::processOnetoMany%655357EE02F1.body preserve=yes
   string strTemp;
   vector<string> hTokens;
   set <string, less<string> >::const_iterator pHeader;
   for (pHeader = viewcommand::FinancialTransaction::instance()->getHeader().begin();
      pHeader != viewcommand::FinancialTransaction::instance()->getHeader().end(); ++pHeader)
   {
      m_strHeader = *pHeader;
      if (m_strHeader != "Transaction")
      {
         set <string, less<string> >::const_iterator pOneToMany;
         for (pOneToMany = viewcommand::FinancialTransaction::instance()->getOneToMany().begin();
            pOneToMany != viewcommand::FinancialTransaction::instance()->getOneToMany().end(); ++pOneToMany)
         {
            Buffer::parse((*pOneToMany), ":", hTokens);
            if (hTokens[1] == m_strHeader)
               break;
         }
         if (pOneToMany != viewcommand::FinancialTransaction::instance()->getOneToMany().end())
            continue;
         m_hQuery[2].reset();
         strTemp = m_strHeader;
         if (viewcommand::FinancialTransaction::instance()->bind(m_hQuery[2], m_strHeader) == true)
         {
            vector<Table>& hTable = m_hQuery[2].getTable();
            if (reusable::DataModel::instance()->isPresent(hTable[0].getTableName()) == true)
            {
               string strTSTAMP_TRANS;
               string strUNIQUENESS_KEY;
               ((Segment*)viewcommand::FinancialTransaction::instance()->getTransactionSegment())->_field("TSTAMP_TRANS", strTSTAMP_TRANS, false, false);
               ((Segment*)viewcommand::FinancialTransaction::instance()->getTransactionSegment())->_field("UNIQUENESS_KEY", strUNIQUENESS_KEY, false, false);
               m_hQuery[2].setBasicPredicate(hTable[0].getTableName().c_str(), "TSTAMP_TRANS", "=", strTSTAMP_TRANS.c_str());
               m_hQuery[2].setBasicPredicate(hTable[0].getTableName().c_str(), "UNIQUENESS_KEY", "=", atoi(strUNIQUENESS_KEY.c_str()));
               auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
               if (!pSelectStatement->execute(m_hQuery[2]))
                  return;
            }
            else
               Trace::put("Table is not present in the system: ", hTable[0].getTableName());
         }
         else
            Trace::put("Template is not defined right for ", m_strHeader);
      }
   }
  //## end restcommand::TransactionListCommand::processOnetoMany%655357EE02F1.body
}

void TransactionListCommand::setColumnByTag (string strTagName)
{
  //## begin restcommand::TransactionListCommand::setColumnByTag%6553580A0314.body preserve=yes
   string strColumnName;
   string strColumnValue;
   string strAmountValue;
   string strCurrencyValue;
   string strPrimaryKey;
   vector<string> hTokens;
   GenericSegment* t = 0;
   bool bAdd = false;
   if (Buffer::parse(strTagName, ":", hTokens) == 2)
   {
      strColumnName = hTokens[1];
      size_t pos = strColumnName.find("format~");
      if (pos != string::npos)
      {
         strColumnName.erase(pos, 7);
         strTagName = hTokens[0] + ":" + strColumnName;
      }
   }
   if (hTokens[0] != "Transaction")
   {
      map <string, segment::GenericSegment*, less<string>>::const_iterator p = viewcommand::FinancialTransaction::instance()->getGenericSegmentList().find(hTokens[0]);
      if (p != viewcommand::FinancialTransaction::instance()->getGenericSegmentList().end())
         t = (*p).second;
   }
   if (!t)
      t = viewcommand::FinancialTransaction::instance()->getTransactionSegment();
   t->_field(strColumnName.c_str(), strColumnValue);
   if (trim(strColumnValue).length() == 0)
   {
      const multimap<string, database::Column, less<string> > hTag = viewcommand::FinancialTransaction::instance()->getTag();
      pair<multimap<string, database::Column, less<string> >::const_iterator, multimap<string, database::Column, less<string> >::const_iterator> hRange = hTag.equal_range(strTagName);
      if (hRange.first != hRange.second)
      {
         multimap<string, database::Column, less<string> >::const_iterator p = hRange.first;
         strAmountValue.erase();
         strCurrencyValue.erase();
         for (p = hRange.first; p != hRange.second; p++)
         {
            if ((*p).second.getColumn().find("AMT_") != string::npos)
               t->_field((*p).second.getColumn().c_str(), strAmountValue);
            else if ((*p).second.getColumn().find("CUR_") != string::npos)
               t->_field((*p).second.getColumn().c_str(), strCurrencyValue);
            else
            {
               if (strColumnName == "PrimaryKey")
               {
                  if (strColumnValue.length() > 0)
                     strColumnValue.append("~");
                  t->_field((*p).second.getColumn().c_str(), strPrimaryKey);
                  strColumnValue.append(strPrimaryKey);
               }
               else
                  t->_field((*p).second.getColumn().c_str(), strColumnValue);
            }
         }
         if (trim(strAmountValue).length() > 0)
         {
            if (hTokens[1].find("format~") != string::npos)
               strColumnValue = CurrencyCode::instance()->formatAmount(atof(strAmountValue.c_str()), strCurrencyValue, 32, true, false, true);
            else
               strColumnValue = strCurrencyValue + " " + strAmountValue;
            bAdd = true;
         }
         else if (trim(strColumnValue).length() > 0)
            bAdd = true;
      }
   }
   if (bAdd || m_hRequestedColumns.size() > 0)
   {
      m_hColumns.push_back(strColumnName);
      m_hValues.push_back(strColumnValue);
   }
  //## end restcommand::TransactionListCommand::setColumnByTag%6553580A0314.body
}

void TransactionListCommand::update (Subject* pSubject)
{
  //## begin restcommand::TransactionListCommand::update%64DF940D02C2.body preserve=yes
   if (pSubject == &m_hQuery[1])
   {
      viewcommand::FinancialTransaction::instance()->revise();
      if (viewcommand::FinancialTransaction::instance()->getDetail() == true
         || viewcommand::FinancialTransaction::instance()->skip() == false)
      {
         if (++m_iTotalRows > m_iSkipRows)
         {
            if ((m_iTotalRows - m_iSkipRows) <= m_iMaxRows
               || viewcommand::FinancialTransaction::instance()->getDetail() == true)
            {
               ++m_iRows;
               viewcommand::FinancialTransaction::instance()->setFinAmount();
               map<string, vector<string> >::iterator pTag;
               populateTags("Transaction");
            }
            else
               m_hQuery[1].setAbort(true);
         }
      }
      return;
   }
   if (pSubject == &m_hQuery[2])
   {
      vector<Table> hTable = m_hQuery[2].getTable();
      if (memcmp(hTable[0].getName().c_str(), "FIN_AMOUNT", 10) == 0)
         viewcommand::FinancialTransaction::instance()->setFinAmount();
      vector<string> hTokens;
      if (!populateTags(m_strHeader))
         return;
      set <string, less<string> >::const_iterator pOneToMany;
      for (pOneToMany = viewcommand::FinancialTransaction::instance()->getOneToMany().begin();
         pOneToMany != viewcommand::FinancialTransaction::instance()->getOneToMany().end(); ++pOneToMany)
      {
         Buffer::parse((*pOneToMany), ":", hTokens);
         if (hTokens[0] == m_strHeader)
         {
            m_bChild = true;
            m_strHeader = hTokens[1];
            m_hQuery[3].reset();
            if (viewcommand::FinancialTransaction::instance()->bind(m_hQuery[3], hTokens[1]) == false)
               return;
            vector<Table>& hTable = m_hQuery[3].getTable();
            m_hQuery[3].setBasicPredicate(hTable[0].getTableName().c_str(), "TSTAMP_TRANS", "=", viewcommand::FinancialTransaction::instance()->getTSTAMP_TRANS().c_str());
            m_hQuery[3].setBasicPredicate(hTable[0].getTableName().c_str(), "UNIQUENESS_KEY", "=", viewcommand::FinancialTransaction::instance()->getUNIQUENESS_KEY());
            auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            if (!pSelectStatement->execute(m_hQuery[3]))
               return;
            m_bChild = false;
            m_pXMLDocument->write("child");
         }
      }
      return;
   }
   if (pSubject == &m_hQuery[3])
   {
      populateTags(m_strHeader);
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::TransactionListCommand::update%64DF940D02C2.body
}

// Additional Declarations
  //## begin restcommand::TransactionListCommand%64DF8C7B0338.declarations preserve=yes
  //## end restcommand::TransactionListCommand%64DF8C7B0338.declarations

} // namespace restcommand

//## begin module%64DF8F740006.epilog preserve=yes
//## end module%64DF8F740006.epilog
