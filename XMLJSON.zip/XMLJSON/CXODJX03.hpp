//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF8F710293.cm preserve=no
//## end module%64DF8F710293.cm

//## begin module%64DF8F710293.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF8F710293.cp

//## Module: CXOSJX03%64DF8F710293; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX03.hpp

#ifndef CXOSJX03_h
#define CXOSJX03_h 1

//## begin module%64DF8F710293.additionalIncludes preserve=no
//## end module%64DF8F710293.additionalIncludes

//## begin module%64DF8F710293.includes preserve=yes
//## end module%64DF8F710293.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: DataNavigator Foundation::ViewCommand_CAT%394E26F50072
namespace viewcommand {
class TransactionSegment;
class FinancialTransaction;
class Investigation;
} // namespace viewcommand

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
class DataModel;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class DateTime;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

namespace database {
class CurrencyCode;
class DatabaseCatalog;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class TimeRange;
class XMLItem;

} // namespace command

//## begin module%64DF8F710293.declarations preserve=no
//## end module%64DF8F710293.declarations

//## begin module%64DF8F710293.additionalDeclarations preserve=yes
//## end module%64DF8F710293.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::TransactionListCommand%64DF8C7B0338.preface preserve=yes
//## end restcommand::TransactionListCommand%64DF8C7B0338.preface

//## Class: TransactionListCommand%64DF8C7B0338
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Research REST Transaction
//	<h6>Research : REST : Transaction
//	<p>
//	The transaction research JSON REST API retrieves a set
//	of transactions (including authorizations, financials
//	and reversals) logged by the transaction source.
//	Refer to details in this <a
//	href="../../REST/transactions/transactions.yml">OpenAPI
//	definition</a>.
//	The API request includes:
//	<ul>
//	<li>User ID and password
//	<li>the query predicates (within the filter array)
//	<li>the data elements (result set) to return (within the
//	column array)
//	</ul>
//	The User ID must be configured in DataNavigator Access
//	Security.
//	Access to financial transactions is limited per the
//	defined security profile for that user.
//	<p>
//	The query predicates include:
//	<ul>
//	<li>StartDateTime - beginning of search
//	<li>EndDateTime - end of search
//	<li>rows - maximum number of rows to return
//	<li>PrimaryKey - continuation point
//	<li>any number of columns from the financial transaction
//	</ul>
//	The following filter operators are supported:
//	<ul>
//	<li>"="
//	<li>">="
//	<li>">"
//	<li>"<"
//	<li>"<="
//	<li>"<>"
//	<li>"LIKE"
//	<li>"NOT LIKE"
//	<li>"BETWEEN"
//	<li>"NOT BETWEEN"
//	<li>"IN"
//	<li>"NOT IN"
//	</ul>
//	The BETWEEN and IN list values must be specified as
//	comma separated values.
//	<p>
//	Transactions are returned in chronological order if Start
//	DateTime is less than EndDateTime.
//	Transactions are returned in reverse chronological order
//	if StartDateTime is greater than EndDateTime.
//	All predicates must be true for a transaction to be
//	returned in the result set.
//	<p>
//	The following JSON schema file documents the Research
//	Transaction API request:
//	<ul>
//	<li><a
//	href="../../REST/transactions/request/transactions.schema
//	.json">API request</a>
//	</ul>
//	<p>
//	The following JSON schema file documents the Research
//	Transaction API response:
//	<ul>
//	<li><a
//	href="../../REST/transactions/response/transactions.schem
//	a.json">API response</a>
//	</ul>
//	<p>
//	The mapping between the API XML tag names and the Data
//	Navigator data model is defined in the
//	<a href="../../Template/CXOXCRFX.txt">financial table
//	create DDL</a>.
//	These tag names are used as predicates and/or the data
//	elements to return in the result set.
//	The tags are specified in comment lines that begin with
//	' /* - '.
//	For example, when cardholder billing amount (tag name
//	CardholderBillingAmount) is requested, two columns are
//	retrieved from the database:
//	<pre>
//	   /* -6:CardholderBillingAmount */
//	          AMT_CARD_BILL        DECIMAL(18) NOT NULL,
//	          CUR_CARD_BILL        CHAR(3) NOT NULL,
//	</pre>
//	<p>
//	The response header will indicate one of the following
//	return codes:
//	<ul>
//	<li>0 - successful (end of result set)
//	<li>1 - successful (maximum rows returned)
//	<li>2 - no transactions found
//	<li>3 - invalid request
//	<li>4 - authentication unsuccessful
//	<li>5 - query failure
//	<li>6 - invalid time range
//	</ul>
//	<p>
//	Three data elements (transaction time, account number
//	and amount) are requested in this <a
//	href="../../REST/transactions/request/transactions.json">
//	sample request</a>.
//	The search is by account number prefix (BIN).
//	Five rows are returned in this <a
//	href="../../REST/transactions/response/transactions.json"
//	>sample response</a>.
//	<p>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64DFCFAD0344;monitor::UseCase { -> F}
//## Uses: <unnamed>%64DFCFB4028B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%64DFCFB60274;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%64DFCFBB033C;segment::GenericSegment { -> F}
//## Uses: <unnamed>%64DFCFBD02B3;viewcommand::FinancialTransaction { -> F}
//## Uses: <unnamed>%64DFCFBF02BD;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%64DFCFC4021C;process::Application { -> F}
//## Uses: <unnamed>%64DFCFC700E4;database::Database { -> F}
//## Uses: <unnamed>%64DFCFCC0044;timer::Clock { -> F}
//## Uses: <unnamed>%64DFCFEE012C;viewcommand::Investigation { -> F}
//## Uses: <unnamed>%64DFD009023C;command::XMLItem { -> F}
//## Uses: <unnamed>%64DFD018034C;IF::DateTime { -> F}
//## Uses: <unnamed>%64DFD01E020B;reusable::Buffer { -> F}
//## Uses: <unnamed>%6554943602A9;viewcommand::TransactionSegment { -> F}
//## Uses: <unnamed>%65549532025F;IF::Extract { -> F}
//## Uses: <unnamed>%655495AE0157;command::TimeRange { -> F}
//## Uses: <unnamed>%655496390256;reusable::DataModel { -> F}
//## Uses: <unnamed>%655496DE0163;database::CurrencyCode { -> F}
//## Uses: <unnamed>%655497930303;database::DatabaseCatalog { -> F}
//## Uses: <unnamed>%655497CA009B;IF::Trace { -> F}

class DllExport TransactionListCommand : public command::RESTCommand  //## Inherits: <unnamed>%64DFD8170117
{
  //## begin restcommand::TransactionListCommand%64DF8C7B0338.initialDeclarations preserve=yes
  //## end restcommand::TransactionListCommand%64DF8C7B0338.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionListCommand();

    //## Constructors (specified)
      //## Operation: TransactionListCommand%64DF93A30059
      TransactionListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~TransactionListCommand();


    //## Other Operations (specified)
      //## Operation: addtoXMLDocument%655357FB0397
      bool addtoXMLDocument ();

      //## Operation: endElement%64E2C187025F
      virtual bool endElement (const string& strTag);

      //## Operation: execute%64DF940B00A1
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: onResume%655357D50337
      virtual void onResume ();

      //## Operation: parse%6553574701CB
      virtual int parse ();

      //## Operation: populateTags%65535A7B0103
      bool populateTags (string strTagName);

      //## Operation: processOnetoMany%655357EE02F1
      void processOnetoMany ();

      //## Operation: setColumnByTag%6553580A0314
      void setColumnByTag (string strTagName);

      //## Operation: update%64DF940D02C2
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::TransactionListCommand%64DF8C7B0338.public preserve=yes
      //## end restcommand::TransactionListCommand%64DF8C7B0338.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Column%65549156021A
      //## begin restcommand::TransactionListCommand::Column%65549156021A.attr preserve=no  private: map<string,vector<string> > {U} 
      map<string,vector<string> > m_hColumn;
      //## end restcommand::TransactionListCommand::Column%65549156021A.attr

    // Additional Protected Declarations
      //## begin restcommand::TransactionListCommand%64DF8C7B0338.protected preserve=yes
      //## end restcommand::TransactionListCommand%64DF8C7B0338.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::TransactionListCommand%64DF8C7B0338.private preserve=yes
      //## end restcommand::TransactionListCommand%64DF8C7B0338.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Child%65547FD003D7
      //## begin restcommand::TransactionListCommand::Child%65547FD003D7.attr preserve=no  private: bool {U} false
      bool m_bChild;
      //## end restcommand::TransactionListCommand::Child%65547FD003D7.attr

      //## Attribute: Columns%65548392031A
      //## begin restcommand::TransactionListCommand::Columns%65548392031A.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumns;
      //## end restcommand::TransactionListCommand::Columns%65548392031A.attr

      //## Attribute: Header%6554818C00ED
      //## begin restcommand::TransactionListCommand::Header%6554818C00ED.attr preserve=no  private: string {U} 
      string m_strHeader;
      //## end restcommand::TransactionListCommand::Header%6554818C00ED.attr

      //## Attribute: RequestedColumns%6597F3D0036E
      //## begin restcommand::TransactionListCommand::RequestedColumns%6597F3D0036E.attr preserve=no  private: set<string> {U} 
      set<string> m_hRequestedColumns;
      //## end restcommand::TransactionListCommand::RequestedColumns%6597F3D0036E.attr

      //## Attribute: Tab%655481AD004C
      //## begin restcommand::TransactionListCommand::Tab%655481AD004C.attr preserve=no  private: string {U} 
      string m_strTab;
      //## end restcommand::TransactionListCommand::Tab%655481AD004C.attr

      //## Attribute: Values%655483C30359
      //## begin restcommand::TransactionListCommand::Values%655483C30359.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hValues;
      //## end restcommand::TransactionListCommand::Values%655483C30359.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64DFD04B0169
      //## Role: TransactionListCommand::<m_hQuery>%64DFD04C00C3
      //## begin restcommand::TransactionListCommand::<m_hQuery>%64DFD04C00C3.role preserve=no  public: reusable::Query { -> 4VHgN}
      reusable::Query m_hQuery[4];
      //## end restcommand::TransactionListCommand::<m_hQuery>%64DFD04C00C3.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%64DFD05701E4
      //## Role: TransactionListCommand::<m_hMessage>%64DFD0590134
      //## begin restcommand::TransactionListCommand::<m_hMessage>%64DFD0590134.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end restcommand::TransactionListCommand::<m_hMessage>%64DFD0590134.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6554927000D0
      //## Role: TransactionListCommand::<m_hGenericSegment>%655492710325
      //## begin restcommand::TransactionListCommand::<m_hGenericSegment>%655492710325.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::TransactionListCommand::<m_hGenericSegment>%655492710325.role

    // Additional Implementation Declarations
      //## begin restcommand::TransactionListCommand%64DF8C7B0338.implementation preserve=yes
      //## end restcommand::TransactionListCommand%64DF8C7B0338.implementation

};

//## begin restcommand::TransactionListCommand%64DF8C7B0338.postscript preserve=yes
//## end restcommand::TransactionListCommand%64DF8C7B0338.postscript

} // namespace restcommand

//## begin module%64DF8F710293.epilog preserve=yes
//## end module%64DF8F710293.epilog


#endif
