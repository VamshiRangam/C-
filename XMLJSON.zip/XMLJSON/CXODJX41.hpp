//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67EE4E7C01C9.cm preserve=no
//## end module%67EE4E7C01C9.cm

//## begin module%67EE4E7C01C9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67EE4E7C01C9.cp

//## Module: CXOSJX41%67EE4E7C01C9; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX41.hpp

#ifndef CXOSJX41_h
#define CXOSJX41_h 1

//## begin module%67EE4E7C01C9.additionalIncludes preserve=no
//## end module%67EE4E7C01C9.additionalIncludes

//## begin module%67EE4E7C01C9.includes preserve=yes
//## end module%67EE4E7C01C9.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67EE4E7C01C9.declarations preserve=no
//## end module%67EE4E7C01C9.declarations

//## begin module%67EE4E7C01C9.additionalDeclarations preserve=yes
//## end module%67EE4E7C01C9.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::SaveCardholderCommand%67EE4FBF0060.preface preserve=yes
//## end restcommand::SaveCardholderCommand%67EE4FBF0060.preface

//## Class: SaveCardholderCommand%67EE4FBF0060
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h5>Resolve REST Save Card Holder
//	<h6>Resolve : REST : Save Card Holder
//	<p>
//	Saves cardholder demographic information associated with
//	a primary account number (PAN).
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/resolve/savecardholder.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67EE511601C9;database::Database { -> F}
//## Uses: <unnamed>%67EE511B037C;reusable::Statement { -> F}
//## Uses: <unnamed>%67EE512A006A;reusable::Table { -> F}
//## Uses: <unnamed>%67EE512D0358;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%67EE51360381;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67EE513B018A;monitor::UseCase { -> F}
//## Uses: <unnamed>%67F3B7B50046;IF::Extract { -> F}

class DllExport SaveCardholderCommand : public command::RESTCommand  //## Inherits: <unnamed>%67EE51210129
{
  //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.initialDeclarations preserve=yes
  //## end restcommand::SaveCardholderCommand%67EE4FBF0060.initialDeclarations

  public:
    //## Constructors (generated)
      SaveCardholderCommand();

    //## Constructors (specified)
      //## Operation: SaveCardholderCommand%67EE52C2005A
      SaveCardholderCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~SaveCardholderCommand();


    //## Other Operations (specified)
      //## Operation: endElement%67EE530C02FC
      virtual bool endElement (const string& strTag);

      //## Operation: execute%67EE53A20283
      virtual bool execute ();

      //## Operation: save%67EE53D201DC
      bool save ();

      //## Operation: update%67EE543100F7
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.public preserve=yes
      //## end restcommand::SaveCardholderCommand%67EE4FBF0060.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.protected preserve=yes
      //## end restcommand::SaveCardholderCommand%67EE4FBF0060.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.private preserve=yes
      //## end restcommand::SaveCardholderCommand%67EE4FBF0060.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Columns%67F37A3901F8
      //## begin restcommand::SaveCardholderCommand::Columns%67F37A3901F8.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hColumns;
      //## end restcommand::SaveCardholderCommand::Columns%67F37A3901F8.attr

      //## Attribute: Values%67F37A85000E
      //## begin restcommand::SaveCardholderCommand::Values%67F37A85000E.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hValues;
      //## end restcommand::SaveCardholderCommand::Values%67F37A85000E.attr

      //## Attribute: Return%67F37ABB0228
      //## begin restcommand::SaveCardholderCommand::Return%67F37ABB0228.attr preserve=no  private: int {U} 0
      int m_iReturn;
      //## end restcommand::SaveCardholderCommand::Return%67F37ABB0228.attr

    // Additional Implementation Declarations
      //## begin restcommand::SaveCardholderCommand%67EE4FBF0060.implementation preserve=yes
      //## end restcommand::SaveCardholderCommand%67EE4FBF0060.implementation

};

//## begin restcommand::SaveCardholderCommand%67EE4FBF0060.postscript preserve=yes
//## end restcommand::SaveCardholderCommand%67EE4FBF0060.postscript

} // namespace restcommand

//## begin module%67EE4E7C01C9.epilog preserve=yes
//## end module%67EE4E7C01C9.epilog


#endif
