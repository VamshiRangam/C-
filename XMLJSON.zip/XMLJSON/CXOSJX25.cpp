//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66BB26E10352.cm preserve=no
//## end module%66BB26E10352.cm

//## begin module%66BB26E10352.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66BB26E10352.cp

//## Module: CXOSJX25%66BB26E10352; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX25.cpp

//## begin module%66BB26E10352.additionalIncludes preserve=no
//## end module%66BB26E10352.additionalIncludes

//## begin module%66BB26E10352.includes preserve=yes
//## end module%66BB26E10352.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB47_h
#include "CXODDB47.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSJX25_h
#include "CXODJX25.hpp"
#endif


//## begin module%66BB26E10352.declarations preserve=no
//## end module%66BB26E10352.declarations

//## begin module%66BB26E10352.additionalDeclarations preserve=yes
//## end module%66BB26E10352.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::CaseDetailCommand 

CaseDetailCommand::CaseDetailCommand()
  //## begin CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.hasinit
  //## begin CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.initialization preserve=yes
   , RESTCommand("/rest/datanavigator/resolve/casedetail/v1.0.0", "S0003D", "@##JRCASE ")
  //## end CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.initialization
{
  //## begin restcommand::CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.body preserve=yes
   memcpy(m_sID, "JX25", 4);
  //## end restcommand::CaseDetailCommand::CaseDetailCommand%66BB27B40256_const.body
}

CaseDetailCommand::CaseDetailCommand (Handler* pSuccessor)
  //## begin restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.hasinit
  //## begin restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.initialization preserve=yes
    , RESTCommand("/rest/datanavigator/resolve/casedetail/v1.0.0", "S0003D", "@##JRCASE ")
  //## end restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.initialization
{
  //## begin restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.body preserve=yes
   memcpy(m_sID, "JX25", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('C', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::CaseDetailCommand::CaseDetailCommand%66BB2BF4036C.body
}


CaseDetailCommand::~CaseDetailCommand()
{
  //## begin restcommand::CaseDetailCommand::~CaseDetailCommand%66BB27B40256_dest.body preserve=yes
   delete m_pPersistentSegment;
  //## end restcommand::CaseDetailCommand::~CaseDetailCommand%66BB27B40256_dest.body
}



//## Other Operations (implementation)
bool CaseDetailCommand::execute ()
{
  //## begin restcommand::CaseDetailCommand::execute%66BB2C42009C.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX25 LIST CASE PHASES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRCASE", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX25", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   m_hTagName.clear();
   m_hColumnName.clear();
   m_hTagColumnValues.clear();
   m_bNationalNetwork = false;
   m_hQuery.reset();
   View hView("DNDNCREX", "CXOXCREX");
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   int lCASE_ID = atoi(m_pXMLItem->get("caseId").c_str());
   SOAPSegment::instance()->setRtnCde('0');
   m_pXMLDocument->add("details");
   map<string, vector<pair<string, string> > > hColumns = hView.getColumns();
   for (map<string, vector<pair<string, string> > >::iterator it = hColumns.begin(); it != hColumns.end(); ++it)
   {
      m_hQuery.reset();
      vector<string> hTokens;
      Buffer::parse(it->first, ":", hTokens);
      m_strHeader = hTokens[0];
      vector<pair<string,string> >::iterator p;
      for (p = it->second.begin(); p != it->second.end(); ++p)
      {
         if (std::find(m_hColumnName.begin(), m_hColumnName.end(), p->second) == m_hColumnName.end())
         {
            m_hTagName.push_back(p->first);
            m_hColumnName.push_back(p->second);
         }
      }
      if (m_strHeader == "Phase")
      {
         m_hTagName.push_back("ChargebackReasonCode");
         m_hTagName.push_back("ChargebackDate");
      }
      if (!m_pPersistentSegment)
         m_pPersistentSegment = new PersistentSegment("XXXX", hTokens[1].c_str(), "CUSTQUAL");
      else if (m_pPersistentSegment->getTableName() != hTokens[1].c_str())
      {
         delete m_pPersistentSegment;
         m_pPersistentSegment = new PersistentSegment("XXXX", hTokens[1].c_str(), "CUSTQUAL");
      }
      m_pPersistentSegment->bindPerCatalog(m_hQuery);
      m_hGenericSegment.set("Tab", m_strHeader);
      m_pXMLDocument->add("tab");
      m_hQuery.setBasicPredicate(hTokens[1].c_str(), "CASE_ID", "=", lCASE_ID);
      bool b = pSelectStatement->execute(m_hQuery);
      if (b == false )
      {
         m_pXMLDocument->revert();
         m_strReply.erase();
         m_hQuery.setAbort(true);
         SOAPSegment::instance()->setRtnCde('5');
         m_pXMLDocument->add("details");
         return reply();
      }
      else if (pSelectStatement->getRows() == 0)
      {
         m_pXMLDocument->revert();
         if (m_strHeader == "Case")
         {
            SOAPSegment::instance()->setRtnCde('2');
            m_pXMLDocument->add("details");
            UseCase::setSuccess(false);
            return reply();
         }
      }
      else
         m_pXMLDocument->write("tab");
      m_iRows = 0;
      m_hTagName.clear();
      m_hColumnName.clear();
   }
   m_pXMLDocument->write("details");
   return reply();
  //## end restcommand::CaseDetailCommand::execute%66BB2C42009C.body
}

void CaseDetailCommand::update (Subject* pSubject)
{
  //## begin restcommand::CaseDetailCommand::update%66BB2C630165.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      if (m_strHeader == "Phase")
      {
         string strFEE_REL_CASE_NO;
         m_pPersistentSegment->_field("FEE_REL_CASE_NO", strFEE_REL_CASE_NO);
         getRelatedCaseCHBInfo(strFEE_REL_CASE_NO);
      }
      populateTags();
      if (addtoXMLDocument())
         m_pXMLDocument->write("row");
      if (m_strHeader == "Phase")
         m_hColumnName.resize(m_hColumnName.size() - 2);
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::CaseDetailCommand::update%66BB2C630165.body
}

void CaseDetailCommand::populateTags ()
{
  //## begin restcommand::CaseDetailCommand::populateTags%66D185B40193.body preserve=yes
   reusable::string strTemp;
   for (int i = 0; i < m_hTagName.size() && i < m_hColumnName.size(); i++)
   {
      if (m_strHeader == "Phase" && (m_hTagName[i] == "ChargebackReasonCode" || m_hTagName[i] == "ChargebackDate"))
         strTemp = m_hColumnName[i];
      else
         m_pPersistentSegment->_field(m_hColumnName[i].c_str(), strTemp, false, false);
      if (m_strHeader == "Case")
         if (m_hColumnName[i] == "CASE_EXTENSION" && (strTemp == "MCI" || strTemp == "VNT"))
            m_bNationalNetwork = true;
      if (i == 0)
         m_hTagColumnValues.push_back(make_pair(m_hTagName[i], strTemp));
      else
      {
         if (m_hTagName[i] != m_hTagName[i - 1])
            m_hTagColumnValues.push_back(make_pair(m_hTagName[i], strTemp));
         else
            m_hTagColumnValues.back().second = m_hTagColumnValues.back().second + " " + strTemp;
      }
   }
  //## end restcommand::CaseDetailCommand::populateTags%66D185B40193.body
}

bool CaseDetailCommand::addtoXMLDocument ()
{
  //## begin restcommand::CaseDetailCommand::addtoXMLDocument%66D1A279003B.body preserve=yes
   bool bSuccess = false;
   m_pXMLDocument->add("row");
   for (int i = 0; i < m_hTagColumnValues.size(); i++)
   {
      if (m_iRows == 1)
      {
         m_hGenericSegment.set("Name", m_hTagColumnValues[i].first);
         if (!(bSuccess = m_pXMLDocument->add("column")))
            break;
      }
      m_hGenericSegment.set("Value", m_hTagColumnValues[i].second);
      if (!(bSuccess = m_pXMLDocument->add("value")))
         break;
   }
   if (!bSuccess)
   {
      m_pXMLDocument->revert();
      m_hQuery.setAbort(true);
   }
   m_hTagColumnValues.clear();
   return bSuccess;
  //## end restcommand::CaseDetailCommand::addtoXMLDocument%66D1A279003B.body
}

void CaseDetailCommand::getRelatedCaseCHBInfo (const string& strFEE_REL_CASE_NO)
{
  //## begin restcommand::CaseDetailCommand::getRelatedCaseCHBInfo%66DB028801E6.body preserve=yes
   string strREASON_CODE;
   string strTSTAMP_CREATED;
   if (!strFEE_REL_CASE_NO.empty() && m_bNationalNetwork)
   {
      Query hQuery;
      hQuery.reset();
      hQuery.join("EMS_CASE", "INNER", "EMS_PHASE", "CASE_ID");
      hQuery.join("EMS_PHASE", "INNER", "EMS_TRANSITION", "CASE_ID");
      hQuery.join("EMS_PHASE", "INNER", "EMS_TRANSITION", "TSTAMP_CREATED", "PHASE_TSTAMP");
      hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", "=", strFEE_REL_CASE_NO.c_str());
      hQuery.setBasicPredicate("EMS_TRANSITION", "REQUEST_TYPE_NEXT", "=", "CHB1");
      hQuery.setBasicPredicate("EMS_TRANSITION", "STATUS_NEXT", "=", "FWRD");
      hQuery.setOrderByClause("EMS_TRANSITION.TSTAMP_CREATED ASC");
      hQuery.bind("EMS_PHASE", "REASON_CODE", reusable::Column::STRING, &strREASON_CODE);
      hQuery.bind("EMS_TRANSITION", "TSTAMP_CREATED", reusable::Column::STRING, &strTSTAMP_CREATED);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(hQuery);
      if (pSelectStatement->getRows() > 0)
      {
         strTSTAMP_CREATED.erase(0, 2);
         strTSTAMP_CREATED.erase(6);
      }
   }
   m_hColumnName.push_back(strREASON_CODE);
   m_hColumnName.push_back(strTSTAMP_CREATED);
  //## end restcommand::CaseDetailCommand::getRelatedCaseCHBInfo%66DB028801E6.body
}

// Additional Declarations
  //## begin restcommand::CaseDetailCommand%66BB27B40256.declarations preserve=yes
  //## end restcommand::CaseDetailCommand%66BB27B40256.declarations

} // namespace restcommand

//## begin module%66BB26E10352.epilog preserve=yes
//## end module%66BB26E10352.epilog
