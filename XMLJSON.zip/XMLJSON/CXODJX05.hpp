//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6509EA9E035E.cm preserve=no
//## end module%6509EA9E035E.cm

//## begin module%6509EA9E035E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6509EA9E035E.cp

//## Module: CXOSJX05%6509EA9E035E; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX05.hpp

#ifndef CXOSJX05_h
#define CXOSJX05_h 1

//## begin module%6509EA9E035E.additionalIncludes preserve=no
//## end module%6509EA9E035E.additionalIncludes

//## begin module%6509EA9E035E.includes preserve=yes
//## end module%6509EA9E035E.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
class CaseManifest;
} // namespace restcommand

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%6509EA9E035E.declarations preserve=no
//## end module%6509EA9E035E.declarations

//## begin module%6509EA9E035E.additionalDeclarations preserve=yes
//## end module%6509EA9E035E.additionalDeclarations


namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::CaseCommand%6509EA120212.preface preserve=yes
//## end restcommand::CaseCommand%6509EA120212.preface

//## Class: CaseCommand%6509EA120212
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6509F87702CA;monitor::UseCase { -> F}
//## Uses: <unnamed>%6509FEC1031C;segment::SOAPSegment { -> F}

class DllExport CaseCommand : public command::RESTCommand  //## Inherits: <unnamed>%6509EA4C0318
{
  //## begin restcommand::CaseCommand%6509EA120212.initialDeclarations preserve=yes
  //## end restcommand::CaseCommand%6509EA120212.initialDeclarations

  public:
    //## Constructors (generated)
      CaseCommand();

    //## Constructors (specified)
      //## Operation: CaseCommand%6509EC6703D8
      CaseCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseCommand();


    //## Other Operations (specified)
      //## Operation: endElement%6509EC8902C7
      virtual bool endElement (const string& strTag);

      //## Operation: execute%6509EA7E01F8
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin restcommand::CaseCommand%6509EA120212.public preserve=yes
      //## end restcommand::CaseCommand%6509EA120212.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::CaseCommand%6509EA120212.protected preserve=yes
      //## end restcommand::CaseCommand%6509EA120212.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::CaseCommand%6509EA120212.private preserve=yes
      //## end restcommand::CaseCommand%6509EA120212.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%650AEA350390
      //## Role: CaseCommand::<m_pCaseManifest>%650AEA3700B8
      //## begin restcommand::CaseCommand::<m_pCaseManifest>%650AEA3700B8.role preserve=no  public: restcommand::CaseManifest { -> RFHgN}
      CaseManifest *m_pCaseManifest;
      //## end restcommand::CaseCommand::<m_pCaseManifest>%650AEA3700B8.role

    // Additional Implementation Declarations
      //## begin restcommand::CaseCommand%6509EA120212.implementation preserve=yes
      //## end restcommand::CaseCommand%6509EA120212.implementation

};

//## begin restcommand::CaseCommand%6509EA120212.postscript preserve=yes
//## end restcommand::CaseCommand%6509EA120212.postscript

} // namespace restcommand

//## begin module%6509EA9E035E.epilog preserve=yes
//## end module%6509EA9E035E.epilog


#endif
