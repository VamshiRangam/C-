//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%645AEDA301C5.cm preserve=no
//## end module%645AEDA301C5.cm

//## begin module%645AEDA301C5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%645AEDA301C5.cp

//## Module: CXOSJX01%645AEDA301C5; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX01.cpp

//## begin module%645AEDA301C5.additionalIncludes preserve=no
//## end module%645AEDA301C5.additionalIncludes

//## begin module%645AEDA301C5.includes preserve=yes
//## end module%645AEDA301C5.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX01_h
#include "CXODJX01.hpp"
#endif


//## begin module%645AEDA301C5.declarations preserve=no
//## end module%645AEDA301C5.declarations

//## begin module%645AEDA301C5.additionalDeclarations preserve=yes
//## end module%645AEDA301C5.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ServersCommand 

ServersCommand::ServersCommand()
  //## begin ServersCommand::ServersCommand%645AECCA0008_const.hasinit preserve=no
  //## end ServersCommand::ServersCommand%645AECCA0008_const.hasinit
  //## begin ServersCommand::ServersCommand%645AECCA0008_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/operate/servers/v1.0.0","S0003D","@##JLSVRS ")
  //## end ServersCommand::ServersCommand%645AECCA0008_const.initialization
{
  //## begin restcommand::ServersCommand::ServersCommand%645AECCA0008_const.body preserve=yes
   memcpy(m_sID,"JX01",4);
  //## end restcommand::ServersCommand::ServersCommand%645AECCA0008_const.body
}

ServersCommand::ServersCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ServersCommand::ServersCommand%645AED2D03D3.hasinit preserve=no
  //## end restcommand::ServersCommand::ServersCommand%645AED2D03D3.hasinit
  //## begin restcommand::ServersCommand::ServersCommand%645AED2D03D3.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/operate/servers/v1.0.0","S0003D","@##JLSVRS ")
  //## end restcommand::ServersCommand::ServersCommand%645AED2D03D3.initialization
{
  //## begin restcommand::ServersCommand::ServersCommand%645AED2D03D3.body preserve=yes
   memcpy(m_sID,"JX01",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::ServersCommand::ServersCommand%645AED2D03D3.body
}


ServersCommand::~ServersCommand()
{
  //## begin restcommand::ServersCommand::~ServersCommand%645AECCA0008_dest.body preserve=yes
  //## end restcommand::ServersCommand::~ServersCommand%645AECCA0008_dest.body
}



//## Other Operations (implementation)
bool ServersCommand::execute ()
{
  //## begin restcommand::ServersCommand::execute%645AED7B0016.body preserve=yes
   UseCase hUseCase("CLIENT","## JX01 LIST SERVERS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLSVRS",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX01",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
   m_hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   m_hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
   m_hQuery.bind("TASK_CONTEXT_COMN","IMAGE_ID",Column::STRING,&m_strIMAGE_ID);
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_TYPE","=","S");
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","=","FM");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   SOAPSegment::instance()->setRtnCde(b ? '0' :'5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ServersCommand::execute%645AED7B0016.body
}

void ServersCommand::update (Subject* pSubject)
{
  //## begin restcommand::ServersCommand::update%645E29D90090.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.set("Name",m_strCONTEXT_KEY);
      m_hGenericSegment.set("State",m_strCONTEXT_DATA);
      m_hGenericSegment.set("Image",m_strIMAGE_ID);
      m_pXMLDocument->add("row");
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ServersCommand::update%645E29D90090.body
}

// Additional Declarations
  //## begin restcommand::ServersCommand%645AECCA0008.declarations preserve=yes
  //## end restcommand::ServersCommand%645AECCA0008.declarations

} // namespace restcommand

//## begin module%645AEDA301C5.epilog preserve=yes
//## end module%645AEDA301C5.epilog
