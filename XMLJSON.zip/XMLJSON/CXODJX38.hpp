//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A2173F01BE.cm preserve=no
//## end module%67A2173F01BE.cm

//## begin module%67A2173F01BE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67A2173F01BE.cp

//## Module: CXOSJX38%67A2173F01BE; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX38.hpp

#ifndef CXOSJX38_h
#define CXOSJX38_h 1

//## begin module%67A2173F01BE.additionalIncludes preserve=no
//## end module%67A2173F01BE.additionalIncludes

//## begin module%67A2173F01BE.includes preserve=yes
//## end module%67A2173F01BE.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%67A2173F01BE.declarations preserve=no
//## end module%67A2173F01BE.declarations

//## begin module%67A2173F01BE.additionalDeclarations preserve=yes
//## end module%67A2173F01BE.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReportFileCommand%67A2163A01CA.preface preserve=yes
//## end restcommand::ReportFileCommand%67A2163A01CA.preface

//## Class: ReportFileCommand%67A2163A01CA
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%67A21662021D;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%67A21665019D;monitor::UseCase { -> F}
//## Uses: <unnamed>%67A216680254;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%67A2166C0074;database::DatabaseFactory { -> F}

class DllExport ReportFileCommand : public command::RESTCommand  //## Inherits: <unnamed>%67A216600037
{
  //## begin restcommand::ReportFileCommand%67A2163A01CA.initialDeclarations preserve=yes
  //## end restcommand::ReportFileCommand%67A2163A01CA.initialDeclarations

  public:
    //## Constructors (generated)
      ReportFileCommand();

    //## Constructors (specified)
      //## Operation: ReportFileCommand%67A216C300DD
      ReportFileCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReportFileCommand();


    //## Other Operations (specified)
      //## Operation: execute%67A216CE009D
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%67A216D002AA
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ReportFileCommand%67A2163A01CA.public preserve=yes
      //## end restcommand::ReportFileCommand%67A2163A01CA.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReportFileCommand%67A2163A01CA.protected preserve=yes
      //## end restcommand::ReportFileCommand%67A2163A01CA.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReportFileCommand%67A2163A01CA.private preserve=yes
      //## end restcommand::ReportFileCommand%67A2163A01CA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATA_BUFFER%67A217020115
      //## begin restcommand::ReportFileCommand::DATA_BUFFER%67A217020115.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDATA_BUFFER;
      //## end restcommand::ReportFileCommand::DATA_BUFFER%67A217020115.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A21673013D
      //## Role: ReportFileCommand::<m_hGenericSegment>%67A216740156
      //## begin restcommand::ReportFileCommand::<m_hGenericSegment>%67A216740156.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReportFileCommand::<m_hGenericSegment>%67A216740156.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67A2167B02C8
      //## Role: ReportFileCommand::<m_hQuery>%67A2167C02CF
      //## begin restcommand::ReportFileCommand::<m_hQuery>%67A2167C02CF.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::ReportFileCommand::<m_hQuery>%67A2167C02CF.role

    // Additional Implementation Declarations
      //## begin restcommand::ReportFileCommand%67A2163A01CA.implementation preserve=yes
      //## end restcommand::ReportFileCommand%67A2163A01CA.implementation

};

//## begin restcommand::ReportFileCommand%67A2163A01CA.postscript preserve=yes
//## end restcommand::ReportFileCommand%67A2163A01CA.postscript

} // namespace restcommand

//## begin module%67A2173F01BE.epilog preserve=yes
//## end module%67A2173F01BE.epilog


#endif
