//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6525EABE0340.cm preserve=no
//## end module%6525EABE0340.cm

//## begin module%6525EABE0340.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6525EABE0340.cp

//## Module: CXOSJX09%6525EABE0340; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX09.hpp

#ifndef CXOSJX09_h
#define CXOSJX09_h 1

//## begin module%6525EABE0340.additionalIncludes preserve=no
//## end module%6525EABE0340.additionalIncludes

//## begin module%6525EABE0340.includes preserve=yes
//## end module%6525EABE0340.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
class CaseManifest;
} // namespace restcommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
class ImportReportAuditSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class ImportData;

} // namespace command

//## begin module%6525EABE0340.declarations preserve=no
//## end module%6525EABE0340.declarations

//## begin module%6525EABE0340.additionalDeclarations preserve=yes
//## end module%6525EABE0340.additionalDeclarations


namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ClaimCommand%6525C089037C.preface preserve=yes
//## end restcommand::ClaimCommand%6525C089037C.preface

//## Class: ClaimCommand%6525C089037C
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6564B2200369;monitor::UseCase { -> F}
//## Uses: <unnamed>%6564B22400F1;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%6564B398003D;command::ImportData { -> F}
//## Uses: <unnamed>%6564B431017E;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%6564B8550264;reusable::Query { -> F}
//## Uses: <unnamed>%6564B8590303;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6564B85E00AD;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6564B862032D;reusable::Statement { -> F}
//## Uses: <unnamed>%659E7C8002DD;database::Database { -> F}

class DllExport ClaimCommand : public command::RESTCommand  //## Inherits: <unnamed>%6525C0A301B1
{
  //## begin restcommand::ClaimCommand%6525C089037C.initialDeclarations preserve=yes
  //## end restcommand::ClaimCommand%6525C089037C.initialDeclarations

  public:
    //## Constructors (generated)
      ClaimCommand();

    //## Constructors (specified)
      //## Operation: ClaimCommand%6525C2FA02C1
      ClaimCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ClaimCommand();


    //## Other Operations (specified)
      //## Operation: endElement%6525C2E601C4
      virtual bool endElement (const string& strTag);

      //## Operation: execute%6525C2E10061
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%6525C2E801D8
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::ClaimCommand%6525C089037C.public preserve=yes
      //## end restcommand::ClaimCommand%6525C089037C.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ClaimCommand%6525C089037C.protected preserve=yes
      //## end restcommand::ClaimCommand%6525C089037C.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ClaimCommand%6525C089037C.private preserve=yes
      //## end restcommand::ClaimCommand%6525C089037C.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6564B1F803AF
      //## Role: ClaimCommand::<m_pCaseManifest>%6564B1F902B9
      //## begin restcommand::ClaimCommand::<m_pCaseManifest>%6564B1F902B9.role preserve=no  public: restcommand::CaseManifest { -> RFHgN}
      CaseManifest *m_pCaseManifest;
      //## end restcommand::ClaimCommand::<m_pCaseManifest>%6564B1F902B9.role

    // Additional Implementation Declarations
      //## begin restcommand::ClaimCommand%6525C089037C.implementation preserve=yes
      //## end restcommand::ClaimCommand%6525C089037C.implementation

};

//## begin restcommand::ClaimCommand%6525C089037C.postscript preserve=yes
//## end restcommand::ClaimCommand%6525C089037C.postscript

} // namespace restcommand

//## begin module%6525EABE0340.epilog preserve=yes
//## end module%6525EABE0340.epilog


#endif
