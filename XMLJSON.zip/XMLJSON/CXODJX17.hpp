//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D428140396.cm preserve=no
//## end module%65D428140396.cm

//## begin module%65D428140396.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D428140396.cp

//## Module: CXOSJX17%65D428140396; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX17.hpp

#ifndef CXOSJX17_h
#define CXOSJX17_h 1

//## begin module%65D428140396.additionalIncludes preserve=no
//## end module%65D428140396.additionalIncludes

//## begin module%65D428140396.includes preserve=yes
//## end module%65D428140396.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
class Email;
} // namespace restcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%65D428140396.declarations preserve=no
//## end module%65D428140396.declarations

//## begin module%65D428140396.additionalDeclarations preserve=yes
//## end module%65D428140396.additionalDeclarations


namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::ReconFileCommand%65D417D5034C.preface preserve=yes
//## end restcommand::ReconFileCommand%65D417D5034C.preface

//## Class: ReconFileCommand%65D417D5034C
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h5>Reconcile REST Recon File
//	<h6>Reconcile : REST : Recon File
//	<p>
//	Returns one file for a transaction reconciliation.
//	<p>
//	<ul>
//	<li><a
//	href="../../REST/reconcile/reconfile.yaml">YAML</a>
//	</ul>
//	</body>
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65D41D890146;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%65D41D8B01F6;monitor::UseCase { -> F}
//## Uses: <unnamed>%65D41D9900FE;IF::Extract { -> F}

class DllExport ReconFileCommand : public command::RESTCommand  //## Inherits: <unnamed>%65D41D820325
{
  //## begin restcommand::ReconFileCommand%65D417D5034C.initialDeclarations preserve=yes
  //## end restcommand::ReconFileCommand%65D417D5034C.initialDeclarations

  public:
    //## Constructors (generated)
      ReconFileCommand();

    //## Constructors (specified)
      //## Operation: ReconFileCommand%65D41FF3009B
      ReconFileCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ReconFileCommand();


    //## Other Operations (specified)
      //## Operation: execute%65D420010176
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin restcommand::ReconFileCommand%65D417D5034C.public preserve=yes
      //## end restcommand::ReconFileCommand%65D417D5034C.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::ReconFileCommand%65D417D5034C.protected preserve=yes
      //## end restcommand::ReconFileCommand%65D417D5034C.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::ReconFileCommand%65D417D5034C.private preserve=yes
      //## end restcommand::ReconFileCommand%65D417D5034C.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%65D41D9E0259
      //## Role: ReconFileCommand::<m_hGenericSegment>%65D41D9F02CF
      //## begin restcommand::ReconFileCommand::<m_hGenericSegment>%65D41D9F02CF.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::ReconFileCommand::<m_hGenericSegment>%65D41D9F02CF.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%67E54873027C
      //## Role: ReconFileCommand::<m_pEmail>%67E5487501BF
      //## begin restcommand::ReconFileCommand::<m_pEmail>%67E5487501BF.role preserve=no  public: restcommand::Email { -> RFHgN}
      Email *m_pEmail;
      //## end restcommand::ReconFileCommand::<m_pEmail>%67E5487501BF.role

    // Additional Implementation Declarations
      //## begin restcommand::ReconFileCommand%65D417D5034C.implementation preserve=yes
      //## end restcommand::ReconFileCommand%65D417D5034C.implementation

};

//## begin restcommand::ReconFileCommand%65D417D5034C.postscript preserve=yes
//## end restcommand::ReconFileCommand%65D417D5034C.postscript

} // namespace restcommand

//## begin module%65D428140396.epilog preserve=yes
//## end module%65D428140396.epilog


#endif
