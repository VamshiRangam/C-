//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67123BCA01C4.cm preserve=no
//## end module%67123BCA01C4.cm

//## begin module%67123BCA01C4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%67123BCA01C4.cp

//## Module: CXOSJX27%67123BCA01C4; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX27.cpp

//## begin module%67123BCA01C4.additionalIncludes preserve=no
//## end module%67123BCA01C4.additionalIncludes

//## begin module%67123BCA01C4.includes preserve=yes
//## end module%67123BCA01C4.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSRS51_h
#include "CXODRS51.hpp"
#endif
#ifndef CXOSJX27_h
#include "CXODJX27.hpp"
#endif


//## begin module%67123BCA01C4.declarations preserve=no
//## end module%67123BCA01C4.declarations

//## begin module%67123BCA01C4.additionalDeclarations preserve=yes
//## end module%67123BCA01C4.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::CardholderCommand 

CardholderCommand::CardholderCommand()
  //## begin CardholderCommand::CardholderCommand%67123C76036A_const.hasinit preserve=no
  //## end CardholderCommand::CardholderCommand%67123C76036A_const.hasinit
  //## begin CardholderCommand::CardholderCommand%67123C76036A_const.initialization preserve=yes
   :RESTCommand("/rest/datanavigator/resolve/cardholder/v1.0.0","S0003D","@##JLCHDR ")
  //## end CardholderCommand::CardholderCommand%67123C76036A_const.initialization
{
  //## begin restcommand::CardholderCommand::CardholderCommand%67123C76036A_const.body preserve=yes
   memcpy(m_sID, "JX27", 4);
  //## end restcommand::CardholderCommand::CardholderCommand%67123C76036A_const.body
}

CardholderCommand::CardholderCommand (Handler* pSuccessor)
  //## begin restcommand::CardholderCommand::CardholderCommand%67123E6B015F.hasinit preserve=no
  //## end restcommand::CardholderCommand::CardholderCommand%67123E6B015F.hasinit
  //## begin restcommand::CardholderCommand::CardholderCommand%67123E6B015F.initialization preserve=yes
   :RESTCommand("/rest/datanavigator/resolve/cardholder/v1.0.0","S0003D","@##JLCHDR ")
  //## end restcommand::CardholderCommand::CardholderCommand%67123E6B015F.initialization
{
  //## begin restcommand::CardholderCommand::CardholderCommand%67123E6B015F.body preserve=yes
   memcpy(m_sID, "JX27", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
   m_hQuery.attach(this);
  //## end restcommand::CardholderCommand::CardholderCommand%67123E6B015F.body
}


CardholderCommand::~CardholderCommand()
{
  //## begin restcommand::CardholderCommand::~CardholderCommand%67123C76036A_dest.body preserve=yes
  //## end restcommand::CardholderCommand::~CardholderCommand%67123C76036A_dest.body
}



//## Other Operations (implementation)
bool CardholderCommand::execute ()
{
  //## begin restcommand::CardholderCommand::execute%67123E9B02B4.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX27 READ CARDHOLDER INFO");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLCHDR", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX27", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   CardholderInformationSegment::instance()->bind(m_hQuery);
   m_hQuery.setBasicPredicate("CARDHOLDER", "PAN", "=", m_pXMLItem->get("accountNumber").c_str());
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
   {
      m_pXMLDocument->revert();
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::CardholderCommand::execute%67123E9B02B4.body
}

void CardholderCommand::update (Subject* pSubject)
{
  //## begin restcommand::CardholderCommand::update%67123EBC0251.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.set("PAN", CardholderInformationSegment::instance()->getPAN().data());
      m_hGenericSegment.set("CARD_ISS_INST_ID", CardholderInformationSegment::instance()->getCARD_ISS_INST_ID().data());
      m_hGenericSegment.set("CUST_ID", CardholderInformationSegment::instance()->getCUST_ID().data());
      m_hGenericSegment.set("FIRST_NAME_1", CardholderInformationSegment::instance()->getFIRST_NAME_1().data());
      m_hGenericSegment.set("LAST_NAME_1", CardholderInformationSegment::instance()->getLAST_NAME_1().data());
      m_hGenericSegment.set("TITLE_1", CardholderInformationSegment::instance()->getTITLE_1().data());
      m_hGenericSegment.set("SSN_1", CardholderInformationSegment::instance()->getSSN_1().data());
      m_hGenericSegment.set("FIRST_NAME_2", CardholderInformationSegment::instance()->getFIRST_NAME_2().data());
      m_hGenericSegment.set("LAST_NAME_2", CardholderInformationSegment::instance()->getLAST_NAME_2().data());
      m_hGenericSegment.set("TITLE_2", CardholderInformationSegment::instance()->getTITLE_2().data());
      m_hGenericSegment.set("SSN_2", CardholderInformationSegment::instance()->getSSN_2().data());
      m_hGenericSegment.set("ADDRESS_LINE_1", CardholderInformationSegment::instance()->getADDRESS_LINE_1().data());
      m_hGenericSegment.set("ADDRESS_LINE_2", CardholderInformationSegment::instance()->getADDRESS_LINE_2().data());
      m_hGenericSegment.set("ADDRESS_LINE_3", CardholderInformationSegment::instance()->getADDRESS_LINE_3().data());
      m_hGenericSegment.set("CITY", CardholderInformationSegment::instance()->getCITY().data());
      m_hGenericSegment.set("REGION", CardholderInformationSegment::instance()->getREGION().data());
      m_hGenericSegment.set("COUNTRY_CODE", CardholderInformationSegment::instance()->getCOUNTRY_CODE().data());
      m_hGenericSegment.set("POSTAL_CODE", CardholderInformationSegment::instance()->getPOSTAL_CODE().data());
      m_hGenericSegment.set("WORK_PHONE_NO", CardholderInformationSegment::instance()->getWORK_PHONE_NO().data());
      m_hGenericSegment.set("HOME_PHONE_NO", CardholderInformationSegment::instance()->getHOME_PHONE_NO().data());
      m_hGenericSegment.set("FAX_NO", CardholderInformationSegment::instance()->getFAX_NO().data());
      m_hGenericSegment.set("EMAIL_ADDRESS", CardholderInformationSegment::instance()->getEMAIL_ADDRESS().data());
      m_hGenericSegment.set("CONTACT_METHOD", CardholderInformationSegment::instance()->getCONTACT_METHOD().data());
      m_hGenericSegment.set("TSTAMP_LAST_UPDATE", CardholderInformationSegment::instance()->getTSTAMP_LAST_UPDATE().data());
      m_hGenericSegment.set("UPDATED_BY_USER_ID",CardholderInformationSegment::instance()->getUPDATED_BY_USER_ID().data());
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::CardholderCommand::update%67123EBC0251.body
}

// Additional Declarations
  //## begin restcommand::CardholderCommand%67123C76036A.declarations preserve=yes
  //## end restcommand::CardholderCommand%67123C76036A.declarations

} // namespace restcommand

//## begin module%67123BCA01C4.epilog preserve=yes
//## end module%67123BCA01C4.epilog
