//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D4272903CF.cm preserve=no
//## end module%65D4272903CF.cm

//## begin module%65D4272903CF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D4272903CF.cp

//## Module: CXOSJX15%65D4272903CF; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX15.cpp

//## begin module%65D4272903CF.additionalIncludes preserve=no
//## end module%65D4272903CF.additionalIncludes

//## begin module%65D4272903CF.includes preserve=yes
//## end module%65D4272903CF.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSJX15_h
#include "CXODJX15.hpp"
#endif


//## begin module%65D4272903CF.declarations preserve=no
//## end module%65D4272903CF.declarations

//## begin module%65D4272903CF.additionalDeclarations preserve=yes
//## end module%65D4272903CF.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReconsCommand 

ReconsCommand::ReconsCommand()
  //## begin ReconsCommand::ReconsCommand%65D417BA011F_const.hasinit preserve=no
  //## end ReconsCommand::ReconsCommand%65D417BA011F_const.hasinit
  //## begin ReconsCommand::ReconsCommand%65D417BA011F_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/reconcile/recons/v1.0.0","S0003D","@##JLRECN ")
  //## end ReconsCommand::ReconsCommand%65D417BA011F_const.initialization
{
  //## begin restcommand::ReconsCommand::ReconsCommand%65D417BA011F_const.body preserve=yes
   memcpy(m_sID,"JX15",4);
  //## end restcommand::ReconsCommand::ReconsCommand%65D417BA011F_const.body
}

ReconsCommand::ReconsCommand (Handler* pSuccessor)
  //## begin restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.hasinit preserve=no
  //## end restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.hasinit
  //## begin restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/reconcile/recons/v1.0.0","S0003D","@##JLRECN ")
  //## end restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.initialization
{
  //## begin restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.body preserve=yes
   memcpy(m_sID,"JX15",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReconsCommand::ReconsCommand%65D41F0403C0.body
}


ReconsCommand::~ReconsCommand()
{
  //## begin restcommand::ReconsCommand::~ReconsCommand%65D417BA011F_dest.body preserve=yes
  //## end restcommand::ReconsCommand::~ReconsCommand%65D417BA011F_dest.body
}



//## Other Operations (implementation)
bool ReconsCommand::execute ()
{
  //## begin restcommand::ReconsCommand::execute%65D41F1F015B.body preserve=yes
   UseCase hUseCase("CLIENT","## JX15 LIST RECONS");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJLRECN",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX15",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_hFileType.clear();
   m_strDESCRPT.erase();
   m_strTABDAT.erase();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   string strCustomerAbbr;
   Extract::instance()->getSpec("CUSTABBR",strCustomerAbbr);
   m_hQuery.setIndex(1);
   m_hQuery.setDistinct(true);
   m_hQuery.setQualifier("QUALIFY","CRTBDET");
   m_hQuery.bind("CRTBDET","TABDAT",Column::STRING,&m_strTABDAT);
   m_hQuery.setBasicPredicate("CRTBDET","TABDAT","LIKE","RECON_RF%");
   m_hQuery.setOrderByClause("TABDAT ASC");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   else
   {
      m_hQuery.setIndex(2);
      vector<pair<string,string> >::iterator p;
      for (p = m_hFileType.begin(); p != m_hFileType.end(); p++)
      {
         m_hGenericSegment.reset();
         m_hGenericSegment.set("File",p->first);
         m_hGenericSegment.set("Type",p->second);
         string strClassName;
         ConfigurationRepository::instance()->translate("AU_CLASS_NAME",p->second.c_str(),strClassName,"","",-1,false);
         m_hGenericSegment.set("Class",strClassName);
         m_hQuery.reset();
         m_hQuery.setQualifier("QUALIFY","CRFILET");
         m_hQuery.bind("CRFILET","DESCRPT",Column::STRING,&m_strDESCRPT);
         m_hQuery.setBasicPredicate("CRFILET","TASKID","LIKE",(strCustomerAbbr + "AU%").c_str());
         m_hQuery.setBasicPredicate("CRFILET","GENNAM","=",p->first.c_str());
         bool b = pSelectStatement->execute(m_hQuery);
         if (b == false)
         {
            SOAPSegment::instance()->setRtnCde('5');
            m_pXMLDocument->add("details");
            return reply();
         }
         m_pXMLDocument->add("row");
      }
   }
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReconsCommand::execute%65D41F1F015B.body
}

void ReconsCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReconsCommand::update%65D41F210394.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      if (m_hQuery.getIndex() == 1)
      {
         if (!m_strTABDAT.empty())
         {
            vector<string> hTokens;
            if (Buffer::parse(m_strTABDAT,"  ,",hTokens) >= 2)
               if (std::find(m_hFileType.begin(),m_hFileType.end(),make_pair(hTokens[1],hTokens[2])) == m_hFileType.end())
                  m_hFileType.push_back(make_pair(hTokens[1],hTokens[2]));
            m_strTABDAT.erase();
         }
      }
      else
      {
         m_hGenericSegment.set("Description",m_strDESCRPT);
         m_strDESCRPT.erase();
      }
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ReconsCommand::update%65D41F210394.body
}

// Additional Declarations
  //## begin restcommand::ReconsCommand%65D417BA011F.declarations preserve=yes
  //## end restcommand::ReconsCommand%65D417BA011F.declarations

} // namespace restcommand

//## begin module%65D4272903CF.epilog preserve=yes
//## end module%65D4272903CF.epilog
