//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%652703F20072.cm preserve=no
//## end module%652703F20072.cm

//## begin module%652703F20072.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%652703F20072.cp

//## Module: CXOSJX12%652703F20072; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXODJX12.hpp

#ifndef CXOSJX12_h
#define CXOSJX12_h 1

//## begin module%652703F20072.additionalIncludes preserve=no
//## end module%652703F20072.additionalIncludes

//## begin module%652703F20072.includes preserve=yes
#include "CXODRU11.hpp"
//## end module%652703F20072.includes

#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class AuthenticateUserCommand;
} // namespace soapcommand

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;

} // namespace segment

//## begin module%652703F20072.declarations preserve=no
//## end module%652703F20072.declarations

//## begin module%652703F20072.additionalDeclarations preserve=yes
//## end module%652703F20072.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::AuthenticateCommand%6526F148004C.preface preserve=yes
//## end restcommand::AuthenticateCommand%6526F148004C.preface

//## Class: AuthenticateCommand%6526F148004C
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6527E0B50159;soapcommand::AuthenticateUserCommand { -> F}
//## Uses: <unnamed>%6527E18D03AF;monitor::UseCase { -> F}
//## Uses: <unnamed>%6527E28D02BD;segment::SOAPSegment { -> F}

class DllExport AuthenticateCommand : public command::RESTCommand  //## Inherits: <unnamed>%6526F16D03AC
{
  //## begin restcommand::AuthenticateCommand%6526F148004C.initialDeclarations preserve=yes
  //## end restcommand::AuthenticateCommand%6526F148004C.initialDeclarations

  public:
    //## Constructors (generated)
      AuthenticateCommand();

    //## Constructors (specified)
      //## Operation: AuthenticateCommand%6526F1EC006C
      AuthenticateCommand (reusable::Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~AuthenticateCommand();


    //## Other Operations (specified)
      //## Operation: execute%6526F1D100E7
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin restcommand::AuthenticateCommand%6526F148004C.public preserve=yes
      virtual void update (Subject* pSubject);
      //## end restcommand::AuthenticateCommand%6526F148004C.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::AuthenticateCommand%6526F148004C.protected preserve=yes
      //## end restcommand::AuthenticateCommand%6526F148004C.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::AuthenticateCommand%6526F148004C.private preserve=yes
      //## end restcommand::AuthenticateCommand%6526F148004C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin restcommand::AuthenticateCommand%6526F148004C.implementation preserve=yes
      GenericSegment m_hGenericSegment;
      Query m_hQuery;
      string m_strCUST_ID;
      //## end restcommand::AuthenticateCommand%6526F148004C.implementation

};

//## begin restcommand::AuthenticateCommand%6526F148004C.postscript preserve=yes
//## end restcommand::AuthenticateCommand%6526F148004C.postscript

} // namespace restcommand

//## begin module%652703F20072.epilog preserve=yes
//## end module%652703F20072.epilog


#endif
