//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66574F220055.cm preserve=no
//## end module%66574F220055.cm

//## begin module%66574F220055.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66574F220055.cp

//## Module: CXOSJX19%66574F220055; Package specification
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXODJX19.hpp

#ifndef CXOSJX19_h
#define CXOSJX19_h 1

//## begin module%66574F220055.additionalIncludes preserve=no
//## end module%66574F220055.additionalIncludes

//## begin module%66574F220055.includes preserve=yes
//## end module%66574F220055.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%66574F220055.declarations preserve=no
//## end module%66574F220055.declarations

//## begin module%66574F220055.additionalDeclarations preserve=yes
//## end module%66574F220055.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

//## begin restcommand::EntitiesCommand%66575071026E.preface preserve=yes
//## end restcommand::EntitiesCommand%66575071026E.preface

//## Class: EntitiesCommand%66575071026E
//## Category: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
//## Subsystem: JXDLL%645AEC9A0298
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%665754960158;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%665754B3000A;monitor::UseCase { -> F}
//## Uses: <unnamed>%665754F60150;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6657554002BA;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66575575008E;IF::Extract { -> F}
//## Uses: <unnamed>%66575B310067;segment::CommonHeaderSegment { -> F}

class DllExport EntitiesCommand : public command::RESTCommand  //## Inherits: <unnamed>%665754D10374
{
  //## begin restcommand::EntitiesCommand%66575071026E.initialDeclarations preserve=yes
  //## end restcommand::EntitiesCommand%66575071026E.initialDeclarations

  public:
    //## Constructors (generated)
      EntitiesCommand();

    //## Constructors (specified)
      //## Operation: EntitiesCommand%665756BC02B2
      EntitiesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~EntitiesCommand();


    //## Other Operations (specified)
      //## Operation: execute%66575708028C
      virtual bool execute ();

      //## Operation: update%6657572E016A
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin restcommand::EntitiesCommand%66575071026E.public preserve=yes
      //## end restcommand::EntitiesCommand%66575071026E.public

  protected:
    // Additional Protected Declarations
      //## begin restcommand::EntitiesCommand%66575071026E.protected preserve=yes
      //## end restcommand::EntitiesCommand%66575071026E.protected

  private:
    // Additional Private Declarations
      //## begin restcommand::EntitiesCommand%66575071026E.private preserve=yes
      //## end restcommand::EntitiesCommand%66575071026E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: RELATIONSHIP_ID%665757F10252
      //## begin restcommand::EntitiesCommand::RELATIONSHIP_ID%665757F10252.attr preserve=no  private: string {U} 
      string m_strRELATIONSHIP_ID;
      //## end restcommand::EntitiesCommand::RELATIONSHIP_ID%665757F10252.attr

      //## Attribute: STS_TRAN_COL_NAME%6657581F0282
      //## begin restcommand::EntitiesCommand::STS_TRAN_COL_NAME%6657581F0282.attr preserve=no  private: string {U} 
      string m_strSTS_TRAN_COL_NAME;
      //## end restcommand::EntitiesCommand::STS_TRAN_COL_NAME%6657581F0282.attr

      //## Attribute: ONLINE_ENTITY_ID%6657584400A4
      //## begin restcommand::EntitiesCommand::ONLINE_ENTITY_ID%6657584400A4.attr preserve=no  private: string {U} 
      string m_strONLINE_ENTITY_ID;
      //## end restcommand::EntitiesCommand::ONLINE_ENTITY_ID%6657584400A4.attr

      //## Attribute: PROFILE_ID%665758650021
      //## begin restcommand::EntitiesCommand::PROFILE_ID%665758650021.attr preserve=no  private: string {U} 
      string m_strPROFILE_ID;
      //## end restcommand::EntitiesCommand::PROFILE_ID%665758650021.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%665755D202B1
      //## Role: EntitiesCommand::<m_hQuery>%665755D30269
      //## begin restcommand::EntitiesCommand::<m_hQuery>%665755D30269.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end restcommand::EntitiesCommand::<m_hQuery>%665755D30269.role

      //## Association: DataNavigator Foundation::RESTCommand_CAT::<unnamed>%6657564F010C
      //## Role: EntitiesCommand::<m_hGenericSegment>%665756500103
      //## begin restcommand::EntitiesCommand::<m_hGenericSegment>%665756500103.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end restcommand::EntitiesCommand::<m_hGenericSegment>%665756500103.role

    // Additional Implementation Declarations
      //## begin restcommand::EntitiesCommand%66575071026E.implementation preserve=yes
      //## end restcommand::EntitiesCommand%66575071026E.implementation

};

//## begin restcommand::EntitiesCommand%66575071026E.postscript preserve=yes
//## end restcommand::EntitiesCommand%66575071026E.postscript

} // namespace restcommand

//## begin module%66574F220055.epilog preserve=yes
//## end module%66574F220055.epilog


#endif
