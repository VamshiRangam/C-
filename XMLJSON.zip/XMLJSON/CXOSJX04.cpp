//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF8FCB0284.cm preserve=no
//## end module%64DF8FCB0284.cm

//## begin module%64DF8FCB0284.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF8FCB0284.cp

//## Module: CXOSJX04%64DF8FCB0284; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX04.cpp

//## begin module%64DF8FCB0284.additionalIncludes preserve=no
//## end module%64DF8FCB0284.additionalIncludes

//## begin module%64DF8FCB0284.includes preserve=yes
//## end module%64DF8FCB0284.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTC58_h
#include "CXODTC58.hpp"
#endif
#ifndef CXOSTC57_h
#include "CXODTC57.hpp"
#endif
#ifndef CXOSTC59_h
#include "CXODTC59.hpp"
#endif
#ifndef CXOSTC66_h
#include "CXODTC66.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB24_h
#include "CXODDB24.hpp"
#endif
#ifndef CXOSDB47_h
#include "CXODDB47.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSJX04_h
#include "CXODJX04.hpp"
#endif


//## begin module%64DF8FCB0284.declarations preserve=no
//## end module%64DF8FCB0284.declarations

//## begin module%64DF8FCB0284.additionalDeclarations preserve=yes
//## end module%64DF8FCB0284.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::FinancialTotalsCommand 

FinancialTotalsCommand::FinancialTotalsCommand()
  //## begin FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.hasinit preserve=no
      : m_pView(0),
        m_pGenericSegment(0)
  //## end FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.hasinit
  //## begin FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/settle/financialtotals/v1.0.0","S0003D","@##JRFINT ")
  //## end FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.initialization
{
  //## begin restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.body preserve=yes
   memcpy(m_sID, "JX04", 4);
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
  //## end restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF8E5E036A_const.body
}

FinancialTotalsCommand::FinancialTotalsCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.hasinit preserve=no
      : m_pView(0),
        m_pGenericSegment(0)
  //## end restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.hasinit
  //## begin restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.initialization preserve=yes
   ,RESTCommand("/rest/datanavigator/settle/financialtotals/v1.0.0","S0003D","@##JRFINT ")
  //## end restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.initialization
{
  //## begin restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.body preserve=yes
   memcpy(m_sID, "JX04", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('C', &m_hGenericSegment);
   m_pXMLItem = new XMLItem();
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
  //## end restcommand::FinancialTotalsCommand::FinancialTotalsCommand%64DF944303CA.body
}


FinancialTotalsCommand::~FinancialTotalsCommand()
{
  //## begin restcommand::FinancialTotalsCommand::~FinancialTotalsCommand%64DF8E5E036A_dest.body preserve=yes
  //## end restcommand::FinancialTotalsCommand::~FinancialTotalsCommand%64DF8E5E036A_dest.body
}



//## Other Operations (implementation)
bool FinancialTotalsCommand::endElement (const string& strTag)
{
  //## begin restcommand::FinancialTotalsCommand::endElement%64E2C1660346.body preserve=yes
   string strOperator(m_pXMLItem->get("operator"));
   string strValue(m_pXMLItem->get("value"));
   if (strTag == "filter")
   {
      if (m_pXMLItem->get("column") == "rows")
         setMaxRows(atoi(strValue.c_str()));
      else
      {
         totalscommand::FinancialTotal::instance()->setBasicPredicate(getQuery(0), "Total", m_pXMLItem->get("column").c_str(), strOperator, strValue.c_str());
         totalscommand::TransactionTotal::instance()->setBasicPredicate(getQuery(1), "Total", m_pXMLItem->get("column").c_str(), strOperator, strValue.c_str());
      }
      m_pXMLItem->resetToken();
   }
   return true;
  //## end restcommand::FinancialTotalsCommand::endElement%64E2C1660346.body
}

bool FinancialTotalsCommand::execute ()
{
  //## begin restcommand::FinancialTotalsCommand::execute%64DF9463008E.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX04 RETRIEVE TOTALS");
   m_hQuery[0].reset();
   m_hQuery[1].reset();
   m_hQuery[0].setTruncate(false);
   m_hQuery[1].setTruncate(false);
   ((Segment*)totalscommand::FinancialTotal::instance()->getGenericSegment())->reset();
   ((Segment*)totalscommand::TransactionTotal::instance()->getGenericSegment())->reset();
   totalscommand::FinancialTotal::instance()->reset(m_hQuery[0]);
   totalscommand::TransactionTotal::instance()->reset(m_hQuery[1]);
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJRFINT", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX04", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC = parse();
   m_pXMLDocument->add("root");
   if (iRC != 0)
   {
      m_pXMLDocument->add("details");
      SOAPSegment::instance()->setTxt("Invalid request (parse failure)");
      reply();
      return true;
   }
   m_hGenericSegment.reset();
   m_pXMLDocument->add("tab");
   string strColumn(m_pXMLItem->get("column"));
   m_hColumn.erase(m_hColumn.begin(), m_hColumn.end());
   Buffer::parse(strColumn, ",", m_hColumn);
   for (int i = 0;i < m_hColumn.size();++i)
   {
      string strTagName = m_hColumn[i];
      size_t pos = strTagName.find("format~");
      if (pos != string::npos)
         strTagName.erase(pos,7);
      totalscommand::FinancialTotal::instance()->bind(getQuery(0), "Total", strTagName);
      totalscommand::TransactionTotal::instance()->bind(getQuery(1), "Total", strTagName);
      m_hGenericSegment.set("Name", strTagName.c_str());
      m_pXMLDocument->add("column");
   }
   if (((totalscommand::FinancialTotal::instance()->getENTITY_TYPE(0) == "AT"
      || totalscommand::FinancialTotal::instance()->getENTITY_TYPE(1) == "AT")
      && totalscommand::Total::instance()->isDisabled("AT"))
      || ((totalscommand::FinancialTotal::instance()->getENTITY_TYPE(0) == "AM"
         || totalscommand::FinancialTotal::instance()->getENTITY_TYPE(1) == "AM")
         && totalscommand::Total::instance()->isDisabled("AM"))
      || Extract::instance()->getCustomCode() == "RPSL")
   {
      totalscommand::TransactionTotal::instance()->setDatePredicate(m_hQuery[1]);
      m_hQuery[0] = m_hQuery[1]; // query FIN_Lyyyymm/FIN_RECORDyyyymm instead of T_FIN_TOTAL/T_FIN_CATEGORY
      m_pView = totalscommand::TransactionTotal::instance();
      m_pGenericSegment = totalscommand::TransactionTotal::instance()->getGenericSegment();
   }
   else
   {
      totalscommand::FinancialTotal::instance()->setDatePredicate(m_hQuery[0]);
      m_pView = totalscommand::FinancialTotal::instance();
      m_pGenericSegment = totalscommand::FinancialTotal::instance()->getGenericSegment();
   }
   segment::SOAPSegment::instance()->setRtnCde('0');
   m_hQuery[0].setRetainCursor(true);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[0]))
      SOAPSegment::instance()->setRtnCde('5');
   else
      SOAPSegment::instance()->setRtnCde(m_iRows == 0 ? '2' : m_hQuery[0].getAbort() ? '1' : '0');
   m_pXMLDocument->add("details");
   reply();
   return true;
  //## end restcommand::FinancialTotalsCommand::execute%64DF9463008E.body
}

int FinancialTotalsCommand::parse ()
{
  //## begin restcommand::FinancialTotalsCommand::parse%64FF0DD90173.body preserve=yes
   int iRC = RESTCommand::parse();
   if (iRC != 0)
      return iRC;
   // !!! add checks for input
   return 0;
  //## end restcommand::FinancialTotalsCommand::parse%64FF0DD90173.body
}

void FinancialTotalsCommand::update (Subject* pSubject)
{
  //## begin restcommand::FinancialTotalsCommand::update%64DF946501C9.body preserve=yes
   if (pSubject == &m_hQuery[0])
   {
      if (++m_iRows > m_iSkipRows)
      {
         if ((m_iRows - m_iSkipRows) <= m_iMaxRows)
         {
            string strColumnValue;
            string strTagName;
            string strAmountValue;
            string strCurrencyValue;
            if (m_pXMLDocument->add("row") == false)
            {
               m_pXMLDocument->revert();
               m_hQuery[0].setAbort(true);
               return;
            }
            const multimap<string, database::Column, less<string> > hTag = m_pView->getTag();
            for (int i = 0;i < m_hColumn.size();++i)
            {
               strTagName = "Total:" + m_hColumn[i];
               size_t pos = strTagName.find("format~");
               if (pos != string::npos)
                  strTagName.erase(pos, 7);
               pair<multimap<string, database::Column, less<string> >::const_iterator, multimap<string, database::Column, less<string> >::const_iterator> hRange = hTag.equal_range(strTagName);
               if (hRange.first != hRange.second)
               {
                  multimap<string, database::Column, less<string> >::const_iterator p = hRange.first;
                  strAmountValue.erase();
                  strCurrencyValue.erase();
                  for (p = hRange.first; p != hRange.second; p++)
                  {
                     strColumnValue.erase();
                     if ((*p).second.getColumn().find("AMT_") != string::npos)
                        strAmountValue = m_pGenericSegment->get((*p).second.getColumn().c_str());
                     else if ((*p).second.getColumn().find("CUR_") != string::npos)
                        strCurrencyValue = m_pGenericSegment->get((*p).second.getColumn().c_str());
                     else
                        strColumnValue = m_pGenericSegment->get((*p).second.getColumn().c_str());
                     if (strColumnValue.length() > 0)
                     {
                        m_hGenericSegment.set("Value", strColumnValue);
                        if (m_pXMLDocument->add("value") == false)
                        {
                           m_pXMLDocument->revert();
                           m_hQuery[0].setAbort(true);
                           return;
                        }
                     }
                  }
                  if (strAmountValue.length() > 0)
                  {
                     if (m_hColumn[i].find("format~") != string::npos)
                        strColumnValue = CurrencyCode::instance()->formatAmount(atof(strAmountValue.c_str()), strCurrencyValue, 32, true, false, true);
                     else
                        strColumnValue = strCurrencyValue + " " + strAmountValue;
                     m_hGenericSegment.set("Value", strColumnValue);
                     if (m_pXMLDocument->add("value") == false)
                     {
                        m_pXMLDocument->revert();
                        m_hQuery[0].setAbort(true);
                        return;
                     }
                  }
               }
            }
            m_pXMLDocument->write("row");
         }
         else
            m_hQuery[0].setAbort(true);
      }
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::FinancialTotalsCommand::update%64DF946501C9.body
}

// Additional Declarations
  //## begin restcommand::FinancialTotalsCommand%64DF8E5E036A.declarations preserve=yes
  //## end restcommand::FinancialTotalsCommand%64DF8E5E036A.declarations

} // namespace restcommand

//## begin module%64DF8FCB0284.epilog preserve=yes
//## end module%64DF8FCB0284.epilog
