//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65D427C0002D.cm preserve=no
//## end module%65D427C0002D.cm

//## begin module%65D427C0002D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65D427C0002D.cp

//## Module: CXOSJX16%65D427C0002D; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX16.cpp

//## begin module%65D427C0002D.additionalIncludes preserve=no
//## end module%65D427C0002D.additionalIncludes

//## begin module%65D427C0002D.includes preserve=yes
//## end module%65D427C0002D.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJX16_h
#include "CXODJX16.hpp"
#endif


//## begin module%65D427C0002D.declarations preserve=no
//## end module%65D427C0002D.declarations

//## begin module%65D427C0002D.additionalDeclarations preserve=yes
//## end module%65D427C0002D.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReconFilesCommand 

ReconFilesCommand::ReconFilesCommand()
  //## begin ReconFilesCommand::ReconFilesCommand%65D418040175_const.hasinit preserve=no
  //## end ReconFilesCommand::ReconFilesCommand%65D418040175_const.hasinit
  //## begin ReconFilesCommand::ReconFilesCommand%65D418040175_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/reconcile/reconfiles/v1.0.0", "S0003D", "@##JLRCFS ")
  //## end ReconFilesCommand::ReconFilesCommand%65D418040175_const.initialization
{
  //## begin restcommand::ReconFilesCommand::ReconFilesCommand%65D418040175_const.body preserve=yes
   memcpy(m_sID, "JX16", 4);
  //## end restcommand::ReconFilesCommand::ReconFilesCommand%65D418040175_const.body
}

ReconFilesCommand::ReconFilesCommand (Handler* pSuccessor)
  //## begin restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.hasinit preserve=no
  //## end restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.hasinit
  //## begin restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/reconcile/reconfiles/v1.0.0", "S0003D", "@##JLRCFS ")
  //## end restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.initialization
{
  //## begin restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.body preserve=yes
   memcpy(m_sID, "JX16", 4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X', segment::SOAPSegment::instance());
   m_hXMLText.add('R', &m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReconFilesCommand::ReconFilesCommand%65D41FAD0358.body
}


ReconFilesCommand::~ReconFilesCommand()
{
  //## begin restcommand::ReconFilesCommand::~ReconFilesCommand%65D418040175_dest.body preserve=yes
  //## end restcommand::ReconFilesCommand::~ReconFilesCommand%65D418040175_dest.body
}



//## Other Operations (implementation)
bool ReconFilesCommand::execute ()
{
  //## begin restcommand::ReconFilesCommand::execute%65D41FC7026E.body preserve=yes
   UseCase hUseCase("CLIENT", "## JX16 LIST RECON FILES");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL", "RJLRCFS", &m_hRow, &m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE", "CXORJX16", &m_hRow, &m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.bind("AU_FILE_CONTROL", "AU_FILE_NAME", Column::STRING, &m_strAU_FILE_NAME);
   m_hQuery.bind("AU_FILE_CONTROL", "DATE_RECON", Column::STRING, &m_strDATE_RECON);
   m_hQuery.bind("AU_FILE_CONTROL", "AU_STATE", Column::STRING, &m_strAU_STATE);
   m_hQuery.bind("AU_FILE_CONTROL", "TSTAMP_TRANS_FROM", Column::STRING, &m_strTSTAMP_TRANS_FROM);
   m_hQuery.bind("AU_FILE_CONTROL", "TSTAMP_TRANS_TO", Column::STRING, &m_strTSTAMP_TRANS_TO);
   m_hQuery.bind("AU_FILE_CONTROL", "BIN", Column::STRING, &m_strBIN);
   m_hQuery.bind("AU_FILE_CONTROL", "BIN_COUNT", Column::STRING, &m_strBIN_COUNT);
   m_hQuery.bind("AU_FILE_CONTROL", "TASK_RECONCILED", Column::STRING, &m_strTASK_RECONCILED);
   m_hQuery.setBasicPredicate("AU_FILE_CONTROL", "AU_FILE_NAME", "=", (m_pXMLItem->get("file")).c_str());
   m_hQuery.setOrderByClause("DATE_RECON DESC");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReconFilesCommand::execute%65D41FC7026E.body
}

void ReconFilesCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReconFilesCommand::update%65D41FCA0266.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.reset();
      m_hGenericSegment.set("File", m_strAU_FILE_NAME);
      m_hGenericSegment.set("Date", m_strDATE_RECON);
      m_hGenericSegment.set("State", m_strAU_STATE);
      m_hGenericSegment.set("From", m_strTSTAMP_TRANS_FROM);
      m_hGenericSegment.set("To", m_strTSTAMP_TRANS_TO);
      m_hGenericSegment.set("Progress", m_strBIN);
      m_hGenericSegment.set("Count", m_strBIN_COUNT);
      m_hGenericSegment.set("Task", m_strTASK_RECONCILED);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   command::RESTCommand::update(pSubject);
  //## end restcommand::ReconFilesCommand::update%65D41FCA0266.body
}

// Additional Declarations
  //## begin restcommand::ReconFilesCommand%65D418040175.declarations preserve=yes
  //## end restcommand::ReconFilesCommand%65D418040175.declarations

} // namespace restcommand

//## begin module%65D427C0002D.epilog preserve=yes
//## end module%65D427C0002D.epilog
