//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%667EAD6E016E.cm preserve=no
//## end module%667EAD6E016E.cm

//## begin module%667EAD6E016E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%667EAD6E016E.cp

//## Module: CXOSJX22%667EAD6E016E; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX22.cpp

//## begin module%667EAD6E016E.additionalIncludes preserve=no
//## end module%667EAD6E016E.additionalIncludes

//## begin module%667EAD6E016E.includes preserve=yes
//## end module%667EAD6E016E.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSJX22_h
#include "CXODJX22.hpp"
#endif


//## begin module%667EAD6E016E.declarations preserve=no
//## end module%667EAD6E016E.declarations

//## begin module%667EAD6E016E.additionalDeclarations preserve=yes
//## end module%667EAD6E016E.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::SignoutCommand 

SignoutCommand::SignoutCommand()
  //## begin SignoutCommand::SignoutCommand%667E32190207_const.hasinit preserve=no
  //## end SignoutCommand::SignoutCommand%667E32190207_const.hasinit
  //## begin SignoutCommand::SignoutCommand%667E32190207_const.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/signout/v1.0.0","S0003D","@##JSNOUT ")
  //## end SignoutCommand::SignoutCommand%667E32190207_const.initialization
{
  //## begin restcommand::SignoutCommand::SignoutCommand%667E32190207_const.body preserve=yes
   memcpy(m_sID,"JX22",4);
  //## end restcommand::SignoutCommand::SignoutCommand%667E32190207_const.body
}

SignoutCommand::SignoutCommand (Handler* pSuccessor)
  //## begin restcommand::SignoutCommand::SignoutCommand%667EACE902E0.hasinit preserve=no
  //## end restcommand::SignoutCommand::SignoutCommand%667EACE902E0.hasinit
  //## begin restcommand::SignoutCommand::SignoutCommand%667EACE902E0.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/secure/signout/v1.0.0","S0003D","@##JSNOUT ")
  //## end restcommand::SignoutCommand::SignoutCommand%667EACE902E0.initialization
{
  //## begin restcommand::SignoutCommand::SignoutCommand%667EACE902E0.body preserve=yes
   memcpy(m_sID,"JX22",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_pXMLItem = new XMLItem();
  //## end restcommand::SignoutCommand::SignoutCommand%667EACE902E0.body
}


SignoutCommand::~SignoutCommand()
{
  //## begin restcommand::SignoutCommand::~SignoutCommand%667E32190207_dest.body preserve=yes
  //## end restcommand::SignoutCommand::~SignoutCommand%667E32190207_dest.body
}



//## Other Operations (implementation)
bool SignoutCommand::execute ()
{
  //## begin restcommand::SignoutCommand::execute%667EACC10007.body preserve=yes
   UseCase hUseCase("CLIENT","## JX22 SIGNOUT");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJSNOUT",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX22",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int iRC = parse();
   char* pMessage[] = {
      "Success",
      "1",
      "2",
      "Invalid request (parse failure)",
      "Authentication unsuccessful"
   };
   if (iRC <= 4)
      SOAPSegment::instance()->setTxt(pMessage[iRC]);
   m_pXMLDocument->add("root");
   CommonHeaderSegment::instance()->setResultCode(iRC);
   if (iRC > 0)
      UseCase::addItem();
   m_strSession.assign("0000000000000000000000000000000000==",36);
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::SignoutCommand::execute%667EACC10007.body
}

// Additional Declarations
  //## begin restcommand::SignoutCommand%667E32190207.declarations preserve=yes
  //## end restcommand::SignoutCommand%667E32190207.declarations

} // namespace restcommand

//## begin module%667EAD6E016E.epilog preserve=yes
//## end module%667EAD6E016E.epilog
