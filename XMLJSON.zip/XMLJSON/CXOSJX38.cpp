//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%67A2174102F3.cm preserve=no
//## end module%67A2174102F3.cm

//## begin module%67A2174102F3.cp preserve=no
//	Copyright (c) 1997 - 2025
//	FIS
//## end module%67A2174102F3.cp

//## Module: CXOSJX38%67A2174102F3; Package body
//## Subsystem: JXDLL%645AEC9A0298
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Jxdll\CXOSJX38.cpp

//## begin module%67A2174102F3.additionalIncludes preserve=no
//## end module%67A2174102F3.additionalIncludes

//## begin module%67A2174102F3.includes preserve=yes
//## end module%67A2174102F3.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSJX38_h
#include "CXODJX38.hpp"
#endif


//## begin module%67A2174102F3.declarations preserve=no
//## end module%67A2174102F3.declarations

//## begin module%67A2174102F3.additionalDeclarations preserve=yes
//## end module%67A2174102F3.additionalDeclarations


//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
//## begin restcommand%645AEC55037E.initialDeclarations preserve=yes
//## end restcommand%645AEC55037E.initialDeclarations

// Class restcommand::ReportFileCommand 

ReportFileCommand::ReportFileCommand()
  //## begin ReportFileCommand::ReportFileCommand%67A2163A01CA_const.hasinit preserve=no
  //## end ReportFileCommand::ReportFileCommand%67A2163A01CA_const.hasinit
  //## begin ReportFileCommand::ReportFileCommand%67A2163A01CA_const.initialization preserve=yes
  //## end ReportFileCommand::ReportFileCommand%67A2163A01CA_const.initialization
{
  //## begin restcommand::ReportFileCommand::ReportFileCommand%67A2163A01CA_const.body preserve=yes
  //## end restcommand::ReportFileCommand::ReportFileCommand%67A2163A01CA_const.body
}

ReportFileCommand::ReportFileCommand (reusable::Handler* pSuccessor)
  //## begin restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.hasinit preserve=no
  //## end restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.hasinit
  //## begin restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.initialization preserve=yes
   : RESTCommand("/rest/datanavigator/report/file/v1.0.0","S0003D","@##JRFILE ")
  //## end restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.initialization
{
  //## begin restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.body preserve=yes
   memcpy(m_sID,"JX38",4);
   m_pSuccessor = pSuccessor;
   m_hXMLText.add('X',segment::SOAPSegment::instance());
   m_hXMLText.add('R',&m_hGenericSegment);
   m_hQuery.attach(this);
   m_hRow.attach(this);
   m_pXMLItem = new XMLItem();
  //## end restcommand::ReportFileCommand::ReportFileCommand%67A216C300DD.body
}


ReportFileCommand::~ReportFileCommand()
{
  //## begin restcommand::ReportFileCommand::~ReportFileCommand%67A2163A01CA_dest.body preserve=yes
  //## end restcommand::ReportFileCommand::~ReportFileCommand%67A2163A01CA_dest.body
}



//## Other Operations (implementation)
bool ReportFileCommand::execute ()
{
  //## begin restcommand::ReportFileCommand::execute%67A216CE009D.body preserve=yes
   UseCase hUseCase("CLIENT","## JX37 PREVIEW ENTITY FILE");
   if (!m_pXMLDocument)
#ifdef MVS
      m_pXMLDocument = new XMLDocument("JCL","RJRFILE",&m_hRow,&m_hXMLText);
#else
      m_pXMLDocument = new XMLDocument("SOURCE","CXORJX38",&m_hRow,&m_hXMLText);
#endif
   m_pXMLDocument->reset();
   m_pXMLItem->reset();
   m_hQuery.reset();
   m_pXMLDocument->setMaximumSize(64000);
   m_pXMLDocument->setSuppressEmptyTags(false);
   int i = parse();
   m_pXMLDocument->add("root");
   if (i != 0)
   {
      m_pXMLDocument->add("details");
      return reply();
   }
   m_hQuery.reset();
   string strTable("DX_DATA_");
   strTable += m_pXMLItem->get("date");
   m_hQuery.bind(strTable.c_str(),"DATA_BUFFER",Column::STRING,&m_strDATA_BUFFER);
   m_hQuery.setBasicPredicate(strTable.c_str(),"DX_FILE_ID","=",atoi(m_pXMLItem->get("file").c_str()));
   m_hQuery.setOrderByClause("SEQ_NO");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery);
   if (b == false
      || pSelectStatement->getRows() == 0)
      SOAPSegment::instance()->setRtnCde(b ? '2' : '5');
   m_pXMLDocument->add("details");
   return reply();
  //## end restcommand::ReportFileCommand::execute%67A216CE009D.body
}

void ReportFileCommand::update (Subject* pSubject)
{
  //## begin restcommand::ReportFileCommand::update%67A216D002AA.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      ++m_iRows;
      ++m_iTotalRows;
      m_hGenericSegment.reset();
      m_hGenericSegment.set("Buffer",m_strDATA_BUFFER);
      m_pXMLDocument->add("row");
      UseCase::addItem();
      return;
   }
   RESTCommand::update(pSubject);
  //## end restcommand::ReportFileCommand::update%67A216D002AA.body
}

// Additional Declarations
  //## begin restcommand::ReportFileCommand%67A2163A01CA.declarations preserve=yes
  //## end restcommand::ReportFileCommand%67A2163A01CA.declarations

} // namespace restcommand

//## begin module%67A2174102F3.epilog preserve=yes
//## end module%67A2174102F3.epilog
