//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C613642038A.cm preserve=no
//## end module%3C613642038A.cm

//## begin module%3C613642038A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3C613642038A.cp

//## Module: CXOSAI02%3C613642038A; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Ai\CXOSAI02.cpp

//## begin module%3C613642038A.additionalIncludes preserve=no
//## end module%3C613642038A.additionalIncludes

//## begin module%3C613642038A.includes preserve=yes
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#include "CXODIF10.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
#include "CXODRS69.hpp"
#include "CXODRU34.hpp"
#include "CXODRS62.hpp"
#include "CXODRS64.hpp"
#include "CXODRS66.hpp"
#include "CXODRSA5.hpp"
#include "CXODRU37.hpp"
#include "CXODTM06.hpp"
#include "CXODDB49.hpp"
#include "CXODRSA1.hpp"
#include "CXODRSA6.hpp"
#include "CXODRS79.hpp"
#include "CXODRS98.hpp"
#include "CXODSI09.hpp"
#include "CXODSI10.hpp"
#include "CXODRS99.hpp"
#include "CXODRS87.hpp"
#include "CXODRSC1.hpp"
#include "CXODRSA2.hpp"
#ifndef CXOSRU62_h
#include "CXODRU62.hpp"
#endif
#include "CXODRS77.hpp"
#include "CXODDB65.hpp"
//## end module%3C613642038A.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSRS70_h
#include "CXODRS70.hpp"
#endif
#ifndef CXOSRS76_h
#include "CXODRS76.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSRS80_h
#include "CXODRS80.hpp"
#endif
#ifndef CXOSRU47_h
#include "CXODRU47.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSRS94_h
#include "CXODRS94.hpp"
#endif
#ifndef CXOSRSA4_h
#include "CXODRSA4.hpp"
#endif
#ifndef CXOSRS95_h
#include "CXODRS95.hpp"
#endif
#ifndef CXOSRSC2_h
#include "CXODRSC2.hpp"
#endif
#ifndef CXOSAI02_h
#include "CXODAI02.hpp"
#endif


//## begin module%3C613642038A.declarations preserve=no
//## end module%3C613642038A.declarations

//## begin module%3C613642038A.additionalDeclarations preserve=yes
//## end module%3C613642038A.additionalDeclarations


// Class AdvantageFinancial 

AdvantageFinancial::AdvantageFinancial()
  //## begin AdvantageFinancial::AdvantageFinancial%3C6131880148_const.hasinit preserve=no
      : m_bAddEvidence(true),
        m_bAsciiInput(false),
        m_bAuthByAltRoute(false),
        m_iBufferStartp(0),
        m_cClass(' ' ),
        m_bCVV_CVC3(false),
        m_bExpirationDate(false),
        m_iLinkOption(-1),
        m_cNetworkDecPos(' ' ),
        m_cPreAuthFlag(' ' ),
        m_cPreauthInd(' ' ),
        m_bReversal(false),
        m_pSegment(0),
        m_bTokenExpirationDate(false),
        m_bTrack2(false),
        m_pFinancialAdjustmentExtensionSegment(0),
        m_pFinancialAdjustmentSegment(0),
        m_pFinancialBaseSegment(0),
        m_pFinancialFeeSegment(0),
        m_pFinancialReversalSegment(0),
        m_pFinancialSettlementSegment(0),
        m_pFinancialUserSegment(0),
        m_pAdvantageMessageProcessor(0),
        m_pIntegratedCircuitCardSegment(0),
        m_pMultipleRouteSegment(0),
        m_pPulseSegment(0),
        m_pFinancialMCDPSegment(0),
        m_pSegment24(0),
        m_pFinancialPaymentSegment(0),
        m_pFinancialAPSegment(0)
  //## end AdvantageFinancial::AdvantageFinancial%3C6131880148_const.hasinit
  //## begin AdvantageFinancial::AdvantageFinancial%3C6131880148_const.initialization preserve=yes
   , m_pFinancialPNBSegment(0)
   , AdvantageMessage("0400", "S200")
  //## end AdvantageFinancial::AdvantageFinancial%3C6131880148_const.initialization
{
  //## begin AdvantageFinancial::AdvantageFinancial%3C6131880148_const.body preserve=yes
   memcpy(m_sID, "AI02", 4);
   m_siUniquenessKey = 0;
   m_pFinancialAdjustmentExtensionSegment = FinancialAdjustmentExtensionSegment::instance();
   m_pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   m_pFinancialFeeSegment = FinancialFeeSegment::instance();
   m_pFinancialReversalSegment = FinancialReversalSegment::instance();
   m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   m_pFinancialUserSegment = FinancialUserSegment::instance();
   m_pIntegratedCircuitCardSegment = IntegratedCircuitCardSegment::instance();
   m_pMultipleRouteSegment = MultipleRouteSegment::instance();
   m_pPulseSegment = PulseSegment::instance();
   m_pSegment24 = Segment24::instance();
   m_pFinancialPaymentSegment = FinancialPaymentSegment::instance();
   m_pFinancialMCDPSegment = FinancialMCDPSegment::instance();
   m_pFinancialPNBSegment = FinancialPNBSegment::instance();
   m_pFinancialAPSegment = FinancialAPSegment::instance();
   if (m_hNetTermId.empty())
   {
      string strRecord, strOldNetTermId, strNewNetTermId, strInstIdAcq, strInstIdReconAcq;
      int i = 0;
      vector<string> hTokens;
      while (Extract::instance()->getRecord(i++, strRecord))
      {
         if (strRecord.substr(0, 16) == "DSPEC   NET_TERM")
         {
            if (Buffer::parse(strRecord.data() + 17, " ", hTokens) >= 4)
            {
               strOldNetTermId = hTokens[0];
               strOldNetTermId.resize(8, ' ');
               strNewNetTermId = hTokens[1];
               strNewNetTermId.resize(8, ' ');
               strInstIdAcq = hTokens[2];
               strInstIdAcq.resize(11, ' ');
               strInstIdReconAcq = hTokens[3];
               strInstIdReconAcq.resize(11, ' ');
               m_hNetTermId.insert(map<string, string, less<string> >::value_type(strOldNetTermId, strNewNetTermId + strInstIdAcq + strInstIdReconAcq));
            }
         }
         else if (strRecord.substr(0,16) == "DSPEC   AI02    ")
         {
            if (Buffer::parse(strRecord.data() + 16, "~,!",hTokens) >= 2)
            {
               if (hTokens[0] == "EXCLUDESEG24")
                  m_hSeg24Tokens.insert(atoi(hTokens[1].c_str()));
            }
         }
      }
   }
#ifdef MVS
   FlatFile hFlatFile("JCL", "CXOXSG24");
#else
   FlatFile hFlatFile("SOURCE", "CXOXSG24");
#endif
   char szBuffer[81];
   size_t m = 0;
   string strTag;
   while (hFlatFile.read(szBuffer, 81, &m))
   {
      szBuffer[m] = '\0';
      m_hSeg24NumericTokens.insert(atoi(szBuffer));
   }
  //## end AdvantageFinancial::AdvantageFinancial%3C6131880148_const.body
}


AdvantageFinancial::~AdvantageFinancial()
{
  //## begin AdvantageFinancial::~AdvantageFinancial%3C6131880148_dest.body preserve=yes
   m_hNetTermId.erase(m_hNetTermId.begin(), m_hNetTermId.end());
   m_hUsecaseOptions.erase(m_hUsecaseOptions.begin(), m_hUsecaseOptions.end());
  //## end AdvantageFinancial::~AdvantageFinancial%3C6131880148_dest.body
}



//## Other Operations (implementation)
double AdvantageFinancial::convertAmt (double dAmount, char cDecPos, char* sRate)
{
  //## begin AdvantageFinancial::convertAmt%3C6195B6032C.body preserve=yes
   double dRate = atof(sRate);
   if (dRate == 1
      && cDecPos == '0')
      return dAmount;
   double dConvertedAmt = 0;
   switch (cDecPos)
   {
   case '0':
      dConvertedAmt = (dAmount * dRate);
      break;
   case '1':
      dConvertedAmt = (dAmount * dRate) * .1;
      break;
   case '2':
      dConvertedAmt = (dAmount * dRate) * .01;
      break;
   case '3':
      dConvertedAmt = (dAmount * dRate) * .001;
      break;
   case '4':
      dConvertedAmt = (dAmount * dRate) * .0001;
      break;
   case '5':
      dConvertedAmt = (dAmount * dRate) * .00001;
      break;
   case '6':
      dConvertedAmt = (dAmount * dRate) * .000001;
      break;
   case '7':
      dConvertedAmt = (dAmount * dRate) * .0000001;
      break;
   case '8':
      dConvertedAmt = (dAmount * dRate) * .00000001;
      break;
   case '9':
      dConvertedAmt = (dAmount * dRate) * .000000001;
      break;
   default:
      dConvertedAmt = dAmount;
   }
   if (dConvertedAmt > 0)
      dConvertedAmt += .5;
   else
      if (dConvertedAmt < 0)
         dConvertedAmt -= .5;
   char szTemp[PERCENTF];
   snprintf(szTemp, sizeof(szTemp), "%f", dConvertedAmt);
   char* p = strchr(szTemp, '.');
   if (p)
      *p = '\0';
   dConvertedAmt = atof(szTemp);
   return dConvertedAmt;
  //## end AdvantageFinancial::convertAmt%3C6195B6032C.body
}

int AdvantageFinancial::convertAmt (int lAmount, char cDecPos, char* sRate)
{
  //## begin AdvantageFinancial::convertAmt%5AB10083008E.body preserve=yes
   return (int)convertAmt((double)lAmount, cDecPos, sRate);
  //## end AdvantageFinancial::convertAmt%5AB10083008E.body
}

void AdvantageFinancial::convertBitMap (const char cCharBit, char* psBits)
{
  //## begin AdvantageFinancial::convertBitMap%3D66A0AD03B9.body preserve=yes
   char sBits[65] = { "0000000100100011010001010110011110001001101010111100110111101111" };
   char pszHex[17] = { "0123456789ABCDEF" };
   char* p = strchr(pszHex, cCharBit);
   if (!p)
      memcpy(psBits, sBits, 4);
   else
      memcpy(psBits, sBits + ((p - pszHex) * 4), 4);
  //## end AdvantageFinancial::convertBitMap%3D66A0AD03B9.body
}

string AdvantageFinancial::hexToChar (char* pBuffer, int ilen)
{
  //## begin AdvantageFinancial::hexToChar%46356FCF02D3.body preserve=yes
   string strTemp;
   CodeTable::nibbleToByte(pBuffer, ilen, strTemp);
   return strTemp;
  //## end AdvantageFinancial::hexToChar%46356FCF02D3.body
}

bool AdvantageFinancial::insert (Message& hMessage)
{
  //## begin AdvantageFinancial::insert%3C618FB601D4.body preserve=yes
   m_bAuthByAltRoute = false;
   m_bReversal = false;
   m_bCVV_CVC3 = false;
   m_bAddEvidence = true;
   m_cPreAuthFlag = 'N';
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialSettlementSegment->reset();
   m_pFinancialUserSegment->reset();
   m_pFinancialReversalSegment->reset();
   m_pFinancialAdjustmentSegment->reset();
   m_pIntegratedCircuitCardSegment->reset();
   m_pMultipleRouteSegment->reset();
   m_pPulseSegment->reset();
   m_pSegment24->reset();
   m_pFinancialPaymentSegment->reset();
   m_pFinancialMCDPSegment->reset();
   m_pFinancialPNBSegment->reset();
   m_pFinancialAPSegment->reset();
   if (m_iLinkOption < 0)
   {
      string strRecord;
      Extract::instance()->getRecord("DUSER   ", strRecord);
      m_iLinkOption = strRecord.find("LINK") != string::npos ? 1 : 0;
      m_bExpirationDate = strRecord.find("DATE_EXP") != string::npos;
      m_bTokenExpirationDate = strRecord.find("TOKEN_EXP_DATE") != string::npos;
      m_bTrack2 = strRecord.find("TRACK2") != string::npos;
   }
   AdvantageMessage::insert(hMessage);
   m_pAdvantageMessageProcessor = AdvantageMessageProcessor::instance();
   m_bAsciiInput = m_pAdvantageMessageProcessor->getAsciiInput();
   m_pSegment = hMessage.data();
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)m_pSegment;
   hFinancialSeg1* pFinancialSeg1 = (hFinancialSeg1*)(m_pSegment += sizeof(hV13AdvantageHeader));
   if ((m_pAdvantageMessageProcessor->getMessageCode() == "0482")
      && (ntohs(pAdvantageHeader->siHdrMsgStep) != 9014))
      return false;
   if (m_pAdvantageMessageProcessor->getMessageCode() == "0400")
      UseCase hUseCase("TANDEM", "## AD12 READ 0400 FINANCIAL", false);
   else if (m_pAdvantageMessageProcessor->getMessageCode() == "0401")
      UseCase hUseCase("TANDEM", "## AD33 READ 0401 FINANCIAL", false);
   else if (m_pAdvantageMessageProcessor->getMessageCode() == "0482")
      UseCase hUseCase("TANDEM", "## AD34 READ 0482 FINANCIAL", false);
   else if (m_pAdvantageMessageProcessor->getMessageCode() == "0491")
      UseCase hUseCase("TANDEM", "## AD35 READ 0491 FINANCIAL", false);
   mapSegment1(pFinancialSeg1);
   if ((ConfigurationRepository::instance()->isSubscriber(FinancialBaseSegment::instance()->zINST_ID_RECN_ACQ_B(), FinancialBaseSegment::instance()->zINST_ID_RECN_ISS_B())) == "X")
   {
      return false;
   }
   else
   {
      FinancialBaseSegment::instance()->setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }
   m_pSegment += sizeof(hFinancialSeg1);
   if (pFinancialSeg1->bSeg2)
   {
      mapSegment2((hFinancialSeg2*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg2);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg2);
   }
   if (pFinancialSeg1->bSeg3)
   {
      mapSegment3((hFinancialSeg3*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg3);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg3);
   }
   if (pFinancialSeg1->bSeg4)
   {
      mapSegment4((hFinancialSeg4*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg4);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg4);
   }
   if (pFinancialSeg1->bSeg5)
   {
      mapSegment5((hFinancialSeg5*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg5);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg5);
   }
   if (pFinancialSeg1->bSeg6)
   {
      mapSegment6((hFinancialSeg6*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg6);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg6);
   }
   if (pFinancialSeg1->bSeg7)
   {
      mapSegment7((hFinancialSeg7*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg7);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg7);
   }
   if (pFinancialSeg1->bSeg8)
   {
      mapSegment8((hFinancialSeg8*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg8);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg8);
   }
   if (pFinancialSeg1->bSeg9)
   {
      mapSegment9((hFinancialSeg9*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg9);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg9);
   }
   if (pFinancialSeg1->bSeg10)
   {
      mapSegment10((hFinancialSeg10*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg10);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg10);
   }
   if (pFinancialSeg1->bSeg11)
   {
      mapSegment11((hFinancialSeg11*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg11);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg11);
   }
   if (pFinancialSeg1->bSeg12)
   {
      mapSegment12((hFinancialSeg12*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg12);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg12);
   }
   if (pFinancialSeg1->bSeg13)
   {
      mapSegment13((hFinancialSeg13*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg13);
   }
   else
   {
      mapSegment13(0);
      if (!m_bAsciiInput)
         m_pSegment += sizeof(hFinancialSeg13);
   }
   if (pFinancialSeg1->bSeg14)
   {
      mapSegment14((hFinancialSeg14*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg14);
   }
   else
   {
      mapSegment14(0);
      if (!m_bAsciiInput)
         m_pSegment += sizeof(hFinancialSeg14);
   }
   char sTempTranDesc[9] = { "        " };
   string strTRAN_DESC;
   if (pFinancialSeg1->bSeg15)
   {
      mapSegment15((hFinancialSeg15*)m_pSegment, sTempTranDesc);
      m_pSegment += sizeof(hFinancialSeg15);
      string strReimbFlag;
      string strNetId(pFinancialSeg1->sNetworkIdAcqr,
         sizeof(pFinancialSeg1->sNetworkIdAcqr));
      if (ConfigurationRepository::instance()->translate("ONLINE_NETWORK",
         strNetId, strReimbFlag, "FIN_RECORD", "REIMBURSEMENT_ATTR", 0, false))
      {
         if (strReimbFlag == "Y")
            m_pFinancialBaseSegment->setREIMBURSEMENT_ATTR(sTempTranDesc, 1);
      }
      strTRAN_DESC.assign(m_pFinancialSettlementSegment->zTRAN_DESC(), 4);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg15);
   }
   char sPAN_RANGE[19];
   memset(sPAN_RANGE, ' ', sizeof(sPAN_RANGE));
   if (m_pFinancialSettlementSegment->getREF_DATA_ISS_FMT() == 4 &&
      pFinancialSeg1->bSeg12)
   {
      if (m_pFinancialSettlementSegment->getDATA_PRIV_ISS_FMT() == 77)
      {
         visasms::segREF_DATA_ISS* pREF_DATA_ISS_Sms;
         pREF_DATA_ISS_Sms = (struct visasms::segREF_DATA_ISS*)m_pFinancialSettlementSegment->zREF_DATA_ISS();
         if (Extract::instance()->getCustomCode() == "WOW")
            memcpy(sPAN_RANGE, pREF_DATA_ISS_Sms->sPanSuffix, 4);
         if (memcmp(m_pFinancialSettlementSegment->zTRAN_DESC(), " ", 1) == 0 ||
            strlen(m_pFinancialSettlementSegment->zTRAN_DESC()) == 0)
            m_pFinancialBaseSegment->setREIMBURSEMENT_ATTR(&pREF_DATA_ISS_Sms->cREIMBURSEMENT_ATTR, 1);
         m_pFinancialUserSegment->setVISA_TRANSACTION_ID(pREF_DATA_ISS_Sms->sTRAN_IDENTIFIER, sizeof(pREF_DATA_ISS_Sms->sTRAN_IDENTIFIER));
      }
      else
      if (m_pFinancialSettlementSegment->getDATA_PRIV_ISS_FMT() == 38)
      {
         visabaseii::segREF_DATA_ISS_EVES* pREF_DATA_ISS_Eves;
         pREF_DATA_ISS_Eves = (struct visabaseii::segREF_DATA_ISS_EVES*)m_pFinancialSettlementSegment->zREF_DATA_ISS();
         if (Extract::instance()->getCustomCode() == "WOW")
            memcpy(sPAN_RANGE, pREF_DATA_ISS_Eves->sPanSuffix, 4);
         if (memcmp(m_pFinancialSettlementSegment->zTRAN_DESC(), " ", 1) == 0 ||
            strlen(m_pFinancialSettlementSegment->zTRAN_DESC()) == 0)
            m_pFinancialBaseSegment->setREIMBURSEMENT_ATTR(&pREF_DATA_ISS_Eves->cREIMBURSEMENT_ATTR, 1);
         m_pFinancialUserSegment->setVISA_TRANSACTION_ID(pREF_DATA_ISS_Eves->sTRAN_IDENTIFIER, sizeof(pREF_DATA_ISS_Eves->sTRAN_IDENTIFIER));
      }
   }
   if (pFinancialSeg1->bSeg16)
   {
      mapSegment16((hFinancialSeg16*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg16);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg16);
   }
   if (pFinancialSeg1->bSeg17)
   {
      mapSegment17((hFinancialSeg17*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg17);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg17);
   }
   if (pFinancialSeg1->bSeg18)
   {
      char sRevMTI[5] = { "    " };
      if(Extract::instance()->getCustomCode() == "CBA" && m_hUsecaseOptions.empty())
         EntityOption::instance()->get("*I", "INST_ID_RECN_EFN", Customer::instance()->getCUST_ID(), "AI02", &m_hUsecaseOptions);

      mapSegment18((hFinancialSeg18*)m_pSegment, sRevMTI);
      if (m_bReversal)
      {
         m_cClass = sRevMTI[1];
      }
      m_pSegment += sizeof(hFinancialSeg18);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg18);
   }
   if (pFinancialSeg1->bSeg19)
   {
      mapSegment19((hFinancialSeg19*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg19);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg19);
   }
   if (pFinancialSeg1->bSeg20)
   {
      mapSegment20((hFinancialSeg20*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg20);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg20);
   }
   if (pFinancialSeg1->bSeg21)
   {
      mapSegment21((hFinancialSeg21*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg21);
   }
   else
   {
      if (!m_bAsciiInput)
         m_pSegment += sizeof(hFinancialSeg21);
   }
   if (pFinancialSeg1->bSeg22)
   {
      mapSegment22((hFinancialSeg22*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg22);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg22);
   }
   if (pFinancialSeg1->bSeg23)
   {
      mapSegment23((hFinancialSeg23*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg23);
   }
   else if (!m_bAsciiInput)
   {
      m_pSegment += sizeof(hFinancialSeg23);
   }
   if (pFinancialSeg1->bSeg24)
   {
      mapSegment24((hFinancialSeg24*)m_pSegment);
      // hFinancialSeg24* p = (hFinancialSeg24*)m_pSegment;
      // m_pSegment += sizeof(hFinancialSeg24) + p->siSegmentLength;
   }
   /*
   int m = ntohs(pData->siLength) - (m_pSegment - pData->sText);
   while (m > 0)
   {
      h2400* p = (h2400*)m_pSegment;
      if (ntohs(p->h.siHdrMsgCode) != 2400)
        break;
      mapSegment24(&p->t);
      m_pSegment += sizeof (p->h) - 28 + ntohs(p->h.siHdrMsgLength);
      m -= sizeof (p->h) - 28 + ntohs(p->h.siHdrMsgLength);
   }
   */
   if (Extract::instance()->getCustomCode() == "WOW" && sPAN_RANGE[0] != ' ')
      m_pFinancialUserSegment->setPAN_RANGE(sPAN_RANGE, sizeof(sPAN_RANGE));
   string strProcCode;
   if (m_iLinkOption
      && m_cPreAuthFlag == 'Y'
      && !memcmp(pFinancialSeg1->sProcessCode, "590080", 6))
      strProcCode.assign("590008");
   else
      strProcCode.assign(pFinancialSeg1->sProcessCode, 6);
   strProcCode.append(&m_cClass, 1);
   strProcCode.append(pFinancialSeg1->sAcctQual1, 3);
   strProcCode.append(&m_cPreauthInd, 1);
   if (pFinancialSeg1->bSeg15)
   {
      if (!memcmp(sTempTranDesc, "DLX", 3))
         strProcCode.append(sTempTranDesc + 3, 4);
      else if (pFinancialSeg1->sProcessCode[0] == '9')
         strProcCode.append(sTempTranDesc, 4);
      else
         strProcCode.append("    ");
   }
   else
      strProcCode.append("    ");
   bool bEvidence[] = { false,m_bAddEvidence };
   if (Extract::instance()->getCustomCode() == "FIS"
      && strcmp(m_pFinancialBaseSegment->zTSTAMP_TRANS(), "2020060100000000") < 0)
   {
      if (pFinancialSeg1->sActionCode[0] == '0')
         m_pFinancialBaseSegment->setACT_CODE("000", 3);
   }
   bool bFound = false;
   int iIterator = 0;
   string strTemp(strProcCode);
   string strTranTypeId;
   while (bFound == false && iIterator < 2)
   {
      if (iIterator == 1)
         strTemp.replace(7, 3, "   ", 3);
      if (ConfigurationRepository::instance()->translate("X_ADV_PROC_CODE", strTemp, strTranTypeId, "FIN_LOCATOR", "TRAN_TYPE_ID", 0, bEvidence[iIterator]))
      {
         m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2, 4).data(), 4);
         if (Extract::instance()->getCustomCode() == "FIS")
            strTranTypeId.replace(2,4,"0000",4);
         m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(), strTranTypeId.length());
         bFound = true;
      }
      iIterator++;
   }
   if (bFound == false
      && m_bAddEvidence)
   {
      if (memcmp(pFinancialSeg1->sActionCode, "005", 3) == 0)
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACT_CODE);
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   }
   if (m_hNetTermId.size() > 0 && bFound)
   {
      if ((memcmp(strTranTypeId.data(), "21", 2) == 0)
         || (memcmp(strTranTypeId.data(), "24", 2) == 0)
         || (memcmp(strTranTypeId.data(), "25", 2) == 0))
      {
         string strNET_TERM_ID(pFinancialSeg1->sNetworkTermId, 8);
         map<string, string, less<string> >::iterator pNetId;
         pNetId = m_hNetTermId.find(strNET_TERM_ID);
         if (pNetId != m_hNetTermId.end())
         {
            m_pFinancialBaseSegment->setNET_TERM_ID(pNetId->second.data(), 8);
            m_pFinancialBaseSegment->setINST_ID_ACQ(pNetId->second.data() + 8, 11);
            m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(pNetId->second.data() + 19, 11);
         }
      }
   }
   // The following checks are for non-settled transactions
   if ((Extract::instance()->getCustomCode() != "DGMC") && (pFinancialSeg1->bPrcBillFlag3bit9))
      m_pFinancialBaseSegment->setAMT_RECON_NET(0);
   if (m_iLinkOption
      && memcmp(m_pFinancialSettlementSegment->zF_TYPEn(0), "70", 2) == 0) // surcharge
   {
      double dAmt = m_pFinancialBaseSegment->getAMT_RECON_NET();
      if (m_pFinancialSettlementSegment->getF_AMTn()[0] < 0)
         dAmt += m_pFinancialSettlementSegment->getF_AMTn()[0];
      else
         dAmt -= m_pFinancialSettlementSegment->getF_AMTn()[0];
      m_pFinancialBaseSegment->setAMT_RECON_NET(dAmt);
      dAmt = m_pFinancialBaseSegment->getAMT_CARD_BILL();
      if (m_pFinancialSettlementSegment->getF_AMTn()[0] < 0)
         dAmt += m_pFinancialSettlementSegment->getF_AMTn()[0];
      else
         dAmt -= m_pFinancialSettlementSegment->getF_AMTn()[0];
      m_pFinancialBaseSegment->setAMT_CARD_BILL(dAmt);
   }
   if (m_pFinancialReversalSegment->presence() && ((Extract::instance()->getCustomCode() != "DGMC") && pFinancialSeg1->bPrcBillFlag3bit9))
      m_pFinancialReversalSegment->setO_AMT_RECON_NET(0);
   // The following code is for fraud advice records  (Visa CRIS and MasterCard RiskFinder)
   if (m_pAdvantageMessageProcessor->getMessageCode() == "0401")
   {
      m_pFinancialBaseSegment->setFIN_TYPE("800", 3);
      m_pFinancialBaseSegment->setTRAN_DISPOSITION("2", 1);
   }
   // AcqDataFmt 40 = ISO; 24 = MC Batch PI
   // Visa and MC acquirers occasionally send in duplicate files which Visa and MC
   // pass on to their issuers.  All infomation is identical except for the switch
   // time stamp.  If this is a Visa or MC acquired transaction behind an ISO PI or
   // a MC acquired transaction at the MC Batch PI we are using the time stamp to
   // prevent us from dropping the duplicate as Visa and MC will move funds for each
   // and the duplicate is required to issue a chargeback.
   if ((m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 40
      && (m_pFinancialSettlementSegment->getREF_DATA_ACQ_FMT() == 5
         || memcmp(m_pFinancialSettlementSegment->zTERM_CLASS(), "25", 2) == 0))
      || (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 24
         && m_pFinancialSettlementSegment->getREF_DATA_ACQ_FMT() == 5))
   {
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone0).data(), 16);
   }
   // AcqDataFmt 103 = Visa Base II
   else
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 103)
   {
      string strMAPPED_DUP_DATA(m_pFinancialBaseSegment->zTSTAMP_TRANS());
      strMAPPED_DUP_DATA += (string)m_pFinancialBaseSegment->zAPPROVAL_CODE();
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA.data(), strMAPPED_DUP_DATA.length());
   }
   // AcqDataFmt 20 = Cirrus
   else
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 20)
       m_pFinancialBaseSegment->setMAPPED_DUP_DATA(m_pFinancialSettlementSegment->zDATA_PRIV_ACQ() + 13, 9);
   // AcqDataFmt 57 = Cirrus Ex9.2
   else
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 57)
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(m_pFinancialSettlementSegment->zREF_DATA_ACQ() + 18, 9);
   // AcqDataFmt 77 = Visa
   else
   if ((m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 40
      && m_pFinancialSettlementSegment->getREF_DATA_ACQ_FMT() == 4)
      || m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 77)
   {
      visasms::segREF_DATA_ACQ *pREF_DATA_ACQ_Sms;
      pREF_DATA_ACQ_Sms = (struct visasms::segREF_DATA_ACQ*) m_pFinancialSettlementSegment->zREF_DATA_ACQ();
      string strTRAN_IDENTIFIER(pREF_DATA_ACQ_Sms->sTRAN_IDENTIFIER,15);
      string strMAPPED_DUP_DATA(NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone0).substr(4,12)+ strTRAN_IDENTIFIER);
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA.data(),27);
   }
   else
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 50)
   {
      string strMAPPED_DUP_DATA(m_pFinancialBaseSegment->zTSTAMP_TRANS() + 8, 8);
      mastercardmds::segREF_DATA_ACQ *pREF_DATA_ACQ;
      pREF_DATA_ACQ = (struct mastercardmds::segREF_DATA_ACQ*) m_pFinancialSettlementSegment->zREF_DATA_ACQ();
      strMAPPED_DUP_DATA.append(pREF_DATA_ACQ->sNETWORK_REF_NO, sizeof(pREF_DATA_ACQ->sNETWORK_REF_NO));
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA.data(), strMAPPED_DUP_DATA.length());
   }
// ECommerce Transactions for regional networks
   else
   if (strTRAN_DESC == "ITEC"
      && memcmp(m_pFinancialSettlementSegment->zTERM_CLASS(), "25", 2) == 0)
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone0).data(), 16);
   if (memcmp(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ(), "PS033C", 6) == 0)
   {
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ() + 29, 4);
   }
   if (strlen(m_pFinancialSettlementSegment->zMULTI_CLEAR_SEQ_NO()) > 0)
   {
      string strMAPPED_DUP_DATA(m_pFinancialBaseSegment->zMAPPED_DUP_DATA());
      strMAPPED_DUP_DATA.append(m_pFinancialSettlementSegment->zMULTI_CLEAR_SEQ_NO());
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA.data(),strMAPPED_DUP_DATA.length());
   }
   if (m_bReversal)
   {
      string strTemp;
      string strFirst(m_pFinancialBaseSegment->zMSG_RESON_CODE_ACQ());
      if (ConfigurationRepository::instance()->translate("REV_REASON", strFirst, strTemp, " ", " ", -1, false))
      {
         string strMAPPED_DUP_DATA(m_pFinancialBaseSegment->zMAPPED_DUP_DATA());
         strMAPPED_DUP_DATA.append(strTemp.data(), strTemp.length());
         m_pFinancialBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA.data(), strMAPPED_DUP_DATA.length());
      }
   }
   // check for an over-dispense transaction
   if (memcmp(m_pFinancialBaseSegment->zMSG_RESON_CODE_ACQ(), "1378", 4) == 0)
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA("100", 3);
   else
   if (memcmp(m_pFinancialBaseSegment->zMSG_RESON_CODE_ACQ(), "1385", 4) == 0
      || memcmp(m_pFinancialBaseSegment->zMSG_RESON_CODE_ACQ(), "1386", 4) == 0)// Load Provisonal credit and debit
   {
      strTranTypeId.replace(6, 1, "1", 1);
      m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(), strTranTypeId.length());
      m_pFinancialBaseSegment->setFUNC_CODE("208", 3);
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA(m_pFinancialBaseSegment->zTSTAMP_TRANS(), 16);
   }
   if (Extract::instance()->getCustomCode() == "CBA" &&
      (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 40
         && (m_pFinancialSettlementSegment->getREF_DATA_ACQ_FMT() == 0
            || memcmp(m_pFinancialSettlementSegment->zTERM_CLASS(), "25", 2) == 0)))
   {// CBA memo as acquirer not applicable to receive duplicates
      m_pFinancialBaseSegment->setMAPPED_DUP_DATA("                              ", 30);
   }
   if (!m_bCVV_CVC3)
   {
      if (pFinancialSeg1->bPrcFlag0bit5)
         m_pFinancialSettlementSegment->setCVV_CVC_RESULT("F", 1);
      else if (pFinancialSeg1->bPrcFlag0bit2)
         m_pFinancialSettlementSegment->setCVV_CVC_RESULT("P", 1);
      else
         m_pFinancialSettlementSegment->setCVV_CVC_RESULT("N", 1);
   }
   else
      m_pFinancialSettlementSegment->setCVV_CVC_RESULT("N", 1);
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 103
      && memcmp(m_pFinancialBaseSegment->zFIN_TYPE(), "020", 3) == 0
      && *m_pFinancialBaseSegment->zTRAN_DISPOSITION() == '3')
      return false;
   if (Extract::instance()->getCustomCode() == "FIS")
   {
      char szPROC_BILLING_FLGS2[16];
      FinancialUserSegment::instance()->processFlags(string(FinancialUserSegment::instance()->zPROC_BILLING_FLGSn(1), 2), szPROC_BILLING_FLGS2);
      if (memcmp(m_pFinancialBaseSegment->zCARD_ACPT_BUS_CODE(), "6011", 4) == 0
         || memcmp(m_pFinancialBaseSegment->zCARD_ACPT_BUS_CODE(), "6012", 4) == 0)
         m_pFinancialBaseSegment->setTRAN_CLASS("ATM", 3);
      else
         if (m_pFinancialUserSegment->getPIN_DATA_FMT() >= 0
            || szPROC_BILLING_FLGS2[7] == 'Y')
            m_pFinancialBaseSegment->setTRAN_CLASS("PPN", 3);
         else
            if (m_pFinancialBaseSegment->zTRAN_TYPE_ID()[6] == '1')
               m_pFinancialBaseSegment->setTRAN_CLASS("PSA", 3);
            else
               m_pFinancialBaseSegment->setTRAN_CLASS("PSS", 3);
   }
   if (m_pAdvantageMessageProcessor->getMessageCode() == "0491")
   {
      m_pFinancialBaseSegment->setAMT_CARD_BILL(0);
      m_pFinancialBaseSegment->setAMT_RECON_NET(0);
      m_pFinancialSettlementSegment->setAMT_RECON_ISS(0);
      m_pFinancialSettlementSegment->setAMT_RECON_ACQ(0);
   }
   if (Extract::instance()->getCustomCode() == "EFTPOS"
      && (memcmp(m_pFinancialSettlementSegment->zMTI(), "14", 2) == 0
         || memcmp(m_pFinancialSettlementSegment->zMTI(), "12", 2) == 0)
      && m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 30
      && m_pFinancialSettlementSegment->getF_AMTn()[0] == 0
      && memcmp(m_pFinancialSettlementSegment->zTERM_CLASS(), "02", 2) != 0)
      FeeTable::instance()->applyFees();
   else if (Extract::instance()->getCustomCode() == "FIS")
      FeeTable::instance()->applyFees();
   m_pFinancialBaseSegment->setACQ_REF_NO();
   hMessage.reset("AI LE ", "S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialSettlementSegment->write(&psBuffer);
   m_pFinancialAdjustmentSegment->write(&psBuffer);
   if (m_pFinancialReversalSegment->presence())
      m_pFinancialReversalSegment->write(&psBuffer);
   if (m_pIntegratedCircuitCardSegment->presence())
      m_pIntegratedCircuitCardSegment->write(&psBuffer);
   if (m_pMultipleRouteSegment->presence())
      m_pMultipleRouteSegment->write(&psBuffer);
   m_pFinancialUserSegment->write(&psBuffer);
   if (m_pPulseSegment->presence())
      m_pPulseSegment->write(&psBuffer);
   if (m_pSegment24->presence())
      m_pSegment24->write(&psBuffer);
   if (m_pFinancialPaymentSegment->presence())
      m_pFinancialPaymentSegment->write(&psBuffer);
   if (m_pFinancialMCDPSegment->presence())
      m_pFinancialMCDPSegment->write(&psBuffer);
   if (m_pFinancialPNBSegment->presence())
      m_pFinancialPNBSegment->write(&psBuffer);
   if (m_pFinancialAdjustmentExtensionSegment->presence())
      m_pFinancialAdjustmentExtensionSegment->write(&psBuffer);
   if (m_pFinancialAPSegment->presence())
      m_pFinancialAPSegment->write(&psBuffer);
   if (Extract::instance()->getCustomCode(1) == "TILL")
      Extract::instance()->setCustomCode("", 1);
   char* p = psBuffer + 4;
   ListSegment hListSegment;
   hListSegment.write(&psBuffer);
   int iSEQ_NO = 1;
   vector<FraudBlockSegment>::iterator pFraudBlockSegment;
   for (pFraudBlockSegment = m_hFraudBlockSegment.begin(); pFraudBlockSegment != m_hFraudBlockSegment.end(); ++pFraudBlockSegment)
   {
      pFraudBlockSegment->setSEQ_NO(iSEQ_NO++);
      pFraudBlockSegment->write(&psBuffer);
   }
   hListSegment.update(p, m_hFraudBlockSegment.size(), (int)(psBuffer - p));
   m_hFraudBlockSegment.erase(m_hFraudBlockSegment.begin(), m_hFraudBlockSegment.end());
    p = psBuffer + 4;
    hListSegment.write(&psBuffer);
    vector<CashDepositSegment>::iterator pCashDepositSegment;
    for (pCashDepositSegment = m_hCashDepositSegment.begin(); pCashDepositSegment != m_hCashDepositSegment.end();++pCashDepositSegment)
    {
       pCashDepositSegment->setSEQ_NO(iSEQ_NO++);
       pCashDepositSegment->write(&psBuffer);
    }
    hListSegment.update(p,m_hCashDepositSegment.size(),(int)(psBuffer - p));
    m_hCashDepositSegment.erase(m_hCashDepositSegment.begin(),m_hCashDepositSegment.end());
   ConfigurationRepository::instance()->write(&psBuffer, m_pFinancialBaseSegment->zTSTAMP_TRANS(), m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer, "Z999", 4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageFinancial::insert%3C618FB601D4.body
}

bool AdvantageFinancial::isAVS2 ()
{
  //## begin AdvantageFinancial::isAVS2%3C6195C90251.body preserve=yes
   if (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "AV", 2) == 0
      || memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "AR", 2) == 0)
      return true;
   else
      return false;
  //## end AdvantageFinancial::isAVS2%3C6195C90251.body
}

bool AdvantageFinancial::isCVC2_CVV2 ()
{
  //## begin AdvantageFinancial::isCVC2_CVV2%3C6195D103B9.body preserve=yes
   if (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "CV", 2) == 0
      || memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "CR", 2) == 0)
      return true;
   else if (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "AV", 2) == 0
      || memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "AR", 2) == 0)
      if (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA() + 30, "        ", 8) != 0)
         return true;
      else
         return false;
   else
      return false;
  //## end AdvantageFinancial::isCVC2_CVV2%3C6195D103B9.body
}

void AdvantageFinancial::mapSegment1 (hFinancialSeg1* pFinancialSeg1)
{
  //## begin AdvantageFinancial::mapSegment1%3C618FEE009C.body preserve=yes
   char sDate8[9] = { "20      " };
   char sDateTime14[15] = { "20            " };
   char sMTI[5] = { "    " };
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
   translate(pFinancialSeg1->sMTI,
      ((char *)(&pFinancialSeg1->siRptInstAcqrBranch) -
         pFinancialSeg1->sMTI));
   translate(pFinancialSeg1->sPan,
      ((char*)(&pFinancialSeg1->siRouteToAP) -
         pFinancialSeg1->sPan));
   translate(pFinancialSeg1->sAltProcId,
      ((char *)(&pFinancialSeg1->siAltRouteToAP) -
         pFinancialSeg1->sAltProcId));
   translate(pFinancialSeg1->sAcctType1,
      ((char *)(&pFinancialSeg1->siCurrType) -
         pFinancialSeg1->sAcctType1));
   translate(pFinancialSeg1->sCurrTran,
      ((char *)(&pFinancialSeg1->lAmtTran) -
         pFinancialSeg1->sCurrTran));
   char sSearchValue[9] = { "       " };
   if (AdvantageMessageProcessor::instance()->getVersion() == 130)
   {
      hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
      snprintf(sSearchValue, sizeof(sSearchValue), "%04d%04d", ntohs(pV13AdvantageHeader->siHdrMsgCode), ntohs(pV13AdvantageHeader->siHdrMsgStep));
      m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   }
   else
      if (AdvantageMessageProcessor::instance()->getVersion() == 120)
      {
         hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
         snprintf(sSearchValue, sizeof(sSearchValue), "%04d%04d", ntohs(pAdvantageHeader->siHdrMsgCode), ntohs(pAdvantageHeader->siHdrMsgStep));
         m_pFinancialBaseSegment->setCED_BUILD_NO(0);
      }
   // This code is for 491 messages for LINK
   if (m_pAdvantageMessageProcessor->getMessageCode() == "0491")
   {
      m_pFinancialBaseSegment->setFIN_TYPE("900", 3);
      m_bAddEvidence = false;
   }
   else
   {
      string strSearchValue(sSearchValue), strFinType;
      if (ConfigurationRepository::instance()->translate("X_ADV_MSG_CODE", strSearchValue, strFinType, "FIN_LOCATOR", "FIN_TYPE", 0))
         m_pFinancialBaseSegment->setFIN_TYPE(strFinType.data(), strFinType.length());
   }
   m_lTstampHash = ntohl(pAdvantageHeader->lHdrTstamp2Hash);
   if (Customer::instance()->getTest())
      memcpy(pFinancialSeg1->sPan + 6, "999999", 6);
   m_pFinancialBaseSegment->setPAN(pFinancialSeg1->sPan, 28);
   m_pFinancialBaseSegment->setACCT_ID_1(pFinancialSeg1->sAcctId1, 28);
   m_pFinancialBaseSegment->setACCT_ID_2(pFinancialSeg1->sAcctId2, 28);
   m_pFinancialBaseSegment->setACCT_ID_3(pFinancialSeg1->sAcctId3, 28);
   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pFinancialSeg1->sRetrievalRefNo, 12);
   m_pFinancialBaseSegment->setACT_CODE(pFinancialSeg1->sActionCode, 3);
   m_pFinancialBaseSegment->setFUNC_CODE(pFinancialSeg1->sFuncCode, 3);
   m_pFinancialBaseSegment->setCARD_ACPT_TERM_ID(pFinancialSeg1->sCardAcptTermId, 15);
   m_pFinancialBaseSegment->setNET_TERM_ID(pFinancialSeg1->sNetworkTermId, 8);
   string strNET_TERM_ID(pFinancialSeg1->sNetworkTermId, 8);
   m_cClass = pFinancialSeg1->sMTI[1];
   reformatInstId(pFinancialSeg1->sInstIdAcqr);
   m_pFinancialBaseSegment->setINST_ID_ACQ(m_sStdInstId, 11);
   if (Extract::instance()->getCustomCode() == "PAAS")
   {
      string strTenant;
      if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON", (string)m_pFinancialBaseSegment->zINST_ID_ACQ(), "", "A", strTenant))
      {
         Extract::instance()->setCustomCode("TILL", 1);
         transform(strTenant.begin(), strTenant.end(), strTenant.begin(), ::toupper);
         if (memcmp(strNET_TERM_ID.data(), m_pFinancialBaseSegment->zCARD_ACPT_TERM_ID(), 8)
            && strTenant == "TILLCNP")
         {
            strNET_TERM_ID.assign(m_pFinancialBaseSegment->zCARD_ACPT_TERM_ID(), 8);
            m_pFinancialBaseSegment->setNET_TERM_ID(strNET_TERM_ID.data(), 8);
         }
      }
   }
   reformatInstId(pFinancialSeg1->sInstIdIssr);
   m_pFinancialBaseSegment->setINST_ID_ISS(m_sStdInstId, 11);
   reformatInstId(pFinancialSeg1->sRptInstIdAcqr);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(m_sStdInstId, 11);
   string sInstId(m_sStdInstId);
   string strOverrideAcqInst;
   bool bOverride = ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON", (string)m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(), (string)m_pFinancialBaseSegment->zINST_ID_ACQ(), "A", strOverrideAcqInst);
   if (bOverride
      && strOverrideAcqInst == "INST_ID_***")
   {
      strOverrideAcqInst.assign(m_pFinancialBaseSegment->zINST_ID_ACQ());
      size_t pos = strOverrideAcqInst.find_first_of(" ");
      if (pos != string::npos)
         strOverrideAcqInst.erase(pos);
      if (strOverrideAcqInst.length() == 6)
         strOverrideAcqInst.append("001");
   }
   string strChannel;
   if (Extract::instance()->getCustomCode() == "CBA"
      && ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON", (string)m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(), "", "A", strChannel))
   {
#include "CXODAI52.hpp"
   }
   if (strChannel == "CBACNP");
   else
   if (ConfigurationRepository::instance()->translate("DEVICE", strNET_TERM_ID, m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B, "FIN_LOCATOR", "INST_ID_RECN_ACQ_B", 0, m_bAddEvidence))
   {
      string strInstIdReconAcq;
      if (m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 0)
      {
         strInstIdReconAcq.assign(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(), 11);
         if (m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 11)
            m_pFinancialBaseSegment->setRPT_LVL_ID_B(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data() + 11, m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() - 11);
      }
      if (bOverride)
         m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strOverrideAcqInst.data(), strOverrideAcqInst.length());
      else
         m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strInstIdReconAcq.data(), strInstIdReconAcq.length());
      string strProcIdAcq;
      if (ConfigurationRepository::instance()->translate("INSTITUTION", (string)m_pFinancialBaseSegment->zINST_ID_RECN_ACQ_B(), strProcIdAcq, "FIN_LOCATOR", "PROC_ID_ACQ_B", 0, m_bAddEvidence))
      {
         m_pFinancialBaseSegment->setPROC_ID_ACQ_B(strProcIdAcq.data(), strProcIdAcq.length());
         string strProcGrpIdAcq;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",
            strProcIdAcq, strProcGrpIdAcq, "FIN_LOCATOR", "PROC_GRP_ID_ACQ_B", 0, m_bAddEvidence))
            m_pFinancialBaseSegment->setPROC_GRP_ID_ACQ_B(strProcGrpIdAcq.data(), strProcGrpIdAcq.length());
      }
      else
         if (m_bAddEvidence)
         {
            ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
         }
   }
   else
      if (m_bAddEvidence)
      {
         string strSOURCE_VALUE(strNET_TERM_ID);
         strSOURCE_VALUE.resize(8, ' ');
         strSOURCE_VALUE.append(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ());
         strSOURCE_VALUE.resize(19, ' ');
         strSOURCE_VALUE.append(m_pFinancialBaseSegment->zINST_ID_ACQ());
         ConfigurationRepository::instance()->getEvidenceSegment().setSOURCE_VALUE(strSOURCE_VALUE);
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
      }
   m_pFinancialBaseSegment->setSYS_TRACE_AUDIT_NO(pFinancialSeg1->sSystemTraceAuditNo, 6);
   m_pFinancialBaseSegment->setAUTH_BY(&pFinancialSeg1->cAuthBy, 1);
   m_pFinancialBaseSegment->setAPPROVAL_CODE(pFinancialSeg1->sApprovalCode, 6);
   m_pFinancialBaseSegment->setCARD_ACPT_BUS_CODE(pFinancialSeg1->sCardAcptBusiness, 4);
   m_pFinancialBaseSegment->setCARD_ACPT_COUNTRY(pFinancialSeg1->sCardAcptCountry, 3);
   m_pFinancialBaseSegment->setCARD_ACPT_PST_CODE(pFinancialSeg1->sCardAcptPostalCode, 10);
   m_pFinancialBaseSegment->setCARD_ACPT_REGION(pFinancialSeg1->sCardAcptRegion, 3);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(pFinancialSeg1->sCardAcptNameLoc, 83);
   m_pFinancialBaseSegment->setCARD_SEQ_NO(pFinancialSeg1->sCardSeqNo, 5);
   m_pFinancialBaseSegment->setCOUNTRY_ACQ_INST(pFinancialSeg1->sCountryAcqrInst, 3);
   m_pFinancialBaseSegment->setCUR_CARD_BILL(pFinancialSeg1->sCurrCardBill, 3);
   m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg1->sCurrReconNetwork, 3);
   m_pFinancialBaseSegment->setCUR_TRAN(pFinancialSeg1->sCurrTran, 3);
   m_pFinancialBaseSegment->setMERCH_TYPE(pFinancialSeg1->sMerchType, 4);
   m_pFinancialBaseSegment->setMSG_RESON_CODE_ACQ(pFinancialSeg1->sMsgReasonCodeAcqr, 4);
   m_pFinancialBaseSegment->setNET_ID_ACQ(pFinancialSeg1->sNetworkIdAcqr, 3);
   m_pFinancialBaseSegment->setPOS_CRDHLDR_A_METH(&pFinancialSeg1->cCardholderAuthentMeth, 1);
   m_pFinancialBaseSegment->setPROC_ID_ACQ(pFinancialSeg1->sProcIdAcqr, 6);
   m_pFinancialBaseSegment->setREV_BY(&pFinancialSeg1->cRevBy, 1);
   memcpy(sDate8 + 2, pFinancialSeg1->sDateReconNetworkYYMMDD, 6);
   m_pFinancialUserSegment->setDATE_RECON_NET(sDate8, 8);
   if ((pFinancialSeg1->sDateReconAcqrYYMMDD[0] == ' ') || (memcmp(pFinancialSeg1->sDateReconAcqrYYMMDD, "000000", 6) == 0))
      m_pFinancialBaseSegment->setDATE_RECON_ACQ(m_pFinancialUserSegment->zDATE_RECON_NET(), 8);
   else
   {
      memcpy(sDate8 + 2, pFinancialSeg1->sDateReconAcqrYYMMDD, 6);
      m_pFinancialBaseSegment->setDATE_RECON_ACQ(sDate8, 8);
   }
   if (Extract::instance()->getCustomCode() == "EFTPOS")
      m_pFinancialSettlementSegment->setDATE_RECON_ISS(m_pFinancialBaseSegment->zDATE_RECON_ACQ(), 8);
   else if (pFinancialSeg1->sDateReconIssrYYMMDD[0] == ' ')
      m_pFinancialSettlementSegment->setDATE_RECON_ISS(m_pFinancialUserSegment->zDATE_RECON_NET(), 8);
   else
   {
      memcpy(sDate8 + 2, pFinancialSeg1->sDateReconIssrYYMMDD, 6);
      m_pFinancialSettlementSegment->setDATE_RECON_ISS(sDate8, 8);
   }
   memcpy(sDateTime14 + 2, pFinancialSeg1->sDateLocalYYMMDD, 6);
   memcpy(sDateTime14 + 8, pFinancialSeg1->sTimeLocalHRMNSC, 6);
   m_pFinancialBaseSegment->setTSTAMP_LOCAL(sDateTime14, 14);
   string strTemp(pFinancialSeg1->sTimeLocalHRMNSC + 4, 2);
   m_bAuthByAltRoute = (pFinancialSeg1->bPrcFlag3bit7) ? true : false;
   if (m_bAuthByAltRoute)
   {
      reformatInstId(pFinancialSeg1->sAltRptInstIdIssr);
      m_pFinancialBaseSegment->setMSG_RESON_CODE_ISS(pFinancialSeg1->sAltMsgReasonCodeIssr, 4);
      if (Extract::instance()->getCustomCode() != "CBA")
         m_pFinancialBaseSegment->setNET_ID_ISS(pFinancialSeg1->sAltNetworkIdIssr, 3);
      m_pFinancialBaseSegment->setPROC_ID_ISS(pFinancialSeg1->sAltProcId, 6);
   }
   else
   {
      reformatInstId(pFinancialSeg1->sRptInstIdIssr);
      m_pFinancialBaseSegment->setMSG_RESON_CODE_ISS(pFinancialSeg1->sMsgReasonCodeIssr, 4);
      if (Extract::instance()->getCustomCode() != "CBA")
         m_pFinancialBaseSegment->setNET_ID_ISS(pFinancialSeg1->sNetworkIdIssr, 3);
      m_pFinancialBaseSegment->setPROC_ID_ISS(pFinancialSeg1->sProcId, 6);
   }
   if (memcmp(m_sStdInstId, "           ", 11) != 0)
   {
      m_pFinancialBaseSegment->setINST_ID_RECON_ISS(m_sStdInstId, 11);
      string strINST_ID_RECN_ISS_B;
      if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON", (string)m_pFinancialBaseSegment->zINST_ID_RECON_ISS(), (string)m_pFinancialBaseSegment->zINST_ID_ISS(), "I", strINST_ID_RECN_ISS_B))
      {
         if (strINST_ID_RECN_ISS_B == "INST_ID_***")
         {
            strINST_ID_RECN_ISS_B.assign(m_pFinancialBaseSegment->zINST_ID_ISS());
            size_t pos = strINST_ID_RECN_ISS_B.find_first_of(" ");
            if (pos != string::npos)
               strINST_ID_RECN_ISS_B.erase(pos);
            if (strINST_ID_RECN_ISS_B.length() == 6)
               strINST_ID_RECN_ISS_B.append("001");
         }
      }
      else
         strINST_ID_RECN_ISS_B.assign(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(), 11);
      m_pFinancialBaseSegment->setINST_ID_RECN_ISS_B(strINST_ID_RECN_ISS_B.data(), strINST_ID_RECN_ISS_B.length());
      string strPROC_ID_ISS_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION", strINST_ID_RECN_ISS_B, strPROC_ID_ISS_B, "FIN_LOCATOR", "PROC_ID_ISS_B", 0, m_bAddEvidence))
      {
         m_pFinancialBaseSegment->setPROC_ID_ISS_B(strPROC_ID_ISS_B.data(), strPROC_ID_ISS_B.length());
         string strPROC_GRP_ID_ISS_B;
         if (ConfigurationRepository::instance()->translate("PROCESSOR", strPROC_ID_ISS_B, strPROC_GRP_ID_ISS_B, "FIN_LOCATOR", "PROC_GRP_ID_ISS_B", 0, m_bAddEvidence))
            m_pFinancialBaseSegment->setPROC_GRP_ID_ISS_B(strPROC_GRP_ID_ISS_B.data(), strPROC_GRP_ID_ISS_B.length());
      }
      else
         if (m_bAddEvidence)
            ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);
   }
   m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pFinancialSeg1->lAmtTran[0]), ntohl(pFinancialSeg1->lAmtTran[1]));
   m_pFinancialBaseSegment->setAMT_CARD_BILL(ntohl(pFinancialSeg1->lAmtCardBill[0]), ntohl(pFinancialSeg1->lAmtCardBill[1]));
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone0));
   m_pFinancialBaseSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(), 16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(), 16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp.data(), 14);
      string strCutOff(getTestDate());
      strCutOff += Customer::instance()->getCUTOFF_TIME();
      if (strTemp < strCutOff)
      {
         m_pFinancialUserSegment->setDATE_RECON_NET(getTestDate().data(), 8);
         m_pFinancialBaseSegment->setDATE_RECON_ACQ(getTestDate().data(), 8);
         m_pFinancialSettlementSegment->setDATE_RECON_ISS(getTestDate().data(), 8);
      }
      else
      {
         Date hDate(getTestDate().c_str());
         hDate += 1;
         strCutOff = hDate.asString("%Y%m%d");
         m_pFinancialUserSegment->setDATE_RECON_NET(strCutOff.data(), 8);
         m_pFinancialBaseSegment->setDATE_RECON_ACQ(strCutOff.data(), 8);
         m_pFinancialSettlementSegment->setDATE_RECON_ISS(strCutOff.data(), 8);
      }
   }
   if (!(pFinancialSeg1->bPrcFlag1bit9) &&
      !(pFinancialSeg1->bPrcFlag1bit10))
      m_cPreauthInd = '0';
   else if (pFinancialSeg1->bPrcFlag1bit9)
      m_cPreauthInd = '1';
   else
      m_cPreauthInd = '2';
   char szActionCode[4];
   memcpy(szActionCode, pFinancialSeg1->sActionCode, 3);
   szActionCode[3] = '\0';
   if (pFinancialSeg1->sMTI[1] == '4')
   {
      m_bReversal = true;
      m_pFinancialBaseSegment->setTRAN_DISPOSITION("3", 1);
      m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pFinancialSeg1->lOrigAmtTran[0]), ntohl(pFinancialSeg1->lOrigAmtTran[1]));
      if (atoi(szActionCode) > 400)    // implies rejected reversal
         m_pFinancialBaseSegment->setTRAN_DISPOSITION("2", 1);
      m_pFinancialUserSegment->setODE_INST_ID_FRWD("00000000000",11);
   }
   //It checks for Alphanumeric Action Codes
   else if ((isalpha(szActionCode[0])) || (isalpha(szActionCode[1])) || (isalpha(szActionCode[2])) || (atoi(szActionCode) > 99))
   {
      m_pFinancialBaseSegment->setTRAN_DISPOSITION("2", 1);
      m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pFinancialSeg1->lOrigAmtTran[0]), ntohl(pFinancialSeg1->lOrigAmtTran[1]));
   }
   else
      m_pFinancialBaseSegment->setTRAN_DISPOSITION("1", 1);
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(0);
   if (memcmp(pFinancialSeg1->sProcessCode, "24", 2) == 0)
   {  //set uniqueness key for check deposits
      database::UniquenessKey::hash(m_pFinancialBaseSegment->zPAN(), 16);
      database::UniquenessKey::hash(m_pFinancialBaseSegment->zRETRIEVAL_REF_NO(), 12);
      database::UniquenessKey::hash(m_pFinancialBaseSegment->zSYS_TRACE_AUDIT_NO(), 6);
      m_pFinancialBaseSegment->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   }
   if (Extract::instance()->getCustomCode() == "PNB")
   {
      m_pFinancialPNBSegment->setPresence(true);
      m_pFinancialPNBSegment->setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
      m_pFinancialPNBSegment->setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   }
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A", 1);
   if (AdvantageMessageProcessor::instance()->getTranClassLength() != 0)
   {
      string strTemp;
      string strTranClass;
      strTemp.assign(((char*)m_pSegment - m_iBufferStartp) +
         (AdvantageMessageProcessor::instance()->getTranClassOffset() - 1),
         AdvantageMessageProcessor::instance()->getTranClassLength());
      if (ConfigurationRepository::instance()->translate
      ("X_TO_TRAN_CLASS", strTemp, strTranClass,
         "FIN_LOCATOR", "TRAN_CLASS", 0, m_bAddEvidence))
         m_pFinancialBaseSegment->setTRAN_CLASS(strTranClass.data(), strTranClass.length());
   }
   // Segment 1 to SETTLEMENT table mappings
   m_pFinancialSettlementSegment->setACCT_QUAL_1(pFinancialSeg1->sAcctQual1, 3);
   m_pFinancialSettlementSegment->setACCT_QUAL_2(pFinancialSeg1->sAcctQual2, 3);
   m_pFinancialSettlementSegment->setCNV_CRD_BIL_DE_POS(&pFinancialSeg1->cConvCardBillDecPos, 1);
   m_pFinancialSettlementSegment->setCNV_CRD_BIL_RATE(pFinancialSeg1->sConvCardBillRate, 7);
   m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pFinancialSeg1->cConvReconNetworkDecPos, 1);
   m_cNetworkDecPos = pFinancialSeg1->cConvReconNetworkDecPos;
   m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pFinancialSeg1->sConvReconNetworkRate, 7);
   memcpy(m_sNetworkRate, pFinancialSeg1->sConvReconNetworkRate, 7);
   m_sNetworkRate[7] = '\0';
   m_pFinancialSettlementSegment->setCUR_TYPE(ntohs(pFinancialSeg1->siCurrType));
   m_pFinancialSettlementSegment->setCRD_ACP_NAM_FMTFLG(&pFinancialSeg1->cCardAcptInfoInd, 1);
   m_pFinancialSettlementSegment->setCARD_ACPT_ID(pFinancialSeg1->sCardAcptId, 15);
   string strCARD_ACPT_ID(m_pFinancialSettlementSegment->zCARD_ACPT_ID());
   if (strCARD_ACPT_ID.find_first_not_of(' ') == string::npos)
      m_pFinancialSettlementSegment->setCARD_ACPT_ID("BLANK", 5);
   if (m_bExpirationDate)
      m_pFinancialSettlementSegment->setDATE_EXP(pFinancialSeg1->sDateExpYYMM, 4);
   //sMTI[0] = pFinancialSeg1->cMTIVersion;
   //sMTI[1] = pFinancialSeg1->cMTIClass;
   //sMTI[2] = pFinancialSeg1->cMTIFunction;
   //sMTI[3] = pFinancialSeg1->cMTIOriginator;
   m_pFinancialSettlementSegment->setMTI(pFinancialSeg1->sMTI, 4);
   m_pFinancialSettlementSegment->setPOS_CARD_CAPT_CAP(&pFinancialSeg1->cCardCaptCap, 1);
   m_pFinancialSettlementSegment->setPOS_CRD_DAT_IN_CAP(&pFinancialSeg1->cCardDataInputCap, 1);
   m_pFinancialSettlementSegment->setPOS_CRD_DAT_IN_MOD(&pFinancialSeg1->cCardDataInputMode, 1);
   m_pFinancialSettlementSegment->setPOS_CRD_DAT_OT_CAP(&pFinancialSeg1->cCardDataOutputCap, 1);
   m_pFinancialSettlementSegment->setPOS_CRDHLDR_AUTH(&pFinancialSeg1->cCardholderAuthent, 1);
   m_pFinancialSettlementSegment->setPOS_CRDHLDR_AUTH_C(&pFinancialSeg1->cCardholderAuthentCap, 1);
   m_pFinancialSettlementSegment->setPOS_CRDHLDR_PRESNT(&pFinancialSeg1->cCardholderPres, 1);
   m_pFinancialSettlementSegment->setPOS_CARD_PRES(&pFinancialSeg1->cCardPres, 1);
   m_pFinancialSettlementSegment->setPOS_OPER_ENV(&pFinancialSeg1->cOpEnv, 1);
   m_pFinancialSettlementSegment->setPOS_PIN_CAPT_CAP(&pFinancialSeg1->cPinCaptCap, 1);
   m_pFinancialSettlementSegment->setPOS_TERM_OUT_CAP(&pFinancialSeg1->cTermOutputCap, 1);
   m_pFinancialSettlementSegment->setPRINT_MASK_ID(pFinancialSeg1->sPrintMaskId, 8);
   m_pFinancialSettlementSegment->setTERM_CLASS(pFinancialSeg1->sTermClass, 2);
   char sSPLIT_TRANS_TYPE = pFinancialSeg1->cSplitTransFlg & 0x01 ? 'Y' : 'N';
   m_pFinancialSettlementSegment->setSPLIT_TRANS_TYPE(&sSPLIT_TRANS_TYPE, 1);
   short siSPLIT_TRANS_IND = pFinancialSeg1->cSplitTransFlg;
   siSPLIT_TRANS_IND = siSPLIT_TRANS_IND >> 1;
   m_pFinancialSettlementSegment->setSPLIT_TRANS_IND(siSPLIT_TRANS_IND);
   string strReturnValue;
   string strCardCategory(pFinancialSeg1->sCardCategory, sizeof(pFinancialSeg1->sCardCategory));
   if (ConfigurationRepository::instance()->translate("X_ADV_CARD_TYPE", strCardCategory, strReturnValue, "FIN_RECORD", "CARD_TYPE", 0, m_bAddEvidence))
      m_pFinancialSettlementSegment->setCARD_TYPE(strReturnValue.data(), strReturnValue.length());
   string strCardLogoId(pFinancialSeg1->sCardLogoId, sizeof(pFinancialSeg1->sCardLogoId));
   if (ConfigurationRepository::instance()->translate("X_ADV_CARD_LOGO", strCardLogoId, strReturnValue, "FIN_RECORD", "CARD_OWNER", 0, m_bAddEvidence))
      m_pFinancialSettlementSegment->setCARD_OWNER(strReturnValue.data(), strReturnValue.length());
   (pFinancialSeg1->bPrcFlag3bit0) ? m_pFinancialSettlementSegment->setDRAFT_CAPTURE_FLG("Y", 1) :
      m_pFinancialSettlementSegment->setDRAFT_CAPTURE_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag3bit3) ? m_pFinancialSettlementSegment->setHOST_RECV_FLG("Y", 1) :
      m_pFinancialSettlementSegment->setHOST_RECV_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag3bit4) ? m_pFinancialSettlementSegment->setHOST_SENT_FLG("Y", 1) :
      m_pFinancialSettlementSegment->setHOST_SENT_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag3bit1 || pFinancialSeg1->bPrcFlag3bit2) ?
      m_pFinancialSettlementSegment->setOAR_RQST_FLG("Y", 1) :
      m_pFinancialSettlementSegment->setOAR_RQST_FLG("N", 1);
   if (pFinancialSeg1->bPrcFlag1bit1 && pFinancialSeg1->bPrcFlag1bit2)
   {
      m_pFinancialSettlementSegment->setEXCHG_MASTER("B", 1);
   }
   else if (pFinancialSeg1->bPrcFlag1bit1 &&
      !(pFinancialSeg1->bPrcFlag1bit2))
   {
      m_pFinancialSettlementSegment->setEXCHG_MASTER("A", 1);
   }
   else if (!(pFinancialSeg1->bPrcFlag1bit1) &&
      pFinancialSeg1->bPrcFlag1bit2)
   {
      m_pFinancialSettlementSegment->setEXCHG_MASTER("I", 1);
   }
   else
   {
      m_pFinancialSettlementSegment->setEXCHG_MASTER(" ", 1);
   }
   if (pFinancialSeg1->bPrcFlag3bit7)
   {
      (ntohs(pFinancialSeg1->siAltRouteToAP) > 0) ? m_pFinancialSettlementSegment->setAP_FLG("Y", 1) :
         m_pFinancialSettlementSegment->setAP_FLG("N", 1);
   }
   else
   {
      (ntohs(pFinancialSeg1->siRouteToAP) > 0) ? m_pFinancialSettlementSegment->setAP_FLG("Y", 1) :
         m_pFinancialSettlementSegment->setAP_FLG("N", 1);
   }
   short siCurrControl = 0;
   if (pFinancialSeg1->bPrcFlag0bit10)
      siCurrControl += 4;
   if (pFinancialSeg1->bPrcFlag0bit11)
      siCurrControl += 2;
   if (pFinancialSeg1->bPrcFlag0bit12)
      siCurrControl += 1;
   if (siCurrControl == 4 || siCurrControl == 5)
      m_sExchgFlag[0] = 'A';
   else if (siCurrControl == 1)
      m_sExchgFlag[0] = 'N';
   else
      m_sExchgFlag[0] = 'I';
   m_pFinancialSettlementSegment->setEXCHG_SETL(m_sExchgFlag, 1);
   if ((m_sExchgFlag[0] == 'I') && (pFinancialSeg1->bSeg14))
      ;
   else
      if ((m_sExchgFlag[0] == 'A') && (pFinancialSeg1->bSeg13))
         ;
      else
         if (((m_sExchgFlag[0] == 'I') || (m_sExchgFlag[0] == 'A'))
            && (memcmp(FinancialBaseSegment::instance()->zNET_ID_ACQ(), "MCI", 3) == 0 
               || Extract::instance()->getCustomCode() == "DGMC")
            && (FinancialBaseSegment::instance()->zFUNC_CODE()[0] != '1')) //only needed for MasterCard IPM fianancials (not auths)
         {
            m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg1->sCurrTran, 3);
            m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pFinancialSeg1->lAmtTran[0]), ntohl(pFinancialSeg1->lAmtTran[1]));
            m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS("0", 1);
            m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE("1", 1);
         }
         else
         {
            double dAmtTran = Segment::lltof(ntohl(pFinancialSeg1->lAmtTran[0]), ntohl(pFinancialSeg1->lAmtTran[1]));
            double dConvertedAmt = convertAmt(dAmtTran,
               pFinancialSeg1->cConvReconNetworkDecPos, m_sNetworkRate);
            m_pFinancialBaseSegment->setAMT_RECON_NET(dConvertedAmt);
            if (dConvertedAmt == dAmtTran)
               m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg1->sCurrTran, 3);
         }
   char sDateTime0[17], sDateTime1[17], sDateTime2[17], sDateTime3[17],
      sDateTime4[17], sDateTime6[17], sDateTime9[17], sDateTime10[17];
   char sAllZerosDateTime[17];
   memset(sAllZerosDateTime, '0', sizeof(sAllZerosDateTime));
   sAllZerosDateTime[16] = '\0';
   sDateTime0[16] = '\0';
   sDateTime1[16] = '\0';
   sDateTime2[16] = '\0';
   sDateTime3[16] = '\0';
   sDateTime4[16] = '\0';
   sDateTime6[16] = '\0';
   sDateTime9[16] = '\0';
   sDateTime10[16] = '\0';
   memcpy(sDateTime0, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone0,false).data(), 16);
   memcpy(sDateTime1, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone1,false).data(), 16);
   memcpy(sDateTime2, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone2,false).data(), 16);
   memcpy(sDateTime3, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone3,false).data(), 16);
   memcpy(sDateTime4, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone4,false).data(), 16);
   memcpy(sDateTime6, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone6,false).data(), 16);
   memcpy(sDateTime9, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone9,false).data(), 16);
   memcpy(sDateTime10, NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone10,false).data(), 16);
   if (Extract::instance()->getCustomCode() == "PNB")
   {
      m_pFinancialPNBSegment->setPresence(true);
      m_pFinancialPNBSegment->setTIME_TO_ISSR(sDateTime1, min(size_t(16), strlen(sDateTime1)));
      m_pFinancialPNBSegment->setTIME_FRM_ISSR(sDateTime2, min(size_t(16), strlen(sDateTime2)));
   }
   if (!strcmp(sDateTime6, sAllZerosDateTime))
      strcpy(sDateTime6, sDateTime1);
   if (!strcmp(sDateTime4, sAllZerosDateTime))
      strcpy(sDateTime4, sDateTime3);
   if ((atof(sDateTime6)) < (atof(sDateTime0)))
      strcpy(sDateTime6, sDateTime0);
   if (atof(sDateTime4) > 0
      && ((atof(sDateTime4)) < (atof(sDateTime2))))
      strcpy(sDateTime4, sDateTime2);
   if ((!strcmp(sDateTime9, sAllZerosDateTime)) ||
      (!strcmp(sDateTime10, sAllZerosDateTime)))
      m_pFinancialSettlementSegment->setTIME_AT_AP(0);
   else
   {
      DateTime hDateTime9;
      DateTime hDateTime10;
      hDateTime9.setDateTime(sDateTime9);
      hDateTime10.setDateTime(sDateTime10);
      m_pFinancialSettlementSegment->setTIME_AT_AP((short)hDateTime10.calcQueueTime(hDateTime9));
   }
   if ((!strcmp(sDateTime2, sAllZerosDateTime)) ||
      (!strcmp(sDateTime1, sAllZerosDateTime)))
   {
      m_pFinancialSettlementSegment->setTIME_AT_ISS(0);
   }
   else
   {
      DateTime hDateTime1;
      DateTime hDateTime2;
      hDateTime1.setDateTime(sDateTime1);
      hDateTime2.setDateTime(sDateTime2);
      m_pFinancialSettlementSegment->setTIME_AT_ISS((short)hDateTime2.calcQueueTime(hDateTime1));
   }
   if ((!strcmp(sDateTime1, sAllZerosDateTime)) ||
      (!strcmp(sDateTime6, sAllZerosDateTime)))
   {
      m_pFinancialSettlementSegment->setTIME_AT_RESP_QUE(0);
   }
   else
   {
      DateTime hDateTime6;
      DateTime hDateTime1;
      hDateTime6.setDateTime(sDateTime6);
      hDateTime1.setDateTime(sDateTime1);
      m_pFinancialSettlementSegment->setTIME_AT_RESP_QUE((short)hDateTime1.calcQueueTime(hDateTime6));
   }
   if ((!strcmp(sDateTime2, sAllZerosDateTime)) ||
      (!strcmp(sDateTime4, sAllZerosDateTime)))
   {
      m_pFinancialSettlementSegment->setTIME_AT_RESP_SWTCH(0);
   }
   else
   {
      DateTime hDateTime2;
      DateTime hDateTime4;
      hDateTime2.setDateTime(sDateTime2);
      hDateTime4.setDateTime(sDateTime4);
      m_pFinancialSettlementSegment->setTIME_AT_RESP_SWTCH((short)hDateTime4.calcQueueTime(hDateTime2));
   }
   if ((!strcmp(sDateTime3, sAllZerosDateTime)) ||
      (!strcmp(sDateTime4, sAllZerosDateTime)))
   {
      m_pFinancialSettlementSegment->setTIME_AT_RQST_QUE(0);
   }
   else
   {
      DateTime hDateTime4;
      DateTime hDateTime3;
      hDateTime4.setDateTime(sDateTime4);
      hDateTime3.setDateTime(sDateTime3);
      m_pFinancialSettlementSegment->setTIME_AT_RQST_QUE
      ((short)hDateTime3.calcQueueTime(hDateTime4));
   }
   if ((!strcmp(sDateTime4, sAllZerosDateTime)) ||
      (!strcmp(sDateTime0, sAllZerosDateTime)))
   {
      m_pFinancialSettlementSegment->setTIME_AT_RQST_SWTCH(0);
   }
   else
   {
      DateTime hDateTime0;
      DateTime hDateTime4;
      hDateTime0.setDateTime(sDateTime0);
      hDateTime4.setDateTime(sDateTime4);
      m_pFinancialSettlementSegment->setTIME_AT_RQST_SWTCH
      ((short)hDateTime4.calcQueueTime(hDateTime0));
   }
   m_pFinancialSettlementSegment->setCARD_LOGO_ID(pFinancialSeg1->sCardLogoId, 8);
   m_pFinancialSettlementSegment->setCOUNTRY_PAN(pFinancialSeg1->sCountryPan, 3);
   // Segment 1 to USER OPTION table mappings
   m_pFinancialUserSegment->setACCT_TYPE_1(pFinancialSeg1->sAcctType1, 4);
   m_pFinancialUserSegment->setACCT_TYPE_2(pFinancialSeg1->sAcctType2, 4);
   m_pFinancialUserSegment->setACCT_TYPE_3(pFinancialSeg1->sAcctType3, 4);
   m_pFinancialUserSegment->setAUTH_LCYCLE_TCODE((const char*)&pFinancialSeg1->cAuthLifeCycleTimeCode, 1);
   m_pFinancialUserSegment->setAUTH_LIFECYCLE_INT(pFinancialSeg1->sAuthLifeCycleTimeInterval, 2);
   m_pFinancialUserSegment->setCARD_ACPT_COUNTY(pFinancialSeg1->sCardAcptCounty, 3);
   if (m_bAuthByAltRoute)
      m_pFinancialUserSegment->setCARD_ACPT_SPNSR_ID(pFinancialSeg1->sAltSponsorBankId, 11);
   else
      m_pFinancialUserSegment->setCARD_ACPT_SPNSR_ID(pFinancialSeg1->sSponsorBankId, 11);
   m_pFinancialUserSegment->setCLERK_ID(pFinancialSeg1->sClerkId, 28);
   m_pFinancialUserSegment->setCNTRY_RCN_ISS_INST(pFinancialSeg1->sCountryAuthAgentInst, 3);
   m_pFinancialUserSegment->setDATE_EFFECTIVE(pFinancialSeg1->sDateEffectYYMM, 4);
   m_pFinancialUserSegment->setEXTENDED_PAY_DATA(pFinancialSeg1->sExtPayData, 2);
   m_pFinancialUserSegment->setRECON_IND_ACQ(pFinancialSeg1->sReconIndAcqr, 3);
   hProcessFlags* pProcessFlags = (hProcessFlags*)(pFinancialSeg1->sCurrCardBill + 55);
   m_pFinancialUserSegment->setPROC_FLGSn((char*)&pProcessFlags->siProcFlag1, 2, 0);
   m_pFinancialUserSegment->setPROC_FLGSn((char*)&pProcessFlags->siProcFlag2, 2, 1);
   m_pFinancialUserSegment->setPROC_FLGSn((char*)&pProcessFlags->siProcFlag3, 2, 2);
   m_pFinancialUserSegment->setPROC_FLGSn((char*)&pProcessFlags->siProcFlag4, 2, 3);
   hProcessBillingFlags* pProcessBillingFlags = (hProcessBillingFlags*)(pFinancialSeg1->sCurrCardBill + 63);
   m_pFinancialUserSegment->setPROC_BILLING_FLGSn((char*)&pProcessBillingFlags->siProcBillFlag1, 2, 0);
   m_pFinancialUserSegment->setPROC_BILLING_FLGSn((char*)&pProcessBillingFlags->siProcBillFlag2, 2, 1);
   m_pFinancialUserSegment->setPROC_BILLING_FLGSn((char*)&pProcessBillingFlags->siProcBillFlag3, 2, 2);
   m_pFinancialUserSegment->setPROC_BILLING_FLGSn((char*)&pProcessBillingFlags->siProcBillFlag4, 2, 3);
   m_pFinancialUserSegment->setCARD_CAPT_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag3bit7) ? m_pFinancialUserSegment->setALT_ROUTE_FLG("Y", 1) :
      m_pFinancialUserSegment->setALT_ROUTE_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag2bit0) ? m_pFinancialUserSegment->setDEPOSIT_ONLY_FLG("Y", 1) :
      m_pFinancialUserSegment->setDEPOSIT_ONLY_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag0bit9) ? m_pFinancialUserSegment->setTRAN_FROM_ACCT_FLG("Y", 1) :
      m_pFinancialUserSegment->setTRAN_FROM_ACCT_FLG("N", 1);
   (pFinancialSeg1->bPrcFlag0bit9) ? m_pFinancialUserSegment->setTRAN_TO_ACCT_FLG("Y", 1) :
      m_pFinancialUserSegment->setTRAN_TO_ACCT_FLG("N", 1);
   m_pFinancialReversalSegment->setPresence(true);
   m_pFinancialReversalSegment->setTSTAMP_REV_CREATED(NonStopClock::getYYYYMMDDHHMMSShh(pFinancialSeg1->sMilestone5).data(), 16);
   if (m_bReversal && getTestDate().length() == 0 && 
      memcmp(m_pFinancialBaseSegment->zTSTAMP_TRANS(), m_pFinancialReversalSegment->zTSTAMP_REV_CREATED(), 16) < 0)
      m_pFinancialBaseSegment->setTSTAMP_TRANS(m_pFinancialReversalSegment->zTSTAMP_REV_CREATED(), 16);
   m_pFinancialReversalSegment->setO_AMT_CARD_BILL(ntohl(pFinancialSeg1->lOrigAmtCardBill[0]), ntohl(pFinancialSeg1->lOrigAmtCardBill[1]));
   m_pFinancialReversalSegment->setO_AMT_RECON_ACQ(ntohl(pFinancialSeg1->lOrigAmtReconAcqr[0]), ntohl(pFinancialSeg1->lOrigAmtReconAcqr[1]));
   m_pFinancialReversalSegment->setO_AMT_RECON_ISS(ntohl(pFinancialSeg1->lOrigAmtReconIssr[0]), ntohl(pFinancialSeg1->lOrigAmtReconIssr[1]));
   m_pFinancialReversalSegment->setO_AMT_TRAN(ntohl(pFinancialSeg1->lOrigAmtTran[0]), ntohl(pFinancialSeg1->lOrigAmtTran[1]));
   if (((m_sExchgFlag[0] == 'I') && (pFinancialSeg1->bSeg14)) ||
      ((m_sExchgFlag[0] == 'A') && (pFinancialSeg1->bSeg13)))
      ;
   else
   {
      double dAmtTran = Segment::lltof(ntohl(pFinancialSeg1->lOrigAmtTran[0]), ntohl(pFinancialSeg1->lOrigAmtTran[1]));
      double dConvertedAmt = convertAmt(dAmtTran, pFinancialSeg1->cConvReconNetworkDecPos, m_sNetworkRate);
      m_pFinancialReversalSegment->setO_AMT_RECON_NET(dConvertedAmt);
   }
   //map Field 7 for ILK/Visa/Plus/EFTPOS transactions
   string strTSTAMP_LOCAL_ADJ(m_pFinancialBaseSegment->zTSTAMP_LOCAL(), 4);
   strTSTAMP_LOCAL_ADJ.append(pFinancialSeg1->sDateTransRqstMMDD);
   strTSTAMP_LOCAL_ADJ.append(pFinancialSeg1->sTimeTransRqstHRMNSC);
   m_pFinancialAdjustmentSegment->setTSTAMP_LOCAL_ADJ(strTSTAMP_LOCAL_ADJ.c_str(), 14);
   m_pFinancialAdjustmentSegment->setPresence(true);
  //## end AdvantageFinancial::mapSegment1%3C618FEE009C.body
}

void AdvantageFinancial::mapSegment2 (hFinancialSeg2* pFinancialSeg2)
{
  //## begin AdvantageFinancial::mapSegment2%3C619041030D.body preserve=yes
   char sDate8[9] = { "20      " };
   translate(pFinancialSeg2->sControllerId, ((char*)(&pFinancialSeg2->siStandinOpt) - pFinancialSeg2->sControllerId));
   translate(pFinancialSeg2->sStandinLimits, sizeof(pFinancialSeg2->sStandinLimits));
   translate(pFinancialSeg2->sOnlineFeeGrp, sizeof(pFinancialSeg2->sOnlineFeeGrp));
   translate(pFinancialSeg2->sSegmentLogOptAcqr, (&pFinancialSeg2->cFiller6 - pFinancialSeg2->sSegmentLogOptAcqr));
   m_pFinancialBaseSegment->setCIRC_ID_ACQ(pFinancialSeg2->sCircIdAcqr, 8);
   m_pFinancialBaseSegment->setCIRC_ID_ISS(pFinancialSeg2->sCircIdIssr, 8);
   if (memcmp(pFinancialSeg2->sDateActYYMMDD, "      ", 6) != 0)
   {
   memcpy(sDate8 + 2, pFinancialSeg2->sDateActYYMMDD, 6);
   m_pFinancialUserSegment->setDATE_ACTION(sDate8, 8);
   }
   m_pFinancialUserSegment->setDATE_CAPTURE(pFinancialSeg2->sDateCaptMMDD, 4);
   m_pFinancialUserSegment->setRESTRIC_INTCHG_GRP(pFinancialSeg2->sRestrictGrp, 8);
   m_pFinancialUserSegment->setTRANSET_ID(pFinancialSeg2->sTransetId, 8);
   m_pFinancialUserSegment->setROUTELIST_ID(pFinancialSeg2->sRouteListId, 8);
   m_pFinancialUserSegment->setCARD_OPT_ID(pFinancialSeg2->sCardOptId, 8);
   m_pFinancialUserSegment->setSOURCE_ROUTE_ID(pFinancialSeg2->sSourceRouteId, 8);
   m_pFinancialUserSegment->setSTANDIN_ACT(&pFinancialSeg2->cStandinAct, 1);
   m_pFinancialUserSegment->setTRACK_INFO_KEY_ID(pFinancialSeg2->sTrackInfoId, 8);
   m_pFinancialUserSegment->setTRACINF_KEYTRAC_NO(&pFinancialSeg2->cTrackInfoTrackNo, 1);
   if (m_bTrack2)
   {
      if (pFinancialSeg2->cTrack32Ind == '2')
         m_pFinancialSettlementSegment->setTRACK_2_DATA(pFinancialSeg2->sTrack32Data, 37);
      else
      {
         if (pFinancialSeg2->cTrack12Ind == '2')
            m_pFinancialSettlementSegment->setTRACK_2_DATA(pFinancialSeg2->sTrack12Data, 37);
         else
         {
            if (pFinancialSeg2->cTrack12Ind == '1')
               m_pFinancialSettlementSegment->setTRACK_2_DATA(pFinancialSeg2->sTrack12Data, 40);
         }
      }
   }
   m_pFinancialUserSegment->setSRV_GRP_INTCHG_IND(&pFinancialSeg2->cIchgDesignator, 1);
   m_pFinancialUserSegment->setSRV_GRP_SERV_CODE(pFinancialSeg2->sServCode, 2);
   m_pFinancialUserSegment->setSTANDIN_OPTION(ntohs(pFinancialSeg2->siStandinOpt));
   m_pFinancialUserSegment->setAUTH_RQST_TIMEOUT(ntohs(pFinancialSeg2->siAuthRqstTimer));
   m_pFinancialUserSegment->setPIN_DATA_FMT(ntohs(pFinancialSeg2->siPinDataFormat));
   m_pFinancialUserSegment->setPMC_ERROR(ntohs(pFinancialSeg2->siPmcErrors));
   m_pFinancialUserSegment->setUSAGE_UPDATE_BITS(ntohs(pFinancialSeg2->siUsageUpdateFlag));
   m_pFinancialUserSegment->setPIN_RESULT(ntohs(pFinancialSeg2->siPinResults));
   m_pFinancialUserSegment->setPREAUTH_COMP_OPT(ntohs(pFinancialSeg2->siPreauthCompletionOpt));
   m_pFinancialSettlementSegment->setCARD_INTRCHG_ID(pFinancialSeg2->sCoptIcngId, 8);
  //## end AdvantageFinancial::mapSegment2%3C619041030D.body
}

void AdvantageFinancial::mapSegment3 (hFinancialSeg3* pFinancialSeg3)
{
  //## begin AdvantageFinancial::mapSegment3%3C6190430148.body preserve=yes

   m_pFinancialSettlementSegment->setDATA_PRIV_ACQ_FMT(ntohs(pFinancialSeg3->siCnxDataFormatAcqr));
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 77)
   {
      struct visasms::segDATA_PRIV_ACQ *pDATA_PRIV_ACQ_Sms;
      pDATA_PRIV_ACQ_Sms = (struct visasms::segDATA_PRIV_ACQ*) pFinancialSeg3->sCnxDataPrivAcqr;
      translate(pDATA_PRIV_ACQ_Sms->sSrcID, offsetof(visasms::segDATA_PRIV_ACQ, sMsgStatusFlags) + 2 - offsetof(visasms::segDATA_PRIV_ACQ, sSrcID));
      translate(pDATA_PRIV_ACQ_Sms->sBase2Flags, offsetof(visasms::segDATA_PRIV_ACQ, sFiller3) + 55 - offsetof(visasms::segDATA_PRIV_ACQ, sBase2Flags));
   }
   else
      translate(pFinancialSeg3->sCnxDataPrivAcqr, sizeof(pFinancialSeg3->sCnxDataPrivAcqr));
   m_pFinancialSettlementSegment->setDATA_PRIV_ACQ(pFinancialSeg3->sCnxDataPrivAcqr, 100);
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 7)
   {
      vocalink::segDATA_PRIV_ACQ *r = (struct vocalink::segDATA_PRIV_ACQ*)pFinancialSeg3->sCnxDataPrivAcqr;
      m_pFinancialBaseSegment->setPOS_CRDHLDR_A_METH(&r->cPOS_CRDHLDR_A_METH, 1);
      m_pFinancialSettlementSegment->setPOS_CARD_CAPT_CAP(&r->cPOS_CARD_CAPT_CAP, 1);
      m_pFinancialSettlementSegment->setPOS_CRD_DAT_IN_CAP(&r->cPOS_CRD_DAT_IN_CAP, 1);
      m_pFinancialSettlementSegment->setPOS_CRD_DAT_IN_MOD(&r->cPOS_CRD_DAT_IN_MOD, 1);
      m_pFinancialSettlementSegment->setPOS_CRD_DAT_OT_CAP(&r->cPOS_CRD_DAT_OT_CAP, 1);
      m_pFinancialSettlementSegment->setPOS_CRDHLDR_AUTH(&r->cPOS_CRDHLDR_AUTH, 1);
      m_pFinancialSettlementSegment->setPOS_CRDHLDR_AUTH_C(&r->cPOS_CRDHLDR_AUTH_C, 1);
      m_pFinancialSettlementSegment->setPOS_CRDHLDR_PRESNT(&r->cPOS_CRDHLDR_PRESNT, 1);
      m_pFinancialSettlementSegment->setPOS_CARD_PRES(&r->cPOS_CARD_PRES, 1);
      m_pFinancialSettlementSegment->setPOS_OPER_ENV(&r->cPOS_OPER_ENV, 1);
      m_pFinancialSettlementSegment->setPOS_PIN_CAPT_CAP(&r->cPOS_PIN_CAPT_CAP, 1);
      m_pFinancialSettlementSegment->setPOS_TERM_OUT_CAP(&r->cPOS_TERM_OUT_CAP, 1);
      char sDATA_PRIV_ACQ[100];
      memcpy(sDATA_PRIV_ACQ, m_pFinancialSettlementSegment->zDATA_PRIV_ACQ(), 100);
      r = (struct vocalink::segDATA_PRIV_ACQ*)sDATA_PRIV_ACQ;
      memset(r->sBitmap, ' ', sizeof(r->sBitmap));
      m_pFinancialSettlementSegment->setDATA_PRIV_ACQ(sDATA_PRIV_ACQ, 100);
   }
  //## end AdvantageFinancial::mapSegment3%3C6190430148.body
}

void AdvantageFinancial::mapSegment4 (hFinancialSeg4* pFinancialSeg4)
{
  //## begin AdvantageFinancial::mapSegment4%3C6190430261.body preserve=yes
   m_pFinancialSettlementSegment->setDATA_PRIV_ISS_FMT(ntohs(pFinancialSeg4->siCnxDataFormatIssr));
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ISS_FMT() == 77)
   {
      visasms::segDATA_PRIV_ISS *pDATA_PRIV_ISS_Sms;
      pDATA_PRIV_ISS_Sms = (struct visasms::segDATA_PRIV_ISS*) pFinancialSeg4->sCnxDataPrivIssr;
      translate(pDATA_PRIV_ISS_Sms->sAcquirerMember, offsetof(visasms::segDATA_PRIV_ISS, cSettlementServiceInd) - offsetof(visasms::segDATA_PRIV_ISS, sAcquirerMember));
      translate(pDATA_PRIV_ISS_Sms->sFiller3, offsetof(visasms::segDATA_PRIV_ISS, sFiller3) + 36 - (offsetof(visasms::segDATA_PRIV_ISS, cSettlementServiceInd) + 1));
   }
   else
      translate(pFinancialSeg4->sCnxDataPrivIssr, sizeof(pFinancialSeg4->sCnxDataPrivIssr));
   m_pFinancialSettlementSegment->setDATA_PRIV_ISS(pFinancialSeg4->sCnxDataPrivIssr, 100);
  //## end AdvantageFinancial::mapSegment4%3C6190430261.body
}

void AdvantageFinancial::mapSegment5 (hFinancialSeg5* pFinancialSeg5)
{
  //## begin AdvantageFinancial::mapSegment5%3C619043036B.body preserve=yes
   for (int i = 0; i <= 5; ++i)
   {
      translate(pFinancialSeg5->hEntry5[i].sAcctTypeRespn, 8);
      m_pFinancialUserSegment->setADL_RESP_ACCT_TYPn(pFinancialSeg5->hEntry5[i].sAcctTypeRespn, 2, i);
      m_pFinancialUserSegment->setADL_RESP_AMT_TYPn(pFinancialSeg5->hEntry5[i].sAmtTypeRespn, 2, i);
      m_pFinancialUserSegment->setADL_RESP_CUR_CODEn(pFinancialSeg5->hEntry5[i].sCurrCodeRespn, 3, i);
      m_pFinancialUserSegment->setADL_RESP_ACCT_IDXn(ntohs(pFinancialSeg5->hEntry5[i].siAcctIdxRespn), i);
      m_pFinancialUserSegment->setADL_RESP_AMTn(ntohl(pFinancialSeg5->hEntry5[i].lAmtRespn[0]), ntohl(pFinancialSeg5->hEntry5[i].lAmtRespn[1]), i);
   }
  //## end AdvantageFinancial::mapSegment5%3C619043036B.body
}

void AdvantageFinancial::mapSegment6 (hFinancialSeg6* pFinancialSeg6)
{
  //## begin AdvantageFinancial::mapSegment6%3C619044008C.body preserve=yes
   translate(pFinancialSeg6->sApCardGrp, ((char*)(&pFinancialSeg6->siApRejReasonCode) - pFinancialSeg6->sApCardGrp));
   m_pFinancialUserSegment->setAP_APPROVAL_CODE(pFinancialSeg6->sApApprovalCode, 6);
   m_pFinancialUserSegment->setAP_CARD_GRP(pFinancialSeg6->sApCardGrp, 8);
   m_pFinancialUserSegment->setAP_DATA(pFinancialSeg6->sApData, 8);
   m_pFinancialUserSegment->setAP_ERROR_NO(ntohs(pFinancialSeg6->siApErrorNo));
   m_pFinancialUserSegment->setAP_ERROR_TRACE_LOC(ntohs(pFinancialSeg6->siApErrorTraceLoc));
   m_pFinancialUserSegment->setAP_REJ_REASON_CODE(ntohs(pFinancialSeg6->siApRejReasonCode));
   m_pFinancialUserSegment->setAP_PROCESS_ID(pFinancialSeg6->sApProcessId, 6);
   m_pFinancialUserSegment->setAP_RULE_ID(pFinancialSeg6->sApRuleId, 8);
   m_pFinancialUserSegment->setAP_FILE_NO(pFinancialSeg6->siApFileNo);
  //## end AdvantageFinancial::mapSegment6%3C619044008C.body
}

void AdvantageFinancial::mapSegment7 (hFinancialSeg7* pFinancialSeg7)
{
  //## begin AdvantageFinancial::mapSegment7%3C6190440186.body preserve=yes
   translate(pFinancialSeg7->sAdtlRespData, sizeof(hFinancialSeg7));
   m_pFinancialSettlementSegment->setADL_RESP_DATA(pFinancialSeg7->sAdtlRespData, 99);
  //## end AdvantageFinancial::mapSegment7%3C6190440186.body
}

void AdvantageFinancial::mapSegment8 (hFinancialSeg8* pFinancialSeg8)
{
  //## begin AdvantageFinancial::mapSegment8%3C619044029F.body preserve=yes
   translate(pFinancialSeg8->sTranUniqDataFormat, sizeof(hFinancialSeg8));
   m_pFinancialSettlementSegment->setTRAN_UNIQ_DATA_FMT(pFinancialSeg8->sTranUniqDataFormat, 2);
   m_pFinancialSettlementSegment->setTRAN_UNIQUE_DATA(pFinancialSeg8->sTranUniqDataInfo, 50);
   if (isAVS2() || (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "CV", 2) == 0)
      || (memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "CR", 2) == 0))
   {
      if (m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()[31] != ' ')
         m_pFinancialSettlementSegment->setCVV2_CVC2_RESULT((m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()) + 31, 1);
      else
         if (m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()[30] != ' ')
            m_pFinancialSettlementSegment->setCVV2_CVC2_RESULT((m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()) + 30, 1);
         else
            m_pFinancialSettlementSegment->setCVV2_CVC2_RESULT(" ", 1);
   }
   if ((memcmp(m_pFinancialSettlementSegment->zTRAN_UNIQ_DATA_FMT(), "VR", 2) == 0) ||
      ((isAVS2() || isCVC2_CVV2()) && (m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()[38] != ' ')))
      m_pFinancialSettlementSegment->setCAVV_RESULT((m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA()) + 38, 1);
   if (pFinancialSeg8->sTranUniqDataInfo[43] != ' '
      || pFinancialSeg8->sTranUniqDataInfo[44] != ' ')
      m_bCVV_CVC3 = true;
  //## end AdvantageFinancial::mapSegment8%3C619044029F.body
}

void AdvantageFinancial::mapSegment9 (hFinancialSeg9* pFinancialSeg9)
{
  //## begin AdvantageFinancial::mapSegment9%3C61904403A9.body preserve=yes
   for (int i = 0; i <= 5; ++i)
   {
      translate(pFinancialSeg9->Seg9Sub[i].sAcctTypeRqst, 8);
      m_pFinancialUserSegment->setADL_RQST_ACCT_IDXn(ntohs(pFinancialSeg9->Seg9Sub[i].siAcctIdxRqst), i);
      m_pFinancialUserSegment->setADL_RQST_ACCT_TYPn(pFinancialSeg9->Seg9Sub[i].sAcctTypeRqst, 2, i);
      m_pFinancialUserSegment->setADL_RQST_AMTn(ntohl(pFinancialSeg9->Seg9Sub[i].lAmtRqst[0]), ntohl(pFinancialSeg9->Seg9Sub[i].lAmtRqst[1]), i);
      m_pFinancialUserSegment->setADL_RQST_AMT_TYPn(pFinancialSeg9->Seg9Sub[i].sAmtTypeRqst, 2, i);
      m_pFinancialUserSegment->setADL_RQST_CUR_CODEn(pFinancialSeg9->Seg9Sub[i].sCurrCodeRqst, 3, i);
   }
  //## end AdvantageFinancial::mapSegment9%3C61904403A9.body
}

void AdvantageFinancial::mapSegment10 (hFinancialSeg10* pFinancialSeg10)
{
  //## begin AdvantageFinancial::mapSegment10%3C61904500CB.body preserve=yes
   for (int i = 0; i <= 7; ++i)
   {
      m_pFinancialSettlementSegment->setCAN_ITEM_VALUEn(ntohl(pFinancialSeg10->hB[i].lItemValuen), i);
      m_pFinancialSettlementSegment->setCAN_NO_ITEMS_DISPn(ntohs(pFinancialSeg10->hA[i].siNbrItemsDispn), i);
      m_pFinancialSettlementSegment->setCAN_ORIG_NO_ITEMSn(ntohs(pFinancialSeg10->hC[i].siOrigNbrItemsn), i);
   }
  //## end AdvantageFinancial::mapSegment10%3C61904500CB.body
}

void AdvantageFinancial::mapSegment11 (hFinancialSeg11* pFinancialSeg11)
{
  //## begin AdvantageFinancial::mapSegment11%3C61904501F4.body preserve=yes
   translate(&pFinancialSeg11->cRefDataFormatAcqr, sizeof(hFinancialSeg11));
   if (pFinancialSeg11->cRefDataFormatAcqr >= 'A' && pFinancialSeg11->cRefDataFormatAcqr <= 'Z')
      m_pFinancialSettlementSegment->setREF_DATA_ACQ_FMT(pFinancialSeg11->cRefDataFormatAcqr - 'A' + 10);
   else
      m_pFinancialSettlementSegment->setREF_DATA_ACQ_FMT(&pFinancialSeg11->cRefDataFormatAcqr, 1);
   if (pFinancialSeg11->cRefDataFormatAcqr == '5')
   {
      char sREF_DATA_ACQ[100];
      memset(sREF_DATA_ACQ, ' ', sizeof(sREF_DATA_ACQ));
      memcpy(sREF_DATA_ACQ, pFinancialSeg11->sRefDataAcqr, 84);
      memcpy(sREF_DATA_ACQ + 86, pFinancialSeg11->sRefDataAcqr + 84, sizeof(pFinancialSeg11->sRefDataAcqr) - 86);
      m_pFinancialSettlementSegment->setREF_DATA_ACQ(sREF_DATA_ACQ, 99);
   }
   else
      m_pFinancialSettlementSegment->setREF_DATA_ACQ(pFinancialSeg11->sRefDataAcqr, 99);
  //## end AdvantageFinancial::mapSegment11%3C61904501F4.body
}

void AdvantageFinancial::mapSegment12 (hFinancialSeg12* pFinancialSeg12)
{
  //## begin AdvantageFinancial::mapSegment12%3C61904502FD.body preserve=yes
   translate(&pFinancialSeg12->cRefDataFormatIssr, sizeof(hFinancialSeg12));
   m_pFinancialSettlementSegment->setREF_DATA_ISS_FMT(&pFinancialSeg12->cRefDataFormatIssr, 1);
   m_pFinancialSettlementSegment->setREF_DATA_ISS(pFinancialSeg12->sRefDataIssr, 99);
  //## end AdvantageFinancial::mapSegment12%3C61904502FD.body
}

void AdvantageFinancial::mapSegment13 (hFinancialSeg13* pFinancialSeg13)
{
  //## begin AdvantageFinancial::mapSegment13%3C619046001F.body preserve=yes
   if (pFinancialSeg13 == 0)
   {
      if (*m_pFinancialBaseSegment->zTRAN_DISPOSITION() != '2')
      {
         m_pFinancialSettlementSegment->setAMT_RECON_ACQ(m_pFinancialBaseSegment->getAMT_TRAN());
         m_pFinancialSettlementSegment->setCNV_RCN_ACQ_RATE(1);
         m_pFinancialSettlementSegment->setCUR_RECON_ACQ(m_pFinancialBaseSegment->zCUR_TRAN(), 3);
      }
      return;
   }
   translate(pFinancialSeg13->sCurrReconAcqr, ((char*)(&pFinancialSeg13->lAmtReconAcqr) - pFinancialSeg13->sCurrReconAcqr));
   m_pFinancialSettlementSegment->setAMT_RECON_ACQ(ntohl(pFinancialSeg13->lAmtReconAcqr[0]), ntohl(pFinancialSeg13->lAmtReconAcqr[1]));
   m_pFinancialSettlementSegment->setCNV_RCN_ACQ_DE_POS(&pFinancialSeg13->cReconAcqrDecPos, 1);
   m_pFinancialSettlementSegment->setCNV_RCN_ACQ_RATE(pFinancialSeg13->sReconAcqrRate, 7);
   m_pFinancialSettlementSegment->setCUR_RECON_ACQ(pFinancialSeg13->sCurrReconAcqr, 3);
   m_pFinancialUserSegment->setDATE_CNV_ACQ(pFinancialSeg13->sDateConvAcqrMMDD, 4);
   if (m_sExchgFlag[0] == 'A'
      || memcmp(m_pFinancialSettlementSegment->zCUR_RECON_ACQ(), m_pFinancialBaseSegment->zCUR_RECON_NET(), 3) == 0)
   {
      m_pFinancialSettlementSegment->setEXCHG_SETL("A", 1);
      m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pFinancialSeg13->lAmtReconAcqr[0]), ntohl(pFinancialSeg13->lAmtReconAcqr[1]));
      m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pFinancialSeg13->cReconAcqrDecPos, 1);
      m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pFinancialSeg13->sReconAcqrRate, 7);
      m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg13->sCurrReconAcqr, 3);
      m_pFinancialReversalSegment->setO_AMT_RECON_NET(ntohl(pFinancialSeg13->lAmtReconAcqr[0]), ntohl(pFinancialSeg13->lAmtReconAcqr[1]));
   }
  //## end AdvantageFinancial::mapSegment13%3C619046001F.body
}

void AdvantageFinancial::mapSegment14 (hFinancialSeg14* pFinancialSeg14)
{
  //## begin AdvantageFinancial::mapSegment14%3C6190460138.body preserve=yes
   if (pFinancialSeg14 == 0)
   {
      if (*m_pFinancialBaseSegment->zTRAN_DISPOSITION() != '2')
      {
         m_pFinancialSettlementSegment->setAMT_RECON_ISS(m_pFinancialBaseSegment->getAMT_TRAN());
         m_pFinancialSettlementSegment->setCNV_RCN_ISS_RATE(1);
         m_pFinancialSettlementSegment->setCUR_RECON_ISS(m_pFinancialBaseSegment->zCUR_TRAN(), 3);
      }
      return;
   }
   translate(pFinancialSeg14->sCurrReconIssr, ((char*)(&pFinancialSeg14->lAmtReconIssr) - pFinancialSeg14->sCurrReconIssr));
   translate(pFinancialSeg14->sAltCurrReconIssr, ((char*)(&pFinancialSeg14->lAltAmtReconIssr) - pFinancialSeg14->sAltCurrReconIssr));
   if (m_bAuthByAltRoute)
   {
      m_pFinancialSettlementSegment->setAMT_RECON_ISS(ntohl(pFinancialSeg14->lAltAmtReconIssr[0]), ntohl(pFinancialSeg14->lAltAmtReconIssr[1]));
      m_pFinancialSettlementSegment->setCNV_RCN_ISS_DE_POS(&pFinancialSeg14->cAltIssrDecPos, 1);
      m_pFinancialSettlementSegment->setCNV_RCN_ISS_RATE(pFinancialSeg14->sAltIssrRate, 7);
      m_pFinancialSettlementSegment->setCUR_RECON_ISS(pFinancialSeg14->sAltCurrReconIssr, 3);
      m_pFinancialUserSegment->setDATE_CNV_ISS(pFinancialSeg14->sAltDateConvIssrMMDD, 4);
      if (m_sExchgFlag[0] == 'I'
         || memcmp(m_pFinancialSettlementSegment->zCUR_RECON_ISS(), m_pFinancialBaseSegment->zCUR_RECON_NET(), 3) == 0)
      {
         m_pFinancialSettlementSegment->setEXCHG_SETL("I", 1);
         m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pFinancialSeg14->lAltAmtReconIssr[0]), ntohl(pFinancialSeg14->lAltAmtReconIssr[1]));
         m_pFinancialReversalSegment->setO_AMT_RECON_NET(ntohl(pFinancialSeg14->lAltAmtReconIssr[0]), ntohl(pFinancialSeg14->lAltAmtReconIssr[1]));
         m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pFinancialSeg14->cAltIssrDecPos, 1);
         m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pFinancialSeg14->sAltIssrRate, 7);
         m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg14->sAltCurrReconIssr, 3);
      }
   }
   else
   {
      m_pFinancialSettlementSegment->setAMT_RECON_ISS(ntohl(pFinancialSeg14->lAmtReconIssr[0]), ntohl(pFinancialSeg14->lAmtReconIssr[1]));
      m_pFinancialSettlementSegment->setCNV_RCN_ISS_DE_POS(&pFinancialSeg14->cReconIssrDecPos, 1);
      m_pFinancialSettlementSegment->setCNV_RCN_ISS_RATE(pFinancialSeg14->sReconIssrRate, 7);
      m_pFinancialSettlementSegment->setCUR_RECON_ISS(pFinancialSeg14->sCurrReconIssr, 3);
      m_pFinancialUserSegment->setDATE_CNV_ISS(pFinancialSeg14->sDateConvIssrMMDD, 4);
      if (m_sExchgFlag[0] == 'I'
         || memcmp(m_pFinancialSettlementSegment->zCUR_RECON_ISS(), m_pFinancialBaseSegment->zCUR_RECON_NET(), 3) == 0)
      {
         m_pFinancialSettlementSegment->setEXCHG_SETL("I", 1);
         m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pFinancialSeg14->lAmtReconIssr[0]), ntohl(pFinancialSeg14->lAmtReconIssr[1]));
         m_pFinancialReversalSegment->setO_AMT_RECON_NET(ntohl(pFinancialSeg14->lAmtReconIssr[0]), ntohl(pFinancialSeg14->lAmtReconIssr[1]));
         m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pFinancialSeg14->cReconIssrDecPos, 1);
         m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pFinancialSeg14->sReconIssrRate, 7);
         m_pFinancialBaseSegment->setCUR_RECON_NET(pFinancialSeg14->sCurrReconIssr, 3);
      }
   }
  //## end AdvantageFinancial::mapSegment14%3C6190460138.body
}

void AdvantageFinancial::mapSegment15 (hFinancialSeg15* pFinancialSeg15, char* sTranDesc)
{
  //## begin AdvantageFinancial::mapSegment15%3C6190460242.body preserve=yes
   translate(pFinancialSeg15->sTranDesc, sizeof(hFinancialSeg15));
   m_pFinancialSettlementSegment->setTRAN_DESC(pFinancialSeg15->sTranDesc, 100);
   memcpy(sTranDesc, pFinancialSeg15->sTranDesc, 8);
  //## end AdvantageFinancial::mapSegment15%3C6190460242.body
}

void AdvantageFinancial::mapSegment16 (hFinancialSeg16* pFinancialSeg16)
{
  //## begin AdvantageFinancial::mapSegment16%3C619046035B.body preserve=yes
   for (int i = 0; i <= 5; ++i)
   {
      translate(pFinancialSeg16->Seg16ASub[i].sFeeTypeCode, ((char*)(&pFinancialSeg16->Seg16ASub[i].lFeeAmt) - pFinancialSeg16->Seg16ASub[i].sFeeTypeCode));
      translate(&pFinancialSeg16->Seg16ASub[i].cAltFeeIssrDecPos, ((char*)(&pFinancialSeg16->Seg16ASub[i].cAmtFeeFiller) - &pFinancialSeg16->Seg16ASub[i].cAltFeeIssrDecPos));
      translate(pFinancialSeg16->Seg16BSub[i].sFeeOrigTypeCode, ((char*)(&pFinancialSeg16->Seg16BSub[i].lFeeOrigAmt) - pFinancialSeg16->Seg16BSub[i].sFeeOrigTypeCode));
      m_pFinancialSettlementSegment->setF_ADL_DEC_POSn(&pFinancialSeg16->Seg16ASub[i].cFeeDecPos, 1, i);
      m_pFinancialSettlementSegment->setF_AMTn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmt), i);
      m_pFinancialSettlementSegment->setF_AMT_RECON_ACQn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconAcqr), i);
      if (m_sExchgFlag[0] == 'A')
         m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconAcqr), i);
      m_pFinancialSettlementSegment->setF_CNV_ACQ_DEC_POSn(&pFinancialSeg16->Seg16ASub[i].cFeeAcqrDecPos, 1, i);
      m_pFinancialSettlementSegment->setF_CNV_ACQ_RATEn(pFinancialSeg16->Seg16ASub[i].sFeeAcqrRate, 7, i);
      m_pFinancialSettlementSegment->setF_CUR_CODEn(pFinancialSeg16->Seg16ASub[i].sFeeCurrCode, 3, i);
      m_pFinancialSettlementSegment->setF_CUR_RECON_ACQn(pFinancialSeg16->Seg16ASub[i].sFeeCurrReconAcqr, 3, i);
      m_pFinancialSettlementSegment->setF_CUR_RECON_ISSn(pFinancialSeg16->Seg16ASub[i].sFeeCurrReconIssr, 3, i);
      m_pFinancialSettlementSegment->setF_INITIATORn(&pFinancialSeg16->Seg16ASub[i].cFeeInitiator, 1, i);
      m_pFinancialSettlementSegment->setF_MEMOn(&pFinancialSeg16->Seg16ASub[i].cFeeMemoFlag, 1, i);
      m_pFinancialSettlementSegment->setF_TYPEn(pFinancialSeg16->Seg16ASub[i].sFeeTypeCode, 2, i);
      if (m_bAuthByAltRoute)
      {
         m_pFinancialSettlementSegment->setF_AMT_RECON_ISSn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconIssrAlt), i);
         if (m_sExchgFlag[0] == 'I')
            m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconIssrAlt), i);
         m_pFinancialSettlementSegment->setF_CNV_ISS_DEC_POSn(&pFinancialSeg16->Seg16ASub[i].cAltFeeIssrDecPos, 1, i);
         m_pFinancialSettlementSegment->setF_CNV_ISS_RATEn(pFinancialSeg16->Seg16ASub[i].sAltFeeIssrRate, 7, i);
      }
      else
      {
         m_pFinancialSettlementSegment->setF_AMT_RECON_ISSn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconIssr), i);
         if (m_sExchgFlag[0] == 'I')
            m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmtReconIssr), i);
         m_pFinancialSettlementSegment->setF_CNV_ISS_DEC_POSn(&pFinancialSeg16->Seg16ASub[i].cFeeIssrDecPos, 1, i);
         m_pFinancialSettlementSegment->setF_CNV_ISS_RATEn(pFinancialSeg16->Seg16ASub[i].sFeeIssrRate, 7, i);
      }
      if (m_sExchgFlag[0] == 'N')
      {
         int lConvertedAmt = convertAmt((int)ntohl(pFinancialSeg16->Seg16ASub[i].lFeeAmt), m_cNetworkDecPos, m_sNetworkRate);
         m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(lConvertedAmt, i);
      }
   }
   for (int i = 0; i <= 5; ++i)
   {
      m_pFinancialReversalSegment->setFO_DEC_POSn(&pFinancialSeg16->Seg16BSub[i].cAmtsOrigFeeFiller, 1, i);
      m_pFinancialReversalSegment->setFO_AMTn(ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmt), i);
      m_pFinancialReversalSegment->setFO_AMT_RECON_ACQn(ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmtReconAcqr), i);
      m_pFinancialReversalSegment->setFO_AMT_RECON_ISSn(ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmtReconIssr), i);
      if (m_sExchgFlag[0] == 'I')
         m_pFinancialReversalSegment->setFO_AMT_RECON_NETn(ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmtReconIssr), i);
      else
         if (m_sExchgFlag[0] == 'A')
            m_pFinancialReversalSegment->setFO_AMT_RECON_NETn(ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmtReconAcqr), i);
         else
         {
            int lConvertedAmt = convertAmt((int)ntohl(pFinancialSeg16->Seg16BSub[i].lFeeOrigAmt), m_cNetworkDecPos, m_sNetworkRate);
            m_pFinancialReversalSegment->setFO_AMT_RECON_NETn(lConvertedAmt, i);
         }
      m_pFinancialReversalSegment->setFO_CNV_ACQ_DE_POSn(&pFinancialSeg16->Seg16BSub[i].cFeeOrigAcqrDecPos, 1, i);
      m_pFinancialReversalSegment->setFO_CNV_ACQ_RATEn(pFinancialSeg16->Seg16BSub[i].sFeeOrigAcqrRate, 7, i);
      m_pFinancialReversalSegment->setFO_CNV_ISS_DE_POSn(&pFinancialSeg16->Seg16BSub[i].cFeeOrigIssrDecPos, 1, i);
      m_pFinancialReversalSegment->setFO_CNV_ISS_RATEn(pFinancialSeg16->Seg16BSub[i].sFeeOrigIssrRate, 7, i);
      m_pFinancialReversalSegment->setFO_CUR_CODEn(pFinancialSeg16->Seg16BSub[i].sFeeOrigCurrCode, 3, i);
      m_pFinancialReversalSegment->setFO_CUR_RECON_ACQn(pFinancialSeg16->Seg16BSub[i].sFeeOrigCurrReconAcqr, 3, i);
      m_pFinancialReversalSegment->setFO_CUR_RECON_ISSn(pFinancialSeg16->Seg16BSub[i].sFeeOrigCurrReconIssr, 3, i);
      m_pFinancialReversalSegment->setFO_INITIATORn(&pFinancialSeg16->Seg16BSub[i].cFeeOrigInitiator, 1, i);
      m_pFinancialReversalSegment->setFO_MEMOn(&pFinancialSeg16->Seg16BSub[i].cOrigMemoFlag, 1, i);
      m_pFinancialReversalSegment->setFO_TYPEn(pFinancialSeg16->Seg16BSub[i].sFeeOrigTypeCode, 2, i);
   }
  //## end AdvantageFinancial::mapSegment16%3C619046035B.body
}

void AdvantageFinancial::mapSegment17 (hFinancialSeg17* pFinancialSeg17)
{
  //## begin AdvantageFinancial::mapSegment17%3C619047008C.body preserve=yes
   translate(pFinancialSeg17->sPayee, sizeof(hFinancialSeg17));
   m_pFinancialSettlementSegment->setPAYEE(pFinancialSeg17->sPayee, 25);
  //## end AdvantageFinancial::mapSegment17%3C619047008C.body
}

void AdvantageFinancial::mapSegment18 (hFinancialSeg18* pFinancialSeg18, char* sRevMTI)
{
  //## begin AdvantageFinancial::mapSegment18%3C61904701A5.body preserve=yes
   translate(pFinancialSeg18->sOdeMTI, sizeof(hFinancialSeg18));
   //   char sMTI[5] = {"    "};
   char sDateTime14[15] = { "20            " };
   reformatInstId(pFinancialSeg18->sOdeInstIdAcqr);
   m_pFinancialReversalSegment->setODE_INST_ID_ACQ(m_sStdInstId, 11);
   //   sMTI[0] = pFinancialSeg18->cOdeVersion;
   //   sMTI[1] = pFinancialSeg18->cOdeClass;
   //   sMTI[2] = pFinancialSeg18->cOdeFunction;
   //   sMTI[3] = pFinancialSeg18->cOdeOriginator;
   memcpy(sRevMTI,pFinancialSeg18->sOdeMTI,4);
   if (Extract::instance()->getCustomCode() == "CBA"
      && m_hUsecaseOptions[m_pFinancialBaseSegment->zINST_ID_RECN_ISS_B()] == "YES"
      && m_pFinancialBaseSegment->zFUNC_CODE()[0] == '4')
   {
      memcpy(sRevMTI,"1240",4);
      m_pFinancialReversalSegment->setODE_MTI("1240", 4);
   }
   else
      m_pFinancialReversalSegment->setODE_MTI(pFinancialSeg18->sOdeMTI, 4);
   m_pFinancialReversalSegment->setODE_SYS_TRA_AUD_NO(pFinancialSeg18->sOdeSystemTraceAudNo, 6);
   memcpy(sDateTime14 + 2, pFinancialSeg18->sOdeDateLocYYMMDD, 6);
   memcpy(sDateTime14 + 8, pFinancialSeg18->sOdeTimeLocHRMNSC, 6);
   m_pFinancialReversalSegment->setODE_TSTAMP_LOCL_TR(sDateTime14, 14);
  //## end AdvantageFinancial::mapSegment18%3C61904701A5.body
}

void AdvantageFinancial::mapSegment19 (hFinancialSeg19* pFinancialSeg19)
{
  //## begin AdvantageFinancial::mapSegment19%3C61904702CE.body preserve=yes
   translate(pFinancialSeg19->sCountryTranOrigInst, sizeof(hFinancialSeg19));
   m_pFinancialUserSegment->setCNTRY_RCN_ACQ_INST(pFinancialSeg19->sCountryForwardInst, 3);
   m_pFinancialBaseSegment->setCOUNTRY_ISS_INST(pFinancialSeg19->sCountryReceivingInst, 3);
   m_pFinancialUserSegment->setINST_ID_FRWD(pFinancialSeg19->sInstIdFrwd, 11);
   if (m_pFinancialBaseSegment->zTRAN_DISPOSITION()[0] == '3')
   {
      string strINST_ID_FRWD(m_pFinancialUserSegment->zINST_ID_FRWD());
      strINST_ID_FRWD.trim();
      if (strINST_ID_FRWD.length() < 11)
         strINST_ID_FRWD.insert(0,11 - strINST_ID_FRWD.length(),'0');
      m_pFinancialUserSegment->setODE_INST_ID_FRWD(strINST_ID_FRWD.data(),11);
   }
   if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 7)
   {
      char sDATA_PRIV_ACQ[100];
      memcpy(sDATA_PRIV_ACQ, m_pFinancialSettlementSegment->zDATA_PRIV_ACQ(), 100);
      vocalink::segDATA_PRIV_ACQ* r = (struct vocalink::segDATA_PRIV_ACQ*)sDATA_PRIV_ACQ;
      memset(r->sBitmap, ' ', sizeof(r->sBitmap));
      memcpy(r->sBitmap, pFinancialSeg19->sInstIdFrwd, 11);
      m_pFinancialSettlementSegment->setDATA_PRIV_ACQ(sDATA_PRIV_ACQ, 100);
   }
   if (Extract::instance()->getCustomCode() == "PNB")
   {
      m_pFinancialPNBSegment->setPresence(true);
      m_pFinancialPNBSegment->setDESTBANK_ID(pFinancialSeg19->sInstIdTranDestIB, min(size_t(11), strlen(pFinancialSeg19->sInstIdTranDestIB)));
   }
   if (Extract::instance()->getCustomCode() == "CBA")
      m_pFinancialAdjustmentSegment->setBRANCH_ID_ACQ(pFinancialSeg19->sInstIdTranOrig, 11);
  //## end AdvantageFinancial::mapSegment19%3C61904702CE.body
}

void AdvantageFinancial::mapSegment20 (hFinancialSeg20* pFinancialSeg20)
{
  //## begin AdvantageFinancial::mapSegment20%3C619048003E.body preserve=yes
   translate(pFinancialSeg20->sAdtlDataNatl, sizeof(hFinancialSeg20));
   if (memcmp(pFinancialSeg20->sAdtlDataNatl, "*3D*\\", 5) == 0)
   {
      m_pFinancialSettlementSegment->setMCI_AAV_RESULT_COD(m_pFinancialSettlementSegment->zCAVV_RESULT(), 1);
      short siSkip = 9;
      if (memcmp(pFinancialSeg20->sAdtlDataNatl + siSkip, "SL", 2) == 0)
      {
         siSkip += 2;
         char szTemp[3] = { "  " };
         memcpy(szTemp, pFinancialSeg20->sAdtlDataNatl + siSkip, 2);
         siSkip += 2;
         m_pFinancialSettlementSegment->setMCI_ECS_LVL_IND(pFinancialSeg20->sAdtlDataNatl + siSkip, min(size_t(3), size_t(atoi(szTemp))));
         siSkip += 3;
         m_pFinancialUserSegment->setPGRM_PROTOCOL(pFinancialSeg20->sAdtlDataNatl + siSkip, 1);
         siSkip++;
      }
      if (memcmp(pFinancialSeg20->sAdtlDataNatl + siSkip, "CA", 2) == 0)
      {
         siSkip += 4;
         if ((memcmp(pFinancialSeg20->sAdtlDataNatl + siSkip, "M3", 2) == 0)
            || (memcmp(pFinancialSeg20->sAdtlDataNatl + siSkip, "M4", 2) == 0))
         {
            char szTemp[3] = { "  " };
            memcpy(szTemp, pFinancialSeg20->sAdtlDataNatl + siSkip - 2, 2);
            siSkip += 2;
            m_pFinancialSettlementSegment->setMCI_UCAF_DATA(pFinancialSeg20->sAdtlDataNatl + siSkip, min(size_t(32), size_t(atoi(szTemp) - 2)));
         }
      }
   }
   //checking from the back for the first non-blank character
   int n = 0;
   for (int pos = 98; pos >= 0; pos--)
   {
      if (pFinancialSeg20->sAdtlDataNatl[pos] != ' ')
      {
         n = pos;
         break;
      }
   }
   m_pFinancialSettlementSegment->setADL_DATA_NATIONAL(pFinancialSeg20->sAdtlDataNatl,n + 1);
  //## end AdvantageFinancial::mapSegment20%3C619048003E.body
}

void AdvantageFinancial::mapSegment21 (hFinancialSeg21* pFinancialSeg21)
{
  //## begin AdvantageFinancial::mapSegment21%3C6190480196.body preserve=yes
   translate(pFinancialSeg21->sAdtlDataPrivAcqr, sizeof(hFinancialSeg21));
   if ((memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "MI", 2) == 0)
      || (m_pAdvantageMessageProcessor->getMessageCode() == "0401")
      || (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "PL", 2) == 0)
      || (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "IC", 2) == 0)
      || (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "AI", 2) == 0)
      || (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "AX", 2) == 0))
   {
      string strADL_DATA_PRIV_ACQ(pFinancialSeg21->sAdtlDataPrivAcqr, 255);
      size_t n = strADL_DATA_PRIV_ACQ.find_last_not_of(' ');
      if (n != string::npos)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strADL_DATA_PRIV_ACQ.data(), n + 1);
      if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "IC", 2) == 0)
      {
         vocalink::segADL_DATA_PRIV_ACQ *r = (struct vocalink::segADL_DATA_PRIV_ACQ*)strADL_DATA_PRIV_ACQ.data();
         m_pIntegratedCircuitCardSegment->setPresence(true);
         string strTemp;
         CodeTable::nibbleToByte(r->sTERM_CAPABILITIES, sizeof(r->sTERM_CAPABILITIES), strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_CAPABILITIES(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sTERM_VERIFY_RESULT, sizeof(r->sTERM_VERIFY_RESULT), strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_VERIFY_RESULT(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sUNPREDICTABLE_NO, sizeof(r->sUNPREDICTABLE_NO), strTemp);
         m_pIntegratedCircuitCardSegment->setUNPREDICTABLE_NO(strTemp.data(), strTemp.length());
         m_pIntegratedCircuitCardSegment->setTERM_SERIAL_NO(r->sTERM_SERIAL_NO, sizeof(r->sTERM_SERIAL_NO));
         CodeTable::nibbleToByte(r->sISS_APPL_DATA, sizeof(r->sISS_APPL_DATA), strTemp);
         m_pIntegratedCircuitCardSegment->setISS_APPL_DATA(strTemp.data(), ((int)((unsigned char)r->sAcq_Icc_Map[4])));
         CodeTable::nibbleToByte(r->sAPPL_CRYPTOGRAM, sizeof(r->sAPPL_CRYPTOGRAM), strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_CRYPTOGRAM(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sAPPL_TRAN_COUNTER, sizeof(r->sAPPL_TRAN_COUNTER), strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_TRAN_COUNTER(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sAPPL_INTRCHG_PROF, sizeof(r->sAPPL_INTRCHG_PROF), strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_INTRCHG_PROF(strTemp.data(), strTemp.length());
         m_pIntegratedCircuitCardSegment->setISS_AUTH_DATA(r->sISS_AUTH_DATA, sizeof(r->sISS_AUTH_DATA));
         CodeTable::nibbleToByte(&r->sTRAN_TYPE, sizeof(r->sTRAN_TYPE), strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_TYPE(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sTERM_COUNTRY_CODE, sizeof(r->sTERM_COUNTRY_CODE), strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_COUNTRY_CODE(strTemp.data() + 1, 3);
         CodeTable::nibbleToByte(r->sTRAN_DATE, sizeof(r->sTRAN_DATE), strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_DATE(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sCRYPTOGRAM_AMOUNT, sizeof(r->sCRYPTOGRAM_AMOUNT), strTemp);
         m_pIntegratedCircuitCardSegment->setCRYPTOGRAM_AMOUNT(strTemp.data(), strTemp.length());
         CodeTable::nibbleToByte(r->sTRAN_CURRENCY_CODE, sizeof(r->sTRAN_CURRENCY_CODE), strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_CURRENCY_CODE(strTemp.data() + 1, 3);
         if (*m_pFinancialBaseSegment->zTRAN_DISPOSITION() != '3')
         {
            CodeTable::nibbleToByte(r->sAMOUNT_OTHER, sizeof(r->sAMOUNT_OTHER), strTemp);
            if (strTemp != "202020202020")
               m_pIntegratedCircuitCardSegment->setAMOUNT_OTHER(strTemp.data(), strTemp.length());
         }
         CodeTable::nibbleToByte(&r->sCRYPT_INFO_DATA, sizeof(r->sCRYPT_INFO_DATA), strTemp);
         m_pIntegratedCircuitCardSegment->setCRYPT_INFO_DATA(strTemp.data(), strTemp.length());
         m_pIntegratedCircuitCardSegment->setTERMINAL_TYPE(&r->sTERMINAL_TYPE, 1);
         m_pIntegratedCircuitCardSegment->setDEDICATED_FILE_NAM(r->sDEDICATED_FILE_NAM, sizeof(r->sDEDICATED_FILE_NAM));
         if (memcmp(r->sAPPL_VERSION_NO, "  ", 2))
         {
            CodeTable::nibbleToByte(r->sAPPL_VERSION_NO, sizeof(r->sAPPL_VERSION_NO), strTemp);
            if (strTemp != "2020")
               m_pIntegratedCircuitCardSegment->setAPPL_VERSION_NO(strTemp.data(), strTemp.length());
         }
         CodeTable::nibbleToByte(r->sTRAN_SEQ_COUNTER, sizeof(r->sTRAN_SEQ_COUNTER), strTemp);
         if (strTemp != "20202020")
            m_pIntegratedCircuitCardSegment->setTRAN_SEQ_COUNTER(strTemp.data(), strTemp.length());
         m_pIntegratedCircuitCardSegment->setTRAN_CATEGORY_CODE(&r->cTRAN_CATEGORY_CODE, 1);
      }
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "MC", 2) == 0)
   {
      // keep in sync with ADL_DATA_PRIV_ACQ in CXODRS63.hpp
      int nVarPos = 13;
      char sFixedFmt[255];
      int nFixedPos = 13;
      // pos 1: Merchant Advice (2)
      // pos 2: Fraud Data (9) = POS Entry Mode (3) - DE22
      //                         Response Code (2) - DE39
      //                         POS Data S1, S4, S11 (3) - DE61.1,61.4,61.11
      //                         POS Data S10 (1) - DE61.10
      // pos 3: Advice Detail Reason Code(4) - DE60.2
      // pos 4: Tag88(1)       -  DE48 Tag 88
      // pos 5: Tag89(1)       -  DE48 Tag 89
      // pos 6: Merchant Postal Code(10) - DE61 s14
      // pos 7: Card Presence (1) - DE61 s5
      short siMCFieldLen1[32] = { 2,9,4,1,1,10,1,3,6,1,3,1,7,10,1,30,1,2,1,1,2,1,2,2,3,1,2,2,1,4,11,8 };
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr + 5, 8);
      memset(sFixedFmt, ' ', 255);
      memcpy(sFixedFmt, "MC118FFFFFFC0", 13);
      char psBits[4];
      for (int i = 0; i < 8; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               if (!((i == 7) && (j == 3)))
                  memcpy(sFixedFmt + nFixedPos,
                     pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siMCFieldLen1[nFieldNum]);
               nVarPos += siMCFieldLen1[nFieldNum];
            }
            nFixedPos += siMCFieldLen1[nFieldNum];
            ++nFieldNum;
         }
      }
      nFieldNum = 0;
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos - 8, 8);
      short siMCFieldLen2[20] = { 11,15,1,3,2,1,3,2,2,1,2,1,3,11,2,22,1,0,0,0 };
      for (int i = 0; i < 5; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sFixedFmt + nFixedPos - 8,
                  pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siMCFieldLen2[nFieldNum]);
               nVarPos += siMCFieldLen2[nFieldNum];
            }
            nFixedPos += siMCFieldLen2[nFieldNum];
            ++nFieldNum;
         }
      }
      string strTemp(sFixedFmt, nFixedPos);
      size_t n = strTemp.find_last_not_of(' ');
      if (n != string::npos)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strTemp.data(), n + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "VD", 2) == 0)
   {
      char sFixedFmt[sizeof(visasms::segADL_DATA_PRIV_ACQ)];
      memset(sFixedFmt, ' ',sizeof(visasms::segADL_DATA_PRIV_ACQ));
      int nVarPos = 0;
      struct visasms::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct visasms::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05.   char cPRCH_ID_FRMT_FLG; //     18    5   62.7
         //      char sPURCHASE_IND[25]; //     19
         memcpy(&pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) +
            sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) +
            sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND);
      }
      if (lBitMap & 0x04000000)
      {  //06. char sEventDate[6]; //     44    6   62.8
         memcpy(pADL_DATA_PRIV_ACQ->sEventDate,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEventDate));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEventDate);
      }
      if (lBitMap & 0x02000000)
      {  //07. char cNo_Show_Ind; //     50    7   62.9
         memcpy(&pADL_DATA_PRIV_ACQ->cNo_Show_Ind,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sEXTRA_CHARGES_IND[6]; //     51    8  62.10
         memcpy(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND);
      }
      if (lBitMap & 0x00800000)
      {  //09. char cRestr_Ticket_Ind; //     57    9  62.13
         memcpy(&pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind);
      }
      if (lBitMap & 0x00400000)
      {  //10. char cREQ_PAYM_SERV_IND; //     58   10  62.15
         memcpy(&pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sCHB_RIGHTS_IND[2]; //     59   11  62.16
         memcpy(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sECOM_GOODS_IND[2]; //     61   12  62.19
         memcpy(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sMERCH_VERIFY_VALUE[10]; //     63   13  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cCAVV_RESULT; //     73   14  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x00020000)
      {  //15. char sRisk_Score[4]; //     74   15  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x00010000)
      {  //16. char sRisk_Condition_Code[6]; //     78   16  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00008000)
      {  //17. char sProcess_CODE[6]; //     84   17      3
         memcpy(pADL_DATA_PRIV_ACQ->sProcess_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE);
      }
      if (lBitMap & 0x00004000)
      {  //18. char cTERM_TYPE_IND; //     90   18   60.1
         memcpy(&pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND);
      }
      if (lBitMap & 0x00002000)
      {  //19. char sMOTO_IND[2]; //     91   19   60.8
         memcpy(pADL_DATA_PRIV_ACQ->sMOTO_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND);
      }
      if (lBitMap & 0x00001000)
      {  //20. char cEXCLD_TRAN_ID; //     93   20  62.18
         memcpy(&pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID);
      }
      if (lBitMap & 0x00000800)
      {  //21. char sSTIP_SW_RESN_CODE[4]; //     94   21   63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00000400)
      {  //22. char cVisaChargeIndicator; //     98   22  63.21
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaChargeIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator);
      }
      if (lBitMap & 0x00000200)
      {  //23. char sLatinISA[15]; //     99   23     46
         memcpy(pADL_DATA_PRIV_ACQ->sLatinISA,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sLatinISA));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sLatinISA);
      }
      if (lBitMap & 0x00000100)
      {  //24. char sPRODUCT_ID[2]; //    114   24  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sPRODUCT_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID);
      }
      if (lBitMap & 0x00000080)
      {  //25. char cCardholderIDMethod;        //    116   25  60.93
         //    char sMISReasonCode[4];          //    117   25  63.3
         //    char cRecurringPaymentIndicator; //    121   25  126.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCardholderIDMethod,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod);

         memcpy(pADL_DATA_PRIV_ACQ->sMISReasonCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMISReasonCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMISReasonCode);

         memcpy(&pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator);
      }
      if (lBitMap & 0x00000040)
      {  //26. char sServiceIndicators[6]; //    122   26  126.12
         memcpy(pADL_DATA_PRIV_ACQ->sServiceIndicators,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators);
      }
      if (lBitMap & 0x00000020)
      {  //27. char sResponseCode[2]; //    128   27  39
         memcpy(pADL_DATA_PRIV_ACQ->sResponseCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sResponseCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sResponseCode);
      }
      if (lBitMap & 0x00000010)
      {  //28. char cPaymentType; //    130   28  104(57)
         memcpy(&pADL_DATA_PRIV_ACQ->cPaymentType,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPaymentType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPaymentType);
      }
      if (lBitMap & 0x00000008)
      {  //29. char sAirlineFields[38]; //    131   29  48,Usage 4
         memcpy(pADL_DATA_PRIV_ACQ->sAirlineFields,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAirlineFields));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAirlineFields);
      }
      if (lBitMap & 0x00000004)
      {  //30. char sBusinessApplicationID[2]; //    169   30  104,Usage 2
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00000002)
      {  //31. char cVisaAVSResult; //    171   31  44.2
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaAVSResult,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult);
      }
      if (lBitMap & 0x00000001)
      {  //32. 2nd bitmap
         memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map2,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2);
         sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map2, "%08x", &lBitMap);
      }
      else
         lBitMap = 0;
      if (lBitMap & 0x80000000)
      {  //33. char cDCCInd; //    180   33  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
      }
      if (lBitMap & 0x40000000)
      {  //34. char cSpendQualifiedIndicator; //    181   34  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
      if (lBitMap & 0x20000000)
      {  //35. char sVisaMerchantIdentifier[8]; //   182 35 126.5
         memcpy(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier);
      }
      if (lBitMap & 0x10000000)
      {  //35. char sAGENT_UNIQUE_ID[5];  //           190 36 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
      if (lBitMap & 0x08000000)
      {  //36. char cAdlAuthInd;      //               195 37 60.10
         memcpy(&pADL_DATA_PRIV_ACQ->cAdlAuthInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd);
      }
      if (lBitMap & 0x04000000)
      {  //38. char sVisaPlanOption[5];      //        196 38 48
         memcpy(pADL_DATA_PRIV_ACQ->sVisaPlanOption,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaPlanOption));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaPlanOption);
      }
      if (lBitMap & 0x02000000)
      {  //39. char sATMRoutingTableIdentifier[7];      //       201 39 62.27
         memcpy(pADL_DATA_PRIV_ACQ->sATMRoutingTableIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sATMRoutingTableIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sATMRoutingTableIdentifier);
      }
      if (lBitMap & 0x01000000)
      {  //40. char sMarketplaceID[11];      //       208 40
         memcpy(pADL_DATA_PRIV_ACQ->sMarketplaceID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMarketplaceID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMarketplaceID);
      }
      if (lBitMap & 0x00800000)
      {  //41. char sSubMerchantID[15];      //       219 41
         memcpy(pADL_DATA_PRIV_ACQ->sSubMerchantID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSubMerchantID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSubMerchantID);
      }
      if (lBitMap & 0x00400000)
      {  //42. char sForeignRetailInd[3];      //     234 42
         memcpy(pADL_DATA_PRIV_ACQ->sForeignRetailInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sForeignRetailInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sForeignRetailInd);
      }
      if (lBitMap & 0x00200000)
      {  //43. char cCVViCVVResultsCode;      //      237 43 44.5
         memcpy(&pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode);
      }
      if (lBitMap & 0x00100000)
      {   //44. char cExtendedSTIPReasonCode;       // 0238 44 44.4
         memcpy(&pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode);
      }
      if (lBitMap & 0x00080000)
      {   //45. char sDeferredOCTRequestType[2];       // 0239 45 104 Usage 2, DS ID 57, Tag 80
         memcpy(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType);
      }
      if (lBitMap & 0x00040000)
      {   //46. char sDeferredOCTDateTime[12];       // 0241 46 104 Usage 2,DS ID 57,Tag 81
         memcpy(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime);
      }
      if (lBitMap & 0x00020000)
      {   //47. char sAccountNameRequestFlag[2];       // 0253 47 34 DS ID 03,Tag C0
         memcpy(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag);
      }
      if (lBitMap & 0x00010000)
      {   //48. char sExpectedClearingDate[4];     // 0255 48 104 DS ID 57,Tag 83
         memcpy(pADL_DATA_PRIV_ACQ->sExpectedClearingDate,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sExpectedClearingDate));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sExpectedClearingDate);
      }
      if (lBitMap & 0x00008000)
      {   //49. char sEnablerVerificationValue[5];  // 0259 49 126.18, pos 7-11
         memcpy(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue);
      }
      if (lBitMap & 0x00004000)
      {   //50. char sVisaDeepAuthScore[2];         // 0264 50 104 DS ID 5B,Tag 86
         memcpy(pADL_DATA_PRIV_ACQ->sVisaDeepAuthScore,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaDeepAuthScore));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaDeepAuthScore);
      }
      if (lBitMap & 0x00002000)
      {   //51. char sSchemeIdentifier[2];          // 0266 51 104 DS ID 57,Tag 84
         memcpy(pADL_DATA_PRIV_ACQ->sSchemeIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier);
      }
      if (lBitMap & 0x00001000)
      {   //52. char sPlanRegistrationSystemID[35]; // 0268 52 104 DS ID 57,Tag 82
         memcpy(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID);
      }
      if (lBitMap & 0x00000800)
      {   //53. char sVisaAccountAttackIntScore[2]; // 0303 53 104 DS ID 5B,Tag 85
         memcpy(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore);
      }
      int i = sizeof(struct visasms::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "V2", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII* pADL_DATA_PRIV_ACQ =
         (struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05.   char cPRCH_ID_FRMT_FLG; //     18    5   62.7
         //      char sPURCHASE_IND[25]; //     19
         memcpy(&pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) +
            sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) +
            sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND);
      }
      if (lBitMap & 0x04000000)
      {  //06. char sCheck_In_Out_Date[6]; //     44    6   62.8
         memcpy(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date);
      }
      if (lBitMap & 0x02000000)
      {  //07. char cNo_Show_Ind; //     50    7   62.9
         memcpy(&pADL_DATA_PRIV_ACQ->cNo_Show_Ind,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sEXTRA_CHARGES_IND[6]; //     51    8  62.10
         memcpy(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND);
      }
      if (lBitMap & 0x00800000)
      {  //09. char cRestr_Ticket_Ind; //     57    9  62.13
         memcpy(&pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind);
      }
      if (lBitMap & 0x00400000)
      {  //10. char cREQ_PAYM_SERV_IND; //     58   10  62.15
         memcpy(&pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sCHB_RIGHTS_IND[2]; //     59   11  62.16
         memcpy(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sECOM_GOODS_IND[2]; //     61   12  62.19
         memcpy(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sMERCH_VERIFY_VALUE[10]; //     63   13  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cCAVV_RESULT; //     73   14  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x00020000)
      {  //15. char sRisk_Score[4]; //     74   15  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x00010000)
      {  //16. char sRisk_Condition_Code[6]; //     78   16  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00008000)
      {  //17. char sProcess_CODE[6]; //     84   17      3
         memcpy(pADL_DATA_PRIV_ACQ->sProcess_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE);
      }
      if (lBitMap & 0x00004000)
      {  //18. char cTERM_TYPE_IND; //     90   18   60.1
         memcpy(&pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND);
      }
      if (lBitMap & 0x00002000)
      {  //19. char sMOTO_IND[2]; //     91   19   60.8
         memcpy(pADL_DATA_PRIV_ACQ->sMOTO_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND);
      }
      if (lBitMap & 0x00001000)
      {  //20. char cEXCLD_TRAN_ID; //     93   20  62.18
         memcpy(&pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID);
      }
      if (lBitMap & 0x00000800)
      {  //21. char sSTIP_SW_RESN_CODE[4]; //     94   21   63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00000400)
      {  //22. char cVisaChargeIndicator; //     98   22  63.21
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaChargeIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator);
      }
      if (lBitMap & 0x00000200)
      {  //23. char sCardLevelResults[2]; //     99   23  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sCardLevelResults,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCardLevelResults));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCardLevelResults);
      }
      if (lBitMap & 0x00000100)
      {  //24. char sBusinessApplicationID[2]; //     101  24  104
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00000080)
      {  //25. char cDCCInd; //     103  25  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
      }
      if (lBitMap & 0x00000040)
      {  //26. char cFastFundsInd; //    104   26  TCR3
         memcpy(&pADL_DATA_PRIV_ACQ->cFastFundsInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cFastFundsInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cFastFundsInd);
      }
      if (lBitMap & 0x00000020)
      {  //27. char cSpendQualifiedIndicator; //    105   27  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
      if (lBitMap & 0x00000010)
      {  //28. char sAGENT_UNIQUE_ID[5];  //          106 28 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
      if (lBitMap & 0x00000008)
      {  //29. char sAcqBusinessID[8];  //          111 29
         memcpy(pADL_DATA_PRIV_ACQ->sAcqBusinessID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAcqBusinessID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAcqBusinessID);
      }
      if (lBitMap & 0x00000004)
      {  //30. char sVisaMerchantID[8];  // 0119 30 TCR 6, pos 64 to 71
         memcpy(pADL_DATA_PRIV_ACQ->sVisaMerchantID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantID);
      }
      if (lBitMap & 0x00000002)
      {  //31. char sServiceProcessingType[2];  // 0127 31 TCR 3, pos 5 to 6
         memcpy(pADL_DATA_PRIV_ACQ->sServiceProcessingType,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sServiceProcessingType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sServiceProcessingType);
      }
      if (lBitMap & 0x00000001)
      {  //32. 2nd bitmap
         memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map2,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2);
         sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map2, "%08x", &lBitMap);
      }
      else
         lBitMap = 0;
      if (lBitMap & 0x80000000)
      {  //33. char sSchemeIdentifier[2];  // 0137 33 TCR 1, pos 13 to 14
         memcpy(pADL_DATA_PRIV_ACQ->sSchemeIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier);
      }
      int i = sizeof(struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "VE", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct visabaseii::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct visabaseii::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05. char sMERCH_VERIFY_VALUE[10]; //     18    5  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x04000000)
      {  //06. char cCAVV_RESULT; //     28    6  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x02000000)
      {  //07. char sRisk_Score[4]; //     29    7  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sRisk_Condition_Code[6]; //     33    8  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00800000)
      {  //09. char sPRODUCT_ID[2]; //     39    9  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sPRODUCT_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID);
      }
      if (lBitMap & 0x00400000)
      {  //10. char sMSG_REASON_CODE[4]; //     41   10  63.3
         memcpy(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sSTIP_SW_RESN_CODE[4]; //     45   11  63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sResponseCode[2]; //     49   12  39
         memcpy(pADL_DATA_PRIV_ACQ->sResponseCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sResponseCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sResponseCode);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sBusinessApplicationID[2]; //     51   13  104 usage 2 hex 57 Tag 01
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cVisaAVSResult; //     53   14  44.2
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaAVSResult,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult);
      }
      if (lBitMap & 0x00020000)
      {  //15. char cDCCInd; //     54   15  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
      }
      if (lBitMap & 0x00010000)
      {  //16. char cCardholderIDMethod;    //     55   16  60.9
         memcpy(&pADL_DATA_PRIV_ACQ->cCardholderIDMethod,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod);
      }
      if (lBitMap & 0x00008000)
      {  //17. char cSpendQualifiedIndicator;    //     56   17  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
      if (lBitMap & 0x00004000)
      {  //18. char sVisaMerchantIdentifier[8];    //     57 18 126.5
         memcpy(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier);
      }
      if (lBitMap & 0x00002000)
      {  //19. char sServiceIndicators[6];         //    65 19 126.12
         memcpy(pADL_DATA_PRIV_ACQ->sServiceIndicators,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators);
      }
      if (lBitMap & 0x00001000)
      {  //20. char sAGENT_UNIQUE_ID[5];             //    71 20 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
      if (lBitMap & 0x00000800)
      {  //21. char cPOSEnvironment;             //     76   21  126.13
         memcpy(&pADL_DATA_PRIV_ACQ->cPOSEnvironment,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cPOSEnvironment));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cPOSEnvironment);
      }
      if (lBitMap & 0x00000400)
      {  //22. char cAdlAuthInd;               //       77  22  60.10
         memcpy(&pADL_DATA_PRIV_ACQ->cAdlAuthInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd);
      }
      if (lBitMap & 0x00000200)
      {  //23. char sMarketplaceID[11];               //       78  23
         memcpy(pADL_DATA_PRIV_ACQ->sMarketplaceID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMarketplaceID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMarketplaceID);
      }
      if (lBitMap & 0x00000100)
      {  //24. char sSubMerchantID[15];               //       89  24
         memcpy(pADL_DATA_PRIV_ACQ->sSubMerchantID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSubMerchantID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSubMerchantID);
      }
      if (lBitMap & 0x00000080)
      {  //25. char cCVViCVVResultsCode;              //      104  25
         memcpy(&pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cCVViCVVResultsCode);
      }
      if (lBitMap & 0x00000040)
      {  //26. char cExtendedSTIPReasonCode;       // 0105 26 44.4
         memcpy(&pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode,
           pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
           sizeof(pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cExtendedSTIPReasonCode);
      }
      if (lBitMap & 0x00000020)
      {  //27. char sDeferredOCTRequestType[2];    // 0106 27 104 Usage 2, DS ID 57, Tag 80
         memcpy(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType,
             pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
             sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTRequestType);
      }
      if (lBitMap & 0x00000010)
      {  //28. char sDeferredOCTDateTime[12];     // 0108 28 104 Usage 2, DS ID 57, Tag 81
         memcpy(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sDeferredOCTDateTime);
      }
      if (lBitMap & 0x00000008)
      {  //29. char sAccountNameRequestFlag[2];     // 0120 29 34 DS ID 03,Tag C0
         memcpy(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAccountNameRequestFlag);
      }
      if (lBitMap & 0x00000004)
      {  //30. char sEventDate[6];     //     122 30 62.8
         memcpy(pADL_DATA_PRIV_ACQ->sEventDate,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEventDate));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEventDate);
      }
      if (lBitMap & 0x00000002)
      {  //31. char sExpectedClearingDate[4];     //     0128 31 104, U2, DSID 57, Tag 83
         memcpy(pADL_DATA_PRIV_ACQ->sExpectedClearingDate,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sExpectedClearingDate));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sExpectedClearingDate);
      }
      if (lBitMap & 0x00000001)
      {  //32. 2nd bitmap
         memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map2,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2);
         sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map2, "%08x", &lBitMap);
      }
      else
         lBitMap = 0;
      if (lBitMap & 0x80000000)
      {  //33. char sEnablerVerificationValue[5];     //     0140 33 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEnablerVerificationValue);
      }
      if (lBitMap & 0x40000000)
      {  //34. char sSchemeIdentifier[2];          // 0145 34 104, U2, DSID 57, Tag 84
         memcpy(pADL_DATA_PRIV_ACQ->sSchemeIdentifier,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sSchemeIdentifier);
      }
      if (lBitMap & 0x20000000)
      {  //35. char sPlanRegistrationSystemID[35]; // 0147 35 104, U2, DSID 5D, Tag 82
         memcpy(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sPlanRegistrationSystemID);
      }
      if (lBitMap & 0x10000000)
      {  //36. char sForeignRetailerIndicator[3];  // 0182 36 104, U2, DSID 56, Tag 04
         memcpy(pADL_DATA_PRIV_ACQ->sForeignRetailerIndicator,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sForeignRetailerIndicator));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sForeignRetailerIndicator);
      }
      if (lBitMap & 0x08000000)
      {  //37. char sVisaAccountAttackIntScore[2]; // 0185 37 104, U2, DSID 5B, Tag 85 
         memcpy(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sVisaAccountAttackIntScore);
      }
      int i = sizeof(struct visabaseii::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "MD", 2) == 0)
   {
      // pos 1: Merchant ID (6) bit 110 Master Card
      // pos 2: Cross-Border Flags (2)  bit 126 Master Card
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[13+6+2+1+2+1+1+1+1+1+1+2+3+6+1+1+1+2+2+2+1+11+15+3+2+2+1+1+4+11+11+15+1+3+4+3+2+3+2+2+15+1+1+1+2+15+3+11+2+22+1];
      int nFixedPos = 13;
      short siSubFieldLen1[32] = {6,2,1,2,1,1,1,1,1,1,2,3,6,1,1,1,2,2,2,1,11,15,3,2,2,1,1,4,11,11,15,8};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr + 5, 8);
      memset(sADL_DATA_PRIV_ACQ, ' ', sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ, "MD078FFFFFFE00", 13);
      char psBits[4];
      for (int i = 0; i < 8; i++)
      {
         //convertBitMap(pFinancialSeg21->sAdtlDataPrivAcqr[5],psBits);
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               if (nFieldNum != 31) //dont save the second bitmap
                  memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,
                     pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siSubFieldLen1[nFieldNum]);
               nVarPos += siSubFieldLen1[nFieldNum];
               if (j == 0 && i == 0) // do only for 6 Bytes mertype
                  m_pFinancialSettlementSegment->setMERCH_TIER_ID(
                     sADL_DATA_PRIV_ACQ + nFixedPos, siSubFieldLen1[nFieldNum]);
            }
            if (nFieldNum != 31)
               nFixedPos += siSubFieldLen1[nFieldNum++];
         }
      }
      nFieldNum = 0;
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos - 8, 8);
      short siSubFieldLen2[20] = {1,3,4,3,2,3,2,2,15,1,1,1,2,15,3,11,2,22,1,0};
      for (int i = 0; i < 5; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,
                  pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siSubFieldLen2[nFieldNum]);
               nVarPos += siSubFieldLen2[nFieldNum];
            }
            nFixedPos += siSubFieldLen2[nFieldNum];
            ++nFieldNum;
         }
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
         sizeof(sADL_DATA_PRIV_ACQ));
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "AF", 2) == 0)
   {
      // pos 1: Cross-Border Indicator Flag (1)
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[13 + 1];
      int nFixedPos = 13;
      short siSubFieldLen[8] = { 1,0,0,0,0,0,0,0 };
      int nFieldNum = 0;
      memset(sADL_DATA_PRIV_ACQ, ' ', sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ, "AF00980000000", 13);
      char psBits[4];
      convertBitMap(pFinancialSeg21->sAdtlDataPrivAcqr[5], psBits);
      for (int i = 0; i < 3; ++i)   // four fields per byte
      {
         if (psBits[i] == '1')      //field is present
         {
            memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,
               pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siSubFieldLen[nFieldNum]);
            nVarPos += siSubFieldLen[nFieldNum];
         }
         nFixedPos += siSubFieldLen[nFieldNum];
         ++nFieldNum;
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
         sizeof(sADL_DATA_PRIV_ACQ));
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "ST", 2) == 0)
   {
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[13+2+1+10+1+1+1+2+15+1+23+3+15+3+8+1];
      int nFixedPos = 13;
      short siSubFieldLen[16] = {2,1,10,1,1,1,2,15,1,23,3,15,3,8,1,0};
      int nFieldNum = 0;
      memset(sADL_DATA_PRIV_ACQ, ' ', sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ, pFinancialSeg21->sAdtlDataPrivAcqr, 2);
      memcpy(sADL_DATA_PRIV_ACQ+2, pFinancialSeg21->sAdtlDataPrivAcqr+2, 3);
      memcpy(sADL_DATA_PRIV_ACQ+5, pFinancialSeg21->sAdtlDataPrivAcqr+5, 8);
      char psBits[4];
      char sBitMap[8];
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr+5, 8);
      for (int i = 0; i < 4; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ACQ+nFixedPos,
                  pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, siSubFieldLen[nFieldNum]);
               nVarPos += siSubFieldLen[nFieldNum];
            }
            nFixedPos += siSubFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
         sizeof(sADL_DATA_PRIV_ACQ));
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "SR", 2) == 0)
   {
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[13 + 1 + 6 + 1];
      int nFixedPos = 13;
      short siSubFieldLen[4] = { 1,6,1,0 };
      int nFieldNum = 0;
      memset(sADL_DATA_PRIV_ACQ, ' ', sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ, pFinancialSeg21->sAdtlDataPrivAcqr, 2);
      memcpy(sADL_DATA_PRIV_ACQ + 2, pFinancialSeg21->sAdtlDataPrivAcqr + 2, 3);
      memcpy(sADL_DATA_PRIV_ACQ + 5, pFinancialSeg21->sAdtlDataPrivAcqr + 5, 8);
      char psBits[4];
      convertBitMap(pFinancialSeg21->sAdtlDataPrivAcqr[5], psBits);
      for (int j = 0; j <= 3; ++j)   // four fields per byte
      {
         if (psBits[j] == '1')      //field is present
         {
            memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,
               pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siSubFieldLen[nFieldNum]);
            nVarPos += siSubFieldLen[nFieldNum];
         }
         nFixedPos += siSubFieldLen[nFieldNum];
         ++nFieldNum;
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
         sizeof(sADL_DATA_PRIV_ACQ));
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "SH", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct shazam::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct shazam::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. sTransactionID[16]; //     13    1   63.18
         memcpy(pADL_DATA_PRIV_ACQ->sTransactionID,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sTransactionID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sTransactionID);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cEComInd; //     29    2   123.10
         memcpy(&pADL_DATA_PRIV_ACQ->cEComInd,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cEComInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cEComInd);
      }
      if (lBitMap & 0x20000000)
      {  //03. char cDualMessageAuthorizationTypeInd; //     30    3   123.13
         memcpy(&pADL_DATA_PRIV_ACQ->cDualMessageAuthorizationTypeInd,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cDualMessageAuthorizationTypeInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cDualMessageAuthorizationTypeInd);
      }
      if (lBitMap & 0x10000000)
      {  //04. char sChargebackRightsInd[2]; //     31    4   123.29
         memcpy(pADL_DATA_PRIV_ACQ->sChargebackRightsInd,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sChargebackRightsInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sChargebackRightsInd);
      }
      if (lBitMap & 0x08000000)
      {  //05. char sAirlinePassengerTicketNumber[15]; //     33    5  124
         memcpy(pADL_DATA_PRIV_ACQ->sAirlinePassengerTicketNumber,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAirlinePassengerTicketNumber));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAirlinePassengerTicketNumber);
      }
      if (lBitMap & 0x04000000)
      {  //06. char sFunctionCode[3]; //     48    6  24
         memcpy(pADL_DATA_PRIV_ACQ->sFunctionCode,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sFunctionCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sFunctionCode);
      }
      if (lBitMap & 0x02000000)
      {  //06. char sOriginatingSwitchID[3]; //     51    7  63.1
         memcpy(pADL_DATA_PRIV_ACQ->sOriginatingSwitchID,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sOriginatingSwitchID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sOriginatingSwitchID);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sShazamSequenceNumber[6]; // 0054 8 63.6
         memcpy(pADL_DATA_PRIV_ACQ->sShazamSequenceNumber,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sShazamSequenceNumber));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sShazamSequenceNumber);
      }
      if (lBitMap & 0x00800000)
      {  //09. char sOriginalSequenceNumber[6]; // 0060 9 63.8
         memcpy(pADL_DATA_PRIV_ACQ->sOriginalSequenceNumber,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sOriginalSequenceNumber));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sOriginalSequenceNumber);
      }
      int i = sizeof(struct shazam::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i+1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "NY", 2) == 0 || memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "CU", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct nyce::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct nyce::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. cIncPreInd;
         memcpy(&pADL_DATA_PRIV_ACQ->cIncPreInd,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cIncPreInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cIncPreInd);
      }
      if (lBitMap & 0x40000000)
      {  //02. char sRTR_REF_ID;
         memcpy(pADL_DATA_PRIV_ACQ->sRTR_REF_ID,
            pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sRTR_REF_ID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sRTR_REF_ID);
      }
      int i = sizeof(struct nyce::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i+1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "PS", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct pulsediscover::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct pulsediscover::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,
         pFinancialSeg21->sAdtlDataPrivAcqr+nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x80000000)
      {
         //01. char sReferenceNum;
         memcpy(pADL_DATA_PRIV_ACQ->sReferenceNum,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sReferenceNum));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sReferenceNum);
      }
      if (lBitMap & 0x40000000)
      {
         //02. char sMerchTransID;
         memcpy(pADL_DATA_PRIV_ACQ->sMerchTransID,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMerchTransID));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMerchTransID);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sTravelEntertainmentInd;  //04. char sTransactionDetail;
         memcpy(pADL_DATA_PRIV_ACQ->sTravelEntertainmentInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, 2);
         nVarPos += 2;
         if (memcmp(pADL_DATA_PRIV_ACQ->sTravelEntertainmentInd, "AI", 2) == 0)
         {
            memcpy(pADL_DATA_PRIV_ACQ->sTransactionDetail,
               pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, 56);
            nVarPos += 56;
         }
         else if (memcmp(pADL_DATA_PRIV_ACQ->sTravelEntertainmentInd, "VR", 2) == 0)
         {
            memcpy(pADL_DATA_PRIV_ACQ->sTransactionDetail,
               pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, 27);
            nVarPos += 27;
         }
         else if (memcmp(pADL_DATA_PRIV_ACQ->sTravelEntertainmentInd, "LO", 2) == 0)
         {
            memcpy(pADL_DATA_PRIV_ACQ->sTransactionDetail,
               pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, 16);
            nVarPos += 16;
         }
      }
      if (lBitMap & 0x10000000)
      {  //04. char cTranstatusInd
         memcpy(&pADL_DATA_PRIV_ACQ->cTranstatusInd,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->cTranstatusInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cTranstatusInd);
      }
      int i = sizeof(struct pulsediscover::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "AG", 2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      int nVarPos = 0;
      struct amex::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct amex::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,
         pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map, "%08x", &lBitMap);
      if (lBitMap & 0x40000000) // Bit 2 for EmailLength and email
      {
         memcpy(pADL_DATA_PRIV_ACQ->sEmailLen,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEmailLen));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEmailLen);
         memcpy(pADL_DATA_PRIV_ACQ->sEmail,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sEmail));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sEmail);
      }
      if (lBitMap & 0x20000000) //Bit 3 Hostname length and Hostname
      {
         memcpy(pADL_DATA_PRIV_ACQ->sHostnameLen,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sHostnameLen));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sHostnameLen);
         memcpy(pADL_DATA_PRIV_ACQ->sHostname,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sHostname));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sHostname);
      }
      if (lBitMap & 0x10000000) // Bit 4 for BrowserTypeLen and BrowserType
      {
         memcpy(pADL_DATA_PRIV_ACQ->sBrowserTypeLen,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sBrowserTypeLen));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sBrowserTypeLen);
         memcpy(pADL_DATA_PRIV_ACQ->sBrowserType,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sBrowserType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sBrowserType);
      }
      if (lBitMap & 0x08000000) // Bit 5 for Ship to country code
      {
         memcpy(pADL_DATA_PRIV_ACQ->sShipToCountryCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sShipToCountryCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sShipToCountryCode);
      }
      if (lBitMap & 0x04000000) // Bit6
      {
         memcpy(pADL_DATA_PRIV_ACQ->sShipMethod,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sShipMethod));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sShipMethod);
      }
      if (lBitMap & 0x02000000) //Bit 7
      {
         memcpy(pADL_DATA_PRIV_ACQ->sMerchantProductSku,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sMerchantProductSku));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sMerchantProductSku);
      }
      if (lBitMap & 0x01000000) // Bit 8
      {
         memcpy(pADL_DATA_PRIV_ACQ->sCustIPAddress,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCustIPAddress));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCustIPAddress);
      }
      if (lBitMap & 0x00800000) // Bit 9
      {
         memcpy(pADL_DATA_PRIV_ACQ->sCustPhone,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCustPhone));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCustPhone);
      }
      if (lBitMap & 0x00400000) // Bit 10
      {
         memcpy(pADL_DATA_PRIV_ACQ->sCustPhoneType,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sCustPhoneType));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sCustPhoneType);
      }
      if (lBitMap & 0x00200000)  // Bit 11
      {
         memcpy(pADL_DATA_PRIV_ACQ->sGoodsSoldDataVersion,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sGoodsSoldDataVersion));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sGoodsSoldDataVersion);
      }
      if (lBitMap & 0x00100000)  // Bit 12
      {
         memcpy(pADL_DATA_PRIV_ACQ->sGoodsSoldProductCode,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sGoodsSoldProductCode));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sGoodsSoldProductCode);
      }
      if (lBitMap & 0x00000200) // Bit 23
      {
         memcpy(pADL_DATA_PRIV_ACQ->sAMEX_SE_NUMBER,
            pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos,
            sizeof(pADL_DATA_PRIV_ACQ->sAMEX_SE_NUMBER));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sAMEX_SE_NUMBER);
      }
      int i = sizeof(struct amex::segADL_DATA_PRIV_ACQ) - 1;
      while (i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
         i--;
      if (i >= 0)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, i + 1);
   }
   else if (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "MG", 2) == 0)
   {
      int nVarPos = 13;
      char sFixedFmt[255];
      int nFixedPos = 13;
      //pos 1 : Banknet Reference Number(9)                 FINIPC Bit : 1
      //pos 2 : Airline Ticket Number(15)                   FINIPC Bit : 2
      //pos 3 : Airline Passenger Name(25)                  FINIPC Bit : 3
      //pos 4 : Airline Travel Date(6)                      FINIPC Bit : 4
      //pos 5 : Airline City Origin(5)                      FINIPC Bit : 5
      //pos 6 : Airline City Destination(5)                 FINIPC Bit : 6
      //pos 7 : Vehicle Agreement Number(9)                 FINIPC Bit : 7
      //pos 8 : Vehicle Return City(18)                     FINIPC Bit : 8
      //pos 9 : Arrival Date(6)                             FINIPC Bit : 9
      //pos 10 : Folio Number(10)                           FINIPC Bit : 10
      //pos 11 : Cross Border Transaction Indicator(1)
               // and Cross Border Currency Indicator(1)  FINIPC Bit : 11
      //pos 12 : Function Code(3)                           FINIPC Bit : 12
      //pos 13 : Network Reference ID(15)                   FINIPC Bit : 13
      //pos 14 : Interchange Rate Qualifier(8)              FINIPC Bit : 14
      //pos 15 : Acquirer Reference Number(23)              FINIPC Bit : 15
      short siMGFieldLen[16] = { 9, 15, 25, 6, 5, 5, 9, 18, 6, 10, 2, 3, 15, 8, 23, 0 };
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap, pFinancialSeg21->sAdtlDataPrivAcqr + 5, 8);
      memset(sFixedFmt, ' ', sizeof(sFixedFmt));
      memcpy(sFixedFmt, pFinancialSeg21->sAdtlDataPrivAcqr, 13);
      char psBits[4];
      for (int i = 0; i < 4; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sFixedFmt + nFixedPos,
                  pFinancialSeg21->sAdtlDataPrivAcqr + nVarPos, siMGFieldLen[nFieldNum]);
               nVarPos += siMGFieldLen[nFieldNum];
            }
            nFixedPos += siMGFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(sFixedFmt, sizeof(sFixedFmt));
   }
   else if ((Extract::instance()->getCustomCode() == "SUN") &&
      (memcmp(pFinancialSeg21->sAdtlDataPrivAcqr, "EH", 2) == 0))
   {
      string strADL_DATA_PRIV_ACQ(pFinancialSeg21->sAdtlDataPrivAcqr, 255);
      size_t n = strADL_DATA_PRIV_ACQ.find_last_not_of(' ');
      if (n != string::npos)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strADL_DATA_PRIV_ACQ.data(), n + 1);
   }
   else if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 30)
   {
      string strADL_DATA_PRIV_ACQ(pFinancialSeg21->sAdtlDataPrivAcqr, 255);
      size_t n = strADL_DATA_PRIV_ACQ.find_last_not_of(' ');
      if (n != string::npos)
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strADL_DATA_PRIV_ACQ.data(), n + 1);
   }
   else if (Extract::instance()->getCustomCode() == "EBT")
   {
      char sFixedFmt[255];
      memset(sFixedFmt, ' ', 255);
      struct ebt::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct ebt::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
      if (Token::parse(255, string(pFinancialSeg21->sAdtlDataPrivAcqr, 255), 1, m_hTokenMap, sizeof(pADL_DATA_PRIV_ACQ->sData_Len)))
      {
         map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("EB");
         if (pToken != m_hTokenMap.end())
         {
            memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier, pFinancialSeg21->sAdtlDataPrivAcqr, (*pToken).second.length());
            memcpy(pADL_DATA_PRIV_ACQ->sData_Len, pFinancialSeg21->sAdtlDataPrivAcqr + 2, (*pToken).second.length());
            memcpy(pADL_DATA_PRIV_ACQ->sFNSNumber, (*pToken).second.data(), (*pToken).second.length());
         }
         pToken = m_hTokenMap.find("IT");
         if (pToken != m_hTokenMap.end())
            memcpy(pADL_DATA_PRIV_ACQ->sShippingAddress, (*pToken).second.data(), (*pToken).second.length());
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ, sizeof(sFixedFmt));
      }
   }
  //## end AdvantageFinancial::mapSegment21%3C6190480196.body
}

void AdvantageFinancial::mapSegment22 (hFinancialSeg22* pFinancialSeg22)
{
  //## begin AdvantageFinancial::mapSegment22%3C61904802FD.body preserve=yes
   translate(pFinancialSeg22->sAdtlDataPrivIssr, sizeof(hFinancialSeg22));
   if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "MC", 2) == 0)
   {
      int nVarPos = 13;
      char sFixedFmt[82];
      int nFixedPos = 13;
      // pos 1: Merchant Advice (2)                               FINIPC Bit :1
      // pos 2: Magnetic Stripe Compliance Status Indicator (1)   FINIPC Bit :4
      // pos 3: Magnetic Stripe Compliance Error Indicator (1)    FINIPC Bit :5
      // pos 4: Paypass Ind - Account Number Indicator (1)        FINIPC Bit :6
      // pos 5: Paypass Ind - Account Number (19)                 FINIPC Bit :7
      // pos 6: Paypass Ind - Expiration Date (4)                 FINIPC Bit :8
      //pos 7: Original e-Com Security Level Indicator
            //and UCAF Collection Indicator(3)                 FINIPC Bit:12
      //pos 8: Reason for UCAF Collection Indicator
            //Downgrade Values                                 FINIPC Bit: 13
      short siMCFieldLen[20] = { 2,0,0,1,1,1,19,4,2,1,1,3,1,1,1,22,6,2,0 };
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
      memset(sFixedFmt, ' ', sizeof(sFixedFmt));
      memcpy(sFixedFmt, pFinancialSeg22->sAdtlDataPrivIssr, 13);
      char psBits[4];
      for (int i = 0; i < 5; i++)
      {
         convertBitMap(sBitMap[i], psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sFixedFmt + nFixedPos,
                  pFinancialSeg22->sAdtlDataPrivIssr + nVarPos, siMCFieldLen[nFieldNum]);
               nVarPos += siMCFieldLen[nFieldNum];
            }
            nFixedPos += siMCFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sFixedFmt, sizeof(sFixedFmt));
   }
   else
      if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "MD", 2) == 0)
      {
         int nVarPos = 13;
         char sAdtlDataPrivIssr[79];
         int nFixedPos = 13;
         short siMCFieldLen[16] = {6,2,1,19,4,1,3,1,3,2,1,1,22,0,0,0};
         int nFieldNum = 0;
         char sBitMap[8];
         memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
         memset(sAdtlDataPrivIssr, ' ', sizeof(sAdtlDataPrivIssr));
         memcpy(sAdtlDataPrivIssr, "MD043F8000000", 13);
         char psBits[4];
         for (int i = 0; i < 4; i++)
         {
            convertBitMap(sBitMap[i], psBits);
            for (int j = 0; j < 4; ++j)
            {
               if (psBits[j] == '1')      //field is present
               {
                  memcpy(sAdtlDataPrivIssr + nFixedPos,
                     pFinancialSeg22->sAdtlDataPrivIssr + nVarPos, siMCFieldLen[nFieldNum]);
                  nVarPos += siMCFieldLen[nFieldNum];
               }
               nFixedPos += siMCFieldLen[nFieldNum];
               ++nFieldNum;
            }
         }
         m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sAdtlDataPrivIssr, sizeof(sAdtlDataPrivIssr));
      }
      else
         if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "VD", 2) == 0)
         {
            int nVarPos = 13;
            char sADL_DATA_PRIV_ISS[46];
            int nFixedPos = 13;
            short siVDFieldLen[12] = { 4,1,1,6,1,1,1,12,1,1,4,0 };
            int nFieldNum = 0;
            char sBitMap[8];
            memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
            memset(sADL_DATA_PRIV_ISS, ' ', sizeof(sADL_DATA_PRIV_ISS));
            memcpy(sADL_DATA_PRIV_ISS, "VD023FE000000", 13);
            char psBits[4];
            for (int i = 0; i < 3; i++)
            {
               convertBitMap(sBitMap[i], psBits);
               for (int j = 0; j < 4; ++j)    // four fields per byte.
               {
                  if (psBits[j] == '1')      //field is present
                  {
                     memcpy(sADL_DATA_PRIV_ISS + nFixedPos,
                        pFinancialSeg22->sAdtlDataPrivIssr + nVarPos, siVDFieldLen[nFieldNum]);
                     nVarPos += siVDFieldLen[nFieldNum];
                  }
                  nFixedPos += siVDFieldLen[nFieldNum];
                  ++nFieldNum;
               }
            }
            m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sADL_DATA_PRIV_ISS, sizeof(sADL_DATA_PRIV_ISS));
         }
         else
            if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "VE", 2) == 0)
            {
               int nVarPos = 13;
               char sADL_DATA_PRIV_ISS[33];
               int nFixedPos = 13;
               short siVDFieldLen[8] = { 1,1,12,1,1,4,0,0 };
               int nFieldNum = 0;
               char sBitMap[8];
               memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
               memset(sADL_DATA_PRIV_ISS, ' ', sizeof(sADL_DATA_PRIV_ISS));
               memcpy(sADL_DATA_PRIV_ISS, "VE00980000000", 13);
               char psBits[4];
               for (int i = 0; i < 2; i++)
               {
                  convertBitMap(sBitMap[i], psBits);
                  for (int j = 0; j < 4; ++j)    // four fields per byte.
                  {
                     if (psBits[j] == '1')      //field is present
                     {
                        memcpy(sADL_DATA_PRIV_ISS + nFixedPos,
                           pFinancialSeg22->sAdtlDataPrivIssr + nVarPos, siVDFieldLen[nFieldNum]);
                        nVarPos += siVDFieldLen[nFieldNum];
                     }
                     nFixedPos += siVDFieldLen[nFieldNum];
                     ++nFieldNum;
                  }
               }
               m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sADL_DATA_PRIV_ISS, sizeof(sADL_DATA_PRIV_ISS));
            }
            else
               if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "IC", 2) == 0)
               {
                  string strADL_DATA_PRIV_ISS(pFinancialSeg22->sAdtlDataPrivIssr, 255);
                  size_t n = strADL_DATA_PRIV_ISS.find_last_not_of(' ');
                  if (n != string::npos)
                     m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(strADL_DATA_PRIV_ISS.data(), n + 1);
                  vocalink::segADL_DATA_PRIV_ISS* r = (struct vocalink::segADL_DATA_PRIV_ISS*) strADL_DATA_PRIV_ISS.data();
                  m_pIntegratedCircuitCardSegment->setPresence(true);
                  // CodeTable::nibbleToByte(r->sAPPL_CRYPTOGRAM,sizeof(r->sAPPL_CRYPTOGRAM),strTemp,true);
                  // m_pIntegratedCircuitCardSegment->setAPPL_CRYPTOGRAM(strTemp.data(),strTemp.length());
                  string strTemp(r->sISS_SCRIPT1_DATA, sizeof(r->sISS_SCRIPT1_DATA));
                  n = strTemp.find_last_not_of(' ');
                  if (n != string::npos)
                  {
                     CodeTable::nibbleToByte(r->sISS_SCRIPT1_DATA, sizeof(r->sISS_SCRIPT1_DATA), strTemp, true);
                     m_pIntegratedCircuitCardSegment->setISS_SCRIPT1_DATA(strTemp.data(), strTemp.length());
                  }
                  strTemp.assign(r->sISS_SCRIPT2_DATA, sizeof(r->sISS_SCRIPT2_DATA));
                  n = strTemp.find_last_not_of(' ');
                  if (n != string::npos)
                  {
                     CodeTable::nibbleToByte(r->sISS_SCRIPT2_DATA, sizeof(r->sISS_SCRIPT2_DATA), strTemp, true);
                     m_pIntegratedCircuitCardSegment->setISS_SCRIPT2_DATA(strTemp.data(), strTemp.length());
                  }
               }
               else
                  if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "SH", 2) == 0)
                  {
                     int nVarPos = 13;
                     char sADL_DATA_PRIV_ISS[30];
                     int nFixedPos = 13;
                     short siSHFieldLen[4] = { 16,1,0,0 };
                     int nFieldNum = 0;
                     char sBitMap[8];
                     memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
                     memset(sADL_DATA_PRIV_ISS, ' ', sizeof(sADL_DATA_PRIV_ISS));
                     memcpy(sADL_DATA_PRIV_ISS, "SH03030000000", 13);
                     char psBits[4];
                     for (int i = 0; i < 1; i++)
                     {
                        convertBitMap(sBitMap[i], psBits);
                        for (int j = 0; j < 4; ++j)    // four fields per byte.
                        {
                           if (psBits[j] == '1')      //field is present
                           {
                              memcpy(sADL_DATA_PRIV_ISS + nFixedPos,
                                 pFinancialSeg22->sAdtlDataPrivIssr + nVarPos, siSHFieldLen[nFieldNum]);
                              nVarPos += siSHFieldLen[nFieldNum];
                           }
                           nFixedPos += siSHFieldLen[nFieldNum];
                           ++nFieldNum;
                        }
                     }
                     m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sADL_DATA_PRIV_ISS, sizeof(sADL_DATA_PRIV_ISS));
                  }
                  else
                     if (memcmp(pFinancialSeg22->sAdtlDataPrivIssr, "ST", 2) == 0)
                     {
                        if (Extract::instance()->getCustomCode() == "WOW")
                        {
                           m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(pFinancialSeg22->sAdtlDataPrivIssr, 34);
                        }
                        else
                        {
                           int nVarPos = 13;
                           char sADL_DATA_PRIV_ISS[30];
                           int nFixedPos = 13;
                           short siSTFieldLen[4] = {15,1,0,0};
                           int nFieldNum = 0;
                           char sBitMap[8];
                           memcpy(sBitMap, pFinancialSeg22->sAdtlDataPrivIssr + 5, 8);
                           memset(sADL_DATA_PRIV_ISS,' ',sizeof(sADL_DATA_PRIV_ISS));
                           memcpy(sADL_DATA_PRIV_ISS,"ST02380000000",13);
                           char psBits[4];
                           for (int i = 0; i<1; i++)
                           {
                              convertBitMap(sBitMap[i], psBits);
                              for (int j = 0; j <4; ++j)    // four fields per byte.
                              {
                                 if (psBits[j] == '1')      //field is present
                                 {
                                    memcpy(sADL_DATA_PRIV_ISS+nFixedPos,
                                    pFinancialSeg22->sAdtlDataPrivIssr+nVarPos,siSTFieldLen[nFieldNum]);
                                    nVarPos += siSTFieldLen[nFieldNum];
                                 }
                                 nFixedPos += siSTFieldLen[nFieldNum];
                                 ++nFieldNum;
                              }
                           }
                           m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(sADL_DATA_PRIV_ISS, sizeof(sADL_DATA_PRIV_ISS));
                        } // end if WOW
                     }
                     else
                        if (m_pFinancialSettlementSegment->getDATA_PRIV_ISS_FMT() == 30)
                        {
                           int n = 0;
                           for (int pos = 252; pos >= 0; pos--)
                           {
                              if (pFinancialSeg22->sAdtlDataPrivIssr[pos] != ' ')
                              {
                                 n = pos;
                                 break;
                              }
                           }
                           m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(pFinancialSeg22->sAdtlDataPrivIssr, n + 1);
                        }
  //## end AdvantageFinancial::mapSegment22%3C61904802FD.body
}

void AdvantageFinancial::mapSegment23 (hFinancialSeg23* pFinancialSeg23)
{
  //## begin AdvantageFinancial::mapSegment23%3C619049009C.body preserve=yes
    //if (m_bAsciiInput)
    //   translate(pFinancialSeg23->sPinData,sizeof(pFinancialSeg23->sPinData),CodeTable::CX_ASCII_TO_EBCDIC);
  //## end AdvantageFinancial::mapSegment23%3C619049009C.body
}

void AdvantageFinancial::mapSegment24 (hFinancialSeg24* pFinancialSeg24)
{
  //## begin AdvantageFinancial::mapSegment24%46356F2C0032.body preserve=yes
   UseCase hUseCase("TANDEM", "## AD29 PARSE SEGMENT 24", false);
   short siNumTokens = ntohs(pFinancialSeg24->siNumTokens);
   hFinancialSeg24_TLV* pTLV = (hFinancialSeg24_TLV*)&pFinancialSeg24->firstTag;
   hFinancialSeg24_TLV_SUB* pTLV_SUB = 0;
   hFinancialSeg24_TLV_SUB_NI* pTLV_SUB_NI = 0;
   hFinancialSeg24_TLV_SUB_MI* pTLV_SUB_MI = 0;
   hFinancialSeg24_TLV_SUB_ID* pTLV_SUB_ID = 0;
   hFinancialSeg24_Token_60* pTOKEN_60 = 0;
   hFinancialSeg24_Token_77* pTOKEN_77 = 0;
   hFinancialSeg24_Token_355* pTOKEN_355 = 0;
   hFinancialSeg24_Token_338* pTOKEN_338 = 0;
   hFinancialSeg24_Token_340* pTOKEN_340 = 0;
   hFinancialSeg24_TLV_SUB_62* pTLV_SUB_62 = 0;
   bool bClearing = false;
   short j = 0;
   short k = 0;
   char sTRAN_DESC[100];
   char sTRAN_UNIQUE_DATA[50];
   short m = ntohs(pFinancialSeg24->siSegmentLength);
   string strSeg24Data;
   size_t lPos = 0, lPos1 = 0, lPos2 = 0, lItemLen = 0, lToken315Len = 0, lTokenIdx = 0, lSpaceCnt = 0;
   const char cSpace = 32;
   string strCooperData;
   const char *pToken315 = 0;
   string strADL_DATA_NATIONAL(m_pFinancialSettlementSegment->zADL_DATA_NATIONAL(),m_pFinancialSettlementSegment->getSizeofADL_DATA_NATIONAL());
   bool bDF09Presence = false;
   for (int i = 0; i < siNumTokens; i++)
   {
      short siToken = ntohs(pTLV->siToken);
      short siTokenLength = ntohs(pTLV->siTokenLength);
      short siWorkingLength = 0;
      m -= 4; // token ID and length
      m -= siTokenLength;
      m -= siTokenLength % 2; // slack byte
      if (m < 0)
      {
         UseCase::setSuccess(false);
         break;
      }
      if (siTokenLength > 0)
      {
         if (m_hSeg24Tokens.find(siToken) == m_hSeg24Tokens.end())
         {
            char* pszTemp = new_char((siTokenLength * 2));
            char* pszTokenValue = new_char((siTokenLength * 2) + (2 * PERCENTD));
            if (m_hSeg24NumericTokens.find(siToken) != m_hSeg24NumericTokens.end())
            {
               siWorkingLength = siTokenLength * 2;
               memcpy(pszTemp,hexToChar(pTLV->sTokenValue, siTokenLength).c_str(), siWorkingLength);
            }
            else
            {
               memcpy(pszTemp, pTLV->sTokenValue, siTokenLength);
               translate(pszTemp, siTokenLength);
               siWorkingLength = siTokenLength;
            }
            if (((strSeg24Data.length() + siWorkingLength + 8 ) <= 16384) && siWorkingLength > 0)
            {
               strSeg24Data.append(pszTokenValue,snprintf(pszTokenValue,(siWorkingLength + 2 * PERCENTD),"%04d%04d",siToken,siWorkingLength));
               strSeg24Data.append(pszTemp,siWorkingLength);
            }
            delete[] pszTokenValue;
            delete[] pszTemp;
         }
         switch (siToken)
         {
         case 14:
            siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue,siWorkingLength);
            if (siTokenLength >= 10)
               m_pFinancialUserSegment->setDATE_TIME_XMIT(pTLV->sTokenValue,10);
            if (siTokenLength >= 20)
               m_pFinancialUserSegment->setODE_DATE_TIME_XMIT(pTLV->sTokenValue + 10,10);
            break;
         case 30:
            if (Extract::instance()->getCustomCode(1) == "TILL")
            {
               // DE 62
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siTokenLength);
               j = siTokenLength;
               pTLV_SUB_62 = (hFinancialSeg24_TLV_SUB_62*)pTLV->sTokenValue;
               string strTokenData;
               while (j > 0)
               {
                  char szTokenSubLen[5] = "    ";
                  memcpy(szTokenSubLen, pTLV_SUB_62->sTokenLength, sizeof(pTLV_SUB_62->sTokenLength));
                  unsigned int iTokenSubLen = atoi(szTokenSubLen);
                  if (memcmp(pTLV_SUB_62->sToken, "DF09", 4) == 0
                     && memcmp(pTLV_SUB_62->sTokenValue, "01", 2) == 0)
                     bDF09Presence = true;
                  if (strTokenData.length() + iTokenSubLen + 7 <= 400)
                  {
                     strTokenData.append("{", 1);
                     strTokenData.append(pTLV_SUB_62->sToken, 4);
                     strTokenData.append("|", 1);
                     strTokenData.append(pTLV_SUB_62->sTokenValue, iTokenSubLen);
                     strTokenData.append("},", 2);
                     pTLV_SUB_62 = (hFinancialSeg24_TLV_SUB_62*)((char*)pTLV_SUB_62 + iTokenSubLen + 8);
                  }
                  j -= (iTokenSubLen + 8);
               }
               if (!strTokenData.empty())
               {
                  m_pFinancialAdjustmentExtensionSegment->setPresence(true);
                  m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(strTokenData.data(), strTokenData.length() - 1);
               }
            }
            break;
         case 43:
            //FALCON_DATA
            siWorkingLength = siTokenLength > 165 ? 165 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialSettlementSegment->setFALCON_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 44:
         {
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("PD");
               if (pToken != m_hTokenMap.end())
               {
                  m_pFinancialSettlementSegment->setPROGRAM_ID((*pToken).second.data(),
                     (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("PI");
               if (pToken != m_hTokenMap.end())
               {
                  m_pFinancialSettlementSegment->setPIN_FLG((*pToken).second.data(),
                     (*pToken).second.length() > 1 ? 1 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("SN");
               if (pToken != m_hTokenMap.end())
               {
                  if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 40)
                  {
                     m_pPulseSegment->setPresence(true);
                     m_pPulseSegment->setMULTI_CLEAR_SEQ_NO((*pToken).second.data(),
                        (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
                  }
                  m_pFinancialSettlementSegment->setMULTI_CLEAR_SEQ_NO((*pToken).second.data(),
                     (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
                  if (m_pFinancialBaseSegment->zMAPPED_DUP_DATA()[0] == '\0')
                  {
                     char sMAPPED_DUP_DATA[18];
                     memcpy(sMAPPED_DUP_DATA, m_pFinancialBaseSegment->zTSTAMP_TRANS(), 16);
                     memcpy(sMAPPED_DUP_DATA + 16, m_pFinancialSettlementSegment->zMULTI_CLEAR_SEQ_NO(), 2);
                     m_pFinancialBaseSegment->setMAPPED_DUP_DATA(sMAPPED_DUP_DATA, 18);
                  }
               }
               pToken = m_hTokenMap.find("CN");
               if (pToken != m_hTokenMap.end())
               {
                  if (m_pFinancialSettlementSegment->getDATA_PRIV_ACQ_FMT() == 40)
                  {
                     m_pPulseSegment->setPresence(true);
                     m_pPulseSegment->setMULTI_CLEAR_COUNT((*pToken).second.data(),
                        (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
                  }
                  m_pFinancialSettlementSegment->setMULTI_CLEAR_COUNT((*pToken).second.data(),
                     (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("FS");
               if (pToken != m_hTokenMap.end())
               {
                  if ((*pToken).second.length() > 31
                     && memcmp((*pToken).second.data(), "05", 2) == 0)   // Product ID 05 Mastercard
                     m_pFinancialUserSegment->setTRAN_INT_CLASS((*pToken).second.data() + 31, 2);
               }
               pToken = m_hTokenMap.find("MK");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialSettlementSegment->setAMX_FRAUD_DATA((*pToken).second.data(),
                     (*pToken).second.length() > 51 ? 51 : (*pToken).second.length());
               m_pFinancialPaymentSegment->setPresence(true);
               pToken = m_hTokenMap.find("R1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setINSTALLMENT_TYPE((*pToken).second.data(),(*pToken).second.length() > 1 ? 1 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R2");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setPER_TRAN_IND((*pToken).second.data(),(*pToken).second.length() > 1 ? 1 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R3");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setNUM_INSTALLMENT((*pToken).second.data(),(*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R4");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setFREQUENCY((*pToken).second.data(),(*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R5");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setREGISTRATION_REFNO((*pToken).second.data(),(*pToken).second.length() > 35 ? 35 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R6");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setAMT_MAXIMUM((*pToken).second.data(),(*pToken).second.length() > 12 ? 12 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R7");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialPaymentSegment->setVALIDATION_IND((*pToken).second.data(),(*pToken).second.length() > 1 ? 1 : (*pToken).second.length());

               char szTagLength[6] = { "     " };
               pToken = m_hTokenMap.find("M1");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M1%02d", (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M2");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M2%02d", (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M3");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M3%02d", (*pToken).second.length() > 99 ? 99 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 99 ? 99 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M4");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M4%02d", (*pToken).second.length() > 16 ? 16 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 16 ? 16 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M5");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M5%02d", (*pToken).second.length() > 16 ? 16 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 16 ? 16 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M6");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M6%02d", (*pToken).second.length() > 25 ? 25 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 25 ? 25 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M7");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M7%02d", (*pToken).second.length() > 21 ? 21 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 21 ? 21 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M8");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M8%02d", (*pToken).second.length() > 06 ? 06 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 06 ? 06 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("M9");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\M9%02d", (*pToken).second.length() > 13 ? 13 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 13 ? 13 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("MA");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\MA%02d", (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("MB");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\MB%02d", (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 03 ? 03 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("MC");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength), "\\MC%02d", (*pToken).second.length() > 10 ? 10 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength, 5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(), (*pToken).second.length() > 10 ? 10 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("MD");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength,sizeof(szTagLength),"\\MD%02d",(*pToken).second.length() > 20 ? 20 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength,5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(),(*pToken).second.length() > 20 ? 20 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("ME");
               if (pToken != m_hTokenMap.end())
               {
                  snprintf(szTagLength, sizeof(szTagLength),"\\ME%02d",(*pToken).second.length() > 20 ? 20 : (*pToken).second.length());
                  strADL_DATA_NATIONAL.append(szTagLength,5);
                  strADL_DATA_NATIONAL.append((*pToken).second.data(),(*pToken).second.length() > 20 ? 20 : (*pToken).second.length());
               }
            }
         }
         break;
         case 57:
            siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_pFinancialUserSegment->setPRM_ADL_RESP_DATA(pTLV->sTokenValue,siWorkingLength);
            break;
            case 60:
            {
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue,siTokenLength);
               pTOKEN_60 = (hFinancialSeg24_Token_60*)pTLV->sTokenValue;
               for (int i = 0; i < 10; i++)
               {
                  CashDepositSegment::instance()->setITEM_VALUE(ntohl(pTOKEN_60->iITEM_VALUE[i]));
                  CashDepositSegment::instance()->setITEM_COUNT(ntohs(pTOKEN_60->siITEM_COUNT[i]));
                  m_hCashDepositSegment.push_back(*(CashDepositSegment::instance()));
               }
            }
            break;
         case 73:
         {
            //NETWORK_INTERCHANGE_TIER_QUAL
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            pTLV_SUB_NI = (hFinancialSeg24_TLV_SUB_NI*)pTLV->sTokenValue;
            char szNetInterchange[6] = { "     " };
            if (memcmp(pTLV_SUB_NI->sSubToken, "PS", 2) == 0)
            {
               hFinancialSeg24_TLV_SUB_PS* pTLV_SUB_PS = (hFinancialSeg24_TLV_SUB_PS*)pTLV_SUB_NI->sSubToken;
               memcpy(szNetInterchange, pTLV_SUB_NI->sSubToken, sizeof(pTLV_SUB_NI->sSubToken));
               memcpy(szNetInterchange + sizeof(pTLV_SUB_NI->sSubToken), pTLV_SUB_PS->sFPAEligibilityStatusInd, sizeof(pTLV_SUB_PS->sFPAEligibilityStatusInd));
               m_pFinancialSettlementSegment->setNET_INTRCHG_TIER(szNetInterchange, sizeof(pTLV_SUB_NI->sSubToken) + sizeof(pTLV_SUB_PS->sFPAEligibilityStatusInd));
            }
            else
            {
               char szSubTokLen[3] = "  ";
               memcpy(szSubTokLen, pTLV_SUB_NI->sSubTokenLength, sizeof(pTLV_SUB_NI->sSubTokenLength));
               int iSubTokLen = atoi(szSubTokLen);
               siWorkingLength = iSubTokLen > 3 ? 3 : iSubTokLen;
               memcpy(szNetInterchange, pTLV_SUB_NI->sSubToken, sizeof(pTLV_SUB_NI->sSubToken));
               memcpy(szNetInterchange + 2, pTLV_SUB_NI->sSubTokenValue, siWorkingLength);
               m_pFinancialSettlementSegment->setNET_INTRCHG_TIER(szNetInterchange, siWorkingLength + sizeof(pTLV_SUB_NI->sSubToken));
            }
         }
         break;
         case 75:
            //Overdraft Indicators
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialSettlementSegment->setOVERDRAFT_IND(pTLV->sTokenValue, siWorkingLength);
            break;
         case 77:
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siTokenLength);
               pTOKEN_77 = (hFinancialSeg24_Token_77*)pTLV->sTokenValue;
               if (memcmp(pTOKEN_77->sFeeTypeCode, "72", 2) == 0)
                  m_pFinancialSettlementSegment->setAFT_CRD_BILL(ntohl(pTOKEN_77->lFeeAmt));
               break;
         case 79:
            //UNFORMATTED MICR DATA
            siWorkingLength = siTokenLength > 48 ? 48 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setUNFORMATTED_MICR_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 83:
            //INSTITUTION_TIER_QUAL
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialSettlementSegment->setINST_TIER(pTLV->sTokenValue, siWorkingLength);
            break;
         case 86:
            //Bin Length
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            m_pFinancialUserSegment->setBIN_LENGTH(hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 87:
         case 94:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 3, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("NDPSTR");
               if (pToken != m_hTokenMap.end())
               {
                  m_pPulseSegment->setPresence(true);
                  m_pPulseSegment->setTRAN_ID((*pToken).second.c_str(),
                     (*pToken).second.length() > 16 ? 16 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("NDACAR");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialSettlementSegment->setREF_DATA_ACQ((*pToken).second.c_str(),
                  (*pToken).second.length() > 23 ? 23 : (*pToken).second.length());
               pToken = m_hTokenMap.find("NDACEI");
               if (pToken != m_hTokenMap.end())
               {
                  m_pFinancialUserSegment->setACL_ECOM_IND((*pToken).second.data(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("NDSTEI");
               if (pToken != m_hTokenMap.end())
               {
                  char szADL_DATA_PRIV_ACQ[255];
                  memset(szADL_DATA_PRIV_ACQ, ' ', sizeof(szADL_DATA_PRIV_ACQ));
                  int iLen = m_pFinancialSettlementSegment->getSizeofADL_DATA_PRIV_ACQ();
                  memcpy(szADL_DATA_PRIV_ACQ, m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ(), iLen);
                  szADL_DATA_PRIV_ACQ[iLen + 1] = '\0';
                  if (memcmp(szADL_DATA_PRIV_ACQ, "ST", 2) == 0)
                     szADL_DATA_PRIV_ACQ[iLen] = (*pToken).second.data()[0];
                  else if (memcmp(szADL_DATA_PRIV_ACQ, "SR", 2) == 0)
                     szADL_DATA_PRIV_ACQ[iLen] = (*pToken).second.data()[0];
                  m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(szADL_DATA_PRIV_ACQ, iLen + 1);
               }
            }
            break;
         case 92:
         case 93:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("T1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setPAN_TOKEN((*pToken).second.c_str(),
                  (*pToken).second.length() > 19 ? 19 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T2");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_ASSURANCE((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T3");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_REQUESTOR_ID((*pToken).second.c_str(),
                  (*pToken).second.length() > 11 ? 11 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T4");
               if (pToken != m_hTokenMap.end())
               {
                  m_pFinancialUserSegment->setPAN_RANGE((*pToken).second.c_str(),
                     (*pToken).second.length() > 19 ? 19 : (*pToken).second.length());
               }
               pToken = m_hTokenMap.find("T5");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setPAN_INDICATOR((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T6");
               if ((m_bTokenExpirationDate) && (pToken != m_hTokenMap.end()))
                  m_pFinancialUserSegment->setTOKEN_EXP_DATE((*pToken).second.c_str(),
                  (*pToken).second.length() > 4 ? 4 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T7");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_CRYPTOGRAM((*pToken).second.c_str(),
                  (*pToken).second.length() > 28 ? 28 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T8");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_REF_NUMBER((*pToken).second.c_str(),
                  (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
               pToken = m_hTokenMap.find("T9");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_TYPE((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TA");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_STATUS((*pToken).second.c_str(),
                  (*pToken).second.length() > 1 ? 1 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TB");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_TRANID((*pToken).second.c_str(),
                  (*pToken).second.length() > 99 ? 99 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TP");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_ENTITY((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TQ");
               if (pToken != m_hTokenMap.end())
               {
                  map<string, string, less<string> > hTokenMap;
                  if (Token::parse((*pToken).second.length(), string((*pToken).second.c_str(), (*pToken).second.length()), 1, hTokenMap))
                  {
                     pToken = hTokenMap.find("01");
                     if (pToken != hTokenMap.end())
                        m_pFinancialUserSegment->setADDL_TRAN_DISP((*pToken).second.c_str(),
                        (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
                     pToken = hTokenMap.find("02");
                     if (pToken != hTokenMap.end())
                        m_pFinancialUserSegment->setADDL_TRAN_RESULT((*pToken).second.c_str(),
                        (*pToken).second.length() > 90 ? 90 : (*pToken).second.length());
                  }
               }
                pToken = m_hTokenMap.find("TY");
                    if (pToken != m_hTokenMap.end())
                        m_pFinancialUserSegment->setTOKEN_SER_PROVIDER((*pToken).second.c_str(),
                       (*pToken).second.length() > 11 ? 11 : (*pToken).second.length());
               pToken = m_hTokenMap.find("00");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_VERSION((*pToken).second.c_str(),
                  (*pToken).second.length() > 6 ? 6 : (*pToken).second.length());
               pToken = m_hTokenMap.find("03");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_CARD_SEQ_NO((*pToken).second.c_str(),
                  (*pToken).second.length() > 3 ? 3 : (*pToken).second.length());
               pToken = m_hTokenMap.find("07");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_ACT_CODE((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("08");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_STATUS_CODE((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("09");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setDOMAIN_CTL_RESTR((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("0V");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setMERCH_DISP_NAME((*pToken).second.c_str(),
                  (*pToken).second.length() > 100 ? 100 : (*pToken).second.length());
            }
            break;
         case 106:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               int siLen = siTokenLength;
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("MI");
               if (pToken != m_hTokenMap.end())
               {
                  siLen = siLen - 4;
                  m_pFinancialPaymentSegment->setPresence(true);
                  m_pFinancialPaymentSegment->setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
                  m_pFinancialPaymentSegment->setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
                  if (siLen >= 6)
                  {
                     m_pFinancialPaymentSegment->setPROMOTION_CODE((*pToken).second.c_str(), 6);
                     siLen = siLen - 6;
                  }
                  if (siLen >= 2)
                  {
                     m_pFinancialPaymentSegment->setINSTALLMENT_TYPE((*pToken).second.c_str() + 6, 2);
                     siLen = siLen - 2;
                  }
                  if (!memcmp((*pToken).second.c_str(), "HGMINS", 6))
                  {
                     pTLV_SUB_MI = (hFinancialSeg24_TLV_SUB_MI*)(*pToken).second.c_str();
                     if (siLen >= sizeof(pTLV_SUB_MI->sNumInstallments))
                     {
                        m_pFinancialPaymentSegment->setNUM_INSTALLMENTS(pTLV_SUB_MI->sNumInstallments, sizeof(pTLV_SUB_MI->sNumInstallments));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sNumInstallments);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sIssuerInterestRate))
                     {
                        m_pFinancialPaymentSegment->setISS_INTER_RATE(pTLV_SUB_MI->sIssuerInterestRate, sizeof(pTLV_SUB_MI->sIssuerInterestRate));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sIssuerInterestRate);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sAmountFirst))
                     {
                        m_pFinancialPaymentSegment->setAMT_FIRST(pTLV_SUB_MI->sAmountFirst, sizeof(pTLV_SUB_MI->sAmountFirst));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sAmountFirst);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sAmountSubsequent))
                     {
                        m_pFinancialPaymentSegment->setAMT_SUBSEQUENT(pTLV_SUB_MI->sAmountSubsequent, sizeof(pTLV_SUB_MI->sAmountSubsequent));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sAmountSubsequent);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sTaxId))
                     {
                        m_pFinancialPaymentSegment->setTAX_ID(pTLV_SUB_MI->sTaxId, sizeof(pTLV_SUB_MI->sTaxId));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sTaxId);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sAnnualPercentRate))
                     {
                        m_pFinancialPaymentSegment->setANNUAL_PERCNT_RATE(pTLV_SUB_MI->sAnnualPercentRate, sizeof(pTLV_SUB_MI->sAnnualPercentRate));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sAnnualPercentRate);
                     }
                     if (siLen >= sizeof(pTLV_SUB_MI->sAmountInstallment))
                     {
                        m_pFinancialPaymentSegment->setF_AMT_INSTALLMENT(pTLV_SUB_MI->sAmountInstallment, sizeof(pTLV_SUB_MI->sAmountInstallment));
                        siLen = siLen - sizeof(pTLV_SUB_MI->sAmountInstallment);
                     }
                  }
                  else
                  {
                     pToken = m_hTokenMap.find("ID");
                     if (pToken != m_hTokenMap.end())
                     {
                        siLen = siLen - 4;
                        pTLV_SUB_ID = (hFinancialSeg24_TLV_SUB_ID*)(*pToken).second.c_str();
                        if (siLen >= sizeof(pTLV_SUB_ID->sNumInstallments))
                        {
                           m_pFinancialPaymentSegment->setNUM_INSTALLMENTS(pTLV_SUB_ID->sNumInstallments, sizeof(pTLV_SUB_ID->sNumInstallments));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sNumInstallments);
                        }
                        if (siLen >= sizeof(pTLV_SUB_ID->sIssuerInterestRate))
                        {
                           m_pFinancialPaymentSegment->setISS_INTER_RATE(pTLV_SUB_ID->sIssuerInterestRate, sizeof(pTLV_SUB_ID->sIssuerInterestRate));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sIssuerInterestRate);
                        }
                        if (siLen >= sizeof(pTLV_SUB_ID->sNumInstallments))
                        {
                           m_pFinancialPaymentSegment->setF_AMT_INSTALLMENT(pTLV_SUB_ID->sAmountInstallment, sizeof(pTLV_SUB_ID->sAmountInstallment));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sAmountInstallment);
                        }
                        if (siLen >= sizeof(pTLV_SUB_ID->sAmountInstallment))
                        {
                           m_pFinancialPaymentSegment->setANNUAL_PERCNT_RATE(pTLV_SUB_ID->sAnnualPercentRate, sizeof(pTLV_SUB_ID->sAnnualPercentRate));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sAnnualPercentRate);
                        }
                        if (siLen >= sizeof(pTLV_SUB_ID->sAmountFirst))
                        {
                           m_pFinancialPaymentSegment->setAMT_FIRST(pTLV_SUB_ID->sAmountFirst, sizeof(pTLV_SUB_ID->sAmountFirst));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sAmountFirst);
                        }
                        if (siLen >= sizeof(pTLV_SUB_ID->sAmountSubsequent))
                        {
                           m_pFinancialPaymentSegment->setAMT_SUBSEQUENT(pTLV_SUB_ID->sAmountSubsequent, sizeof(pTLV_SUB_ID->sAmountSubsequent));
                           siLen = siLen - sizeof(pTLV_SUB_ID->sAmountSubsequent);
                        }
                     }
                  }
               }
            }
            break;
         case 107:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("TC");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setHCE_ACTIVATE_RESULT((*pToken).second.c_str(),
                  (*pToken).second.length() > 1 ? 1 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TD");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setAAM_VELOCITY_RESULT((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TE");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setLUK_ELAPSED_TIME((*pToken).second.c_str(),
                  (*pToken).second.length() > 4 ? 4 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TF");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setLUK_TRAN_COUNT((*pToken).second.c_str(),
                  (*pToken).second.length() > 3 ? 3 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TG");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setLUK_AMT_TRAN((*pToken).second.c_str(),
                  (*pToken).second.length() > 7 ? 7 : (*pToken).second.length());
               pToken = m_hTokenMap.find("TL");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_REF_NO_2((*pToken).second.c_str(),
                  (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
            }
            break;
         case 108:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("D1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_DEVICE_TYPE((*pToken).second.c_str(),
                  (*pToken).second.length() > 2 ? 2 : (*pToken).second.length());
               pToken = m_hTokenMap.find("D3");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_DEVICE_ID((*pToken).second.c_str(),
                     (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
               pToken = m_hTokenMap.find("D5");
               if (pToken != m_hTokenMap.end())
                   m_pFinancialUserSegment->setTOKEN_DEVICE_NAME((*pToken).second.c_str(),
                   (*pToken).second.length() > 25 ? 25 : (*pToken).second.length());
               pToken = m_hTokenMap.find("D6");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_DEVICE_LOC((*pToken).second.c_str(),
                  (*pToken).second.length() > 25 ? 25 : (*pToken).second.length());
            }
            break;
         case 109:
         case 110:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("W1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_WALLET_ID((*pToken).second.c_str(),
                  (*pToken).second.length() > 3 ? 3 : (*pToken).second.length());
               pToken = m_hTokenMap.find("W7");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setWALLET_REASON((*pToken).second.c_str(),
                     (*pToken).second.length() > 6 ? 6 : (*pToken).second.length());
               pToken = m_hTokenMap.find("WM");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setTOKEN_DEVICE_ID((*pToken).second.c_str(),
                     (*pToken).second.length() > 48 ? 48 : (*pToken).second.length());
            }
            break;
         case 200:
            //TRAN_INDICATORS
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setTRAN_INDICATORS(pTLV->sTokenValue, siWorkingLength);
            break;
         case 205:
            siWorkingLength = siTokenLength > 1 ? 1 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setFORCE_POST_DROP_IND(pTLV->sTokenValue, siWorkingLength);
            break;
         case 12:
         case 206:
         {
            siWorkingLength = siTokenLength > 64 ? 64 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            if (m_hFraudBlockSegment.size() > 0)
               m_hFraudBlockSegment.back().setRULE_NAME(pTLV->sTokenValue,siWorkingLength);
            else
            {
               FraudBlockSegment hFraudBlockSegment;
               hFraudBlockSegment.setRULE_NAME(pTLV->sTokenValue, siWorkingLength);
               hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
               hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
               hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
               hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
               m_hFraudBlockSegment.push_back(hFraudBlockSegment);
            }
         }
         break;
         case 201:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setB24_ACQ_ID(pTLV->sTokenValue, min(size_t(8), strlen(pTLV->sTokenValue)));
            }
            else
            {
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               if (siWorkingLength >= 8)
               {
                  translate(pTLV->sTokenValue, siWorkingLength);
                  m_pFinancialUserSegment->setACQ_FIID(pTLV->sTokenValue + 4, 4);
               }
            }
            break;
         case 202:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 12 ? 12 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setB24_ISS_ID(pTLV->sTokenValue, min(size_t(12), strlen(pTLV->sTokenValue)));
            }
            else
            {
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               if (siWorkingLength >= 8)
               {
                  translate(pTLV->sTokenValue, siWorkingLength);
                  m_pFinancialUserSegment->setISS_FIID(pTLV->sTokenValue + 4, 4);
               }
            }
            break;
         case 209:
            //BIN_EXCLUSION_GRP
            m_pFinancialSettlementSegment->setPresence(true);
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialSettlementSegment->setBIN_EXCLUSION_GRP(pTLV->sTokenValue, siWorkingLength);
            break;
         case 219:
            m_pMultipleRouteSegment->setPresence(true);
            siWorkingLength = siTokenLength > 67 ? 67 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pMultipleRouteSegment->setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
            m_pMultipleRouteSegment->setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
            m_pMultipleRouteSegment->setPRIMARY_PROC_ID(pTLV->sTokenValue, 6);
            m_pMultipleRouteSegment->setPRIMARY_PROCESS_ID(pTLV->sTokenValue + 6, 6);
            m_pMultipleRouteSegment->setPRIMARY_TD_PROCESS_ID(pTLV->sTokenValue + 12, 15);
            m_pMultipleRouteSegment->setPRIMARY_TD_MATCH_OPT(pTLV->sTokenValue + 27, 1);
            m_pMultipleRouteSegment->setPROC_ID(pTLV->sTokenValue + 28, 6);
            m_pMultipleRouteSegment->setPROCESS_ID(pTLV->sTokenValue + 34, 6);
            m_pMultipleRouteSegment->setTD_PROCESS_ID(pTLV->sTokenValue + 40, 15);
            m_pMultipleRouteSegment->setTD_MATCH_OPT(pTLV->sTokenValue + 55, 1);
            m_pMultipleRouteSegment->setMULTI_RTE_OPT(pTLV->sTokenValue + 56, 1);
            m_pMultipleRouteSegment->setSTANDIN_IND(pTLV->sTokenValue + 57, 1);
            m_pMultipleRouteSegment->setCOMPLETION_IND(pTLV->sTokenValue + 58, 1);
            m_pMultipleRouteSegment->setADVICE_IND(pTLV->sTokenValue + 59, 1);
            m_pMultipleRouteSegment->setDENY_OPT(pTLV->sTokenValue + 60, 1);
            m_pMultipleRouteSegment->setPREAUTH_IND(pTLV->sTokenValue + 61, 1);
            m_pMultipleRouteSegment->setREQUEST_BAL_IND(pTLV->sTokenValue + 62, 1);
            m_pMultipleRouteSegment->setRESPONSE_BAL_IND(pTLV->sTokenValue + 63, 1);
            m_pMultipleRouteSegment->setAPPROVED_BY(pTLV->sTokenValue + 64, 1);
            m_pMultipleRouteSegment->setADVICE_TRAN(pTLV->sTokenValue + 65, 1);
            m_pMultipleRouteSegment->setTDRESP(pTLV->sTokenValue + 66, 1);
            break;
         case 224: //PrePaid Card Type Value
         {
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            string strCardType(pTLV->sTokenValue, siWorkingLength);
            string strReturnValue;
            if (ConfigurationRepository::instance()->translate("X_ADV_CARD_TYPE", strCardType, strReturnValue, "FIN_RECORD", "CARD_TYPE", 0, m_bAddEvidence))
               m_pFinancialSettlementSegment->setCARD_TYPE(strReturnValue.data(), strReturnValue.length());
         }
         break;
         case 232:
            //TOKEN_ISSUER_PROC
            siWorkingLength = siTokenLength > 12 ? 12 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            if (siWorkingLength == 12)
               m_pFinancialUserSegment->setTOKEN_ISSUER_PROC(pTLV->sTokenValue + 6, 6);
            break;
         case 248:
            //Payment Account Reference PAR
            siWorkingLength = siTokenLength > 29 ? 29 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setPYMT_ACCT_REF(pTLV->sTokenValue, siWorkingLength);
            break;
         case 252:
            if (Extract::instance()->getCustomCode() == "DGMC")
            {
               m_pFinancialMCDPSegment->setPresence(true);
               siWorkingLength = siTokenLength > 100 ? 100 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialMCDPSegment->setMSSP_ROUTE(pTLV->sTokenValue, siWorkingLength);
            }
            break;
         case 253:
            if (Extract::instance()->getCustomCode() == "DGMC")
            {
               m_pFinancialMCDPSegment->setPresence(true);
               siWorkingLength = siTokenLength > 500 ? 500 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialMCDPSegment->setMSSP_RESPONSE(pTLV->sTokenValue, siWorkingLength);
            }
            break;
         case 254:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("R4");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->instance()->setSWIFT_CODE((*pToken).second.c_str(),
                  (*pToken).second.length() > 11 ? 11 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R5");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->instance()->setIFSC_CODE((*pToken).second.c_str(),
                  (*pToken).second.length() > 11 ? 11 : (*pToken).second.length());
               pToken = m_hTokenMap.find("R6");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->instance()->setLOCAL_RETRIEVAL_REF_NO((*pToken).second.c_str(),
                  (*pToken).second.length() > 12 ? 12 : (*pToken).second.length());
            }
            break;
         case 279:
            if (Extract::instance()->getCustomCode() == "DGMC")
            {
               m_pFinancialMCDPSegment->setPresence(true);
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialMCDPSegment->setBPISO_ELIGIBILITY(pTLV->sTokenValue, siWorkingLength);
            }
            break;
         case 281:
            siWorkingLength = siTokenLength > 25 ? 25 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialBaseSegment->setMEMBER_ID(pTLV->sTokenValue, siWorkingLength);
            break;
            case 284:
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siTokenLength);
               m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
               if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
               {
                  map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("AS");
                  if (pToken != m_hTokenMap.end())
                     m_pFinancialSettlementSegment->setANCILRY_SRVC_CHARGES((*pToken).second.c_str(),
                     (*pToken).second.length() > 84 ? 84 : (*pToken).second.length());
               }
               break;
         case 285:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 2, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("RI04");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setVISA_ATM_TRAN_ID((*pToken).second.c_str(),
                  (*pToken).second.length() > 7 ? 7 : (*pToken).second.length());
            }
            break;
         case 288:  // EC120508bbbbC101 
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("EC");
               if (pToken != m_hTokenMap.end())
               {
                  m_pFinancialUserSegment->setECOM_DATA((*pToken).second.c_str(),
                     (*pToken).second.length() > 99 ? 99 : (*pToken).second.length());
               }
            }
            break;   
         case 289:
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(),m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("SI");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setDIR_SERV_TRAN_ID((*pToken).second.c_str(),
                  (*pToken).second.length() > 36 ? 36 : (*pToken).second.length());
            }
            break;
         case 294:
            //CARD STYLE
            siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setCARD_STYLE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 303:
            //Trusted Merchant Id Flag
            {
               siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue,siTokenLength);
               char szTRUSTED_MERCH_FLG[16];
               FinancialUserSegment::instance()->processFlags(string(pTLV->sTokenValue,siWorkingLength),szTRUSTED_MERCH_FLG);
               m_pFinancialUserSegment->setTRUSTED_MERCH_FLG(&szTRUSTED_MERCH_FLG[13],1);
            }
            break;
         case 298:
            //Pan Identifier ePIC
            siWorkingLength = siTokenLength > 25 ? 25 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setPAN_IDENTIFIER(pTLV->sTokenValue, siWorkingLength);
            break;
         case 300: //(9F19)
           //Chip Token Requestor Id
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 11 ? 11 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setCHIP_TOKEN_REQ_ID(pTLV->sTokenValue, siWorkingLength);
            break;
         case 304:
            if (Extract::instance()->getCustomCode(1) == "TILL")
            {
               if (bDF09Presence && (siTokenLength > 15))
               {
                  if (m_bAsciiInput)
                     translate(pTLV->sTokenValue, siTokenLength);
                  m_pFinancialSettlementSegment->setMCI_UCAF_DATA(pTLV->sTokenValue + 15, min(size_t(32), size_t(siTokenLength - 15)));
               }
            }
            break;
         case 305:
            //3D Secure CAV Validation Indicator
            siWorkingLength = siTokenLength > 1 ? 1 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setEMV_3D_CAVV_VER_BY(pTLV->sTokenValue, siWorkingLength);
            break;
         case 306:
            //3D Secure Internet Transaction Identifier
            siWorkingLength = siTokenLength > 40 ? 40 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            if (memcmp(pTLV->sTokenValue,"XID",3) == 0)
               m_pFinancialUserSegment->setEMV_3D_TRAN_ID(pTLV->sTokenValue+3,siWorkingLength-4);
            break;
         case 308:
             siWorkingLength = siTokenLength > 36 ? 36 : siTokenLength;
             if (m_bAsciiInput)
                 translate(pTLV->sTokenValue, siTokenLength);
             m_pFinancialBaseSegment->setTRANSACTION_ID(pTLV->sTokenValue, siWorkingLength);
             break;
         case 310:
             siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
             if (m_bAsciiInput)
                 translate(pTLV->sTokenValue, siTokenLength);
             m_pFinancialUserSegment->setSAP_ADL_RESP_DATA(pTLV->sTokenValue, siWorkingLength);
             break;
         case 311:
             siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
             if (m_bAsciiInput)
                 translate(pTLV->sTokenValue, siTokenLength);
             m_pFinancialUserSegment->setP1C_ADL_RESP_DATA(pTLV->sTokenValue, siWorkingLength);
             break;
         case 312:
             siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
             if (m_bAsciiInput)
                 translate(pTLV->sTokenValue, siTokenLength);
             m_pFinancialUserSegment->setP1C_ACCT_TOKEN(pTLV->sTokenValue, siWorkingLength);
             break;
         case 313:
             siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
             if (m_bAsciiInput)
                 translate(pTLV->sTokenValue, siTokenLength);
             m_pFinancialUserSegment->setP1C_CRDHLDR_TOKEN(pTLV->sTokenValue, siWorkingLength);
             break;
         case 315:
            //COOPER_SCORE, COOPER_REASON
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            lPos = lPos1 = lPos2 = lItemLen = lToken315Len = lTokenIdx = lSpaceCnt = 0;
            lToken315Len = siTokenLength - 2;
            strCooperData.resize(lToken315Len);
            for (pToken315 = pTLV->sTokenValue + 2; lTokenIdx + lSpaceCnt < lToken315Len; pToken315++)
            {
               if (*pToken315 == cSpace)
                  lSpaceCnt++;
               else
                  strCooperData[lTokenIdx++] = *pToken315;
            }
            lPos1 = strCooperData.find("score\":");
            if (lPos1 != string::npos)
            {
               int iIdx1(Extract::instance()->getCustomCode() == "EFTPOS" ? 8 : 7);
               lPos2 = strCooperData.find_first_of(",}", lPos1);
               if (lPos2 != string::npos)
               {
                  lItemLen = min(size_t(lPos2 - (lPos1 + iIdx1)), size_t(3));
                  m_pFinancialSettlementSegment->setCOOPER_SCORE(strCooperData.data() + lPos1 + iIdx1, lItemLen);
                  if (m_hFraudBlockSegment.size() > 0)
                     m_hFraudBlockSegment.back().setFRAUD_SCORE(strCooperData.data() + lPos1 + iIdx1, lItemLen);
                  else
                  {
                     FraudBlockSegment hFraudBlockSegment;
                     hFraudBlockSegment.setFRAUD_SCORE(strCooperData.data() + lPos1 + iIdx1, lItemLen);
                     hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
                     hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
                     hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
                     hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
                     m_hFraudBlockSegment.push_back(hFraudBlockSegment);
                  }
               }
            }
            lPos1 = strCooperData.find("subClassificationCode\":");
            if (lPos1 != string::npos)
            {
               lPos2 = strCooperData.find_first_of(",}", lPos1);
               if (lPos2 != string::npos)
               {
                  lItemLen = min(size_t(lPos2 - (lPos1 + 24)), size_t(2));
                  if (m_hFraudBlockSegment.size() > 0)
                     m_hFraudBlockSegment.back().setSUB_CLASS_CODE(strCooperData.substr(lPos1 + 24, lItemLen).data(), lItemLen);
                  else
                  {
                     FraudBlockSegment hFraudBlockSegment;
                     hFraudBlockSegment.setSUB_CLASS_CODE(strCooperData.substr(lPos1 + 24,lItemLen).data(),lItemLen);
                     hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(),strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
                     hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
                     hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
                     hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
                     m_hFraudBlockSegment.push_back(hFraudBlockSegment);
                  }
               }
            }
            lPos = strCooperData.find("wbe\":[{\"");
            if (lPos != string::npos)
            {  
               int iIdx2(Extract::instance()->getCustomCode() == "EFTPOS" ? 7 : 8);
               lPos1 = strCooperData.find(Extract::instance()->getCustomCode() == "EFTPOS" ? "name\":\"" : "group\":\"", lPos);
               if (lPos1 != string::npos)
               {
                  lPos2 = strCooperData.find_first_of("\"", lPos1 + iIdx2);
                  if (lPos2 != string::npos)
                  {
                     lItemLen = min(size_t(lPos2 - (lPos1 + iIdx2)), size_t(2));
                     m_pFinancialSettlementSegment->setCOOPER_REASON(strCooperData.data() + lPos1 + iIdx2, lItemLen);
                  }
               }
            }
            break;
         case 318:
            //FEE_GROUP
            m_pFinancialUserSegment->setPresence(true);
            siWorkingLength = siTokenLength > 6 ? 6 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setFEE_GROUP(pTLV->sTokenValue, siWorkingLength);
            break;
         case 317:
             siWorkingLength = siTokenLength > 39 ? 39 : siTokenLength;
             if (m_bAsciiInput)
                translate(pTLV->sTokenValue,siTokenLength);
             if (m_hFraudBlockSegment.size() > 0 )
                m_hFraudBlockSegment.back().setFRAUD_ID(pTLV->sTokenValue,siWorkingLength);
             else
             {
                FraudBlockSegment hFraudBlockSegment;
                hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(),strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
                hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
                hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
                hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
                hFraudBlockSegment.setFRAUD_ID(pTLV->sTokenValue,siWorkingLength);
                m_hFraudBlockSegment.push_back(hFraudBlockSegment);
             }
             break;
         case 322:
         case 323:
             siWorkingLength = siTokenLength > 255 ? 255 : siTokenLength;
             if (m_bAsciiInput)
                translate(pTLV->sTokenValue, siTokenLength);
             strADL_DATA_NATIONAL.append(pTLV->sTokenValue, siWorkingLength);
             break;
         case 326:
             siWorkingLength = siTokenLength > 23 ? 23 : siTokenLength;
             if (m_bAsciiInput)
                translate(pTLV->sTokenValue, siTokenLength);
             if (m_hFraudBlockSegment.size() > 0)
                 m_hFraudBlockSegment.back().setCARD_BIN_HASH(pTLV->sTokenValue,siWorkingLength);
             else
             {
                FraudBlockSegment hFraudBlockSegment;
                hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(),strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
                hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
                hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
                hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(),strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
                hFraudBlockSegment.setCARD_BIN_HASH(pTLV->sTokenValue,siWorkingLength);
                m_hFraudBlockSegment.push_back(hFraudBlockSegment);
             }
             break;
         case 331:
            //SellerIdentification
               siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialUserSegment->setSELLER_ID(pTLV->sTokenValue, siWorkingLength);
           break;
         case 332:
            //SellerEmailAddress
               siWorkingLength = siTokenLength > 40 ? 40 : siTokenLength;
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialUserSegment->setSELLER_EMAIL(pTLV->sTokenValue, siWorkingLength);
            break;
         case 333:
            //SellerPhoneNumber
               siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialUserSegment->setSELLER_PHONE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 338:
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            pTOKEN_338 = (hFinancialSeg24_Token_338*)pTLV->sTokenValue;
            m_pFinancialSettlementSegment->setISSUER_SCRIPT_FLG(pTOKEN_338->bAddBillFlagbit0 ? "Y" : "N", 1);
            break;
         case 340:
            {
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               if (m_bAsciiInput)
                  translate(pTLV->sTokenValue, siTokenLength);
               pTOKEN_340 = (hFinancialSeg24_Token_340*)pTLV->sTokenValue;
               bClearing = false;
               if (memcmp(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ(), "MI", 2) == 0
                  || (memcmp(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ(), "VD", 2) == 0
                     && (memcmp(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ() + 94, "9101", 4) == 0)
                     || memcmp(m_pFinancialSettlementSegment->zADL_DATA_PRIV_ACQ() + 117, "2105", 4) == 0) )
                  bClearing = true;
               char szPROC_FLGS1[16];
               FinancialUserSegment::instance()->processFlags(string(FinancialUserSegment::instance()->zPROC_FLGSn(1), 2), szPROC_FLGS1);
               if (memcmp(m_pFinancialSettlementSegment->zAP_FLG(), "Y", 1) == 0
                   && (szPROC_FLGS1[10] == 'Y'
                      || bClearing))
               {
                  char szPROC_BILLING_FLGS2[16];
                  FinancialUserSegment::instance()->processFlags(string(FinancialUserSegment::instance()->zPROC_BILLING_FLGSn(1), 2), szPROC_BILLING_FLGS2);
                  if (pTOKEN_340->bAddProcFlagbit0 && szPROC_BILLING_FLGS2[13] == 'N')
                     m_pFinancialSettlementSegment->setFP_HOLD_MATCH_FLG("Y", 1);
                  else
                     if (pTOKEN_340->bAddProcFlagbit0 && szPROC_BILLING_FLGS2[13] == 'Y')
                        m_pFinancialSettlementSegment->setFP_HOLD_MATCH_FLG("N", 1);
                     else
                        m_pFinancialSettlementSegment->setFP_HOLD_MATCH_FLG(" ", 1);
               }
            }
            break;
         case 349:
            siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            if (!memcmp(pTLV->sTokenValue, "A67", siWorkingLength))
            {
               m_pFinancialBaseSegment->setACT_CODE(pTLV->sTokenValue, siWorkingLength);
               string strValue;
               FraudBlockSegment hFraudBlockSegment;
               if (ConfigurationRepository::instance()->translate("ACTION_CODE", pTLV->sTokenValue, strValue, " ", " ", -1, false))
                  hFraudBlockSegment.setRULE_NAME(ConfigurationRepository::instance()->getThird());
               hFraudBlockSegment.setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
               hFraudBlockSegment.setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
               hFraudBlockSegment.setINST_ID_RECON_ISS(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ISS()));
               hFraudBlockSegment.setINST_ID_RECON_ACQ(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(), strlen(m_pFinancialBaseSegment->zINST_ID_RECON_ACQ()));
               m_hFraudBlockSegment.push_back(hFraudBlockSegment);
            }
            break;
         case 355:
         {
            pTOKEN_355 = (hFinancialSeg24_Token_355*)pTLV->sTokenValue;
            m_pFinancialAPSegment->setPresence(true);
            m_pFinancialAPSegment->setTSTAMP_TRANS(m_pFinancialBaseSegment->zTSTAMP_TRANS(), strlen(m_pFinancialBaseSegment->zTSTAMP_TRANS()));
            m_pFinancialAPSegment->setUNIQUENESS_KEY(m_pFinancialBaseSegment->getUNIQUENESS_KEY());
            for (int i = 0; i < ntohs(pTOKEN_355->siNoOfOccurrence); i++)
            {
               translate(pTOKEN_355->hLimits[i].sAP_LIMIT_ID, sizeof(pTOKEN_355->hLimits[i]));
               m_pFinancialAPSegment->setAP_LIMIT_IDn(pTOKEN_355->hLimits[i].sAP_LIMIT_ID, sizeof(pTOKEN_355->hLimits[i].sAP_LIMIT_ID),i);
               m_pFinancialAPSegment->setAP_AMOUNT_LIMITn(pTOKEN_355->hLimits[i].sAP_AMOUNT_LIMIT, sizeof(pTOKEN_355->hLimits[i].sAP_AMOUNT_LIMIT),i);
               m_pFinancialAPSegment->setAP_OVERRIDE_INDn(&pTOKEN_355->hLimits[i].cAP_OVERRIDE_IND, sizeof(pTOKEN_355->hLimits[i].cAP_OVERRIDE_IND),i);
               m_pFinancialAPSegment->setAP_ONLINE_INDn(pTOKEN_355->hLimits[i].sAP_ONLINE_IND, sizeof(pTOKEN_355->hLimits[i].sAP_ONLINE_IND),i);
               m_pFinancialAPSegment->setAP_OUTLIMIT_BEFOREn(pTOKEN_355->hLimits[i].sAP_OUTLIMIT_BEFORE, sizeof(pTOKEN_355->hLimits[i].sAP_OUTLIMIT_BEFORE),i);
               m_pFinancialAPSegment->setAP_OUTLIMIT_AFTERn(pTOKEN_355->hLimits[i].sAP_OUTLIMIT_AFTER, sizeof(pTOKEN_355->hLimits[i].sAP_OUTLIMIT_AFTER),i);
            }
         }
         break;
         case 356:
            //PAN Token Bin Length
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            m_pFinancialUserSegment->setPAN_TOKEN_BIN_LEN(hexToChar(pTLV->sTokenValue,siWorkingLength).c_str(),siWorkingLength * 2);
            break;
         case 500: //(9F33)
            //TERM_CAPABILITIES
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 6 ? 6 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTERM_CAPABILITIES(pTLV->sTokenValue, siWorkingLength);
            break;
         case 501: //(95  )
            //TERM_VERIFY_RESULT
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 10 ? 10 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTERM_VERIFY_RESULT(pTLV->sTokenValue, siWorkingLength);
            break;
         case 502: //(9F37)
            //UNPREDICTABLE_NO
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setUNPREDICTABLE_NO(hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 503: //(9F1E)
            //TERM_SERIAL_NO
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTERM_SERIAL_NO(pTLV->sTokenValue, siWorkingLength);
            break;
         case 504: //(9F10)
            //ISS_DISCR_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 64 ? 64 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setISS_DISCR_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 505: //(9F10)
            //ISS_APPL_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 64 ? 64 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setISS_APPL_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 506: //(9F26)
            //APPL_CRYPTOGRAM
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setAPPL_CRYPTOGRAM(
               hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
            // }
         case 507: //(9F36)
            //APPL_TRAN_COUNTER
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setAPPL_TRAN_COUNTER(pTLV->sTokenValue, siWorkingLength);
            break;
         case 508: //(82  )
            //APPL_INTRCHG_PROF
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setAPPL_INTRCHG_PROF(pTLV->sTokenValue, siWorkingLength);
            break;
         case 509: //(91  )
            //ISS_AUTH_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 32 ? 32 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setISS_AUTH_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 510: //(71  )
            //ISS_SCRIPT1_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 255 ? 255 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setISS_SCRIPT1_DATA(
               hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 511: //(9F5B)
            //ISS_SCRIPT_RESULT
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 20 ? 20 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setISS_SCRIPT_RESULT(
               hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 512: //(9C  )
            //TRAN_TYPE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTRAN_TYPE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 513: //(9F1A)
            //TERM_COUNTRY_CODE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTERM_COUNTRY_CODE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 514: //(9A  )
            //TRAN_DATE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 6 ? 6 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTRAN_DATE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 515: //(9F02)
            //CRYPTOGRAM_AMOUNT
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 12 ? 12 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setCRYPTOGRAM_AMOUNT(pTLV->sTokenValue, siWorkingLength);
            break;
         case 516: //(5F2A)
            //TRAN_CURRENCY_CODE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTRAN_CURRENCY_CODE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 517: //(9F03)
            //AMOUNT_OTHER
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 12 ? 12 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            if (memcmp(pTLV->sTokenValue, "202020202020", siWorkingLength))
               m_pIntegratedCircuitCardSegment->setAMOUNT_OTHER(pTLV->sTokenValue, siWorkingLength);
            break;
         case 518: //(????)
            //COPAC_CCS_CRYPTO
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setCOPAC_CCS_CRYPTO(
               hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 519: //(9F27)
            //CRYPT_INFO_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setCRYPT_INFO_DATA(pTLV->sTokenValue, siWorkingLength);
            break;
         case 520: //(9F34)
            //CARDHLDR_INFO_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 6 ? 6 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setCARDH_VER_RESULT(pTLV->sTokenValue, siWorkingLength);
            break;
         case 521: //(9F35)
            //TERMINAL_TYPE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 2 ? 2 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTERMINAL_TYPE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 522: //(84  )
            //DEDICATED_FILE_NAM
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setDEDICATED_FILE_NAM(pTLV->sTokenValue, siWorkingLength);
            break;
         case 523: //(9F09)
            //APPL_VERSION_NO
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            if (memcmp(pTLV->sTokenValue, "2020", siWorkingLength))
               m_pIntegratedCircuitCardSegment->setAPPL_VERSION_NO(pTLV->sTokenValue, siWorkingLength);
            break;
         case 524: //(9F41)
            //TRAN_SEQ_COUNTER
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            if (memcmp(pTLV->sTokenValue, "20202020", siWorkingLength))
               m_pIntegratedCircuitCardSegment->setTRAN_SEQ_COUNTER(pTLV->sTokenValue, siWorkingLength);
            break;
         case 525: //(9F53)
            //TRAN_CATEGORY_CODE
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 1 ? 1 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setTRAN_CATEGORY_CODE(pTLV->sTokenValue, siWorkingLength);
            break;
         case 526: //(72  )
            //ISS_SCRIPT2_DATA
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 255 ? 255 : siTokenLength;
            m_pIntegratedCircuitCardSegment->setISS_SCRIPT2_DATA(hexToChar(pTLV->sTokenValue, siWorkingLength).c_str(), siWorkingLength * 2);
            break;
         case 527:
            //PAY_SENDER_NAME
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("N1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setPAY_SENDER_NAME((*pToken).second.c_str(),
                     (*pToken).second.length() > 41 ? 41 : (*pToken).second.length());
            }
            break;
         case 528:
            //PAY_RECEIVER_NAME
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_hTokenMap.erase(m_hTokenMap.begin(), m_hTokenMap.end());
            if (Token::parse(siTokenLength, string(pTLV->sTokenValue, siTokenLength), 1, m_hTokenMap))
            {
               map<string, string, less <string> >::iterator pToken = m_hTokenMap.find("N1");
               if (pToken != m_hTokenMap.end())
                  m_pFinancialUserSegment->setPAY_RECEIVER_NAME((*pToken).second.c_str(),
                     (*pToken).second.length() > 41 ? 41 : (*pToken).second.length());
            }
            break;
         case 555: // AID Value
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setAPPL_ID(pTLV->sTokenValue, siWorkingLength);
            break;
         case 560: //(9F06)
            //APPLICATION_IDENTIFIER
            if (strlen(m_pIntegratedCircuitCardSegment->zAPPL_ID()) == 0)
            {
               m_pIntegratedCircuitCardSegment->setPresence(true);
               siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pIntegratedCircuitCardSegment->setAPPL_ID(pTLV->sTokenValue, siWorkingLength);
            }
            break;
         case 580: //(9F6E)
            //FORM_FACTOR_IND
            m_pIntegratedCircuitCardSegment->setPresence(true);
            siWorkingLength = siTokenLength > 32 ? 32 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pIntegratedCircuitCardSegment->setFORM_FACTOR_IND(pTLV->sTokenValue, siWorkingLength);
            break;
         case 244:
         case 585:
            //NETWORK_PROGRAM
            siWorkingLength = siTokenLength > 10 ? 10 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setNETWORK_PROGRAM(pTLV->sTokenValue, siWorkingLength);
            break;
         case 246:
         case 587:
            //WEIGHTED_AVE_FLG
            siWorkingLength = siTokenLength > 1 ? 1 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setWEIGHTED_AVE_FLG(pTLV->sTokenValue, siWorkingLength);
            break;
         case 900:
            memcpy(sTRAN_DESC, m_pFinancialSettlementSegment->zTRAN_DESC(), 100);
            memcpy(sTRAN_UNIQUE_DATA, m_pFinancialSettlementSegment->zTRAN_UNIQUE_DATA(), 50);
            j = siTokenLength;
            pTLV_SUB = (hFinancialSeg24_TLV_SUB*)pTLV->sTokenValue;
            while (j > 0)
            {
               char sToken[4] = { "   " };
               memcpy(sToken, pTLV_SUB->sToken, 3);
               siToken = atoi(sToken);
               char sLen[4] = { "   " };
               memcpy(sLen, pTLV_SUB->sTokenLength, 3);
               k = atoi(sLen);
               switch (siToken)
               {
               case 1: // Product type
                  memcpy(sTRAN_UNIQUE_DATA + 4, pTLV_SUB->sTokenValue, k);
                  break;
               case 2: // Product ID
                  memcpy(sTRAN_UNIQUE_DATA + 6, pTLV_SUB->sTokenValue, k);
                  break;
               case 5: // Funds type
                  break;
               case 6: // Pre-Auth Flag
                  m_cPreAuthFlag = pTLV_SUB->sTokenValue[0];
                  break;
               case 7: // Pre Pay Account Number
                  memset(sTRAN_DESC + 19, ' ', 20);
                  memcpy(sTRAN_DESC + 19, pTLV_SUB->sTokenValue, k);
                  break;
               case 15: // Pre Pay Service Provider
                  break;
               }
               pTLV_SUB = (hFinancialSeg24_TLV_SUB*)((char*)pTLV_SUB + k + 6);
               j -= (k + 6);
            }
            m_pFinancialSettlementSegment->setTRAN_UNIQUE_DATA(sTRAN_UNIQUE_DATA, 50);
            m_pFinancialSettlementSegment->setTRAN_DESC(sTRAN_DESC, 100);
            break;
         case 901:
            memcpy(sTRAN_DESC, m_pFinancialSettlementSegment->zTRAN_DESC(), 100);
            j = siTokenLength;
            pTLV_SUB = (hFinancialSeg24_TLV_SUB*)pTLV->sTokenValue;
            while (j > 0)
            {
               char sToken[4] = { "   " };
               memcpy(sToken, pTLV_SUB->sToken, 3);
               siToken = atoi(sToken);
               char sLen[4] = { "   " };
               memcpy(sLen, pTLV_SUB->sTokenLength, 3);
               k = atoi(sLen);
               switch (siToken)
               {
               case 3: // Issuer Transaction ID
                  memset(sTRAN_DESC, ' ', 15);
                  memcpy(sTRAN_DESC, pTLV_SUB->sTokenValue, k);
                  break;
               }
               pTLV_SUB = (hFinancialSeg24_TLV_SUB*)((char*)pTLV_SUB + k + 6);
               j -= (k + 6);
            }
            m_pFinancialSettlementSegment->setTRAN_DESC(sTRAN_DESC, 100);
            break;
         case 980:
             siWorkingLength = siTokenLength > 10 ? 10 : siTokenLength;
             translate(pTLV->sTokenValue, siWorkingLength);
             m_pFinancialUserSegment->setWLT_ID(pTLV->sTokenValue, siWorkingLength);
             break;
         case 600:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBILLPAY_SUBNO(pTLV->sTokenValue, min(size_t(16), strlen(pTLV->sTokenValue)));
            }
            break;
         case 601:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBILLPAY_INSTCODE(pTLV->sTokenValue, min(size_t(4), strlen(pTLV->sTokenValue)));
            }
            break;
         case 602:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 19 ? 19 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setMCSETL_AMT(pTLV->sTokenValue, min(size_t(19), strlen(pTLV->sTokenValue)));
            }
            break;
         case 603:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 8 ? 8 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setMCSETL_RATE(pTLV->sTokenValue, min(size_t(8), strlen(pTLV->sTokenValue)));
            }
            break;
         case 604:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 19 ? 19 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setATMSAFE_AMT(pTLV->sTokenValue, min(size_t(19), strlen(pTLV->sTokenValue)));
            }
            break;
         case 605:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 4 ? 4 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setATMSAFE_DAYS(pTLV->sTokenValue, min(size_t(4), strlen(pTLV->sTokenValue)));
            }
            break;
         case 608:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 3 ? 3 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBANC_LENGTH(pTLV->sTokenValue, min(size_t(3), strlen(pTLV->sTokenValue)));
            }
            break;
         case 609:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 99 ? 99 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBANC_DATA(pTLV->sTokenValue, min(size_t(99), strlen(pTLV->sTokenValue)));
            }
            break;
         case 610:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 19 ? 19 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBANC_SETL_AMT(pTLV->sTokenValue, min(size_t(19), strlen(pTLV->sTokenValue)));
            }
            break;
         case 611:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 9 ? 9 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBANC_ACCFEE(pTLV->sTokenValue, min(size_t(9), strlen(pTLV->sTokenValue)));
            }
            break;
         case 612:
            if (Extract::instance()->getCustomCode() == "PNB")
            {
               m_pFinancialPNBSegment->setPresence(true);
               siWorkingLength = siTokenLength > 9 ? 9 : siTokenLength;
               translate(pTLV->sTokenValue, siWorkingLength);
               m_pFinancialPNBSegment->setBANC_CONVFEE(pTLV->sTokenValue, min(size_t(9), strlen(pTLV->sTokenValue)));
            }
            break;
         case 25010: //number is to be confirmed from switch team.
            if (m_bAsciiInput)
               translate(pTLV->sTokenValue, siTokenLength);
            m_pFinancialSettlementSegment->setBRIDGE_ACQ_FLG(&pTLV->sTokenValue[0], 1);
            m_pFinancialSettlementSegment->setBRIDGE_ISS_FLG(&pTLV->sTokenValue[1], 1);
            break;
         case 8952:
         {
            //TSP Req/Resp timestamps
            siWorkingLength = siTokenLength > 22 ? 22 : siTokenLength;
            if (siWorkingLength >= 12)
               m_pFinancialUserSegment->setTOKEN_REQ_TSTAMP(NonStopClock::getYYYYMMDDHHMMSShh(pTLV->sTokenValue + 6).data(), 16);
            if (siWorkingLength >= 18)
               m_pFinancialUserSegment->setTOKEN_RESP_TSTAMP(NonStopClock::getYYYYMMDDHHMMSShh(pTLV->sTokenValue + 12).data(), 16);
            char szTime[6] = { "00000" };
            DateTime hReqDateTime;
            DateTime hRespDateTime;
            hReqDateTime.setDateTime(m_pFinancialUserSegment->zTOKEN_REQ_TSTAMP());
            hRespDateTime.setDateTime(m_pFinancialUserSegment->zTOKEN_RESP_TSTAMP());
            snprintf(szTime, sizeof(szTime), "%05d", ((short)hRespDateTime.calcQueueTime(hReqDateTime)));
            m_pFinancialUserSegment->setTOKEN_TIME_AT_TSP(szTime, 5);
         }
         break;
         case 1002:
            //GMAS Merchant ID
            siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setGMAS_MERCH_ID(pTLV->sTokenValue, siWorkingLength);
            break;
         case 1003:
            //Merchant Scheme Number (MSN)
            siWorkingLength = siTokenLength > 16 ? 16 : siTokenLength;
            translate(pTLV->sTokenValue, siWorkingLength);
            m_pFinancialUserSegment->setMERCH_SCHEME_NUMBER(pTLV->sTokenValue, siWorkingLength);
            break;
         default:
            //ignore
            break;
         }
      }
      //bump to next token
      //note: siTokenLength does not include token or length field.
      //if siTokenLength is odd value then 1 slack byte is added
      pTLV = (hFinancialSeg24_TLV*)((char*)pTLV + siTokenLength + 4 + siTokenLength % 2);
   }
   m_pSegment24->setPresence(strSeg24Data.length() > 0);
   m_pSegment24->setDATA_BUFFER(strSeg24Data.c_str(),(strSeg24Data.length() < 16384) ? strSeg24Data.length() : 16384);
   string strUUID(m_pFinancialBaseSegment->zTRANSACTION_ID());
   strUUID.trim();
   if (strUUID.empty())
   {
      if (Extract::instance()->getCustomCode(1) == "TILL")
         reusable::UUID::get(strUUID);
      if (Extract::instance()->getCustomCode() == "CBA")
         strUUID.assign(36, '0');
      m_pFinancialBaseSegment->setTRANSACTION_ID(strUUID.data(), strUUID.length());
   }
   if (Extract::instance()->getCustomCode() == "CBA" && m_pFinancialUserSegment->zPYMT_ACCT_REF()[0] == '\0')
      m_pFinancialUserSegment->setPYMT_ACCT_REF(m_pFinancialBaseSegment->zRETRIEVAL_REF_NO(), 12);
   if (strADL_DATA_NATIONAL.length())
      m_pFinancialSettlementSegment->setADL_DATA_NATIONAL(strADL_DATA_NATIONAL.data(), strADL_DATA_NATIONAL.length());
  //## end AdvantageFinancial::mapSegment24%46356F2C0032.body
}

void AdvantageFinancial::translate (char* pBuffer, int ilen)
{
  //## begin AdvantageFinancial::translate%4635701F01A4.body preserve=yes
#ifdef MVS
   if (m_bAsciiInput)
      CodeTable::translate(pBuffer, ilen, CodeTable::CX_ASCII_TO_EBCDIC);
#else
   if (!m_bAsciiInput)
      CodeTable::translate(pBuffer, ilen, CodeTable::CX_EBCDIC_TO_ASCII);
#endif
  //## end AdvantageFinancial::translate%4635701F01A4.body
}

// Additional Declarations
  //## begin AdvantageFinancial%3C6131880148.declarations preserve=yes
  //## end AdvantageFinancial%3C6131880148.declarations

//## begin module%3C613642038A.epilog preserve=yes
//## end module%3C613642038A.epilog
